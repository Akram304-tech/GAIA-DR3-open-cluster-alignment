#!/usr/bin/env python
from pathlib import Path
import json, re, sys

if len(sys.argv)!=2:
    raise SystemExit("Usage: python tools/set_zenodo_doi.py 10.5281/zenodo.XXXXXXX")
doi=sys.argv[1].strip()
if not re.fullmatch(r"10\.5281/zenodo\.\d+",doi):
    raise SystemExit("Expected a reserved Zenodo DOI such as 10.5281/zenodo.12345678")
root=Path(__file__).resolve().parents[1]

p=root/"metadata/zenodo_deposit_metadata.json"
x=json.loads(p.read_text(encoding="utf-8")); x["doi"]=doi
p.write_text(json.dumps(x,indent=2)+"\n",encoding="utf-8")

p=root/"metadata/codemeta.json"
x=json.loads(p.read_text(encoding="utf-8")); x["identifier"]=doi
p.write_text(json.dumps(x,indent=2)+"\n",encoding="utf-8")

p=root/"metadata/CITATION.cff"
s=p.read_text(encoding="utf-8")
s=s.replace('repository-code: "DOI_TO_BE_ADDED_AFTER_ZENODO_RESERVATION"',f'doi: "{doi}"')
p.write_text(s,encoding="utf-8")

print("DOI metadata updated:",doi)
print("Rebuild MANIFEST.csv and SHA256SUMS.txt before upload.")

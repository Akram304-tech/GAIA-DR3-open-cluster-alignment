#!/usr/bin/env python
from pathlib import Path
import csv, hashlib

root=Path(__file__).resolve().parents[1]
manifest=root/"MANIFEST.csv"
problems=[]
with manifest.open(newline="",encoding="utf-8") as f:
    rows=list(csv.DictReader(f))
for row in rows:
    p=root/row["path"]
    if not p.exists():
        problems.append((row["path"],"missing"))
        continue
    h=hashlib.sha256(p.read_bytes()).hexdigest()
    if h!=row["sha256"]:
        problems.append((row["path"],"sha256 mismatch"))

forbidden=[]
for p in root.rglob("*"):
    if not p.is_file(): continue
    rel=p.relative_to(root).as_posix().lower()
    if rel in {"main.pdf","main.tex","main_portable.tex","references.bib"} or rel.endswith(".tex") or rel.endswith(".bib"):
        forbidden.append(rel)

if problems or forbidden:
    print("VERIFY_PACKAGE_PASS=False")
    if problems: print("Problems:",problems[:20])
    if forbidden: print("Forbidden manuscript files:",sorted(set(forbidden)))
    raise SystemExit(1)
print("VERIFY_PACKAGE_PASS=True")
print("Files checked:",len(rows))

function ymc_apply_style(ax)
% YMC_APPLY_STYLE  Common journal-style formatting for YHMC figures.
%
% The manuscript uses Computer-Modern-like serif typography. MATLAB does not
% ship a universal Computer Modern font on all systems, so this helper uses
% CMU Serif when available and otherwise falls back to Times New Roman.
%
% Usage:
%   ymc_apply_style(gca)

    fonts = listfonts;
    if any(strcmpi(fonts,'CMU Serif'))
        f = 'CMU Serif';
    elseif any(strcmpi(fonts,'Computer Modern Roman'))
        f = 'Computer Modern Roman';
    else
        f = 'Times New Roman';
    end

    set(ax, ...
        'FontName', f, ...
        'FontSize', 12, ...
        'LineWidth', 1.0, ...
        'Box', 'on', ...
        'TickDir', 'out', ...
        'Layer', 'top');

    ax.XLabel.FontName = f;
    ax.YLabel.FontName = f;
    ax.XLabel.FontSize = 14;
    ax.YLabel.FontSize = 14;

    if ~isempty(ax.Title)
        ax.Title.FontName = f;
    end

    grid(ax,'on');
    ax.GridAlpha = 0.14;
    ax.MinorGridAlpha = 0.08;
end

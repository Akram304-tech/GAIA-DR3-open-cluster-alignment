%% FIGURE 6 — Membership-threshold robustness
% Final manuscript Fig. 6.
% Internal title removed.
% Legend ("agenda") is moved ONLY in this figure to the lower-left corner.

clear; close all; clc;

P = [0.5 0.7 0.8 0.9];

Ay = [0.6388 0.6100 0.5885 0.6110];
Ny = [95 69 66 45];

Ac = [0.8440 0.8683 0.8820 0.9135];
Nc = [95 52 38 20];

fig = figure('Color','w','Units','centimeters','Position',[2 2 17 13.5]);
ax = axes(fig); hold(ax,'on');

plot(ax,P,Ay,'-o','LineWidth',1.7,'MarkerSize',7,'DisplayName','Young');
plot(ax,P,Ac,'-s','LineWidth',1.7,'MarkerSize',7,'DisplayName','Older controls');

% Keep manuscript annotation placement; only legend is intentionally moved.
text(ax,0.475,0.585,'N = 95','FontSize',12.2);
text(ax,0.685,0.525,'N = 69','FontSize',12.2);
text(ax,0.775,0.515,'N = 66','FontSize',12.2);
text(ax,0.855,0.675,'N = 45','FontSize',12.2);

text(ax,0.510,0.900,'N = 95','FontSize',12.2);
text(ax,0.695,0.820,'N = 52','FontSize',12.2);
text(ax,0.785,0.820,'N = 38','FontSize',12.2);
text(ax,0.855,0.825,'N = 20','FontSize',12.2);

yline(ax,0,'--','LineWidth',1.1);

xlim(ax,[0.48 0.925]);
ylim(ax,[-0.02 1.02]);

xlabel(ax,'Minimum membership probability');
ylabel(ax,'A','Interpreter','tex');

% User-requested change: ONLY Fig. 6 legend goes to lower-left.
legend(ax,'Location','southwest','Box','off');

ymc_apply_style(ax);

exportgraphics(fig,'fig06_membership_robustness_matlab.pdf','ContentType','vector');
exportgraphics(fig,'fig06_membership_robustness_matlab.png','Resolution',600);

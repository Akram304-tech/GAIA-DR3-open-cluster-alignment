%% FIGURE 2 — Outer Galactic-plane alignment
% Final manuscript Fig. 2.
% Internal title removed.
% Only this figure has manually de-conflicted N labels.

clear; close all; clc;

M = [1000 3000 5000];

% Young sample
Ay   = [0.6388 0.7696 0.8259];
Ylo  = [0.5882 0.7090 0.7433];
Yhi  = [0.6890 0.8301 0.9100];
Ny   = [95 22 8];

% Older controls
Ac   = [0.8440 0.8970 0.9576];
Clo  = [0.8138 0.8454 0.9437];
Chi  = [0.8743 0.9492 0.9715];
Nc   = [95 23 7];

xoff = 105;

fig = figure('Color','w','Units','centimeters','Position',[2 2 17.5 14]);
ax = axes(fig); hold(ax,'on');

errorbar(ax,M-xoff,Ay,Ay-Ylo,Yhi-Ay,'o', ...
    'LineWidth',1.7,'MarkerSize',7,'CapSize',8, ...
    'DisplayName','Young');

errorbar(ax,M+xoff,Ac,Ac-Clo,Chi-Ac,'s', ...
    'LineWidth',1.7,'MarkerSize',7,'CapSize',8, ...
    'DisplayName','Older controls');

yline(ax,0,'--','LineWidth',1.1);

% Final manuscript label positions — deliberately separated.
posY = [ ...
     720 0.585; ...
    1950 0.690; ...
    4490 0.725];

posC = [ ...
    1100 0.890; ...
    3250 0.985; ...
    4890 1.005];

for k = 1:3
    text(ax,posY(k,1),posY(k,2),sprintf('N = %d',Ny(k)), ...
        'FontSize',12.5,'Interpreter','tex');
    text(ax,posC(k,1),posC(k,2),sprintf('N = %d',Nc(k)), ...
        'FontSize',12.5,'Interpreter','tex');
end

xlim(ax,[650 5450]);
ylim(ax,[-0.02 1.055]);
xticks(ax,M);

xlabel(ax,'M_J threshold [M_\odot]','Interpreter','tex');
ylabel(ax,'A = <cos(2\Delta\theta)>','Interpreter','tex');

legend(ax,'Location','south','Box','off');

ymc_apply_style(ax);

exportgraphics(fig,'fig02_outer_alignment_matlab.pdf','ContentType','vector');
exportgraphics(fig,'fig02_outer_alignment_matlab.png','Resolution',600);

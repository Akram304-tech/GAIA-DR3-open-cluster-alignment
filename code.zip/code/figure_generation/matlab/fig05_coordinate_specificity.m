%% FIGURE 5 — Coordinate-reference specificity
% Final manuscript Fig. 5.
% Internal title removed. Legend placement otherwise unchanged.

clear; close all; clc;

x = [1 2 3];
off = 0.16;

% Observed Galactic / ecliptic / equatorial values
Ay = [0.638833  0.070996 -0.060019];
Ac = [0.844003 -0.085464 -0.034945];

% 95% intervals
Ylo = [0.528783 -0.068681 -0.189025];
Yhi = [0.738092  0.209488  0.070283];
Clo = [0.779927 -0.204039 -0.164304];
Chi = [0.896910  0.035895  0.094713];

% Geometry expectations for non-Galactic references
Ey = [NaN -0.004125 0.009578];
Ec = [NaN -0.007553 0.023032];

Eylo = [NaN -0.114222 -0.095802];
Eyhi = [NaN  0.105024  0.114520];
Eclo = [NaN -0.084942 -0.053609];
Echi = [NaN  0.069513  0.099000];

fig = figure('Color','w','Units','centimeters','Position',[2 2 17.2 13.5]);
ax = axes(fig); hold(ax,'on');

errorbar(ax,x-off,Ay,Ay-Ylo,Yhi-Ay,'o', ...
    'LineWidth',1.7,'MarkerSize',7,'CapSize',8, ...
    'DisplayName','Young observed');

errorbar(ax,x+off,Ac,Ac-Clo,Chi-Ac,'s', ...
    'LineWidth',1.7,'MarkerSize',7,'CapSize',8, ...
    'DisplayName','Control observed');

for k = 2:3
    errorbar(ax,k-off,Ey(k),Ey(k)-Eylo(k),Eyhi(k)-Ey(k),'d', ...
        'LineWidth',1.2,'MarkerSize',6,'CapSize',6, ...
        'MarkerFaceColor','w','MarkerEdgeColor','k', ...
        'Color',[0.35 0.35 0.35], ...
        'HandleVisibility', ternary(k==2,'on','off'));

    errorbar(ax,k+off,Ec(k),Ec(k)-Eclo(k),Echi(k)-Ec(k),'d', ...
        'LineWidth',1.2,'MarkerSize',6,'CapSize',6, ...
        'MarkerFaceColor','w','MarkerEdgeColor','k', ...
        'Color',[0.35 0.35 0.35], ...
        'HandleVisibility','off');
end

% Dummy handle for legend label of geometry expectation
plot(ax,nan,nan,'d','MarkerFaceColor','w','MarkerEdgeColor','k', ...
    'Color',[0.35 0.35 0.35],'DisplayName','Geometry expectation');

yline(ax,0,'--','LineWidth',1.1);

xticks(ax,x);
xticklabels(ax,{'Galactic','Ecliptic','Equatorial EW'});
ylabel(ax,'A','Interpreter','tex');
ylim(ax,[-0.28 1.04]);

legend(ax,'Location','northeast','Box','off');

ymc_apply_style(ax);

exportgraphics(fig,'fig05_coordinate_specificity_matlab.pdf','ContentType','vector');
exportgraphics(fig,'fig05_coordinate_specificity_matlab.png','Resolution',600);

function out = ternary(cond,a,b)
    if cond
        out = a;
    else
        out = b;
    end
end

%% FIGURE 3 — Latitude-stratified alignment
% Final manuscript Fig. 3.
% Internal title removed.
% Only this figure has manually de-conflicted N labels.

clear; close all; clc;

x = [1 2 3];

% Young
Ay  = [0.695789 0.593750 0.600940];
Ylo = [0.544741 0.390715 0.390416];
Yhi = [0.819208 0.771007 0.783160];
Ny  = [40 27 28];

% Older controls
Ac  = [0.764502 0.855350 0.886847];
Clo = [0.559030 0.758078 0.843863];
Chi = [0.920027 0.929114 0.925504];
Nc  = [24 36 35];

off = 0.12;

fig = figure('Color','w','Units','centimeters','Position',[2 2 16.5 14]);
ax = axes(fig); hold(ax,'on');

errorbar(ax,x-off,Ay,Ay-Ylo,Yhi-Ay,'o', ...
    'LineWidth',1.7,'MarkerSize',7,'CapSize',8, ...
    'DisplayName','Young');

errorbar(ax,x+off,Ac,Ac-Clo,Chi-Ac,'s', ...
    'LineWidth',1.7,'MarkerSize',7,'CapSize',8, ...
    'DisplayName','Older controls');

% Final non-overlapping N-label positions
pos = struct;
pos.yLow  = [0.61 0.610];
pos.cLow  = [1.19 0.830];
pos.yMid  = [1.56 0.505];
pos.cMid  = [2.17 0.925];
pos.yHigh = [2.57 0.505];
pos.cHigh = [2.80 0.955];

text(ax,pos.yLow(1), pos.yLow(2), sprintf('N = %d',Ny(1)),'FontSize',12.2);
text(ax,pos.cLow(1), pos.cLow(2), sprintf('N = %d',Nc(1)),'FontSize',12.2);
text(ax,pos.yMid(1), pos.yMid(2), sprintf('N = %d',Ny(2)),'FontSize',12.2);
text(ax,pos.cMid(1), pos.cMid(2), sprintf('N = %d',Nc(2)),'FontSize',12.2);
text(ax,pos.yHigh(1),pos.yHigh(2),sprintf('N = %d',Ny(3)),'FontSize',12.2);
text(ax,pos.cHigh(1),pos.cHigh(2),sprintf('N = %d',Nc(3)),'FontSize',12.2);

xlim(ax,[0.55 3.40]);
ylim(ax,[0.25 1.02]);
xticks(ax,x);
xticklabels(ax,{'Low','Mid','High'});

xlabel(ax,'Common |b| tercile','Interpreter','tex');
ylabel(ax,'A = <cos(2\Delta\theta)>','Interpreter','tex');

legend(ax,'Location','southeast','Box','off');

ymc_apply_style(ax);

exportgraphics(fig,'fig03_latitude_sensitivity_matlab.pdf','ContentType','vector');
exportgraphics(fig,'fig03_latitude_sensitivity_matlab.png','Resolution',600);

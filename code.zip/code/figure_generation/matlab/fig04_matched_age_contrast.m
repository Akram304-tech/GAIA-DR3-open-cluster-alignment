%% FIGURE 4 — Matched age contrast
% Final manuscript Fig. 4.
% Internal title removed. No additional redesign beyond title removal.

clear; close all; clc;

D  = [-0.105883 -0.188067];
lo = [-0.283459 -0.312300];
hi = [ 0.125674 -0.066900];
N  = [19 71];

x = [1 2];

fig = figure('Color','w','Units','centimeters','Position',[2 2 16.5 13.5]);
ax = axes(fig); hold(ax,'on');

errorbar(ax,x,D,D-lo,hi-D,'o', ...
    'LineWidth',1.7,'MarkerSize',7,'CapSize',8);

yline(ax,0,'--','LineWidth',1.1);

text(ax,1.08,-0.060,sprintf('N = %d',N(1)),'FontSize',12.2);
text(ax,1.77,-0.145,sprintf('N = %d',N(2)),'FontSize',12.2);

xlim(ax,[0.75 2.25]);
ylim(ax,[-0.36 0.18]);
xticks(ax,x);
xticklabels(ax,{'Primary high-mass','Extended secondary'});

ylabel(ax,'D = A_{young} - A_{control}','Interpreter','tex');

ymc_apply_style(ax);

exportgraphics(fig,'fig04_matched_age_contrast_matlab.pdf','ContentType','vector');
exportgraphics(fig,'fig04_matched_age_contrast_matlab.png','Resolution',600);

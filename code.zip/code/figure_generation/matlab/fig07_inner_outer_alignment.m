%% FIGURE 7 — Inner versus outer alignment
% Final manuscript Fig. 7.
% Internal title removed.
% IMPORTANT: legend remains in the original upper-left position.

clear; close all; clc;

labels = {'Young','Older controls'};
Aouter = [0.5809 0.8881];
Ainner = [0.4862 0.9180];
N      = [10 6];
R      = [0.0947 -0.0298];

x = [1 2];
w = 0.31;

fig = figure('Color','w','Units','centimeters','Position',[2 2 14.5 12]);
ax = axes(fig); hold(ax,'on');

b1 = bar(ax,x-w/2,Aouter,w,'DisplayName','Outer');
b2 = bar(ax,x+w/2,Ainner,w,'DisplayName','Inner r < r_{50,J}');

yline(ax,0,'--','LineWidth',1.0);

text(ax,1,max(Aouter(1),Ainner(1))+0.035, ...
    sprintf('N = %d\\nR = %+0.3f',N(1),R(1)), ...
    'HorizontalAlignment','center','FontSize',11.2);

text(ax,2,max(Aouter(2),Ainner(2))+0.035, ...
    sprintf('N = %d\\nR = %+0.3f',N(2),R(2)), ...
    'HorizontalAlignment','center','FontSize',11.2);

xticks(ax,x);
xticklabels(ax,labels);
ylabel(ax,'A','Interpreter','tex');
ylim(ax,[-0.02 1.08]);

% Deliberately unchanged from manuscript request:
legend(ax,'Location','northwest','Box','off');

ymc_apply_style(ax);

exportgraphics(fig,'fig07_inner_outer_alignment_matlab.pdf','ContentType','vector');
exportgraphics(fig,'fig07_inner_outer_alignment_matlab.png','Resolution',600);

YHMC MATLAB figure codes v2.3.1
================================

These scripts reproduce the seven figures in the final strict-figure-edit
manuscript version.

Figure mapping
--------------
fig01_workflow.m                 -> manuscript Fig. 1
fig02_outer_alignment.m          -> manuscript Fig. 2
fig03_latitude_sensitivity.m     -> manuscript Fig. 3
fig04_matched_age_contrast.m     -> manuscript Fig. 4
fig05_coordinate_specificity.m   -> manuscript Fig. 5
fig06_membership_robustness.m    -> manuscript Fig. 6
fig07_inner_outer_alignment.m    -> manuscript Fig. 7

Style helper
------------
ymc_apply_style.m

Output
------
Each script writes:
  *_matlab.pdf   vector PDF
  *_matlab.png   600 dpi preview

Important user-requested final edits preserved
----------------------------------------------
- All figure-internal titles are absent.
- Fig. 1 has no bottom internal explanatory note.
- Only Figs. 2 and 3 use aggressively hand-positioned N annotations.
- Only Fig. 6 moves the legend to the lower-left corner.
- Fig. 7 keeps its legend in the upper-left.

MATLAB version
--------------
Recommended: MATLAB R2020a or later, because exportgraphics is used.

Fonts
-----
ymc_apply_style.m prefers:
  1. CMU Serif
  2. Computer Modern Roman
  3. Times New Roman fallback

The scripts are self-contained and use the numerical values already reported
in the manuscript / machine-readable tables.

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-7F v3.0.0
Block-exact / BCa / continuity-correction / cluster-robust latitude audit.

Post-unblind reviewer sensitivity analysis.
No sample threshold, morphology gate, control assignment, or primary endpoint changes.
"""

from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import norm
import statsmodels.api as sm

VERSION="3.0.0"
SEED=20261028
NBOOT=200000
K=4.74047

YHASH="cc1d3ae4ce1cf52387f535da92fbd0dc5d984a3bb2dc750bf6672682e85f65dd"
CHASH="124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd"

RULES=[
    ("tight_50pc_5kms",50.0,5.0),
    ("central_100pc_10kms",100.0,10.0),
    ("loose_150pc_15kms",150.0,15.0),
    ("very_loose_250pc_20kms",250.0,20.0),
]

def sha(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1<<20),b""):
            h.update(b)
    return h.hexdigest()

def axial(a,b):
    return ((np.asarray(a,float)-np.asarray(b,float)+90.0)%180.0)-90.0

class UF:
    def __init__(self,n):
        self.p=list(range(n)); self.s=[1]*n
    def f(self,x):
        while self.p[x]!=x:
            self.p[x]=self.p[self.p[x]]
            x=self.p[x]
        return x
    def u(self,a,b):
        a,b=self.f(a),self.f(b)
        if a==b:return
        if self.s[a]<self.s[b]:a,b=b,a
        self.p[b]=a; self.s[a]+=self.s[b]

def source_geom(master,df):
    ids=df.ID.astype(int).tolist()
    m=master[master.ID.isin(ids)].copy().drop_duplicates("ID").set_index("ID").loc[ids].reset_index()
    def first(cs): return next((c for c in cs if c in m.columns),None)
    ra=first(["__RAdeg","RA_ICRS","RAdeg"])
    de=first(["__DEdeg","DE_ICRS","DEdeg"])
    pr=first(["pmRA","pmra"])
    pdm=first(["pmDE","pmdec"])
    dist=first(["dist50","Dist50","distance"])
    if not all([ra,de,pr,pdm,dist]):
        raise RuntimeError(f"geometry columns missing: RA={ra}, DE={de}, pmRA={pr}, pmDE={pdm}, dist={dist}")
    for c in [ra,de,pr,pdm,dist]:
        m[c]=pd.to_numeric(m[c],errors="coerce")
    a=np.deg2rad(m[ra].to_numpy(float))
    d=np.deg2rad(m[de].to_numpy(float))
    r=m[dist].to_numpy(float)
    rh=np.c_[np.cos(d)*np.cos(a),np.cos(d)*np.sin(a),np.sin(d)]
    ea=np.c_[-np.sin(a),np.cos(a),np.zeros(len(a))]
    ed=np.c_[-np.sin(d)*np.cos(a),-np.sin(d)*np.sin(a),np.cos(d)]
    xyz=r[:,None]*rh
    vt=K*(r/1000.0)[:,None]*(m[pr].to_numpy(float)[:,None]*ea+m[pdm].to_numpy(float)[:,None]*ed)
    return xyz,vt

def joint_labels(master,union,L,V):
    xyz,vt=source_geom(master,union)
    n=len(union); uf=UF(n)
    for i in range(n):
        ds=np.sqrt(((xyz[i+1:]-xyz[i])**2).sum(1))
        dv=np.sqrt(((vt[i+1:]-vt[i])**2).sum(1))
        for j in np.where((ds<=L)&(dv<=V))[0]+i+1:
            uf.u(i,int(j))
    roots=[uf.f(i) for i in range(n)]
    mp={r:k for k,r in enumerate(sorted(set(roots)))}
    return np.array([mp[r] for r in roots],int)

def anchor_meta_labels(AN,CF,CA,union,idlab):
    assmap=CF[["ID","young_ID"]].copy().rename(columns={"ID":"control_ID"})
    ca_ids=set(CA.ID.astype(int))
    assmap=assmap[assmap.control_ID.astype(int).isin(ca_ids)]
    aa=AN.copy().reset_index(drop=True)
    uf=UF(len(aa)); comp_to_anchors={}
    for i,r in aa.iterrows():
        aset={idlab.get(int(r.young_ID))}
        ctr=assmap[assmap.young_ID.astype(int)==int(r.young_ID)].control_ID.astype(int).tolist()
        aset |= {idlab.get(c) for c in ctr}
        aset.discard(None)
        for c in aset:
            comp_to_anchors.setdefault(c,[]).append(i)
    for inds in comp_to_anchors.values():
        for j in inds[1:]:
            uf.u(inds[0],j)
    roots=[uf.f(i) for i in range(len(aa))]
    mp={r:i for i,r in enumerate(sorted(set(roots)))}
    return np.array([mp[r] for r in roots],int)

def block_components(y,lab):
    y=np.asarray(y,float); lab=np.asarray(lab,int)
    ub=np.unique(lab)
    groups=[np.where(lab==b)[0] for b in ub]
    sums=np.array([np.sum(y[g]) for g in groups],float)
    sizes=np.array([len(g) for g in groups],int)
    return ub,groups,sums,sizes

def bootstrap_block_distribution(sums,sizes,tag):
    B=len(sums)
    rng=np.random.default_rng(np.random.SeedSequence([SEED,tag]))
    z=np.empty(NBOOT,float)
    for lo in range(0,NBOOT,10000):
        m=min(10000,NBOOT-lo)
        ix=rng.integers(0,B,size=(m,B))
        z[lo:lo+m]=sums[ix].sum(1)/sizes[ix].sum(1)
    return z

def bca_ci(obs,boot,jack,alpha=(0.025,0.975)):
    boot=np.asarray(boot,float); jack=np.asarray(jack,float)
    # midrank treatment for equality stabilizes z0 in discrete block bootstraps
    prop=(np.sum(boot<obs)+0.5*np.sum(boot==obs))/len(boot)
    prop=np.clip(prop,1/(2*len(boot)),1-1/(2*len(boot)))
    z0=norm.ppf(prop)
    jm=np.mean(jack)
    dif=jm-jack
    den=6.0*(np.sum(dif*dif)**1.5)
    acc=float(np.sum(dif**3)/den) if den>0 else 0.0
    out=[]
    for a in alpha:
        za=norm.ppf(a)
        adj=norm.cdf(z0+(z0+za)/(1-acc*(z0+za)))
        adj=float(np.clip(adj,0,1))
        out.append(float(np.quantile(boot,adj)))
    return out[0],out[1],float(z0),float(acc)

def exact_signflip(sums,N,obs):
    B=len(sums)
    if B>22:
        raise RuntimeError(f"Exact sign flip requested for B={B}>22")
    nstate=1<<B
    vals=np.empty(nstate,float)
    # chunk over bit patterns
    idx=0
    for lo in range(0,nstate,131072):
        hi=min(nstate,lo+131072)
        nums=np.arange(lo,hi,dtype=np.uint64)
        sg=np.empty((hi-lo,B),float)
        for b in range(B):
            sg[:,b]=np.where(((nums>>b)&1)==1,1.0,-1.0)
        vals[idx:idx+(hi-lo)]=(sg*sums[None,:]).sum(1)/N
        idx += hi-lo
    pone=float(np.mean(vals>=obs))
    ptwo=float(np.mean(np.abs(vals)>=abs(obs)))
    pmin=float(2.0/nstate) if nstate>1 else 1.0
    return pone,ptwo,pmin,nstate

def block_inference(y,lab,tag,dmax):
    y=np.asarray(y,float); lab=np.asarray(lab,int)
    ub,groups,sums,sizes=block_components(y,lab)
    N=len(y); obs=float(np.mean(y))
    boot=bootstrap_block_distribution(sums,sizes,tag)
    pctlo,pcthi=np.quantile(boot,[0.025,0.975])
    jack=[]
    for s,n in zip(sums,sizes):
        if N-n>0:
            jack.append((np.sum(sums)-s)/(N-n))
    jack=np.asarray(jack,float)
    bcalo,bcahi,z0,acc=bca_ci(obs,boot,jack)
    pone,ptwo,pmin,nstate=exact_signflip(sums,N,obs)
    lobo_lo=float(np.min(jack)); lobo_hi=float(np.max(jack))
    return dict(
        N=N,N_blocks=len(ub),N_multiblocks=int(sum(len(g)>1 for g in groups)),
        max_block_size=int(max(map(len,groups))),
        D=float(obs),
        percentile_lo95=float(pctlo),percentile_hi95=float(pcthi),
        BCa_lo95=float(bcalo),BCa_hi95=float(bcahi),
        BCa_z0=z0,BCa_acceleration=acc,
        exact_signflip_p_one_D_gt0=pone,exact_signflip_p_two=ptwo,
        exact_states=nstate,min_attainable_two_sided_p=pmin,
        LOBO_min_D=lobo_lo,LOBO_max_D=lobo_hi,
        LOBO_max_abs_shift=float(np.max(np.abs(jack-obs))),
        Dmax_positive=float(dmax),
        BCa_upper_as_fraction_of_Dmax=float(bcahi/dmax) if dmax>0 else np.nan,
    )

def haldane_logodds(ky,ny,kc,nc):
    # Haldane-Anscombe: add 0.5 to all four cells.
    return float(np.log((ky+0.5)/(ny-ky+0.5))-np.log((kc+0.5)/(nc-kc+0.5)))

def primary_binary_metrics(YA,CA,CF):
    y=YA[["ID","Name","MassJ","cos2Delta"]].copy()
    y=y[pd.to_numeric(y.MassJ,errors="coerce")>=3000]
    y["young_ID"]=y.ID.astype(int)
    y["young_Name"]=y.Name.astype(str)
    y["young_success"]=(pd.to_numeric(y.cos2Delta,errors="coerce")>=0.5).astype(int)  # |Delta|<=30 deg iff cos(2Delta)>=0.5

    c=CA[["ID","Name","cos2Delta_control"]].copy()
    c["control_ID"]=c.ID.astype(int); c["control_Name"]=c.Name.astype(str)
    c["control_success"]=(pd.to_numeric(c.cos2Delta_control,errors="coerce")>=0.5).astype(int)

    ass=CF[["ID","Name","young_ID","young_Name"]].copy().rename(columns={"ID":"control_ID","Name":"control_Name"})
    q=ass.merge(c[["control_ID","control_Name","control_success"]],on=["control_ID","control_Name"],how="inner")
    q=q.merge(y[["young_ID","young_Name","young_success"]],on=["young_ID","young_Name"],how="inner")
    if q.empty:
        raise RuntimeError("No primary matched rows for binary sensitivity")

    anchors=[]
    for (aid,aname),g in q.groupby(["young_ID","young_Name"]):
        anchors.append(dict(
            young_ID=int(aid),young_Name=str(aname),
            young_success=int(g.young_success.iloc[0]),
            n_control=int(len(g)),
            k_control=int(g.control_success.sum()),
            control_success_mean=float(g.control_success.mean()),
        ))
    a=pd.DataFrame(anchors)
    ny=len(a); ky=int(a.young_success.sum())
    nc=int(a.n_control.sum()); kc=int(a.k_control.sum())
    lod_ha=haldane_logodds(ky,ny,kc,nc)
    # Uncorrected value is explicitly infinite/undefined when a cell is zero.
    def raw_lod():
        cells=[ky,ny-ky,kc,nc-kc]
        if any(x==0 for x in cells):
            return np.nan
        return float(np.log(ky/(ny-ky))-np.log(kc/(nc-kc)))
    raw=raw_lod()
    dp=float(np.mean(a.young_success-a.control_success_mean))

    rng=np.random.default_rng(np.random.SeedSequence([SEED,700]))
    b_lod=np.empty(NBOOT,float); b_dp=np.empty(NBOOT,float)
    n=len(a)
    for lo in range(0,NBOOT,10000):
        m=min(10000,NBOOT-lo)
        ix=rng.integers(0,n,size=(m,n))
        ys=a.young_success.to_numpy(int)[ix]
        nk=a.n_control.to_numpy(int)[ix]
        kk=a.k_control.to_numpy(int)[ix]
        KY=ys.sum(1); NY=np.full(m,n,int)
        KC=kk.sum(1); NC=nk.sum(1)
        b_lod[lo:lo+m]=np.log((KY+0.5)/(NY-KY+0.5))-np.log((KC+0.5)/(NC-KC+0.5))
        b_dp[lo:lo+m]=(ys-kk/np.maximum(nk,1)).mean(1)

    result=pd.DataFrame([dict(
        N_anchor=n,young_k=ky,young_n=ny,control_k=kc,control_n=nc,
        zero_cell_present=bool(any(x==0 for x in [ky,ny-ky,kc,nc-kc])),
        logodds_raw_uncorrected=raw,
        logodds_Haldane_Anscombe=lod_ha,
        logodds_HA_lo95=float(np.quantile(b_lod,0.025)),
        logodds_HA_hi95=float(np.quantile(b_lod,0.975)),
        matched_anchor_proportion_difference=dp,
        matched_anchor_prop_diff_lo95=float(np.quantile(b_dp,0.025)),
        matched_anchor_prop_diff_hi95=float(np.quantile(b_dp,0.975)),
        definition="young minus control; positive means stronger young concentration within 30 deg",
        correction="Haldane-Anscombe +0.5 to all four cluster-level 2x2 cells; bootstrap resamples matched young anchors with their assigned controls",
    )])
    return a,result

def cluster_robust_latitude(master,AN,CF,CA,union,idlab,alab,common_cut1):
    mm=master[["ID","Name","GLAT"]].drop_duplicates(["ID","Name"])
    yb=mm.rename(columns={"ID":"young_ID","Name":"young_Name","GLAT":"young_GLAT"})
    an=AN.merge(yb,on=["young_ID","young_Name"],how="left").reset_index(drop=True)
    an["D"]=pd.to_numeric(an.D_i_young_minus_control,errors="coerce")
    an["absb"]=pd.to_numeric(an.young_GLAT,errors="coerce").abs()
    an["block"]=alab
    z=an[["D","absb","block"]].replace([np.inf,-np.inf],np.nan).dropna().copy()
    z["z_absb"]=(z.absb-z.absb.mean())/z.absb.std(ddof=1)
    z["mid_or_high"]=(z.absb>common_cut1).astype(float)

    def fit_cluster(xcol):
        X=sm.add_constant(z[[xcol]],has_constant="add")
        mod=sm.OLS(z.D,X).fit(cov_type="cluster",cov_kwds={"groups":z.block,"use_correction":True})
        ci=mod.conf_int().loc[xcol]
        return dict(
            term=xcol,N=len(z),N_blocks=int(z.block.nunique()),
            coef=float(mod.params[xcol]),se_cluster=float(mod.bse[xcol]),
            p_cluster=float(mod.pvalues[xcol]),ci95_lo=float(ci.iloc[0]),ci95_hi=float(ci.iloc[1]),
        )

    r1=fit_cluster("z_absb")
    r2=fit_cluster("mid_or_high")
    low=z[z.mid_or_high==0].D
    mh=z[z.mid_or_high==1].D
    r2.update(
        D_low=float(low.mean()),N_low=len(low),
        D_mid_high=float(mh.mean()),N_mid_high=len(mh),
        interpretation="coef = D(mid+high) - D(low); negative means more negative age contrast above the low-|b| bin",
    )
    return pd.DataFrame([r1,r2]),z

def main():
    ap=argparse.ArgumentParser()
    for x in ["stage0","stage1b","stage1c","stage2c","stage2d"]:
        ap.add_argument("--"+x,required=True)
    ap.add_argument("--out",default="STAGE7F_OUTPUT")
    a=ap.parse_args()
    out=Path(a.out).resolve(); out.mkdir(parents=True,exist_ok=True)
    s0,s1b,s1c,s2c,s2d=map(Path,[a.stage0,a.stage1b,a.stage1c,a.stage2c,a.stage2d])

    yf=s1b/"02_PRIMARY_PA_SAMPLE_FROZEN.csv"
    cf=s2c/"02_CONTROL_PA_SAMPLE_FROZEN.csv"
    if sha(yf)!=YHASH or sha(cf)!=CHASH:
        raise RuntimeError("historical identity gate failed")

    M=pd.read_csv(s0/"01_cluster_master_raw.csv")
    YA=pd.read_csv(s1c/"01_alignment_cluster_table_UNBLINDED.csv")
    CA=pd.read_csv(s2d/"01_control_alignment_UNBLINDED.csv")
    CF=pd.read_csv(cf)
    AN=pd.read_csv(s2d/"03_anchor_normalized_young_control_table.csv")
    for d in [M,YA,CA,CF,AN]:
        if "ID" in d.columns:
            d["ID"]=pd.to_numeric(d.ID,errors="coerce")

    # Ceiling value from the actual primary anchor table.
    pri=AN[pd.to_numeric(AN.MassJ_young,errors="coerce")>=3000].copy()
    D=float(pd.to_numeric(pri.D_i_young_minus_control,errors="coerce").mean())
    Ac=float(pd.to_numeric(pri.C_i_control_mean,errors="coerce").mean()) if "C_i_control_mean" in pri.columns else float(D*-0 + 0.859303)
    dmax=1.0-Ac

    # Joint physical graph.
    union=pd.concat([YA[["ID","Name"]],CA[["ID","Name"]]],ignore_index=True).drop_duplicates("ID").reset_index(drop=True)

    block_rows=[]
    central_alab=None
    for ri,(rn,L,V) in enumerate(RULES):
        lab=joint_labels(M,union,L,V)
        idlab=dict(zip(union.ID.astype(int),lab))
        alab=anchor_meta_labels(AN,CF,CA,union,idlab)
        mask=(pd.to_numeric(AN.MassJ_young,errors="coerce")>=3000).to_numpy()
        yy=pd.to_numeric(AN.loc[mask,"D_i_young_minus_control"],errors="coerce").to_numpy(float)
        ll=alab[mask]
        # Recode labels to contiguous integers.
        mp={b:i for i,b in enumerate(sorted(set(ll)))}
        ll=np.array([mp[b] for b in ll],int)
        z=block_inference(yy,ll,800+ri,dmax)
        z.update(rule=rn,L_pc=L,Vt_kms=V)
        block_rows.append(z)
        if rn=="central_100pc_10kms":
            central_alab=alab.copy()
            central_idlab=idlab.copy()

    block_df=pd.DataFrame(block_rows)
    block_df.to_csv(out/"01_primary_D_exact_BCa_LOBO_by_joint_block_rule.csv",index=False)

    # 30-degree binary sensitivity / continuity correction.
    anchor_binary,binary_summary=primary_binary_metrics(YA,CA,CF)
    anchor_binary.to_csv(out/"02_primary_binary30_anchor_table.csv",index=False)
    binary_summary.to_csv(out/"03_logodds_continuity_and_proportion_difference.csv",index=False)

    # Common pooled |b| cut1 and cluster-robust interaction under central joint blocks.
    mm=M[["ID","Name","GLAT"]].drop_duplicates(["ID","Name"])
    ym=YA[["ID","Name"]].merge(mm,on=["ID","Name"],how="left")
    cm=CA[["ID","Name"]].merge(mm,on=["ID","Name"],how="left")
    pooled=pd.concat([ym,cm],ignore_index=True)
    pooled["absb"]=pd.to_numeric(pooled.GLAT,errors="coerce").abs()
    cuts=np.quantile(pooled.absb.dropna(),[1/3,2/3])
    if central_alab is None:
        raise RuntimeError("central 100pc/10kms labels not created")
    inter,ztable=cluster_robust_latitude(M,AN,CF,CA,union,central_idlab,central_alab,float(cuts[0]))
    inter["common_b_cut1_deg"]=float(cuts[0])
    inter["common_b_cut2_deg"]=float(cuts[1])
    inter["block_rule"]="central_100pc_10kms joint young+control graph"
    inter.to_csv(out/"04_cluster_robust_age_by_absb_and_low_vs_rest.csv",index=False)
    ztable.to_csv(out/"05_extended_anchor_D_absb_block_table.csv",index=False)

    # Authoritative headline values are the central joint-block row.
    head=block_df[block_df.rule=="central_100pc_10kms"].copy()
    head.to_csv(out/"06_authoritative_primary_D_jointblock_headline.csv",index=False)

    report=[
        f"YHMC STAGE-7F BLOCK-EXACT / LOG-ODDS / CLUSTER-ROBUST AUDIT v{VERSION}",
        "="*118,
        "POST_UNBLIND_REVIEWER_STRESS_TEST=True",
        "NO_SAMPLE_RETUNING=True",
        "NO_REMATCHING=True",
        f"YOUNG_FROZEN_SHA256={sha(yf)}",
        f"CONTROL_FROZEN_SHA256={sha(cf)}",
        "",
        "PRIMARY D: EXACT SIGN-FLIP + BCa + LEAVE-ONE-BLOCK-OUT",
        block_df.to_string(index=False),
        "",
        "30-DEG CONCENTRATION: CONTINUITY-CORRECTED LOG-ODDS + MATCHED PROPORTION DIFFERENCE",
        binary_summary.to_string(index=False),
        "",
        "LATITUDE: CENTRAL-JOINT-BLOCK CLUSTER-ROBUST TESTS",
        inter.to_string(index=False),
        "",
        "INTERPRETATION:",
        "  Broad 150/15 and 250/20 rules have few primary matched blocks; BCa, exact sign-flip",
        "  resolution, and leave-one-block-out ranges are therefore reported alongside percentile CIs.",
        "  Ceiling limitation and CI precision answer different questions: Dmax bounds the feasible",
        "  positive effect, whereas the CI describes sampling uncertainty under the chosen block model.",
        "  The 30-degree log-odds uses an explicit Haldane-Anscombe +0.5 correction; the matched",
        "  anchor-level proportion difference is supplied as a finite alternative effect measure.",
        "  Latitude regressions use cluster-robust SEs from the central 100 pc / 10 km s^-1",
        "  joint young+control physical graph and include a low-vs-(mid+high) contrast.",
    ]
    (out/"STAGE7F_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    contract=dict(
        stage="STAGE7F_BLOCKEXACT_LOGODDS_CLUSTERROBUST_AUDIT",
        version=VERSION,
        post_unblind=True,
        sample_retuning=False,
        rematching=False,
        block_rules=[dict(name=n,L_pc=L,Vt_kms=V) for n,L,V in RULES],
        primary_D_inference=[
            "block percentile bootstrap",
            "block BCa bootstrap",
            "exact block sign-flip",
            "leave-one-block-out range",
        ],
        binary30=[
            "Haldane-Anscombe +0.5 cluster-level log-odds",
            "matched-anchor young-minus-control proportion difference",
        ],
        latitude=[
            "cluster-robust OLS D_i ~ standardized |b|",
            "cluster-robust OLS D_i ~ I(mid_or_high common pooled bin)",
        ],
    )
    (out/"STAGE7F_CONTRACT.json").write_text(json.dumps(contract,indent=2),encoding="utf-8")

    lines=[]
    for fp in sorted(out.glob("*")):
        if fp.is_file() and fp.name!="SHA256SUMS.txt":
            lines.append(f"{sha(fp)}  {fp.name}")
    (out/"SHA256SUMS.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print((out/"STAGE7F_REPORT.txt").read_text())

if __name__=="__main__":
    main()

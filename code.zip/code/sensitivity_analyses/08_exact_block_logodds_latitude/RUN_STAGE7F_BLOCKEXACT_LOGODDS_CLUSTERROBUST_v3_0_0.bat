@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo YHMC STAGE-7F BLOCK-EXACT / LOG-ODDS / CLUSTER-ROBUST v3.0.0
echo NO RETUNING / NO REMATCHING
echo ============================================================
set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" (
 echo ERROR: Python not found.
 exit /b 1
)
"%PYEXE%" discover_and_run_stage7f_v3_0_0.py
exit /b %ERRORLEVEL%

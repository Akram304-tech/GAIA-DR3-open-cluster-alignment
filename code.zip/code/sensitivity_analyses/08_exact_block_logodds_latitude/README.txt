YHMC Stage-7F v3.0.0
=====================

Purpose
-------
Resolve the remaining inferential-consistency reviewer comments without changing any
sample, morphology gate, control assignment, or primary endpoint.

1. Primary matched D under joint spatial-kinematic blocks
   - 50/5, 100/10, 150/15, 250/20 rules
   - percentile block bootstrap
   - BCa block bootstrap
   - exact block sign-flip p-values
   - exact p-value resolution
   - leave-one-block-out D range
   - maximum block size
   - BCa upper limit expressed as a fraction of the feasible positive ceiling Dmax

2. 30-degree concentration sensitivity
   - explicit Haldane-Anscombe +0.5 correction to all four 2x2 cells
   - matched-anchor bootstrap
   - finite matched young-minus-control proportion difference

3. Latitude interaction
   - D_i ~ standardized |b| with SE clustered on the central 100 pc/10 km/s
     joint young+control physical blocks
   - low common-|b| bin versus combined mid+high bins with the same cluster-robust SE

All tests are post-unblind reviewer sensitivity analyses.

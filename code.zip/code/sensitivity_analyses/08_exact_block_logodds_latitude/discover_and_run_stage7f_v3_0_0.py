#!/usr/bin/env python
from pathlib import Path
import subprocess,sys,hashlib

def find(d,name,parent):
    hits=[p for p in d.rglob(name) if p.is_file() and p.parent.name==parent]
    if not hits:
        raise FileNotFoundError(f"{parent}/{name}")
    return sorted(hits,key=lambda p:(("REBUILT_HISTORY" in str(p)),p.stat().st_mtime),reverse=True)[0].parent

def main():
    d=Path.home()/"Downloads"
    here=Path(__file__).resolve().parent
    spec=[
        ("stage0","01_cluster_master_raw.csv","STAGE0_OUTPUT"),
        ("stage1b","02_PRIMARY_PA_SAMPLE_FROZEN.csv","STAGE1B_OUTPUT"),
        ("stage1c","01_alignment_cluster_table_UNBLINDED.csv","STAGE1C_OUTPUT"),
        ("stage2c","02_CONTROL_PA_SAMPLE_FROZEN.csv","STAGE2C_OUTPUT"),
        ("stage2d","03_anchor_normalized_young_control_table.csv","STAGE2D_OUTPUT"),
    ]
    paths={k:find(d,f,p) for k,f,p in spec}
    print("="*118)
    print("YHMC STAGE-7F BLOCK-EXACT / LOG-ODDS / CLUSTER-ROBUST AUDIT v3.0.0")
    print("NO RETUNING / NO REMATCHING")
    print("="*118)
    for k,v in paths.items():
        print(f"DISCOVERED_{k.upper()}={v}")
    out=here/"STAGE7F_OUTPUT"
    cmd=[sys.executable,str(here/"stage7f_blockexact_logodds_clusterrobust_audit_v3_0_0.py")]
    for k,v in paths.items():
        cmd += ["--"+k,str(v)]
    cmd += ["--out",str(out)]
    rc=subprocess.run(cmd).returncode
    print()
    print(f"RETURN_CODE={rc}")
    if rc==0:
        print("STAGE7F_AUDIT_PASS=True")
        print(f"REPORT={out/'STAGE7F_REPORT.txt'}")
    raise SystemExit(rc)

if __name__=="__main__":
    main()

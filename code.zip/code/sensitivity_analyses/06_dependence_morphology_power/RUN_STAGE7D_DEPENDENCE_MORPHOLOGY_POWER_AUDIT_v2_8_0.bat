@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo YHMC STAGE-7D DEPENDENCE / MORPHOLOGY / POWER AUDIT v2.8.0
echo AUTO-DISCOVERY / NO SAMPLE RETUNING
echo ============================================================
set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" (
 echo ERROR: Python not found.
 exit /b 1
)
"%PYEXE%" discover_and_run_stage7d_v2_8_0.py
exit /b %ERRORLEVEL%

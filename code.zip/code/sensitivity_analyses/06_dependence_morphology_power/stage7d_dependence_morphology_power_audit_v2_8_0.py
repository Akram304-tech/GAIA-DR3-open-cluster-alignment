#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-7D Dependence / Morphology / Power Audit v2.8.0

POST-UNBLIND REVIEWER STRESS TEST.
No primary sample, mass threshold, PA reliability gate, matched-control assignment,
or primary endpoint is changed.

Reviewer questions addressed
----------------------------
1. Spatial/kinematic dependence: objective block bootstrap, block sign-flip, and
   leave-one-multi-cluster-component-out diagnostics.
2. Dose response / morphology selection: A versus epsilon, Neff, distance and |b|;
   post-unblind within-anchor epsilon-nearest/caliper age-contrast sensitivity.
4. Approximate 80% minimum detectable primary D.
6. Bootstrap CIs and random-orientation nulls for ecliptic/equatorial controls.
7. A versus |b| terciles.
8. Approximate 80% minimum detectable radial R.
9. Audit of the identical control medians at M>=3000 and M>=5000.
10. Authoritative McMillan17 permutation p-value binding when Stage-6B3B output exists.

All newly added analyses are sensitivity/precision diagnostics, not replacement
confirmatory endpoints.
"""
from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import rankdata, spearmanr, norm

VERSION='2.8.0'
SEED=20261028
N_BOOT=100000
N_PERM=200000
N_NULL=500000
EXPECTED_YOUNG='cc1d3ae4ce1cf52387f535da92fbd0dc5d984a3bb2dc750bf6672682e85f65dd'
EXPECTED_CONTROL='124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd'
K=4.74047

LINKING_RULES=[
    ('tight_50pc_5kms',50.0,5.0),
    ('central_100pc_10kms',100.0,10.0),
    ('loose_150pc_15kms',150.0,15.0),
]

def sha256(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def boolish(x):
    return str(x).strip().lower() in {'1','true','t','yes','y'}

def pct(x,p):
    return float(np.nanpercentile(np.asarray(x,float),p))

def boot_mean(x,tag,nboot=N_BOOT):
    x=np.asarray(x,float); x=x[np.isfinite(x)]
    if not len(x): return (np.nan,np.nan,np.nan,np.nan,np.nan)
    rng=np.random.default_rng(np.random.SeedSequence([SEED,tag]))
    vals=np.empty(nboot,float); n=len(x)
    for lo in range(0,nboot,10000):
        hi=min(nboot,lo+10000)
        ix=rng.integers(0,n,size=(hi-lo,n))
        vals[lo:hi]=x[ix].mean(axis=1)
    return (float(x.mean()),pct(vals,2.5),pct(vals,16),pct(vals,84),pct(vals,97.5))

def random_orientation_p(A,n,tag):
    rng=np.random.default_rng(np.random.SeedSequence([SEED,tag]))
    done=0; ext=0
    for lo in range(0,N_NULL,20000):
        m=min(20000,N_NULL-lo)
        ang=rng.uniform(0,90,size=(m,n))
        vals=np.cos(np.deg2rad(2*ang)).mean(axis=1)
        ext += int(np.sum(np.abs(vals)>=abs(A)))
        done += m
    return (ext+1)/(done+1)

def normal_mde(sd,n,alpha=0.05,power=0.80,two_sided=True):
    if n<2 or not np.isfinite(sd) or sd<=0: return np.nan
    za=norm.ppf(1-alpha/2) if two_sided else norm.ppf(1-alpha)
    zp=norm.ppf(power)
    return float((za+zp)*sd/math.sqrt(n))

def axial_diff(a,b):
    return ((np.asarray(a,float)-np.asarray(b,float)+90)%180)-90

def source_geometry(master, ids):
    m=master[master['ID'].isin(ids)].copy()
    if len(m)!=len(set(ids)):
        missing=sorted(set(ids)-set(pd.to_numeric(m['ID'],errors='coerce').dropna().astype(int)))
        if missing: raise RuntimeError(f'Missing master rows for IDs: {missing[:20]}')
    # bind coordinate/proper motion/distance columns
    def first(cols):
        return next((c for c in cols if c in m.columns),None)
    ra=first(['__RAdeg','RA_ICRS','RAdeg','_RA_icrs'])
    de=first(['__DEdeg','DE_ICRS','DEdeg','_DE_icrs'])
    pmra=first(['pmRA','pmra','pmRA50'])
    pmde=first(['pmDE','pmdec','pmDE50'])
    dist=first(['dist50','Dist50','distance'])
    if not all([ra,de,pmra,pmde,dist]):
        raise RuntimeError(f'Cannot bind geometry/PM columns. Available={list(m.columns)}')
    for c in [ra,de,pmra,pmde,dist]: m[c]=pd.to_numeric(m[c],errors='coerce')
    if m[[ra,de,pmra,pmde,dist]].isna().any().any():
        bad=m[m[[ra,de,pmra,pmde,dist]].isna().any(axis=1)][['ID','Name']]
        raise RuntimeError(f'Non-finite geometry/PM for block clustering: {bad.to_dict("records")[:10]}')
    a=np.deg2rad(m[ra].to_numpy(float)); d=np.deg2rad(m[de].to_numpy(float)); r=m[dist].to_numpy(float)
    rh=np.column_stack([np.cos(d)*np.cos(a),np.cos(d)*np.sin(a),np.sin(d)])
    ea=np.column_stack([-np.sin(a),np.cos(a),np.zeros(len(a))])
    ed=np.column_stack([-np.sin(d)*np.cos(a),-np.sin(d)*np.sin(a),np.cos(d)])
    xyz=r[:,None]*rh
    dkpc=r/1000.0
    vt=K*dkpc[:,None]*(m[pmra].to_numpy(float)[:,None]*ea + m[pmde].to_numpy(float)[:,None]*ed)
    out=m[['ID','Name']].copy()
    out[['Xpc','Ypc','Zpc']]=xyz
    out[['Vtx','Vty','Vtz']]=vt
    return out

class UF:
    def __init__(self,n): self.p=list(range(n)); self.sz=[1]*n
    def find(self,x):
        while self.p[x]!=x:
            self.p[x]=self.p[self.p[x]]; x=self.p[x]
        return x
    def union(self,a,b):
        a=self.find(a); b=self.find(b)
        if a==b:return
        if self.sz[a]<self.sz[b]: a,b=b,a
        self.p[b]=a; self.sz[a]+=self.sz[b]

def make_blocks(df,L,V):
    g=source_geometry(MASTER,df['ID'].astype(int).tolist())
    g=g.set_index('ID').loc[df['ID'].astype(int)].reset_index()
    xyz=g[['Xpc','Ypc','Zpc']].to_numpy(float); vt=g[['Vtx','Vty','Vtz']].to_numpy(float)
    n=len(g); uf=UF(n)
    for i in range(n):
        ds=np.sqrt(np.sum((xyz[i+1:]-xyz[i])**2,axis=1))
        dv=np.sqrt(np.sum((vt[i+1:]-vt[i])**2,axis=1))
        js=np.where((ds<=L)&(dv<=V))[0]+i+1
        for j in js: uf.union(i,int(j))
    roots=[uf.find(i) for i in range(n)]
    uniq={r:k for k,r in enumerate(sorted(set(roots)))}
    lab=np.array([uniq[r] for r in roots],int)
    return lab,g

def block_boot_signflip(y,blocks,tag):
    y=np.asarray(y,float); blocks=np.asarray(blocks,int)
    ub=np.unique(blocks); B=len(ub)
    members=[np.where(blocks==b)[0] for b in ub]
    sums=np.array([y[ix].sum() for ix in members],float)
    sizes=np.array([len(ix) for ix in members],float)
    rng=np.random.default_rng(np.random.SeedSequence([SEED,tag]))
    boots=np.empty(N_BOOT,float)
    for lo in range(0,N_BOOT,5000):
        m=min(5000,N_BOOT-lo)
        pick=rng.integers(0,B,size=(m,B))
        boots[lo:lo+m]=sums[pick].sum(axis=1)/sizes[pick].sum(axis=1)
    obs=float(y.mean()); denom=float(len(y))
    ext1=ext2=0
    for lo in range(0,N_PERM,10000):
        m=min(10000,N_PERM-lo)
        signs=rng.choice([-1.0,1.0],size=(m,B))
        vals=(signs*sums[None,:]).sum(axis=1)/denom
        ext1 += int(np.sum(vals>=obs)); ext2 += int(np.sum(np.abs(vals)>=abs(obs)))
    return dict(N=len(y),N_blocks=B,A=obs,boot025=pct(boots,2.5),boot975=pct(boots,97.5),
                p_block_one=(ext1+1)/(N_PERM+1),p_block_two=(ext2+1)/(N_PERM+1),
                max_block_size=max(len(x) for x in members),N_multiblocks=sum(len(x)>=2 for x in members))

def block_jackknife(y,blocks,names):
    rows=[]; y=np.asarray(y,float); blocks=np.asarray(blocks,int); names=np.asarray(names,str)
    for b in np.unique(blocks):
        ix=np.where(blocks==b)[0]
        if len(ix)<2: continue
        keep=blocks!=b
        rows.append(dict(block=int(b),block_size=len(ix),members=' | '.join(names[ix]),estimate_leave_block_out=float(y[keep].mean())))
    return pd.DataFrame(rows)

def tertile_table(df,var,sample,tag):
    d=df[['Y',var]].replace([np.inf,-np.inf],np.nan).dropna().copy()
    if len(d)<9:return []
    # rank-based thirds avoids duplicate-edge failure
    ranks=d[var].rank(method='first',pct=True)
    d['tercile']=pd.cut(ranks,[0,1/3,2/3,1],labels=['low','mid','high'],include_lowest=True)
    out=[]
    for j,t in enumerate(['low','mid','high']):
        x=d.loc[d.tercile==t,'Y'].to_numpy(float)
        A,l,p16,p84,h=boot_mean(x,tag+j)
        out.append(dict(sample=sample,variable=var,tercile=t,N=len(x),A=A,ci95_lo=l,ci95_hi=h,
                        median_covariate=float(d.loc[d.tercile==t,var].median())))
    return out

def spearman_row(df,var,sample):
    d=df[['Y',var]].replace([np.inf,-np.inf],np.nan).dropna()
    r=spearmanr(d['Y'],d[var]) if len(d)>=5 else None
    return dict(sample=sample,variable=var,N=len(d),rho=float(r.statistic) if r else np.nan,p=float(r.pvalue) if r else np.nan)

def bind_morph(align,frozen,master,sample):
    cols=['ID','Name','q_point','Neff','MassJ']
    f=frozen[cols].copy()
    a=align.copy()
    # Y column
    yc='cos2Delta' if 'cos2Delta' in a.columns else 'cos2Delta_control'
    out=f.merge(a[['ID','Name',yc]],on=['ID','Name'],how='left',validate='one_to_one')
    out=out.rename(columns={yc:'Y'})
    mm=master[['ID','Name','dist50','GLAT']].drop_duplicates(['ID','Name'])
    out=out.merge(mm,on=['ID','Name'],how='left',validate='one_to_one')
    out['epsilon']=1-pd.to_numeric(out['q_point'],errors='coerce')
    out['Neff']=pd.to_numeric(out['Neff'],errors='coerce')
    out['distance_pc']=pd.to_numeric(out['dist50'],errors='coerce')
    out['abs_b_deg']=pd.to_numeric(out['GLAT'],errors='coerce').abs()
    out['MassJ']=pd.to_numeric(out['MassJ'],errors='coerce')
    out['sample']=sample
    return out

def epsilon_age_sensitivity(young,controls,tagbase):
    # controls has young_ID and q_point; young has ID/q_point/Y
    yy=young[['ID','Name','MassJ','q_point','Y']].copy().rename(columns={'ID':'young_ID','Name':'young_Name','q_point':'q_y','Y':'Y_y'})
    cc=controls[['ID','Name','young_ID','young_Name','q_point']].copy().rename(columns={'q_point':'q_c','ID':'control_ID','Name':'control_Name'})
    # control outcome is joined from CONTROL_ALIGN global
    ca=CONTROL_ALIGN[['ID','Name','cos2Delta_control']].rename(columns={'ID':'control_ID','Name':'control_Name','cos2Delta_control':'Y_c'})
    cc=cc.merge(ca,on=['control_ID','control_Name'],how='left',validate='one_to_one')
    q=cc.merge(yy,on=['young_ID','young_Name'],how='inner',validate='many_to_one')
    q['eps_y']=1-pd.to_numeric(q['q_y'],errors='coerce'); q['eps_c']=1-pd.to_numeric(q['q_c'],errors='coerce')
    q['abs_deps']=(q['eps_y']-q['eps_c']).abs()
    q=q.sort_values(['young_ID','abs_deps','control_ID']).groupby('young_ID',as_index=False).first()
    q['D_eps_nearest']=q['Y_y']-q['Y_c']
    rows=[]
    for role,mask in [('extended',np.ones(len(q),bool)),('primary_M3000',q['MassJ']>=3000)]:
        z=q[mask].copy()
        for cal in [None,0.10,0.05,0.03]:
            s=z if cal is None else z[z['abs_deps']<=cal]
            if len(s)>=2:
                A,l,p16,p84,h=boot_mean(s['D_eps_nearest'],tagbase+len(rows))
                sd=float(s['D_eps_nearest'].std(ddof=1))
                rows.append(dict(role=role,caliper='nearest_all' if cal is None else f'abs_deps<={cal:.2f}',N=len(s),D=A,ci95_lo=l,ci95_hi=h,
                                 median_abs_deps=float(s['abs_deps'].median()),sd_D=sd))
    return q, pd.DataFrame(rows)

def coordinate_controls(sysdf,sample,tagbase):
    pa=pd.to_numeric(sysdf['PA_deg_point'],errors='coerce').to_numpy(float)
    if 'PA_Ecliptic_parallel_deg' not in sysdf.columns:
        raise RuntimeError('Stage3A cluster table lacks PA_Ecliptic_parallel_deg')
    epa=pd.to_numeric(sysdf['PA_Ecliptic_parallel_deg'],errors='coerce').to_numpy(float)
    vals={
        'ecliptic':np.cos(np.deg2rad(2*np.abs(axial_diff(pa,epa)))),
        'equatorial_EW':np.cos(np.deg2rad(2*np.abs(axial_diff(pa,0.0)))),
    }
    rows=[]
    for j,(ref,y) in enumerate(vals.items()):
        A,l,p16,p84,h=boot_mean(y,tagbase+j)
        rows.append(dict(sample=sample,reference=ref,N=len(y),A=A,ci95_lo=l,ci95_hi=h,
                         p_random_orientation_two_sided=random_orientation_p(A,len(y),tagbase+100+j)))
    return rows

def median_object_audit(control):
    rows=[]
    for m in [3000,5000]:
        s=control[pd.to_numeric(control['MassJ'],errors='coerce')>=m].copy().sort_values('Delta_theta_control_deg')
        n=len(s); k=(n-1)//2; rr=s.iloc[k]
        rows.append(dict(MassJ_threshold=m,N=n,median=float(s['Delta_theta_control_deg'].median()),
                         median_ID=int(rr['ID']),median_Name=str(rr['Name']),median_object_delta=float(rr['Delta_theta_control_deg'])))
    df=pd.DataFrame(rows)
    same=bool(len(df)==2 and df.iloc[0]['median_ID']==df.iloc[1]['median_ID'])
    return df,same

def radial_power(stage4c, fallback_csv):
    src='raw_stage4c'
    if stage4c is not None and (stage4c/'01_young_inner_alignment_UNBLINDED.csv').exists():
        y=pd.read_csv(stage4c/'01_young_inner_alignment_UNBLINDED.csv')
        r=pd.to_numeric(y['R_outer_minus_inner'],errors='coerce').dropna().to_numpy(float)
        n=len(r); sd=float(np.std(r,ddof=1)); obs=float(np.mean(r))
    else:
        src='bootstrap_CI_approximation_fallback'
        f=pd.read_csv(fallback_csv)
        rr=f[f['population']=='Young'].iloc[0]
        n=int(rr['N']); obs=float(rr['R_outer_minus_inner'])
        se=(float(rr['boot975'])-float(rr['boot025']))/(2*1.96)
        sd=float(se*np.sqrt(n))
    return dict(source=src,N=n,R=obs,SD_Ri_est=sd,MDE80_two_sided=normal_mde(sd,n,two_sided=True))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--stage0',required=True); ap.add_argument('--stage1b',required=True); ap.add_argument('--stage1c',required=True)
    ap.add_argument('--stage2c',required=True); ap.add_argument('--stage2d',required=True); ap.add_argument('--stage3a',required=True)
    ap.add_argument('--stage4c',default=None); ap.add_argument('--stage6b3b',default=None)
    ap.add_argument('--fallback-radial',required=True); ap.add_argument('--fallback-orbit',required=True)
    ap.add_argument('--out',default='STAGE7D_OUTPUT')
    args=ap.parse_args()
    global MASTER, CONTROL_ALIGN
    s0=Path(args.stage0); s1b=Path(args.stage1b); s1c=Path(args.stage1c); s2c=Path(args.stage2c); s2d=Path(args.stage2d); s3a=Path(args.stage3a)
    out=Path(args.out).resolve(); out.mkdir(parents=True,exist_ok=True)
    yfp=s1b/'02_PRIMARY_PA_SAMPLE_FROZEN.csv'; cfp=s2c/'02_CONTROL_PA_SAMPLE_FROZEN.csv'
    if sha256(yfp)!=EXPECTED_YOUNG: raise RuntimeError('Young frozen SHA mismatch')
    if sha256(cfp)!=EXPECTED_CONTROL: raise RuntimeError('Control frozen SHA mismatch')
    MASTER=pd.read_csv(s0/'01_cluster_master_raw.csv')
    for c in ['ID','dist50','GLAT','pmRA','pmDE','__RAdeg','__DEdeg']:
        if c in MASTER.columns: MASTER[c]=pd.to_numeric(MASTER[c],errors='coerce')
    YF=pd.read_csv(yfp); CF=pd.read_csv(cfp)
    YA=pd.read_csv(s1c/'01_alignment_cluster_table_UNBLINDED.csv')
    CONTROL_ALIGN=pd.read_csv(s2d/'01_control_alignment_UNBLINDED.csv')
    ANCH=pd.read_csv(s2d/'03_anchor_normalized_young_control_table.csv')
    YSYS=pd.read_csv(s3a/'01_young_systematics_cluster_table.csv')
    CSYS=pd.read_csv(s3a/'01_control_systematics_cluster_table.csv')

    # -------- block dependence --------
    block_rows=[]; jack_rows=[]; comp_rows=[]; tag=100
    for rule,L,V in LINKING_RULES:
        # Define components on the full admitted sample, then inherit those labels
        # in high-mass subsets. This avoids splitting a physical component merely
        # because an intermediate member lies below a mass threshold.
        yfull=YA.copy().reset_index(drop=True)
        yblocks,_=make_blocks(yfull,L,V)
        cfull=CONTROL_ALIGN.copy().reset_index(drop=True)
        cblocks,_=make_blocks(cfull,L,V)
        afull=ANCH.copy().reset_index(drop=True)
        atemp=pd.DataFrame({'ID':afull['young_ID'].astype(int),'Name':afull['young_Name'].astype(str)})
        ablocks,_=make_blocks(atemp,L,V)

        analyses=[
            ('young_all',yfull,'cos2Delta',np.ones(len(yfull),bool),yblocks),
            ('young_M3000',yfull,'cos2Delta',pd.to_numeric(yfull['MassJ'],errors='coerce')>=3000,yblocks),
            ('control_all',cfull,'cos2Delta_control',np.ones(len(cfull),bool),cblocks),
            ('control_M3000',cfull,'cos2Delta_control',pd.to_numeric(cfull['MassJ'],errors='coerce')>=3000,cblocks),
            ('ageD_extended',afull,'D_i_young_minus_control',np.ones(len(afull),bool),ablocks),
            ('ageD_primary_M3000',afull,'D_i_young_minus_control',pd.to_numeric(afull['MassJ_young'],errors='coerce')>=3000,ablocks),
        ]
        for label,df,ycol,mask,fullblocks in analyses:
            d=df[mask].copy().reset_index(drop=True); y=pd.to_numeric(d[ycol],errors='coerce').to_numpy(float)
            blocks=np.asarray(fullblocks)[np.asarray(mask)]
            # Renumber inherited blocks within the retained subset.
            uniq={b:i for i,b in enumerate(sorted(set(blocks.tolist())))}
            blocks=np.array([uniq[b] for b in blocks],int)
            tag+=1; z=block_boot_signflip(y,blocks,tag); z.update(rule=rule,L_pc=L,Vt_kms=V,sample=label); block_rows.append(z)
            names=(d['Name'] if 'Name' in d.columns else d['young_Name']).astype(str).to_numpy()
            jj=block_jackknife(y,blocks,names)
            if len(jj): jj['rule']=rule; jj['sample']=label; jack_rows.append(jj)

        # Component membership is reported from the full admitted samples.
        for label,df,blocks,namecol in [('young_all',yfull,yblocks,'Name'),('control_all',cfull,cblocks,'Name'),('ageD_extended',afull,ablocks,'young_Name')]:
            for b in np.unique(blocks):
                ix=np.where(blocks==b)[0]
                if len(ix)>=2:
                    comp_rows.append(dict(rule=rule,sample=label,block=int(b),size=len(ix),members=' | '.join(df.iloc[ix][namecol].astype(str))))
    pd.DataFrame(block_rows).to_csv(out/'01_block_dependence_summary.csv',index=False)
    pd.concat(jack_rows,ignore_index=True).to_csv(out/'02_multicluster_component_jackknife.csv',index=False) if jack_rows else pd.DataFrame().to_csv(out/'02_multicluster_component_jackknife.csv',index=False)
    pd.DataFrame(comp_rows).to_csv(out/'03_block_component_membership.csv',index=False)

    # -------- dose response / morphology selection --------
    ym=bind_morph(YA,YF,MASTER,'young'); cm=bind_morph(CONTROL_ALIGN,CF,MASTER,'control')
    morph=pd.concat([ym,cm],ignore_index=True)
    morph.to_csv(out/'04_morphology_covariate_object_table.csv',index=False)
    tert=[]; spr=[]; tag=2000
    for sample,d in [('young',ym),('control',cm)]:
        for var in ['epsilon','Neff','distance_pc','abs_b_deg']:
            tag+=10; tert += tertile_table(d,var,sample,tag); spr.append(spearman_row(d,var,sample))
    pd.DataFrame(tert).to_csv(out/'05_alignment_by_morphology_covariate_terciles.csv',index=False)
    pd.DataFrame(spr).to_csv(out/'06_alignment_covariate_spearman.csv',index=False)
    eps_obj,epssum=epsilon_age_sensitivity(ym,CF,3000)
    eps_obj.to_csv(out/'07_epsilon_nearest_control_by_anchor.csv',index=False)
    epssum.to_csv(out/'08_epsilon_matched_age_contrast_sensitivity.csv',index=False)

    # -------- D power --------
    primary=ANCH[pd.to_numeric(ANCH['MassJ_young'],errors='coerce')>=3000]
    di=pd.to_numeric(primary['D_i_young_minus_control'],errors='coerce').dropna().to_numpy(float)
    d_power=pd.DataFrame([dict(N=len(di),D_observed=float(di.mean()),SD_Di=float(np.std(di,ddof=1)),
                                    MDE80_one_sided=normal_mde(np.std(di,ddof=1),len(di),two_sided=False),
                                    MDE80_two_sided=normal_mde(np.std(di,ddof=1),len(di),two_sided=True),
                                    note='normal-approximate precision diagnostic; original primary alternative was D>0')])
    d_power.to_csv(out/'09_primary_age_contrast_power.csv',index=False)

    # -------- coordinate controls + |b| terciles --------
    cc=[]
    cc += coordinate_controls(YSYS,'young',4000); cc += coordinate_controls(CSYS,'control',4100)
    pd.DataFrame(cc).to_csv(out/'10_coordinate_control_CI_null.csv',index=False)
    bter=[]; tag=5000
    for sample,d in [('young',ym),('control',cm)]:
        tag+=10; bter += tertile_table(d,'abs_b_deg',sample,tag)
    pd.DataFrame(bter).to_csv(out/'11_absb_tercile_alignment.csv',index=False)

    # -------- radial power --------
    s4=Path(args.stage4c) if args.stage4c else None
    rp=radial_power(s4,Path(args.fallback_radial))
    pd.DataFrame([rp]).to_csv(out/'12_radial_power.csv',index=False)

    # -------- table median audit --------
    med,same=median_object_audit(CONTROL_ALIGN)
    med['same_median_object_across_thresholds']=same
    med.to_csv(out/'13_control_median_delta_audit.csv',index=False)

    # -------- orbit p-value authority --------
    orbit_source='fallback_manuscript_table'; pval=np.nan; rho=np.nan
    if args.stage6b3b:
        p=Path(args.stage6b3b)/'02_PRIMARY_ASSOCIATION_RESULT.csv'
        if p.exists():
            q=pd.read_csv(p); r=q.iloc[0]
            pc=next((c for c in ['p_two_sided_cohort_stratified_perm','p_two_sided_perm'] if c in q.columns),None)
            rc=next((c for c in ['rho_spearman','rho'] if c in q.columns),None)
            if pc:
                pval=float(r[pc]); rho=float(r[rc]) if rc else np.nan; orbit_source=str(p)
    if not np.isfinite(pval):
        q=pd.read_csv(args.fallback_orbit); r=q[q['potential']=='McMillan17'].iloc[0]
        pval=float(r['p_two_sided_cohort_stratified_perm']); rho=float(r['rho_spearman'])
    pd.DataFrame([dict(source=orbit_source,rho_spearman=rho,p_two_sided_perm_authoritative=pval,
                       recommendation='use this archived machine-readable value everywhere in manuscript')]).to_csv(out/'14_orbit_pvalue_consistency.csv',index=False)

    # report
    bs=pd.DataFrame(block_rows)
    central=bs[bs['rule']=='central_100pc_10kms']
    cor=pd.DataFrame(cc)
    report=[
        f'YHMC STAGE-7D DEPENDENCE / MORPHOLOGY / POWER AUDIT v{VERSION}', '='*116,
        'POST_UNBLIND_REVIEWER_STRESS_TEST=True','NO_PRIMARY_SAMPLE_CHANGE=True','NO_GATE_RETUNING=True','NO_REMATCHING=True','',
        'CENTRAL 100 pc / 10 km s^-1 BLOCK RESULTS:',
        central[['sample','N','N_blocks','N_multiblocks','max_block_size','A','boot025','boot975','p_block_one','p_block_two']].to_string(index=False),'',
        'MORPHOLOGY / DOSE-RESPONSE SPEARMAN:',pd.DataFrame(spr).to_string(index=False),'',
        'EPSILON-MATCHED AGE-CONTRAST SENSITIVITY:',epssum.to_string(index=False),'',
        'PRIMARY D POWER:',d_power.to_string(index=False),'',
        'COORDINATE-CONTROL CIs / NULL:',cor.to_string(index=False),'',
        '|b| TERCILES:',pd.DataFrame(bter).to_string(index=False),'',
        'RADIAL POWER:',pd.DataFrame([rp]).to_string(index=False),'',
        'CONTROL MEDIAN DELTA AUDIT:',med.to_string(index=False),f'SAME_MEDIAN_OBJECT={same}','',
        f'AUTHORITATIVE_MCMILLAN17_P={pval:.9f}',f'ORBIT_P_SOURCE={orbit_source}','',
        'INTERPRETATION CEILING:',
        '  Block definitions are objective post-unblind dependence stress tests, not a redefinition of the science sample.',
        '  Epsilon-nearest/caliper contrasts condition on measured morphology after outcome-free sample selection and are sensitivity analyses only.',
        '  MDE values are normal-approximate precision diagnostics, not equivalence tests.',
    ]
    (out/'STAGE7D_REPORT.txt').write_text('\n'.join(report)+'\n',encoding='utf-8')
    contract=dict(stage='STAGE7D_DEPENDENCE_MORPHOLOGY_POWER_AUDIT',version=VERSION,post_unblind=True,
                  primary_sample_changed=False,gate_retuning=False,rematching=False,
                  block_rules=[dict(name=n,L_pc=L,Vt_kms=V) for n,L,V in LINKING_RULES],
                  block_velocity='3D ICRS transverse-velocity vector from pmRA, pmDE, dist50; no RV required',
                  epsilon_matching='within each originally assigned anchor, closest admitted control; calipers descriptive',
                  coordinate_controls='bootstrap CI + two-sided random-orientation null',
                  power='normal-approximate 80% MDE')
    (out/'STAGE7D_CONTRACT.json').write_text(json.dumps(contract,indent=2),encoding='utf-8')
    lines=[]
    for p in sorted(out.glob('*')):
        if p.is_file() and p.name!='SHA256SUMS.txt': lines.append(f'{sha256(p)}  {p.name}')
    (out/'SHA256SUMS.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print((out/'STAGE7D_REPORT.txt').read_text(encoding='utf-8'))

if __name__=='__main__': main()

#!/usr/bin/env python
from __future__ import annotations
import subprocess, sys
from pathlib import Path

def find_parent(d,marker,parent=None):
    hits=[p for p in d.rglob(marker) if p.is_file() and (parent is None or p.parent.name==parent)]
    if not hits: return None
    hits=sorted(hits,key=lambda p:(('REBUILT_HISTORY' in str(p)),p.stat().st_mtime),reverse=True)
    return hits[0].parent

def main():
    here=Path(__file__).resolve().parent; d=Path.home()/'Downloads'
    print('='*112); print('YHMC STAGE-7D DEPENDENCE / MORPHOLOGY / POWER AUDIT v2.8.0'); print('AUTO-DISCOVERY / POST-UNBLIND REVIEWER STRESS TEST'); print('='*112)
    req={
      'stage0':('01_cluster_master_raw.csv','STAGE0_OUTPUT'),
      'stage1b':('02_PRIMARY_PA_SAMPLE_FROZEN.csv','STAGE1B_OUTPUT'),
      'stage1c':('01_alignment_cluster_table_UNBLINDED.csv','STAGE1C_OUTPUT'),
      'stage2c':('02_CONTROL_PA_SAMPLE_FROZEN.csv','STAGE2C_OUTPUT'),
      'stage2d':('03_anchor_normalized_young_control_table.csv','STAGE2D_OUTPUT'),
      'stage3a':('02_global_systematics_summary.csv','STAGE3A_OUTPUT'),
    }
    paths={}
    for k,(m,pn) in req.items():
        q=find_parent(d,m,pn)
        if q is None: raise FileNotFoundError(f'Missing {pn}/{m} under {d}')
        paths[k]=q; print(f'DISCOVERED_{k.upper()}={q}')
    s4=find_parent(d,'04_inner_outer_radial_contrast.csv','STAGE4C_OUTPUT')
    s6=find_parent(d,'02_PRIMARY_ASSOCIATION_RESULT.csv','STAGE6B3B_OUTPUT')
    print(f'DISCOVERED_STAGE4C={s4 if s4 else "NONE; radial power uses CI fallback"}')
    print(f'DISCOVERED_STAGE6B3B={s6 if s6 else "NONE; orbit p uses manuscript-table fallback"}')
    rc=subprocess.run([sys.executable,'-c','import numpy,pandas,scipy']).returncode
    if rc: raise SystemExit('ERROR: numpy pandas scipy required')
    out=here/'STAGE7D_OUTPUT'
    cmd=[sys.executable,str(here/'stage7d_dependence_morphology_power_audit_v2_8_0.py')]
    for k in ['stage0','stage1b','stage1c','stage2c','stage2d','stage3a']:
        cmd += [f'--{k}',str(paths[k])]
    if s4: cmd += ['--stage4c',str(s4)]
    if s6: cmd += ['--stage6b3b',str(s6)]
    cmd += ['--fallback-radial',str(here/'fallback_radial_summary.csv'),'--fallback-orbit',str(here/'fallback_orbit_mechanism_summary.csv'),'--out',str(out)]
    rc=subprocess.run(cmd).returncode
    print(); print(f'RETURN_CODE={rc}')
    if rc==0:
        print('STAGE7D_DEPENDENCE_MORPHOLOGY_POWER_AUDIT_PASS=True'); print(f'REPORT={out/"STAGE7D_REPORT.txt"}')
    raise SystemExit(rc)
if __name__=='__main__':main()

YHMC Stage-7D dependence / morphology / power audit v2.8.0
================================================================

This package is a single post-unblind reviewer stress-test stage. It does not change
any primary sample, threshold, PA gate, matched-control assignment, or endpoint.

It addresses the new critique by adding:
- objective spatial-kinematic connected components at 50pc/5km/s, 100pc/10km/s,
  and 150pc/15km/s;
- block bootstrap and block sign-flip inference;
- leave-one-multi-cluster-component-out jackknife;
- A stratified by epsilon, Neff, distance and |b| terciles;
- within-original-anchor epsilon-nearest and epsilon-caliper age-contrast sensitivity;
- approximate 80% MDE for primary D and radial R;
- bootstrap CIs and random-orientation nulls for ecliptic/equatorial controls;
- explicit |b| tercile alignment;
- Table-4 median-object audit;
- authoritative machine-readable McMillan17 p-value binding when Stage6B3B output is available.

Block kinematics use the 3D ICRS transverse-velocity vector constructed from cluster
pmRA, pmDE and dist50. No radial velocity is required. Component definitions are
objective and outcome-blind with respect to the alignment statistic, although the
analysis itself is explicitly post-unblind.

If STAGE4C_OUTPUT is not present, radial MDE is estimated from the already reported
bootstrap 95% CI in the embedded manuscript table and marked as a fallback. If
STAGE6B3B_OUTPUT is not present, the embedded manuscript machine-readable orbit table
is used only to bind a single consistent p-value.

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-7C Local Directional Density/Dust Gradient Audit v2.7.0

POST-UNBLIND REVIEWER STRESS TEST
NO NEW PRIMARY ENDPOINT
NO SAMPLE RETUNING
NO REPLACEMENT MECHANISM SEARCH

Question
--------
Could Galactic-plane alignment of recovered cluster shapes be a local observational
artefact caused by directional gradients in field-star density, faint-source
completeness, or foreground dust?

Design
------
For every already-admitted young/control object:
1) Place four small background probes just outside rJ in local Galactic directions
   +l, -l, +b, -b.
2) Query Gaia DR3 source counts (G<=20.5 and G<18) in those four probes from
   VizieR TAP. This measures local source-density anisotropy and a faint-source
   fraction proxy without using cluster members.
3) Query IRSA SFD/SandF E(B-V) at the same four locations as a 2D total-dust-column
   directional proxy.
4) Test observed Y=cos(2 Delta_GP) against gradient amplitude/quadrupole metrics.
5) Re-estimate alignment in low-gradient subsets defined without Y.
6) Descriptively test whether cluster PA tracks the local density/dust gradient axis.

Interpretation ceiling
----------------------
Gaia background probes are empirical local source-density/completeness proxies, not
a direct rerun of the Hunt & Reffert membership algorithm.
SFD/SandF E(B-V) is total Galactic dust to infinity, not 3D extinction at the cluster
distance. Therefore this is a directional observational-systematics stress test,
not proof that every possible membership or extinction artefact is absent.
"""

from __future__ import annotations
import argparse, io, json, math, time, hashlib
from pathlib import Path

import numpy as np
import pandas as pd
import requests
from scipy.stats import rankdata
from astropy.coordinates import SkyCoord
import astropy.units as u
from astroquery.ipac.irsa.irsa_dust import IrsaDust

VERSION="2.7.0"
SEED=20261027
N_BOOT=100000
N_PERM=100000

TAP="https://tapvizier.cds.unistra.fr/TAPVizieR/tap/sync"
GAIA_TABLE='"I/355/gaiadr3"'
PROBE_RADIUS_DEG=0.05        # 3 arcmin
MIN_PROBE_SEP_DEG=0.25
RJ_CLEARANCE_DEG=0.10
G_ALL_MAX=20.5
G_BRIGHT_MAX=18.0

EXPECTED_YOUNG_SHA="cc1d3ae4ce1cf52387f535da92fbd0dc5d984a3bb2dc750bf6672682e85f65dd"
EXPECTED_CONTROL_SHA="124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd"

DIRS=("lp","lm","bp","bm")
DIR_PA_GAL_DEG={"bp":0.0,"lp":90.0,"bm":180.0,"lm":270.0}

def sha256(p:Path):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def axial_signed_diff_deg(a,b):
    return ((np.asarray(a,float)-np.asarray(b,float)+90.0)%180.0)-90.0

def tap_query(adql, timeout=180, retries=4):
    payload={"REQUEST":"doQuery","LANG":"ADQL","FORMAT":"csv","QUERY":adql}
    last=None
    for k in range(retries):
        try:
            r=requests.post(TAP,data=payload,timeout=timeout)
            if r.status_code!=200:
                raise RuntimeError(f"HTTP {r.status_code}: {r.text[:3000]}")
            txt=r.text
            if txt.lstrip().startswith("<?xml") or "QUERY_STATUS" in txt[:3000]:
                raise RuntimeError("TAP error payload: "+txt[:3000])
            return pd.read_csv(io.StringIO(txt))
        except Exception as e:
            last=e
            if k+1<retries:
                time.sleep(min(2**k,12))
    raise RuntimeError(f"VizieR TAP query failed: {last!r}")

def spherical_sep_deg(ra,dec,ra0,dec0):
    ra=np.deg2rad(np.asarray(ra,float)); dec=np.deg2rad(np.asarray(dec,float))
    ra0=np.deg2rad(float(ra0)); dec0=np.deg2rad(float(dec0))
    c=np.sin(dec)*np.sin(dec0)+np.cos(dec)*np.cos(dec0)*np.cos(ra-ra0)
    return np.rad2deg(np.arccos(np.clip(c,-1,1)))

def make_probe_positions(ra,dec,rj_deg):
    sep=max(float(rj_deg)+RJ_CLEARANCE_DEG,MIN_PROBE_SEP_DEG)
    c=SkyCoord(ra=float(ra)*u.deg,dec=float(dec)*u.deg,frame="icrs").galactic
    out={}
    for d in DIRS:
        q=c.directional_offset_by(DIR_PA_GAL_DEG[d]*u.deg,sep*u.deg).icrs
        out[d]=(float(q.ra.deg),float(q.dec.deg))
    return sep,out

def gaia_probe_counts(target_row, probe_positions, cache_dir):
    """
    One TAP query per cluster for the union of four disjoint 3-arcmin probes.
    Only RA, Dec and Gmag are returned. Local classification produces counts.
    """
    sample=str(target_row["sample"])
    cid=int(target_row["ID"])
    f=cache_dir/f"{sample}_{cid:06d}.csv"
    if f.exists():
        q=pd.read_csv(f)
        if set(["dir","N_G20p5","N_G18","faint_fraction"]).issubset(q.columns):
            return q

    ors=[]
    for d,(ra,dec) in probe_positions.items():
        ors.append(
            f"1=CONTAINS(POINT('ICRS',RA_ICRS,DE_ICRS),"
            f"CIRCLE('ICRS',{ra:.10f},{dec:.10f},{PROBE_RADIUS_DEG:.8f}))"
        )
    adql=(
        f"SELECT RA_ICRS,DE_ICRS,Gmag FROM {GAIA_TABLE} "
        f"WHERE Gmag<={G_ALL_MAX:.3f} AND ("+" OR ".join(ors)+")"
    )
    df=tap_query(adql)
    if len(df):
        rac=pd.to_numeric(df["RA_ICRS"],errors="coerce").to_numpy(float)
        dec=pd.to_numeric(df["DE_ICRS"],errors="coerce").to_numpy(float)
        g=pd.to_numeric(df["Gmag"],errors="coerce").to_numpy(float)
    else:
        rac=np.array([],float); dec=np.array([],float); g=np.array([],float)

    rows=[]
    for d,(pra,pde) in probe_positions.items():
        if len(rac):
            sep=spherical_sep_deg(rac,dec,pra,pde)
            m=np.isfinite(sep)&np.isfinite(g)&(sep<=PROBE_RADIUS_DEG)
            gg=g[m]
        else:
            gg=np.array([],float)
        nall=int(np.sum(gg<=G_ALL_MAX))
        nb=int(np.sum(gg<G_BRIGHT_MAX))
        ff=float((nall-nb)/nall) if nall>0 else np.nan
        rows.append({"dir":d,"N_G20p5":nall,"N_G18":nb,"faint_fraction":ff})
    q=pd.DataFrame(rows)
    cache_dir.mkdir(parents=True,exist_ok=True)
    q.to_csv(f,index=False)
    return q

def dust_ebv_sandf(coord:SkyCoord, cache_file:Path, retries=3):
    if cache_file.exists():
        try:
            x=json.loads(cache_file.read_text(encoding="utf-8"))
            if x.get("ok",False):
                return float(x["ebv_sandf"])
            return np.nan
        except Exception:
            pass
    last=None
    for k in range(retries):
        try:
            tab=IrsaDust.get_query_table(coord,section="ebv",timeout=60)
            col="ext SandF ref"
            if col not in tab.colnames:
                raise RuntimeError(f"IRSA EBV schema changed: {tab.colnames}")
            val=float(tab[col][0])
            payload={"ok":True,"ebv_sandf":val,"column":col,
                     "ra_deg":float(coord.icrs.ra.deg),"dec_deg":float(coord.icrs.dec.deg)}
            cache_file.parent.mkdir(parents=True,exist_ok=True)
            cache_file.write_text(json.dumps(payload,indent=2),encoding="utf-8")
            return val
        except Exception as e:
            last=e
            if k+1<retries:
                time.sleep(min(2**k,8))
    cache_file.parent.mkdir(parents=True,exist_ok=True)
    cache_file.write_text(json.dumps({"ok":False,"error":repr(last)},indent=2),encoding="utf-8")
    return np.nan

def four_direction_metrics(values,prefix):
    v={d:float(values.get(d,np.nan)) for d in DIRS}
    arr=np.array([v[d] for d in DIRS],float)
    if not np.isfinite(arr).all():
        return {f"{prefix}_{k}":np.nan for k in
                ["mean","grad_l","grad_b","grad_amp","grad_phi_deg","quad_parallel_minus_perp"]}
    eps=max(1e-12,1e-12*abs(float(np.mean(arr))))
    dl=(v["lp"]-v["lm"])/(abs(v["lp"])+abs(v["lm"])+eps)
    db=(v["bp"]-v["bm"])/(abs(v["bp"])+abs(v["bm"])+eps)
    amp=float(np.hypot(dl,db))
    phi=float(np.degrees(np.arctan2(db,dl))%180.0)
    quad=float(((v["lp"]+v["lm"])-(v["bp"]+v["bm"]))/
               (np.sum(np.abs(arr))+eps))
    return {
        f"{prefix}_mean":float(np.mean(arr)),
        f"{prefix}_grad_l":float(dl),
        f"{prefix}_grad_b":float(db),
        f"{prefix}_grad_amp":amp,
        f"{prefix}_grad_phi_deg":phi,
        f"{prefix}_quad_parallel_minus_perp":quad,
    }

def cohort_median_flag(df,col,low=True):
    out=pd.Series(False,index=df.index)
    for sample,g in df.groupby("sample"):
        x=pd.to_numeric(g[col],errors="coerce")
        med=float(x.median())
        flag=x<=med if low else x>=med
        out.loc[g.index]=flag.fillna(False)
    return out

def bootstrap_A(y,seed_tag):
    y=np.asarray(y,float); y=y[np.isfinite(y)]
    if len(y)==0:
        return {"N":0,"A":np.nan,"p025":np.nan,"p16":np.nan,"p84":np.nan,"p975":np.nan}
    rng=np.random.default_rng(np.random.SeedSequence([SEED,seed_tag]))
    n=len(y); vals=np.empty(N_BOOT,float)
    for lo in range(0,N_BOOT,10000):
        hi=min(N_BOOT,lo+10000)
        ix=rng.integers(0,n,size=(hi-lo,n))
        vals[lo:hi]=np.mean(y[ix],axis=1)
    return {
        "N":n,"A":float(np.mean(y)),
        "p025":float(np.percentile(vals,2.5)),
        "p16":float(np.percentile(vals,16)),
        "p84":float(np.percentile(vals,84)),
        "p975":float(np.percentile(vals,97.5)),
    }

def stratified_spearman_perm(df,metric,seed_tag):
    d=df[["sample","Y",metric]].replace([np.inf,-np.inf],np.nan).dropna().copy()
    if len(d)<8:
        return {"N":len(d),"rho":np.nan,"p":np.nan}
    x=rankdata(d[metric].to_numpy(float),method="average")
    y=rankdata(d["Y"].to_numpy(float),method="average")
    x=x-x.mean(); y=y-y.mean()
    dx=np.sqrt(np.sum(x*x)); dy=np.sqrt(np.sum(y*y))
    rho=float(np.sum(x*y)/(dx*dy))
    groups=d["sample"].astype(str).to_numpy()
    idxs=[np.where(groups==g)[0] for g in np.unique(groups)]
    rng=np.random.default_rng(np.random.SeedSequence([SEED,seed_tag]))
    extreme=0
    for _ in range(N_PERM):
        yp=y.copy()
        for ix in idxs:
            yp[ix]=y[ix][rng.permutation(len(ix))]
        r=float(np.sum(x*yp)/(dx*np.sqrt(np.sum(yp*yp))))
        extreme += (abs(r)>=abs(rho))
    p=(extreme+1)/(N_PERM+1)
    return {"N":len(d),"rho":rho,"p":float(p)}

def orientation_summary(df,grad_prefix,seed_tag):
    amp=f"{grad_prefix}_grad_amp"
    phi=f"{grad_prefix}_grad_phi_deg"
    d=df[["sample","phi_cluster_rel_gp_deg",amp,phi]].replace([np.inf,-np.inf],np.nan).dropna().copy()
    # Only upper-half gradient amplitudes within each cohort: gradient direction
    # is otherwise noise-dominated. Threshold is independent of cluster Y.
    d["highgrad"]=False
    for s,g in d.groupby("sample"):
        med=float(g[amp].median())
        d.loc[g.index,"highgrad"]=g[amp]>=med
    d=d[d["highgrad"]].copy()
    if len(d)==0:
        return pd.DataFrame()
    d["grad_vs_gp_cos2"]=np.cos(np.deg2rad(2*d[phi]))
    dd=axial_signed_diff_deg(d["phi_cluster_rel_gp_deg"],d[phi])
    d["cluster_vs_grad_cos2"]=np.cos(np.deg2rad(2*dd))
    rows=[]
    k=seed_tag
    for sample in ["pooled","young","control"]:
        q=d if sample=="pooled" else d[d["sample"]==sample]
        for metric in ["grad_vs_gp_cos2","cluster_vs_grad_cos2"]:
            k+=1
            b=bootstrap_A(q[metric],k)
            rows.append({"gradient":grad_prefix,"sample":sample,"metric":metric,**b})
    return pd.DataFrame(rows)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage0",required=True)
    ap.add_argument("--stage1b",required=True)
    ap.add_argument("--stage1c",required=True)
    ap.add_argument("--stage2a",required=True)
    ap.add_argument("--stage2c",required=True)
    ap.add_argument("--stage2d",required=True)
    ap.add_argument("--out",default="STAGE7C_OUTPUT")
    args=ap.parse_args()

    s0=Path(args.stage0).resolve()
    s1b=Path(args.stage1b).resolve()
    s1c=Path(args.stage1c).resolve()
    s2a=Path(args.stage2a).resolve()
    s2c=Path(args.stage2c).resolve()
    s2d=Path(args.stage2d).resolve()
    out=Path(args.out).resolve(); out.mkdir(parents=True,exist_ok=True)

    # ---------------- chain-of-custody ----------------
    hy=sha256(s1b/"02_PRIMARY_PA_SAMPLE_FROZEN.csv")
    hc=sha256(s2c/"02_CONTROL_PA_SAMPLE_FROZEN.csv")
    if hy!=EXPECTED_YOUNG_SHA:
        raise RuntimeError("Young frozen sample SHA mismatch.")
    if hc!=EXPECTED_CONTROL_SHA:
        raise RuntimeError("Control frozen sample SHA mismatch.")

    young=pd.read_csv(s1c/"01_alignment_cluster_table_UNBLINDED.csv")
    control=pd.read_csv(s2d/"01_control_alignment_UNBLINDED.csv")
    ysrc=pd.read_csv(s0/"07_provisional_morphology_ready.csv")
    csrc=pd.read_csv(s2a/"02_MATCHED_OLDER_CONTROLS_FROZEN.csv")

    # Ensure alignment tables are exactly the frozen admitted identities.
    yf=pd.read_csv(s1b/"02_PRIMARY_PA_SAMPLE_FROZEN.csv")[["ID","Name"]].copy()
    cf=pd.read_csv(s2c/"02_CONTROL_PA_SAMPLE_FROZEN.csv")[["ID","Name"]].copy()
    def idset(df): return set(zip(df["ID"].astype(int),df["Name"].astype(str)))
    if idset(young)!=idset(yf):
        raise RuntimeError("Young alignment identities differ from frozen sample.")
    if idset(control)!=idset(cf):
        raise RuntimeError("Control alignment identities differ from frozen sample.")

    yadd=ysrc[["ID","Name","rJ","AV50","GLON","GLAT"]].drop_duplicates(["ID","Name"])
    cadd=csrc[["ID","Name","rJ","AV50","GLON","GLAT"]].drop_duplicates(["ID","Name"])
    young=young.merge(yadd,on=["ID","Name"],how="left",validate="one_to_one")
    control=control.merge(cadd,on=["ID","Name"],how="left",validate="one_to_one")

    Y=young[["ID","Name","MassJ","__RAdeg","__DEdeg","PA_deg_point",
             "PA_Galactic_parallel_deg","cos2Delta","rJ","AV50","GLON","GLAT"]].copy()
    Y["sample"]="young"; Y["Y"]=pd.to_numeric(Y["cos2Delta"],errors="coerce")

    C=control[["ID","Name","MassJ","__RAdeg","__DEdeg","PA_deg_point",
               "PA_Galactic_parallel_deg","cos2Delta_control","rJ","AV50","GLON","GLAT"]].copy()
    C["sample"]="control"; C["Y"]=pd.to_numeric(C["cos2Delta_control"],errors="coerce")

    targets=pd.concat([Y.drop(columns=["cos2Delta"]),
                       C.drop(columns=["cos2Delta_control"])],ignore_index=True)
    for c in ["MassJ","__RAdeg","__DEdeg","rJ","AV50","GLON","GLAT",
              "PA_deg_point","PA_Galactic_parallel_deg","Y"]:
        targets[c]=pd.to_numeric(targets[c],errors="coerce")
    if targets[["__RAdeg","__DEdeg","rJ","PA_deg_point","PA_Galactic_parallel_deg","Y"]].isna().any().any():
        raise RuntimeError("Non-finite target geometry after source-table join.")
    targets["phi_cluster_rel_gp_deg"]=axial_signed_diff_deg(
        targets["PA_deg_point"],targets["PA_Galactic_parallel_deg"]
    )

    # ---------------- probe positions ----------------
    probe_rows=[]
    target_probe_map={}
    for _,r in targets.iterrows():
        sep,pp=make_probe_positions(r["__RAdeg"],r["__DEdeg"],r["rJ"])
        target_probe_map[(r["sample"],int(r["ID"]))]=(sep,pp)
        for d,(ra,dec) in pp.items():
            probe_rows.append({
                "sample":r["sample"],"ID":int(r["ID"]),"Name":r["Name"],
                "dir":d,"rJ_deg":float(r["rJ"]),
                "probe_sep_deg":float(sep),"probe_radius_deg":PROBE_RADIUS_DEG,
                "probe_ra_deg":ra,"probe_dec_deg":dec,
            })
    probes=pd.DataFrame(probe_rows)
    probes.to_csv(out/"01_local_probe_positions.csv",index=False)

    # ---------------- Gaia local density probes ----------------
    gaia_cache=out/"CACHE_GAIA_PROBES"
    gaia_rows=[]
    total=len(targets)
    for j,(_,r) in enumerate(targets.iterrows(),1):
        sep,pp=target_probe_map[(r["sample"],int(r["ID"]))]
        q=gaia_probe_counts(r,pp,gaia_cache)
        rec={"sample":r["sample"],"ID":int(r["ID"]),"Name":r["Name"]}
        for _,z in q.iterrows():
            d=str(z["dir"])
            rec[f"N20_{d}"]=int(z["N_G20p5"])
            rec[f"N18_{d}"]=int(z["N_G18"])
            rec[f"faintfrac_{d}"]=float(z["faint_fraction"])
        rec.update(four_direction_metrics(
            {d:rec[f"N20_{d}"] for d in DIRS},"density"
        ))
        rec.update(four_direction_metrics(
            {d:rec[f"faintfrac_{d}"] for d in DIRS},"faintfrac"
        ))
        gaia_rows.append(rec)
        if j<=5 or j%10==0 or j==total:
            print(f"GAIA_LOCAL_PROBES {j}/{total} {r['sample']} {r['Name']}",flush=True)
    gaia=pd.DataFrame(gaia_rows)
    gaia.to_csv(out/"02_local_gaia_density_metrics.csv",index=False)

    # ---------------- IRSA 2D dust probes ----------------
    dust_cache=out/"CACHE_IRSA_DUST"
    dust_rows=[]
    dust_success=0
    for j,(_,r) in enumerate(targets.iterrows(),1):
        sep,pp=target_probe_map[(r["sample"],int(r["ID"]))]
        rec={"sample":r["sample"],"ID":int(r["ID"]),"Name":r["Name"]}
        vals={}
        for d,(ra,dec) in pp.items():
            coord=SkyCoord(ra=ra*u.deg,dec=dec*u.deg,frame="icrs")
            val=dust_ebv_sandf(
                coord,dust_cache/f"{r['sample']}_{int(r['ID']):06d}_{d}.json"
            )
            vals[d]=val
            rec[f"ebv_{d}"]=val
        if np.isfinite(np.array(list(vals.values()),float)).all():
            dust_success+=1
        rec.update(four_direction_metrics(vals,"dust"))
        dust_rows.append(rec)
        if j<=5 or j%10==0 or j==total:
            print(f"DUST_LOCAL_PROBES {j}/{total} complete4={dust_success}",flush=True)
    dust=pd.DataFrame(dust_rows)
    dust.to_csv(out/"03_local_sfd_dust_metrics.csv",index=False)

    # ---------------- combined audit table ----------------
    full=targets.merge(gaia,on=["sample","ID","Name"],validate="one_to_one")
    full=full.merge(dust,on=["sample","ID","Name"],validate="one_to_one")
    full["density_abs_quad"]=full["density_quad_parallel_minus_perp"].abs()
    full["faintfrac_abs_quad"]=full["faintfrac_quad_parallel_minus_perp"].abs()
    full["dust_abs_quad"]=full["dust_quad_parallel_minus_perp"].abs()
    full["density_cluster_grad_cos2"]=np.cos(np.deg2rad(
        2*axial_signed_diff_deg(full["phi_cluster_rel_gp_deg"],full["density_grad_phi_deg"])
    ))
    full["dust_cluster_grad_cos2"]=np.cos(np.deg2rad(
        2*axial_signed_diff_deg(full["phi_cluster_rel_gp_deg"],full["dust_grad_phi_deg"])
    ))
    full.to_csv(out/"04_combined_local_gradient_table.csv",index=False)

    # ---------------- correlations ----------------
    metrics=[
        "density_grad_amp","density_quad_parallel_minus_perp","density_abs_quad",
        "faintfrac_grad_amp","faintfrac_quad_parallel_minus_perp","faintfrac_abs_quad",
        "dust_grad_amp","dust_quad_parallel_minus_perp","dust_abs_quad",
    ]
    corr=[]
    k=1000
    for m in metrics:
        k+=1
        z=stratified_spearman_perm(full,m,k)
        corr.append({
            "metric":m,"N":z["N"],"rho_spearman":z["rho"],
            "p_two_sided_cohort_stratified":z["p"],
            "status":"post-unblind reviewer stress test"
        })
    corr=pd.DataFrame(corr)
    corr.to_csv(out/"05_alignment_vs_local_gradient_correlations.csv",index=False)

    # ---------------- clean subsets defined without Y ----------------
    full["low_density_grad"]=cohort_median_flag(full,"density_grad_amp",True)
    full["low_density_quad"]=cohort_median_flag(full,"density_abs_quad",True)
    full["low_faintfrac_grad"]=cohort_median_flag(full,"faintfrac_grad_amp",True)

    dust_available=np.isfinite(full["dust_grad_amp"]).sum() >= int(0.8*len(full))
    if dust_available:
        full["low_dust_grad"]=cohort_median_flag(full,"dust_grad_amp",True)
        full["low_dust_quad"]=cohort_median_flag(full,"dust_abs_quad",True)
    else:
        full["low_dust_grad"]=False
        full["low_dust_quad"]=False

    full["joint_low_density_dust_grad"]=(
        full["low_density_grad"] &
        (full["low_dust_grad"] if dust_available else True)
    )
    full["joint_density_clean"]=(
        full["low_density_grad"] & full["low_density_quad"] & full["low_faintfrac_grad"]
    )

    subsets=[
        ("all",pd.Series(True,index=full.index)),
        ("low_density_grad",full["low_density_grad"]),
        ("low_density_quad",full["low_density_quad"]),
        ("low_faintfrac_grad",full["low_faintfrac_grad"]),
        ("joint_density_clean",full["joint_density_clean"]),
    ]
    if dust_available:
        subsets += [
            ("low_dust_grad",full["low_dust_grad"]),
            ("low_dust_quad",full["low_dust_quad"]),
            ("joint_low_density_dust_grad",full["joint_low_density_dust_grad"]),
        ]

    subrows=[]; k=5000
    for label,mask in subsets:
        for sample in ["pooled","young","control"]:
            for role,mm in [("ALL_M1000",1000.0),("M3000",3000.0)]:
                use=mask & (full["MassJ"]>=mm)
                if sample!="pooled":
                    use &= (full["sample"]==sample)
                k+=1
                b=bootstrap_A(full.loc[use,"Y"],k)
                subrows.append({
                    "subset":label,"sample":sample,"role":role,**b,
                    "definition":"cohort-median local-systematics threshold; no Y used"
                })
    subsets_df=pd.DataFrame(subrows)
    subsets_df.to_csv(out/"06_alignment_in_low_gradient_subsets.csv",index=False)

    # ---------------- orientation diagnostics ----------------
    o1=orientation_summary(full,"density",8000)
    o2=orientation_summary(full,"dust",9000) if dust_available else pd.DataFrame()
    orient=pd.concat([o1,o2],ignore_index=True) if len(o2) else o1
    orient.to_csv(out/"07_cluster_vs_gradient_orientation.csv",index=False)

    full.to_csv(out/"08_combined_table_with_clean_flags.csv",index=False)

    # ---------------- report ----------------
    headline_corr=corr[corr["metric"].isin([
        "density_grad_amp","density_abs_quad","faintfrac_grad_amp",
        "dust_grad_amp","dust_abs_quad"
    ])]
    headline_sub=subsets_df[
        (subsets_df["sample"]=="pooled") &
        (subsets_df["role"]=="ALL_M1000") &
        (subsets_df["subset"].isin([
            "all","low_density_grad","joint_density_clean",
            "low_dust_grad","joint_low_density_dust_grad"
        ]))
    ]

    report=[
        f"YHMC STAGE-7C LOCAL DENSITY/DUST GRADIENT AUDIT v{VERSION}",
        "="*118,
        "POST_UNBLIND_REVIEWER_STRESS_TEST=True",
        "NO_NEW_PRIMARY_ENDPOINT=True",
        "NO_SAMPLE_RETUNING=True",
        f"YOUNG_FROZEN_SHA256={hy}",
        f"CONTROL_FROZEN_SHA256={hc}",
        f"TARGETS_N={len(full)}",
        f"GAIA_LOCAL_PROBE_COMPLETE_N={int(np.isfinite(full['density_grad_amp']).sum())}",
        f"DUST_COMPLETE4_N={int(np.isfinite(full['dust_grad_amp']).sum())}",
        f"DUST_AUDIT_AVAILABLE={dust_available}",
        f"PROBE_RADIUS_DEG={PROBE_RADIUS_DEG}",
        "PROBE_SEPARATION_RULE=max(rJ+0.10 deg, 0.25 deg)",
        "",
        "KEY COHORT-STRATIFIED CORRELATIONS:",
        headline_corr.to_string(index=False),
        "",
        "POOLED ALIGNMENT IN LOW-GRADIENT SUBSETS:",
        headline_sub[["subset","N","A","p025","p975"]].to_string(index=False),
        "",
        "GRADIENT-ORIENTATION DIAGNOSTICS (upper-half gradient amplitudes only):",
        orient.to_string(index=False) if len(orient) else "NA",
        "",
        "INTERPRETATION CEILING:",
        "  Gaia probe counts measure local DR3 source-density/faint-fraction anisotropy",
        "  immediately outside rJ; they do not rerun the membership classifier.",
        "  IRSA SandF/SFD E(B-V) is a 2D total-dust-column proxy to infinity, not",
        "  cluster-distance 3D extinction.",
        "  This stage therefore directly addresses directional local observational",
        "  gradients but cannot prove that every possible membership bias is absent.",
        "",
        "REVIEWER-CRITIQUE DECISION RULE:",
        "  Persistence of positive A in low-density/dust-gradient subsets, together",
        "  with weak Y-gradient correlations and weak cluster-gradient PA coupling,",
        "  substantially weakens a simple Galactic-plane-linked observational-gradient",
        "  explanation. Any non-negligible coupling must instead be reported explicitly.",
    ]
    (out/"STAGE7C_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    contract={
        "stage":"STAGE7C_LOCAL_DENSITY_DUST_GRADIENT_AUDIT",
        "version":VERSION,
        "status":"post-unblind reviewer stress test",
        "new_primary_endpoint":False,
        "sample_retuning":False,
        "probe_geometry":{
            "directions":["+l","-l","+b","-b"],
            "probe_radius_deg":PROBE_RADIUS_DEG,
            "probe_separation_rule":"max(rJ+0.10 deg, 0.25 deg)"
        },
        "gaia_probe":{
            "catalogue":"VizieR I/355/gaiadr3",
            "G_all_max":G_ALL_MAX,
            "G_bright_max":G_BRIGHT_MAX,
            "metrics":["source density gradient","parallel-perpendicular quadrupole",
                       "faint-source-fraction gradient"]
        },
        "dust_probe":{
            "service":"NASA/IPAC IRSA Dust Extinction Service",
            "value":"ext SandF ref E(B-V)",
            "interpretation":"2D total Galactic dust-column proxy; not cluster-distance extinction"
        },
        "interpretation_ceiling":"directional local-systematics stress test; not a direct membership-injection PA recovery"
    }
    (out/"STAGE7C_CONTRACT.json").write_text(json.dumps(contract,indent=2),encoding="utf-8")

    lines=[]
    for p in sorted(out.glob("*")):
        if p.is_file() and p.name!="SHA256SUMS.txt":
            lines.append(f"{sha256(p)}  {p.name}")
    (out/"SHA256SUMS.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")

    print((out/"STAGE7C_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

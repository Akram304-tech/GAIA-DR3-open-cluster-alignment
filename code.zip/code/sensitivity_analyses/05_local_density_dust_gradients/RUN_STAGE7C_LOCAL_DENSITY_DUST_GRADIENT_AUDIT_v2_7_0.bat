@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo YHMC STAGE-7C LOCAL DENSITY/DUST GRADIENT AUDIT v2.7.0
echo POST-UNBLIND REVIEWER STRESS TEST / NO SAMPLE RETUNING
echo ============================================================
set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" (
 echo ERROR: Python not found.
 exit /b 1
)
"%PYEXE%" discover_and_run_stage7c_v2_7_0.py
exit /b %ERRORLEVEL%

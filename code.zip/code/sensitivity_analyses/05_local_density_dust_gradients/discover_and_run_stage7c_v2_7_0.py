#!/usr/bin/env python
from __future__ import annotations
import hashlib, subprocess, sys
from pathlib import Path

YH="cc1d3ae4ce1cf52387f535da92fbd0dc5d984a3bb2dc750bf6672682e85f65dd"
CH="124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd"

def sha256(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def find_stage(d,marker,parent):
    hits=[p for p in d.rglob(marker) if p.is_file() and p.parent.name==parent]
    if not hits:
        raise FileNotFoundError(f"Missing {parent}/{marker}")
    return sorted(hits,key=lambda p:(("REBUILT_HISTORY" in str(p)),p.stat().st_mtime),reverse=True)[0].parent

def find_exact(d,name,expected):
    hits=[]
    for p in d.rglob(name):
        if p.is_file():
            try:
                if sha256(p)==expected: hits.append(p)
            except Exception: pass
    if not hits:
        raise FileNotFoundError(f"Exact {name} SHA not found: {expected}")
    return sorted(hits,key=lambda p:p.stat().st_mtime,reverse=True)[0]

def main():
    here=Path(__file__).resolve().parent
    d=Path.home()/"Downloads"
    print("="*112)
    print("YHMC STAGE-7C LOCAL DENSITY/DUST GRADIENT AUDIT v2.7.0")
    print("POST-UNBLIND REVIEWER STRESS TEST / NO SAMPLE RETUNING")
    print("="*112)

    s0=find_stage(d,"07_provisional_morphology_ready.csv","STAGE0_OUTPUT")
    s1c=find_stage(d,"01_alignment_cluster_table_UNBLINDED.csv","STAGE1C_OUTPUT")
    s2a=find_stage(d,"02_MATCHED_OLDER_CONTROLS_FROZEN.csv","STAGE2A_OUTPUT")
    s2d=find_stage(d,"01_control_alignment_UNBLINDED.csv","STAGE2D_OUTPUT")

    yf=find_exact(d,"02_PRIMARY_PA_SAMPLE_FROZEN.csv",YH)
    cf=find_exact(d,"02_CONTROL_PA_SAMPLE_FROZEN.csv",CH)
    s1b=yf.parent
    s2c=cf.parent

    for k,v in [("STAGE0",s0),("STAGE1B",s1b),("STAGE1C",s1c),
                ("STAGE2A",s2a),("STAGE2C",s2c),("STAGE2D",s2d)]:
        print(f"DISCOVERED_{k}={v}")
    print(f"YOUNG_FROZEN_SHA256={sha256(yf)}")
    print(f"CONTROL_FROZEN_SHA256={sha256(cf)}")

    # dependency/connectivity smoke test
    rc=subprocess.run([
        sys.executable,"-c",
        "import numpy,pandas,scipy,requests,astropy,astroquery"
    ]).returncode
    if rc!=0:
        print("ERROR: required packages missing: numpy pandas scipy requests astropy astroquery")
        raise SystemExit(1)

    out=here/"STAGE7C_OUTPUT"
    cmd=[
        sys.executable,str(here/"stage7c_local_density_dust_gradient_audit_v2_7_0.py"),
        "--stage0",str(s0),"--stage1b",str(s1b),"--stage1c",str(s1c),
        "--stage2a",str(s2a),"--stage2c",str(s2c),"--stage2d",str(s2d),
        "--out",str(out)
    ]
    rc=subprocess.run(cmd).returncode
    print()
    print(f"RETURN_CODE={rc}")
    if rc==0:
        print("STAGE7C_LOCAL_DENSITY_DUST_GRADIENT_AUDIT_PASS=True")
        print(f"REPORT={out/'STAGE7C_REPORT.txt'}")
    raise SystemExit(rc)

if __name__=="__main__":
    main()

YHMC Stage-7C local directional density/dust gradient audit v2.7.0
====================================================================

Purpose
-------
Directly stress-test the remaining reviewer concern that field-star density,
faint-source completeness, or extinction gradients aligned with Galactic structure
could bias recovered cluster shapes.

For each frozen admitted young/control cluster, the code places four 3-arcmin
background probes just outside rJ:
  +l, -l, +b, -b.

The probe-center separation is:
  max(rJ + 0.10 deg, 0.25 deg)

Data
----
Gaia DR3 source counts:
  VizieR I/355/gaiadr3
  G <= 20.5, plus G < 18 bright counts.
One union query per cluster is used for the four probes and cached locally.

Dust:
  NASA/IPAC IRSA Dust Extinction Service.
  Uses the Schlafly & Finkbeiner recalibrated "ext SandF ref" E(B-V) value
  at the same four probe positions. Queries are cached individually.

Important scientific limits
---------------------------
- Gaia background counts are an empirical local source-density/completeness proxy,
  not a rerun of the Hunt & Reffert membership classifier.
- IRSA SFD/SandF dust is total line-of-sight Galactic reddening to infinity,
  not 3D extinction at the cluster distance.
- This is a post-unblind reviewer stress test, not a new primary endpoint.

No sample threshold, mass cut, PA gate, or primary inference is altered.

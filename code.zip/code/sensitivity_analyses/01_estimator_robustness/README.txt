YHMC STAGE-3C ESTIMATOR ROBUSTNESS v1.1.0
==============================================

Question
--------
Is the Galactic-plane alignment driven by a few high-radius members that
have disproportionate leverage in ordinary second moments?

Sensitivity estimators
----------------------
CAP80:
  member radii are capped at the weighted 80th-percentile radius before
  computing the probability-weighted covariance tensor.

CAP90:
  same at the 90th percentile.

Capping is radial and rotation-invariant.

Each estimator gets its own blind synthetic q/PA calibration and its own
morphology gate. The baseline estimator is NOT replaced.

Run
---
call RUN_STAGE3C_ESTIMATOR_ROBUSTNESS_v1_1_0.bat

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-3C estimator robustness v1.1.0

Purpose
-------
Test whether the Galactic-plane alignment depends on the high radial leverage
of the ordinary second-moment estimator.

Exact frozen identities only:
  - 95 Stage-1B young PA-resolved clusters
  - 95 Stage-2C older-control PA-resolved clusters

Two pre-declared robust estimators:
  CAP80: probability-weighted second moments after capping each member's
         radius at the weighted 80th percentile radius.
  CAP90: same at the weighted 90th percentile.

The centre remains the probability-weighted centroid, preserving the baseline
centering convention. Capping is radial and therefore rotation-invariant.

For EACH estimator and EACH cluster:
  1) independently calibrate q/PA recovery on the actual radii and weights;
  2) recompute real q/PA;
  3) bootstrap uncertainty;
  4) apply the same four-part morphology-only gate;
  5) compute alignment only for admitted objects.

This is a sensitivity analysis; no estimator replaces the frozen baseline.
"""

from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path
import numpy as np
import pandas as pd

VERSION = "1.1.0"
SEED = 20260912
CAPS = [0.80, 0.90]
Q_GRID = [1.00,0.98,0.96,0.94,0.92,0.90,0.85,0.80,0.70,0.60]
N_SYNTH = 250
N_BOOT = 1500
N_PERM = 250000
N_SIGNFLIP = 250000

PA_P68_MAX = 20.0
PA_MED_MAX = 10.0
Q_BIAS_MED_MAX = 0.05
PRIMARY_MASS = 3000.0

EXPECTED_YOUNG_SHA256 = "cc1d3ae4ce1cf52387f535da92fbd0dc5d984a3bb2dc750bf6672682e85f65dd"
EXPECTED_CONTROL_SHA256 = "124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd"

def sha256(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda:f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()

def safe_name(s):
    return "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in str(s))

def find_member_file(member_dir,cid,name):
    hits=sorted(member_dir.glob(f"{int(cid):04d}_*.csv"))
    if not hits:
        return None
    if len(hits)==1:
        return hits[0]
    sn=safe_name(name)
    for p in hits:
        if sn in p.stem:
            return p
    return hits[0]

def tangent_xy_arcmin(ra,dec,ra0,dec0):
    ra=np.asarray(ra,float); dec=np.asarray(dec,float)
    dra=((ra-float(ra0)+180.0)%360.0)-180.0
    x=dra*math.cos(math.radians(float(dec0)))*60.0
    y=(dec-float(dec0))*60.0
    return x,y

def weighted_quantile(values, weights, q):
    v=np.asarray(values,float); w=np.asarray(weights,float)
    g=np.isfinite(v)&np.isfinite(w)&(w>0)
    v,w=v[g],w[g]
    if len(v)==0: return np.nan
    o=np.argsort(v); v,w=v[o],w[o]
    c=np.cumsum(w)
    target=float(q)*c[-1]
    return float(v[min(np.searchsorted(c,target,side="left"),len(v)-1)])

def capped_shape(x,y,w,cap_quantile):
    x=np.asarray(x,float); y=np.asarray(y,float); w=np.asarray(w,float)
    g=np.isfinite(x)&np.isfinite(y)&np.isfinite(w)&(w>0)
    x,y,w=x[g],y[g],w[g]
    if len(x)<3 or w.sum()<=0:
        return np.nan,np.nan,np.nan

    sw=w.sum()
    xc=np.sum(w*x)/sw
    yc=np.sum(w*y)/sw
    dx=x-xc; dy=y-yc
    r=np.hypot(dx,dy)
    rcap=weighted_quantile(r,w,cap_quantile)
    if not np.isfinite(rcap) or rcap<=0:
        return np.nan,np.nan,np.nan

    fac=np.ones_like(r)
    m=r>rcap
    fac[m]=rcap/r[m]
    ux=dx*fac; uy=dy*fac

    sxx=np.sum(w*ux*ux)/sw
    syy=np.sum(w*uy*uy)/sw
    sxy=np.sum(w*ux*uy)/sw
    C=np.array([[sxx,sxy],[sxy,syy]],float)

    vals,vecs=np.linalg.eigh(C)
    order=np.argsort(vals)[::-1]
    vals=vals[order]; vecs=vecs[:,order]
    if vals[0]<=0 or vals[1]<0:
        return np.nan,np.nan,rcap
    q=float(np.sqrt(max(vals[1],0.0)/vals[0]))
    vx,vy=vecs[:,0]
    pa=float(np.degrees(np.arctan2(vy,vx))%180.0)
    return q,pa,rcap

def neff(w):
    w=np.asarray(w,float)
    w=w[np.isfinite(w)&(w>0)]
    return float(w.sum()**2/np.square(w).sum()) if len(w) and np.square(w).sum()>0 else 0.0

def axial_diff(a,b):
    return ((np.asarray(a,float)-np.asarray(b,float)+90.0)%180.0)-90.0

def pct(x,p):
    x=np.asarray(x,float); x=x[np.isfinite(x)]
    return float(np.percentile(x,p)) if len(x) else np.nan

def med(x):
    x=np.asarray(x,float); x=x[np.isfinite(x)]
    return float(np.median(x)) if len(x) else np.nan

def local_gal_pa(ra,dec,eps=1e-3):
    from astropy.coordinates import SkyCoord
    import astropy.units as u
    c=SkyCoord(ra=float(ra)*u.deg,dec=float(dec)*u.deg,frame="icrs")
    g=c.galactic
    p=SkyCoord(l=g.l+eps*u.deg,b=g.b,frame="galactic").icrs
    m=SkyCoord(l=g.l-eps*u.deg,b=g.b,frame="galactic").icrs
    def xy(o):
        dra=((o.ra.deg-c.ra.deg+180.0)%360.0)-180.0
        return dra*math.cos(math.radians(c.dec.deg)), o.dec.deg-c.dec.deg
    xp,yp=xy(p); xm,ym=xy(m)
    return float(np.degrees(np.arctan2(yp-ym,xp-xm))%180.0)

def calibrate(r,w,cid,cap):
    out=[]
    ctag=int(round(cap*100))
    for qi,qtrue in enumerate(Q_GRID):
        rng=np.random.default_rng(np.random.SeedSequence([SEED,int(cid),ctag,qi,41]))
        qrec=np.full(N_SYNTH,np.nan)
        pae=np.full(N_SYNTH,np.nan)
        for k in range(N_SYNTH):
            th=rng.uniform(0,2*np.pi,len(r))
            phi=rng.uniform(0,np.pi)
            x0=r*np.cos(th)
            y0=qtrue*r*np.sin(th)
            cp=math.cos(phi); sp=math.sin(phi)
            x=cp*x0-sp*y0
            y=sp*x0+cp*y0
            qr,pr,_=capped_shape(x,y,w,cap)
            qrec[k]=qr
            if qtrue<0.999 and np.isfinite(pr):
                pae[k]=abs(float(axial_diff(pr,math.degrees(phi)%180.0)))
        rec={
            "q_true":qtrue,
            "qrec_p05":pct(qrec,5),
            "qrec_med":med(qrec),
            "qbias_med":med(qrec-qtrue),
        }
        if qtrue<0.999:
            rec["pa_med"]=med(pae)
            rec["pa_p68"]=pct(pae,68)
            rec["pass"]=bool(
                np.isfinite(rec["pa_p68"]) and
                rec["pa_p68"]<=PA_P68_MAX and
                rec["pa_med"]<=PA_MED_MAX and
                abs(rec["qbias_med"])<=Q_BIAS_MED_MAX
            )
        else:
            rec["pa_med"]=np.nan; rec["pa_p68"]=np.nan; rec["pass"]=False
        out.append(rec)

    g=pd.DataFrame(out)
    rr=g[np.isclose(g.q_true,1.0)].iloc[0]
    non=g[g.q_true<0.999]
    mp={float(row.q_true):bool(row["pass"]) for _,row in non.iterrows()}
    qs=sorted(mp)
    good=[]
    for q in qs:
        if all(mp[qq] for qq in qs if qq<=q):
            good.append(q)
    return float(rr.qrec_p05), (max(good) if good else np.nan)

def real_and_boot(x,y,w,cid,cap):
    q,pa,rc=capped_shape(x,y,w,cap)
    if not np.isfinite(q) or not np.isfinite(pa):
        return None
    n=len(x)
    rng=np.random.default_rng(np.random.SeedSequence([SEED,int(cid),int(round(cap*100)),88]))
    qs=np.full(N_BOOT,np.nan)
    pas=np.full(N_BOOT,np.nan)
    for k in range(N_BOOT):
        idx=rng.integers(0,n,n)
        qs[k],pas[k],_=capped_shape(x[idx],y[idx],w[idx],cap)
    dpa=np.abs(axial_diff(pas,pa))
    return {
        "q":q,"pa":pa,"rcap":rc,
        "q84":pct(qs,84),
        "pa_p68":pct(dpa,68),
    }

def position_perm(pa,gp,nperm,rng,chunk=20000):
    pa=np.asarray(pa,float); gp=np.asarray(gp,float); n=len(pa)
    obs=float(np.mean(np.cos(np.deg2rad(2*np.abs(axial_diff(pa,gp))))))
    vals=[]; rem=nperm
    while rem:
        k=min(chunk,rem)
        idx=np.argsort(rng.random((k,n)),axis=1)
        pp=pa[idx]
        d=np.abs(((pp-gp[None,:]+90.0)%180.0)-90.0)
        vals.append(np.mean(np.cos(np.deg2rad(2*d)),axis=1))
        rem-=k
    vals=np.concatenate(vals)
    p=float((1+np.count_nonzero(vals>=obs))/(len(vals)+1))
    return obs,p

def signflip(d,rng):
    d=np.asarray(d,float); n=len(d)
    obs=float(np.mean(d))
    vals=[]; rem=N_SIGNFLIP
    while rem:
        k=min(20000,rem)
        s=rng.choice(np.array([-1.0,1.0]),size=(k,n))
        vals.append(np.mean(s*d[None,:],axis=1))
        rem-=k
    vals=np.concatenate(vals)
    p=float((1+np.count_nonzero(vals>=obs))/(len(vals)+1))
    return obs,p

def prepare_young(y,stage0):
    if "__RAdeg" in y.columns and "__DEdeg" in y.columns:
        return y
    coord=stage0[["ID","Name","__RAdeg","__DEdeg"]]
    return y.merge(coord,on=["ID","Name"],how="left",validate="one_to_one")

def process(base,member_dir,label,cap):
    rows=[]
    for i,r in base.reset_index(drop=True).iterrows():
        cid=int(r["ID"]); name=str(r["Name"])
        mf=find_member_file(member_dir,cid,name)
        if mf is None:
            rows.append({"ID":cid,"Name":name,"status":"MISSING"})
            continue
        m=pd.read_csv(mf)
        p=pd.to_numeric(m["Prob"],errors="coerce").to_numpy(float)
        ra=pd.to_numeric(m["__RAdeg"],errors="coerce").to_numpy(float)
        de=pd.to_numeric(m["__DEdeg"],errors="coerce").to_numpy(float)
        g=np.isfinite(p)&np.isfinite(ra)&np.isfinite(de)&(p>=0.5)
        p,ra,de=p[g],ra[g],de[g]
        x,y=tangent_xy_arcmin(ra,de,r["__RAdeg"],r["__DEdeg"])
        gg=np.isfinite(x)&np.isfinite(y)&np.isfinite(p)&(p>0)
        x,y,p=x[gg],y[gg],p[gg]
        if len(x)<20 or neff(p)<10:
            rows.append({"ID":cid,"Name":name,"status":"TOO_FEW","N":len(x),"Neff":neff(p)})
            continue

        # Synthetic calibration uses actual baseline radii around catalogue centre.
        rad=np.hypot(x,y)
        qnull05,qmax=calibrate(rad,p,cid,cap)
        rm=real_and_boot(x,y,p,cid,cap)
        if rm is None:
            rows.append({"ID":cid,"Name":name,"status":"SHAPE_FAIL"})
            continue

        g1=np.isfinite(qmax)
        g2=g1 and rm["q84"]<=qmax
        g3=np.isfinite(qnull05) and rm["q"]<qnull05
        g4=np.isfinite(rm["pa_p68"]) and rm["pa_p68"]<=PA_P68_MAX
        admitted=bool(g1 and g2 and g3 and g4)

        gp=local_gal_pa(r["__RAdeg"],r["__DEdeg"])
        delta=abs(float(axial_diff(rm["pa"],gp)))
        baseline_pa=float(r["PA_deg_point"])
        pa_shift=abs(float(axial_diff(rm["pa"],baseline_pa)))

        rows.append({
            "ID":cid,"Name":name,"sample":label,"status":"OK",
            "MassJ":r["MassJ"],"logAge50":r.get("logAge50",np.nan),
            "__RAdeg":r["__RAdeg"],"__DEdeg":r["__DEdeg"],
            "N":len(x),"Neff":neff(p),
            "cap_quantile":cap,"q":rm["q"],"q84":rm["q84"],
            "PA_deg":rm["pa"],"PAerr68":rm["pa_p68"],
            "radius_cap_arcmin":rm["rcap"],
            "q_round_null_p05":qnull05,"qmax":qmax,
            "gate1":g1,"gate2":g2,"gate3":g3,"gate4":g4,
            "admitted":admitted,
            "PA_Gal":gp,"Delta":delta,
            "cos2Delta":math.cos(math.radians(2*delta)),
            "baseline_PA_deg":baseline_pa,
            "abs_PA_shift_from_baseline_deg":pa_shift,
        })
    return pd.DataFrame(rows)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage0",required=True)
    ap.add_argument("--stage1b",required=True)
    ap.add_argument("--stage2a",required=True)
    ap.add_argument("--stage2c",required=True)
    ap.add_argument("--out",default="STAGE3C_OUTPUT")
    args=ap.parse_args()

    stage0=Path(args.stage0).resolve()
    stage1b=Path(args.stage1b).resolve()
    stage2a=Path(args.stage2a).resolve()
    stage2c=Path(args.stage2c).resolve()
    out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=True)

    yf=stage1b/"02_PRIMARY_PA_SAMPLE_FROZEN.csv"
    cf=stage2c/"02_CONTROL_PA_SAMPLE_FROZEN.csv"
    if sha256(yf)!=EXPECTED_YOUNG_SHA256:
        raise RuntimeError("Young frozen sample hash mismatch.")
    if sha256(cf)!=EXPECTED_CONTROL_SHA256:
        raise RuntimeError("Control frozen sample hash mismatch.")

    y=prepare_young(pd.read_csv(yf),pd.read_csv(stage0/"07_provisional_morphology_ready.csv"))
    c=pd.read_csv(cf)
    ymem=stage0/"members_primary"
    cmem=stage2a/"members_control_frozen"

    print("="*96)
    print(f"YHMC STAGE-3C ESTIMATOR ROBUSTNESS v{VERSION}")
    print("="*96)
    print("CHAIN_OF_CUSTODY=PASS")
    print(f"YOUNG_FROZEN_N={len(y)} CONTROL_FROZEN_N={len(c)}")
    print(f"CAP_QUANTILES={CAPS}")
    print("Each estimator gets independent synthetic calibration.")

    align_rows=[]
    matched_rows=[]
    pa_agree_rows=[]

    for cap in CAPS:
        tag=f"CAP{int(round(cap*100))}"
        print(f"\n--- {tag} ---")
        yr=process(y,ymem,"young",cap)
        cr=process(c,cmem,"control",cap)
        yr.to_csv(out/f"01_{tag}_young_estimator_reanalysis.csv",index=False)
        cr.to_csv(out/f"02_{tag}_control_estimator_reanalysis.csv",index=False)

        for label,df in [("young",yr),("control",cr)]:
            ok=df[(df.status=="OK")&(df.admitted==True)].copy()
            for mass in [1000,3000]:
                s=ok[pd.to_numeric(ok.MassJ,errors="coerce")>=mass]
                if len(s)>=2:
                    rng=np.random.default_rng(np.random.SeedSequence([
                        SEED,int(cap*100),mass,1 if label=="young" else 2
                    ]))
                    A,pp=position_perm(s.PA_deg,s.PA_Gal,N_PERM,rng)
                elif len(s)==1:
                    A=float(s.cos2Delta.iloc[0]); pp=np.nan
                else:
                    A=pp=np.nan
                align_rows.append({
                    "estimator":tag,"sample":label,"MassJ_threshold":mass,
                    "N_admitted":len(s),"A":A,"PA_position_perm_p":pp,
                    "median_Delta_deg":float(s.Delta.median()) if len(s) else np.nan,
                    "median_abs_PA_shift_from_baseline_deg":
                        float(s.abs_PA_shift_from_baseline_deg.median()) if len(s) else np.nan,
                })

            common=df[df.status=="OK"]
            pa_agree_rows.append({
                "estimator":tag,"sample":label,"N_shape_OK":len(common),
                "median_abs_PA_shift_deg":float(common.abs_PA_shift_from_baseline_deg.median()) if len(common) else np.nan,
                "p90_abs_PA_shift_deg":float(common.abs_PA_shift_from_baseline_deg.quantile(0.90)) if len(common) else np.nan,
                "fraction_PA_shift_le10deg":float(np.mean(common.abs_PA_shift_from_baseline_deg<=10)) if len(common) else np.nan,
                "N_admitted":int(common.admitted.sum()) if len(common) else 0,
            })

        # matched contrast among estimator-admitted objects
        ya=yr[(yr.status=="OK")&(yr.admitted==True)].copy()
        ca=cr[(cr.status=="OK")&(cr.admitted==True)].copy()
        cmap=c[["ID","Name","young_ID","young_Name"]]
        ca=ca.merge(cmap,on=["ID","Name"],how="left",validate="one_to_one")
        cagg=ca.groupby(["young_ID","young_Name"],as_index=False).agg(
            cmean=("cos2Delta","mean"),Ncontrol=("ID","size")
        )
        ys=ya[["ID","Name","MassJ","cos2Delta"]].rename(columns={
            "ID":"young_ID","Name":"young_Name","MassJ":"MassJ_young","cos2Delta":"ycos"
        })
        a=ys.merge(cagg,on=["young_ID","young_Name"],how="inner",validate="one_to_one")
        a["D"]=a.ycos-a.cmean
        a.to_csv(out/f"03_{tag}_matched_anchor_table.csv",index=False)

        for role,mask in [
            ("PRIMARY_M3000",pd.to_numeric(a.MassJ_young,errors="coerce")>=PRIMARY_MASS),
            ("EXTENDED",np.ones(len(a),dtype=bool))
        ]:
            s=a.loc[mask]
            if len(s)>=2:
                rng=np.random.default_rng(np.random.SeedSequence([
                    SEED,int(cap*100),700 if role=="PRIMARY_M3000" else 701
                ]))
                D,ps=signflip(s.D.to_numpy(float),rng)
            elif len(s)==1:
                D=float(s.D.iloc[0]); ps=np.nan
            else:
                D=ps=np.nan
            matched_rows.append({
                "estimator":tag,"ROLE":role,"N_anchors":len(s),
                "A_young":float(s.ycos.mean()) if len(s) else np.nan,
                "A_control_anchor":float(s.cmean.mean()) if len(s) else np.nan,
                "D":D,"signflip_p_D_gt0":ps,
                "fraction_D_gt0":float(np.mean(s.D>0)) if len(s) else np.nan,
            })

        print(
            f"{tag}: young admitted={int(((yr.status=='OK')&(yr.admitted==True)).sum())}, "
            f"control admitted={int(((cr.status=='OK')&(cr.admitted==True)).sum())}, "
            f"matched anchors={len(a)}"
        )

    aligns=pd.DataFrame(align_rows)
    matched=pd.DataFrame(matched_rows)
    paagree=pd.DataFrame(pa_agree_rows)
    aligns.to_csv(out/"04_estimator_alignment_summary.csv",index=False)
    matched.to_csv(out/"05_estimator_matched_contrast_summary.csv",index=False)
    paagree.to_csv(out/"06_baseline_vs_robust_PA_agreement.csv",index=False)

    contract={
        "stage":"STAGE3C_ESTIMATOR_ROBUSTNESS",
        "version":VERSION,
        "young_frozen_sha256":sha256(yf),
        "control_frozen_sha256":sha256(cf),
        "estimators":{
            "CAP80":"radial winsorization at weighted 80th percentile radius",
            "CAP90":"radial winsorization at weighted 90th percentile radius",
        },
        "centre":"probability-weighted centroid",
        "rotation_invariant_radial_capping":True,
        "q_grid":Q_GRID,
        "n_synthetic_per_q":N_SYNTH,
        "n_bootstrap":N_BOOT,
        "gate":"same four-part morphology gate, independently recalibrated for each estimator",
        "baseline_replacement":False,
    }
    (out/"STAGE3C_CONTRACT.json").write_text(json.dumps(contract,indent=2),encoding="utf-8")

    report=[
        f"YHMC STAGE-3C ESTIMATOR ROBUSTNESS v{VERSION}",
        "="*96,
        "CHAIN_OF_CUSTODY=PASS",
        "Exact frozen young/control identities only.",
        "CAP80 and CAP90 independently calibrated before real morphology admission.",
        "",
        "ALIGNMENT SUMMARY:",
        aligns.to_string(index=False),
        "",
        "MATCHED AGE-CONTRAST SUMMARY:",
        matched.to_string(index=False),
        "",
        "BASELINE-vs-ROBUST PA AGREEMENT:",
        paagree.to_string(index=False),
        "",
        "INTERPRETATION:",
        "  The common Galactic-plane alignment is estimator-robust if A remains strongly",
        "  positive with small PA-position permutation p for both CAP80 and CAP90.",
        "  Large systematic PA shifts or loss of Galactic specificity would indicate",
        "  that baseline second moments are driven by high-leverage outer members.",
        "",
        "NEXT:",
        "  Independently calibrate inner r<r50J morphology before any radial inference.",
    ]
    (out/"STAGE3C_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")

    print()
    print((out/"STAGE3C_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo YHMC STAGE-7B CLUSTER-LEVEL SELECTION/ENVIRONMENT AUDIT v2.6.1
echo FROZEN-ROW REBIND / NO MEMBER FILE / NO REMATCHING
echo ============================================================
set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" (
 echo ERROR: Python not found.
 exit /b 1
)
"%PYEXE%" discover_and_run_stage7b_cluster_audit_v2_6_1.py
exit /b %ERRORLEVEL%

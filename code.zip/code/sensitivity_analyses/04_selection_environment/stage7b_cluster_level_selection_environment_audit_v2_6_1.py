#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-7B Cluster-Level Selection / Environment Audit v2.6.0

POST-UNBLIND REVIEWER STRESS TEST.
NO NEW PRIMARY ENDPOINT.
NO REMATCHING.
NO MEMBER-LEVEL ORIENTATION CLAIM.

Why this stage exists
---------------------
Hunt et al. (2026) provides:
  clusters.dat : 233,917 injection/retrieval rows (queryable and already cached)
  members.csv  : 50,873,539-row ancillary file

On the current workstation/network, the ancillary members.csv is inaccessible via
tested HTTP direct-file, HTTP Range, HTTP streaming, and anonymous FTP routes.
Therefore a direct recovered-shape injection test cannot be executed responsibly.

This stage uses the already-frozen outcome-blind R2 injection matches and the
cluster-level Hunt+2026 recovery statistics to test a narrower but important question:

  Is the observed Galactic-plane alignment concentrated in environments where
  injection recovery is incomplete/contaminated or where extinction / Gaia
  completeness conditions are adverse?

This audit can weaken or strengthen an observational-selection explanation, but it
CANNOT by itself exclude a directional morphology bias within individual fields.
"""

from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
import statsmodels.api as sm

VERSION="2.6.1"
SEED=20261027
N_PERM=100000
N_BOOT=100000
EXPECTED_MATCH_SHA="40fff1276a3899a37a5e08090fe627de3e05c314d225b8f6d501bd42503bd919"
EXPECTED_YOUNG_SHA="cc1d3ae4ce1cf52387f535da92fbd0dc5d984a3bb2dc750bf6672682e85f65dd"
EXPECTED_CONTROL_SHA="124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd"

def sha256(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def boolish(v):
    return str(v).strip().lower() in {"1","true","t","yes","y"}

def bootstrap_mean(x,seed_tag):
    x=np.asarray(x,float); x=x[np.isfinite(x)]
    if len(x)==0:
        return dict(N=0,A=np.nan,p025=np.nan,p16=np.nan,p84=np.nan,p975=np.nan)
    rng=np.random.default_rng(np.random.SeedSequence([SEED,seed_tag]))
    vals=np.empty(N_BOOT,float)
    n=len(x)
    for lo in range(0,N_BOOT,10000):
        hi=min(N_BOOT,lo+10000)
        ix=rng.integers(0,n,size=(hi-lo,n))
        vals[lo:hi]=np.mean(x[ix],axis=1)
    return dict(
        N=n,A=float(np.mean(x)),
        p025=float(np.percentile(vals,2.5)),
        p16=float(np.percentile(vals,16)),
        p84=float(np.percentile(vals,84)),
        p975=float(np.percentile(vals,97.5)),
    )

def perm_spearman_stratified(df,metric,seed_tag):
    d=df[["sample","target_Y_real",metric]].replace([np.inf,-np.inf],np.nan).dropna().copy()
    if len(d)<8:
        return dict(N=len(d),rho=np.nan,p=np.nan)
    y=d["target_Y_real"].to_numpy(float)
    x=d[metric].to_numpy(float)
    rho=float(spearmanr(y,x).statistic)
    groups=d["sample"].astype(str).to_numpy()
    uniq=np.unique(groups)
    idxs=[np.where(groups==g)[0] for g in uniq]
    rng=np.random.default_rng(np.random.SeedSequence([SEED,seed_tag]))
    extreme=0
    done=0
    for lo in range(0,N_PERM,2000):
        m=min(2000,N_PERM-lo)
        yp=np.tile(y,(m,1))
        for ix in idxs:
            for j in range(m):
                yp[j,ix]=y[ix][rng.permutation(len(ix))]
        # rank once for x; rank each row for y permutations
        xr=pd.Series(x).rank(method="average").to_numpy(float)
        xr=xr-xr.mean()
        denomx=np.sqrt(np.sum(xr*xr))
        vals=np.empty(m,float)
        for j in range(m):
            yr=pd.Series(yp[j]).rank(method="average").to_numpy(float)
            yr=yr-yr.mean()
            denomy=np.sqrt(np.sum(yr*yr))
            vals[j]=np.sum(xr*yr)/(denomx*denomy) if denomx>0 and denomy>0 else np.nan
        extreme += int(np.sum(np.abs(vals)>=abs(rho)))
        done += m
    p=(extreme+1)/(done+1)
    return dict(N=len(d),rho=rho,p=float(p))

def spearman_simple(df,metric):
    d=df[["target_Y_real",metric]].replace([np.inf,-np.inf],np.nan).dropna()
    if len(d)<5: return dict(N=len(d),rho=np.nan,p=np.nan)
    r=spearmanr(d["target_Y_real"],d[metric])
    return dict(N=len(d),rho=float(r.statistic),p=float(r.pvalue))

def cohort_median_flag(df,col,direction):
    out=np.zeros(len(df),bool)
    for s,g in df.groupby("sample"):
        vals=pd.to_numeric(g[col],errors="coerce")
        med=float(vals.median())
        if direction=="low":
            flag=vals<=med
        else:
            flag=vals>=med
        out[g.index.to_numpy()]=flag.to_numpy(bool)
    return out

def zscore(s):
    a=pd.to_numeric(s,errors="coerce").astype(float)
    mu=float(a.mean()); sd=float(a.std(ddof=1))
    if not np.isfinite(sd) or sd<=0: return pd.Series(np.zeros(len(a)),index=a.index)
    return (a-mu)/sd

def _num_close(a,b,rtol=1e-9,atol=1e-9):
    aa=pd.to_numeric(a,errors="coerce").to_numpy(float)
    bb=float(b)
    return np.isfinite(aa) & np.isclose(aa,bb,rtol=rtol,atol=atol)

def _resolve_frozen_hunt_rows(matches,hunt,outdir):
    """
    Rebind each frozen R2 match to its original Hunt+2026 clusters.dat row.

    Important:
      - no rematching;
      - no use of target alignment Y;
      - candidate resolution uses only identifiers and Hunt covariates that were
        already stored in the frozen R2 match table;
      - duplicate representations may be collapsed only if all audit-relevant
        Hunt fields are identical.
    """
    h=hunt.copy()
    h["Cluster"]=pd.to_numeric(h["Cluster"],errors="coerce").astype("Int64")
    h["Det"]=h["Det"].astype(str).str.strip()

    # Fields copied into the frozen R2 match table when matching was executed.
    frozen_pairs=[
        ("NsimDet","inj_NsimDet","integer"),
        ("Nnoise","inj_Nnoise","integer"),
        ("GLON","inj_GLON","float"),
        ("GLAT","inj_GLAT","float"),
        ("Dist","inj_Dist","float"),
        ("Mass","inj_Mass","float"),
        ("logAge","inj_logAge","float"),
        ("Ext","inj_Ext","float"),
    ]

    relevant=[
        "BestDet","cst","Nstars","Nsim","NsimDet","Nnoise","NHunt23",
        "GLON","GLAT","Dist","Mass","logAge","Ext","m10"
    ]
    records=[]
    audit=[]

    for _,r in matches.iterrows():
        cid=int(r["inj_Cluster"])
        det=str(r["inj_Det"]).strip()
        cand=h[(h["Cluster"]==cid) & (h["Det"]==det)].copy()
        n_initial=len(cand)

        # R2 matching pool was restricted to BestDet.
        if "BestDet" in cand.columns:
            bmask=cand["BestDet"].map(boolish)
            if bmask.any():
                cand=cand[bmask].copy()

        # Exact integer identity anchors first.
        for src,frozen,kind in frozen_pairs:
            if frozen not in r.index or src not in cand.columns:
                continue
            val=r[frozen]
            if pd.isna(val):
                continue
            if kind=="integer":
                x=pd.to_numeric(cand[src],errors="coerce")
                mask=(x==int(round(float(val))))
            else:
                mask=_num_close(cand[src],float(val))
            if mask.any():
                cand=cand[mask].copy()

        n_after=len(cand)
        if n_after==0:
            raise RuntimeError(
                f"Frozen-row rebind failed: no Hunt row remains for "
                f"Cluster={cid}, Det={det}; initial_candidates={n_initial}."
            )

        # If several rows remain, they may only be collapsed when every
        # audit-relevant field is identical after numeric normalization.
        collapsed_identical=False
        if n_after>1:
            sig_cols=[c for c in relevant if c in cand.columns]
            sig=cand[sig_cols].copy()
            for c in sig_cols:
                if c=="BestDet":
                    sig[c]=sig[c].map(boolish)
                else:
                    num=pd.to_numeric(sig[c],errors="coerce")
                    if num.notna().any():
                        sig[c]=num.round(12)
                    else:
                        sig[c]=sig[c].astype(str).str.strip()
            nunique=len(sig.drop_duplicates())
            if nunique!=1:
                # Write candidates to make the failure fully inspectable.
                fail=Path(outdir)/f"FAILED_REBIND_cluster_{cid}_det_{det}.csv"
                cand.to_csv(fail,index=False)
                raise RuntimeError(
                    f"Ambiguous frozen-row rebind for Cluster={cid}, Det={det}: "
                    f"{n_after} candidates remain and differ in audit-relevant fields. "
                    f"Candidates written to {fail}. No arbitrary row was selected."
                )
            collapsed_identical=True

        chosen=cand.iloc[0]
        rec=r.to_dict()
        for c in h.columns:
            if c in ["Cluster","Det"]:
                continue
            rec[f"hunt_{c}"]=chosen[c]
        records.append(rec)
        audit.append({
            "inj_Cluster":cid,
            "inj_Det":det,
            "initial_ClusterDet_candidates":n_initial,
            "candidates_after_frozen_identity":n_after,
            "collapsed_identical_duplicates":collapsed_identical,
        })

    resolved=pd.DataFrame(records)
    audit_df=pd.DataFrame(audit)
    audit_df.to_csv(Path(outdir)/"00_frozen_hunt_row_rebind_audit.csv",index=False)
    return resolved

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--matches",required=True)
    ap.add_argument("--hunt-cache",required=True)
    ap.add_argument("--young-frozen",required=True)
    ap.add_argument("--control-frozen",required=True)
    ap.add_argument("--out",default="STAGE7B_CLUSTERAUDIT_OUTPUT")
    args=ap.parse_args()

    mp=Path(args.matches).resolve()
    hp=Path(args.hunt_cache).resolve()
    yp=Path(args.young_frozen).resolve()
    cp=Path(args.control_frozen).resolve()
    out=Path(args.out).resolve(); out.mkdir(parents=True,exist_ok=True)

    # -------- identity gates --------
    hashes={
        "r2_match_table":sha256(mp),
        "young_frozen":sha256(yp),
        "control_frozen":sha256(cp),
        "hunt_cluster_cache":sha256(hp),
    }
    if hashes["r2_match_table"]!=EXPECTED_MATCH_SHA:
        raise RuntimeError("Exact frozen R2 match-table SHA mismatch; refusing to proceed.")
    if hashes["young_frozen"]!=EXPECTED_YOUNG_SHA:
        raise RuntimeError("Young frozen sample SHA mismatch.")
    if hashes["control_frozen"]!=EXPECTED_CONTROL_SHA:
        raise RuntimeError("Control frozen sample SHA mismatch.")

    matches=pd.read_csv(mp)
    hunt=pd.read_csv(hp)

    # -------- bind exact injection row --------
    need=["Cluster","Det","BestDet","cst","Nstars","Nsim","NsimDet","Nnoise",
          "NHunt23","GLON","GLAT","Dist","Mass","logAge","Ext","m10"]
    missing=[c for c in need if c not in hunt.columns]
    if missing:
        raise RuntimeError(f"Hunt cache missing required columns: {missing}")

    matches["inj_Cluster"]=pd.to_numeric(matches["inj_Cluster"],errors="raise").astype(int)
    matches["inj_Det"]=matches["inj_Det"].astype(str).str.strip()

    # Rebind to the exact original Hunt row using only frozen R2 injection identity
    # covariates. Cluster+Det alone is not unique because simulated clusters may
    # have multiple HDBSCAN detection-attempt rows.
    joined=_resolve_frozen_hunt_rows(matches,hunt,out)

    if "hunt_Nsim" not in joined.columns or joined["hunt_Nsim"].isna().any():
        raise RuntimeError("Frozen Hunt-row rebind did not produce complete Nsim values.")

    # numeric columns
    numeric=[
        "target_Y_real","target_MassJ","target_dist_pc","target_logAge","target_AV",
        "target_GLON","target_GLAT","target_N",
        "hunt_cst","hunt_Nstars","hunt_Nsim","hunt_NsimDet","hunt_Nnoise","hunt_NHunt23",
        "hunt_GLON","hunt_GLAT","hunt_Dist","hunt_Mass","hunt_logAge","hunt_Ext","hunt_m10",
    ]
    for c in numeric:
        if c in joined.columns:
            joined[c]=pd.to_numeric(joined[c],errors="coerce")

    joined["recovery_completeness"]=joined["hunt_NsimDet"]/joined["hunt_Nsim"]
    joined["recovery_contamination"]=joined["hunt_Nnoise"]/joined["hunt_Nstars"]
    joined["recovery_true_fraction"]=joined["hunt_NsimDet"]/joined["hunt_Nstars"]
    joined["target_abs_b"]=joined["target_GLAT"].abs()
    joined["inj_abs_b"]=joined["hunt_GLAT"].abs()
    joined["target_logMass"]=np.log10(joined["target_MassJ"])
    joined["target_logDist"]=np.log10(joined["target_dist_pc"])
    joined["target_logN"]=np.log10(joined["target_N"])

    joined.to_csv(out/"01_exact_matched_recovery_environment_table.csv",index=False)

    # -------- correlations with observed alignment outcome --------
    metrics=[
        "recovery_completeness","recovery_contamination","recovery_true_fraction",
        "hunt_cst","hunt_m10","target_AV","target_abs_b","hunt_Ext","inj_abs_b",
    ]
    corr_rows=[]
    seed=1000
    for metric in metrics:
        seed+=1
        z=perm_spearman_stratified(joined,metric,seed)
        corr_rows.append({
            "sample":"pooled_cohort_stratified","metric":metric,
            "N":z["N"],"rho_spearman":z["rho"],"p_two_sided":z["p"],
            "test":"100000 permutations; Y shuffled within young/control cohort"
        })
        for sample,g in joined.groupby("sample"):
            q=spearman_simple(g,metric)
            corr_rows.append({
                "sample":sample,"metric":metric,"N":q["N"],
                "rho_spearman":q["rho"],"p_two_sided":q["p"],
                "test":"descriptive ordinary Spearman"
            })
    corr=pd.DataFrame(corr_rows)
    corr.to_csv(out/"02_alignment_vs_selection_environment_correlations.csv",index=False)

    # -------- clean/adverse subsets defined WITHOUT Y --------
    joined["low_target_extinction"]=cohort_median_flag(joined,"target_AV","low")
    joined["high_abs_b"]=cohort_median_flag(joined,"target_abs_b","high")
    joined["high_recovery"]=cohort_median_flag(joined,"recovery_completeness","high")
    joined["low_contamination"]=cohort_median_flag(joined,"recovery_contamination","low")
    joined["favorable_m10"]=cohort_median_flag(joined,"hunt_m10","high")
    joined["environment_clean"]=joined["low_target_extinction"] & joined["high_abs_b"]
    joined["recovery_clean"]=joined["high_recovery"] & joined["low_contamination"]
    joined["joint_clean"]=joined["environment_clean"] & joined["recovery_clean"]

    subset_defs=[
        ("all",np.ones(len(joined),bool)),
        ("low_target_extinction",joined["low_target_extinction"].to_numpy(bool)),
        ("high_abs_b",joined["high_abs_b"].to_numpy(bool)),
        ("high_recovery",joined["high_recovery"].to_numpy(bool)),
        ("low_contamination",joined["low_contamination"].to_numpy(bool)),
        ("favorable_m10",joined["favorable_m10"].to_numpy(bool)),
        ("environment_clean",joined["environment_clean"].to_numpy(bool)),
        ("recovery_clean",joined["recovery_clean"].to_numpy(bool)),
        ("joint_clean",joined["joint_clean"].to_numpy(bool)),
    ]
    subset_rows=[]
    seed=5000
    for label,mask in subset_defs:
        for sample in ["pooled","young","control"]:
            seed+=1
            use=mask if sample=="pooled" else (mask & (joined["sample"].astype(str).to_numpy()==sample))
            b=bootstrap_mean(joined.loc[use,"target_Y_real"],seed)
            subset_rows.append({
                "subset":label,"sample":sample,**b,
                "definition_note":"cohort-median thresholds; no Y used to define subset"
            })
    subsets=pd.DataFrame(subset_rows)
    subsets.to_csv(out/"03_alignment_in_clean_selection_environment_subsets.csv",index=False)

    # -------- multivariable exploratory HC3 regression --------
    reg=joined.copy()
    cols=[
        "target_Y_real","sample","target_logMass","target_logDist","target_logN",
        "target_AV","target_abs_b","recovery_completeness","recovery_contamination","hunt_m10"
    ]
    reg=reg[cols].replace([np.inf,-np.inf],np.nan).dropna().copy()
    X=pd.DataFrame(index=reg.index)
    X["control_indicator"]=(reg["sample"].astype(str)=="control").astype(float)
    for c in ["target_logMass","target_logDist","target_logN","target_AV","target_abs_b",
              "recovery_completeness","recovery_contamination","hunt_m10"]:
        X["z_"+c]=zscore(reg[c])
    X=sm.add_constant(X,has_constant="add")
    fit=sm.OLS(reg["target_Y_real"].astype(float),X).fit(cov_type="HC3")
    rr=pd.DataFrame({
        "term":fit.params.index,
        "coef":fit.params.values,
        "se_HC3":fit.bse.values,
        "p_HC3":fit.pvalues.values,
        "ci95_lo":fit.conf_int().iloc[:,0].values,
        "ci95_hi":fit.conf_int().iloc[:,1].values,
    })
    rr["N"]=len(reg)
    rr["analysis_status"]="exploratory reviewer stress test; not a new primary endpoint"
    rr.to_csv(out/"04_exploratory_HC3_selection_environment_regression.csv",index=False)

    # -------- environment/recovery summaries --------
    sum_rows=[]
    for sample in ["pooled","young","control"]:
        d=joined if sample=="pooled" else joined[joined["sample"]==sample]
        for c in [
            "recovery_completeness","recovery_contamination","recovery_true_fraction",
            "hunt_cst","hunt_m10","target_AV","target_abs_b"
        ]:
            x=pd.to_numeric(d[c],errors="coerce").dropna()
            sum_rows.append({
                "sample":sample,"metric":c,"N":len(x),
                "median":float(x.median()),"p16":float(x.quantile(.16)),
                "p84":float(x.quantile(.84)),"min":float(x.min()),"max":float(x.max())
            })
    pd.DataFrame(sum_rows).to_csv(out/"05_selection_environment_summary.csv",index=False)

    joined.to_csv(out/"06_matched_table_with_clean_flags.csv",index=False)

    # -------- headline report --------
    pooled=corr[corr["sample"]=="pooled_cohort_stratified"].copy()
    keyterms=rr[rr["term"].isin([
        "z_target_AV","z_target_abs_b","z_recovery_completeness",
        "z_recovery_contamination","z_hunt_m10"
    ])]
    clean=subsets[(subsets["sample"]=="pooled") &
                  (subsets["subset"].isin(["all","environment_clean","recovery_clean","joint_clean"]))]

    report=[
        f"YHMC STAGE-7B CLUSTER-LEVEL SELECTION / ENVIRONMENT AUDIT v{VERSION}",
        "="*116,
        "POST_UNBLIND_REVIEWER_STRESS_TEST=True",
        "NO_NEW_PRIMARY_ENDPOINT=True",
        "NO_REMATCHING=True",
        "HUNT_ROW_REBIND=exact frozen R2 identity fields; no Y used; ambiguous non-identical duplicates forbidden",
        "MEMBER_LEVEL_ORIENTATION_TEST_EXECUTED=False",
        "MEMBER_LEVEL_REASON=Hunt+2026 ancillary members.csv inaccessible on current network via tested HTTP/FTP routes",
        f"EXACT_R2_MATCH_SHA256={hashes['r2_match_table']}",
        f"YOUNG_FROZEN_SHA256={hashes['young_frozen']}",
        f"CONTROL_FROZEN_SHA256={hashes['control_frozen']}",
        f"MATCHED_TARGETS_N={len(joined)}",
        "",
        "POOLED COHORT-STRATIFIED SPEARMAN TESTS: target Y=cos(2 Delta_GP) vs selection/environment",
        pooled[["metric","N","rho_spearman","p_two_sided"]].to_string(index=False),
        "",
        "CLEAN-SUBSET ALIGNMENT:",
        clean[["subset","N","A","p025","p975"]].to_string(index=False),
        "",
        "EXPLORATORY HC3 TERMS:",
        keyterms[["term","coef","se_HC3","p_HC3","ci95_lo","ci95_hi"]].to_string(index=False),
        "",
        "INTERPRETATION CEILING:",
        "  This audit tests whether the observed alignment is concentrated in adverse",
        "  recovery, contamination, extinction, latitude, or Gaia-completeness regimes.",
        "  It does NOT measure the orientation of recovered synthetic clusters and therefore",
        "  cannot, by itself, rule out a directional morphology bias within individual fields.",
        "  Any manuscript claim must preserve that limitation.",
        "",
        "DECISION FOR REVIEWER CRITIQUE #1:",
        "  If Y shows no material association with the recovery/environment metrics and",
        "  A remains strongly positive in environment-clean and recovery-clean subsets,",
        "  the simple selection-severity explanation is weakened but not eliminated.",
        "  A direct local field-density/dust-gradient audit remains the strongest next test.",
    ]
    (out/"STAGE7B_CLUSTER_LEVEL_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    contract={
        "stage":"STAGE7B_CLUSTER_LEVEL_SELECTION_ENVIRONMENT_AUDIT",
        "version":VERSION,
        "post_unblind_reviewer_stress_test":True,
        "new_primary_endpoint":False,
        "rematching":False,
        "exact_r2_match_sha256":hashes["r2_match_table"],
        "member_level_orientation_test_executed":False,
        "member_level_limitation":"ancillary members.csv inaccessible over tested network routes",
        "tests":[
            "cohort-stratified Spearman Y vs recovery completeness/contamination/cst/m10/extinction/|b|",
            "alignment in clean subsets defined without Y",
            "exploratory HC3 multivariable regression"
        ],
        "interpretation_ceiling":"selection-severity stress test only; cannot exclude directional within-field morphology bias"
    }
    (out/"STAGE7B_CLUSTER_LEVEL_CONTRACT.json").write_text(json.dumps(contract,indent=2),encoding="utf-8")

    # hashes
    lines=[]
    for p in sorted(out.glob("*")):
        if p.is_file() and p.name!="SHA256SUMS.txt":
            lines.append(f"{sha256(p)}  {p.name}")
    (out/"SHA256SUMS.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")

    print((out/"STAGE7B_CLUSTER_LEVEL_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

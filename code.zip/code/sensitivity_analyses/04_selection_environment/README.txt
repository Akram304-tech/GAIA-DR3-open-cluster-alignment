YHMC Stage-7B cluster-level selection/environment audit v2.6.1
================================================================

Fix relative to v2.6.0
----------------------
Hunt+2026 clusters.dat may contain several rows per simulated Cluster because the
cluster can be detected in different HDBSCAN min_cluster_size runs. The v2.6.0
one-to-one merge on (Cluster, Det) was therefore too strict.

v2.6.1 does NOT rematch. For every frozen R2 injection it rebinds the original
clusters.dat row using:
  Cluster, Det, BestDet status,
  NsimDet, Nnoise, GLON, GLAT, Dist, Mass, logAge, Ext
that were already stored when the outcome-blind R2 match table was created.

If several rows remain:
  - they are collapsed only when all audit-relevant Hunt fields are identical;
  - if they differ, the audit stops and writes the ambiguous candidates.
No arbitrary row is selected and target alignment Y is never used for rebind.

Scientific scope remains unchanged:
selection/environment stress test only; no member-level orientation claim.

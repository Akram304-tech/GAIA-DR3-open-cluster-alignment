#!/usr/bin/env python
from __future__ import annotations
import hashlib, subprocess, sys
from pathlib import Path

EXPECTED_MATCH="40fff1276a3899a37a5e08090fe627de3e05c314d225b8f6d501bd42503bd919"
EXPECTED_YOUNG="cc1d3ae4ce1cf52387f535da92fbd0dc5d984a3bb2dc750bf6672682e85f65dd"
EXPECTED_CONTROL="124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd"

def sha256(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def find_exact(d,name,expected_sha):
    hits=[]
    for p in d.rglob(name):
        if p.is_file():
            try:
                if sha256(p)==expected_sha: hits.append(p)
            except Exception: pass
    if not hits:
        raise FileNotFoundError(f"Cannot find exact {name} with SHA={expected_sha}")
    return sorted(hits,key=lambda p:p.stat().st_mtime,reverse=True)[0]

def find_hunt_cache(d):
    hits=[p for p in d.rglob("hunt2026_clusters_selected_columns.csv") if p.is_file()]
    if not hits: raise FileNotFoundError("Hunt+2026 cluster cache not found.")
    return sorted(hits,key=lambda p:(("STAGE7B" in str(p)),p.stat().st_mtime),reverse=True)[0]

def main():
    here=Path(__file__).resolve().parent
    d=Path.home()/"Downloads"
    print("="*112)
    print("YHMC STAGE-7B CLUSTER-LEVEL SELECTION / ENVIRONMENT AUDIT v2.6.1")
    print("FROZEN-ROW REBIND / NO MEMBER FILE / NO REMATCHING")
    print("="*112)

    matches=find_exact(d,"02_outcome_blind_injection_matches.csv",EXPECTED_MATCH)
    young=find_exact(d,"02_PRIMARY_PA_SAMPLE_FROZEN.csv",EXPECTED_YOUNG)
    control=find_exact(d,"02_CONTROL_PA_SAMPLE_FROZEN.csv",EXPECTED_CONTROL)
    hunt=find_hunt_cache(d)

    print(f"FROZEN_R2_MATCHES={matches}")
    print(f"FROZEN_R2_MATCHES_SHA256={sha256(matches)}")
    print(f"YOUNG_FROZEN_SHA256={sha256(young)}")
    print(f"CONTROL_FROZEN_SHA256={sha256(control)}")
    print(f"HUNT2026_CLUSTER_CACHE={hunt}")
    print(f"HUNT2026_CLUSTER_CACHE_SHA256={sha256(hunt)}")

    rc=subprocess.run([sys.executable,"-c","import numpy,pandas,scipy,statsmodels"]).returncode
    if rc!=0:
        print("ERROR: statsmodels is required.")
        raise SystemExit(1)

    out=here/"STAGE7B_CLUSTERAUDIT_OUTPUT"
    cmd=[
        sys.executable,str(here/"stage7b_cluster_level_selection_environment_audit_v2_6_1.py"),
        "--matches",str(matches),"--hunt-cache",str(hunt),
        "--young-frozen",str(young),"--control-frozen",str(control),
        "--out",str(out)
    ]
    rc=subprocess.run(cmd).returncode
    print()
    print(f"RETURN_CODE={rc}")
    if rc==0:
        print("STAGE7B_CLUSTER_LEVEL_SELECTION_ENVIRONMENT_AUDIT_PASS=True")
        print(f"REPORT={out/'STAGE7B_CLUSTER_LEVEL_REPORT.txt'}")
    raise SystemExit(rc)

if __name__=="__main__":
    main()

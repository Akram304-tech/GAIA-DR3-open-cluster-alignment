@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-3C1 ESTIMATOR-GATE DIAGNOSTIC v1.1.1
echo READ-ONLY / NO ALIGNMENT RETEST / NO SAMPLE CHANGE
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" (
  echo ERROR: Miniconda Python not found.
  exit /b 1
)

set "STAGE3C=%USERPROFILE%\Downloads\YHMC_STAGE3C_ESTIMATOR_ROBUSTNESS_v1_1_0\YHMC_STAGE3C_ESTIMATOR_ROBUSTNESS_v1_1_0\STAGE3C_OUTPUT"

if not exist "%STAGE3C%\01_CAP80_young_estimator_reanalysis.csv" (
  echo ERROR: Stage-3C outputs not found.
  exit /b 1
)

echo PYEXE=%PYEXE%
"%PYEXE%" --version

"%PYEXE%" -c "import numpy,pandas" >nul 2>nul
if errorlevel 1 (
  "%PYEXE%" -m pip install numpy pandas
  if errorlevel 1 exit /b 1
)

"%PYEXE%" stage3c1_estimator_gate_diagnostic_v1_1_1.py --stage3c "%STAGE3C%" --out "%CD%\STAGE3C1_OUTPUT"
set "RC=%ERRORLEVEL%"

echo.
echo RETURN_CODE=%RC%
if "%RC%"=="0" (
  echo REPORT=%CD%\STAGE3C1_OUTPUT\STAGE3C1_REPORT.txt
  echo SUMMARY=%CD%\STAGE3C1_OUTPUT\01_gate_attrition_summary.csv
  echo CLASS=%CD%\STAGE3C1_OUTPUT\04_CAP80_classification.csv
)
exit /b %RC%

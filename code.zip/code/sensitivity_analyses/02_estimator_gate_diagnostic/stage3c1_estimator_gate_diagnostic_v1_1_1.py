#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-3C1 estimator-gate diagnostic v1.1.1

Read-only diagnostic of Stage-3C CAP80/CAP90 outputs.
No morphology is recomputed. No sample is changed. No alignment is re-tested.

Goal
----
Determine why CAP80 retained only 5/95 young and 0/95 controls despite
small PA shifts relative to the baseline estimator.

For each estimator/sample this script reports:
- individual gate pass counts;
- cumulative gate attrition;
- margins q84-qmax and q-qroundnull05;
- PA-error distribution;
- baseline-to-robust PA shift;
- which gate is the first blocker for each object.

Interpretation
--------------
CAP80 is considered "inconclusive due to estimator/gate degeneracy" rather
than evidence against alignment if:
1) real robust PAs remain close to baseline,
2) most losses arise from q-based admission gates rather than PA instability,
3) CAP90 remains strongly aligned.
"""

from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
import numpy as np
import pandas as pd

VERSION="1.1.1"

def sha256(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda:f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()

def pct(x,p):
    x=pd.to_numeric(pd.Series(x),errors="coerce").dropna().to_numpy(float)
    return float(np.percentile(x,p)) if len(x) else np.nan

def summarize(df, estimator, sample):
    d=df[df["status"]=="OK"].copy()
    for c in ["gate1","gate2","gate3","gate4","admitted"]:
        d[c]=d[c].fillna(False).astype(bool)

    # First-failure classification under the frozen gate order.
    def first_fail(r):
        if not r["gate1"]: return "GATE1_CALIBRATABLE"
        if not r["gate2"]: return "GATE2_Q84_LE_QMAX"
        if not r["gate3"]: return "GATE3_Q_LT_ROUNDNULL"
        if not r["gate4"]: return "GATE4_PAERR68_LE20"
        return "ADMITTED"

    d["first_failure"]=d.apply(first_fail,axis=1)

    n=len(d)
    cum1=d["gate1"]
    cum2=cum1 & d["gate2"]
    cum3=cum2 & d["gate3"]
    cum4=cum3 & d["gate4"]

    q84_minus_qmax=pd.to_numeric(d["q84"],errors="coerce")-pd.to_numeric(d["qmax"],errors="coerce")
    q_minus_null=pd.to_numeric(d["q"],errors="coerce")-pd.to_numeric(d["q_round_null_p05"],errors="coerce")

    row={
        "estimator":estimator,
        "sample":sample,
        "N_shape_OK":n,
        "N_gate1_individual":int(d["gate1"].sum()),
        "N_gate2_individual":int(d["gate2"].sum()),
        "N_gate3_individual":int(d["gate3"].sum()),
        "N_gate4_individual":int(d["gate4"].sum()),
        "N_after_gate1":int(cum1.sum()),
        "N_after_gate1_2":int(cum2.sum()),
        "N_after_gate1_2_3":int(cum3.sum()),
        "N_admitted":int(cum4.sum()),
        "median_q":pct(d["q"],50),
        "median_q84":pct(d["q84"],50),
        "median_qmax":pct(d["qmax"],50),
        "median_qroundnull05":pct(d["q_round_null_p05"],50),
        "median_q84_minus_qmax":pct(q84_minus_qmax,50),
        "p16_q84_minus_qmax":pct(q84_minus_qmax,16),
        "p84_q84_minus_qmax":pct(q84_minus_qmax,84),
        "median_q_minus_roundnull05":pct(q_minus_null,50),
        "p16_q_minus_roundnull05":pct(q_minus_null,16),
        "p84_q_minus_roundnull05":pct(q_minus_null,84),
        "median_PAerr68_deg":pct(d["PAerr68"],50),
        "p90_PAerr68_deg":pct(d["PAerr68"],90),
        "median_abs_PA_shift_deg":pct(d["abs_PA_shift_from_baseline_deg"],50),
        "p90_abs_PA_shift_deg":pct(d["abs_PA_shift_from_baseline_deg"],90),
    }

    fail=d["first_failure"].value_counts().rename_axis("first_failure").reset_index(name="N")
    fail.insert(0,"sample",sample)
    fail.insert(0,"estimator",estimator)

    detail=d[[
        "ID","Name","MassJ","q","q84","qmax","q_round_null_p05",
        "PAerr68","abs_PA_shift_from_baseline_deg",
        "gate1","gate2","gate3","gate4","admitted","first_failure"
    ]].copy()
    detail.insert(0,"sample",sample)
    detail.insert(0,"estimator",estimator)
    detail["q84_minus_qmax"]=q84_minus_qmax.to_numpy()
    detail["q_minus_roundnull05"]=q_minus_null.to_numpy()
    return row,fail,detail

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage3c",required=True)
    ap.add_argument("--out",default="STAGE3C1_OUTPUT")
    args=ap.parse_args()

    s3=Path(args.stage3c).resolve()
    out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=True)

    files={
        ("CAP80","young"):s3/"01_CAP80_young_estimator_reanalysis.csv",
        ("CAP80","control"):s3/"02_CAP80_control_estimator_reanalysis.csv",
        ("CAP90","young"):s3/"01_CAP90_young_estimator_reanalysis.csv",
        ("CAP90","control"):s3/"02_CAP90_control_estimator_reanalysis.csv",
    }
    for p in files.values():
        if not p.exists():
            raise FileNotFoundError(p)

    print("="*92)
    print(f"YHMC STAGE-3C1 ESTIMATOR-GATE DIAGNOSTIC v{VERSION}")
    print("="*92)
    print("READ_ONLY=True")
    print("NO_SAMPLE_CHANGE=True")
    print("NO_ALIGNMENT_RETEST=True")

    rows=[]; fails=[]; details=[]
    input_hashes={}
    for (est,sample),p in files.items():
        input_hashes[f"{est}_{sample}"]=sha256(p)
        df=pd.read_csv(p)
        row,fail,detail=summarize(df,est,sample)
        rows.append(row); fails.append(fail); details.append(detail)

    summary=pd.DataFrame(rows)
    failure=pd.concat(fails,ignore_index=True)
    detail=pd.concat(details,ignore_index=True)

    summary.to_csv(out/"01_gate_attrition_summary.csv",index=False)
    failure.to_csv(out/"02_first_failure_counts.csv",index=False)
    detail.to_csv(out/"03_object_gate_diagnostics.csv",index=False)

    # Automatic classification based only on gate behavior, not science alignment.
    classifications=[]
    for sample in ["young","control"]:
        c80=summary[(summary.estimator=="CAP80")&(summary["sample"]==sample)].iloc[0]
        c90=summary[(summary.estimator=="CAP90")&(summary["sample"]==sample)].iloc[0]

        f80=failure[(failure.estimator=="CAP80")&(failure["sample"]==sample)]
        qfail=int(f80.loc[f80.first_failure.isin(
            ["GATE2_Q84_LE_QMAX","GATE3_Q_LT_ROUNDNULL"]
        ),"N"].sum())
        pafail=int(f80.loc[f80.first_failure=="GATE4_PAERR68_LE20","N"].sum())
        close_pa=bool(c80["median_abs_PA_shift_deg"]<=5.0 and c80["p90_abs_PA_shift_deg"]<=10.0)
        q_gate_dominated=bool(qfail>pafail)
        severe_attrition=bool(c80["N_admitted"] < 0.2*c80["N_shape_OK"])
        cap90_viable=bool(c90["N_admitted"] >= 0.4*c90["N_shape_OK"])

        if severe_attrition and close_pa and q_gate_dominated and cap90_viable:
            cls="CAP80_INCONCLUSIVE_Q_GATE_DEGENERACY"
        elif severe_attrition and not close_pa:
            cls="CAP80_POSSIBLE_PA_INSTABILITY"
        else:
            cls="CAP80_DIAGNOSTIC_MIXED"

        classifications.append({
            "sample":sample,
            "classification":cls,
            "CAP80_N_shape_OK":int(c80["N_shape_OK"]),
            "CAP80_N_admitted":int(c80["N_admitted"]),
            "CAP80_q_first_failures":qfail,
            "CAP80_pa_first_failures":pafail,
            "CAP80_median_PA_shift_deg":float(c80["median_abs_PA_shift_deg"]),
            "CAP80_p90_PA_shift_deg":float(c80["p90_abs_PA_shift_deg"]),
            "CAP90_N_admitted":int(c90["N_admitted"]),
        })

    classdf=pd.DataFrame(classifications)
    classdf.to_csv(out/"04_CAP80_classification.csv",index=False)

    contract={
        "stage":"STAGE3C1_ESTIMATOR_GATE_DIAGNOSTIC",
        "version":VERSION,
        "read_only":True,
        "sample_changes":False,
        "alignment_retested":False,
        "input_hashes":input_hashes,
        "classification_rule":
            "CAP80 classified as q-gate degeneracy when attrition is severe, PA shifts remain small, q-based gates dominate first failures, and CAP90 remains viable."
    }
    (out/"STAGE3C1_CONTRACT.json").write_text(json.dumps(contract,indent=2),encoding="utf-8")

    report=[
        f"YHMC STAGE-3C1 ESTIMATOR-GATE DIAGNOSTIC v{VERSION}",
        "="*92,
        "READ_ONLY=True",
        "NO_SAMPLE_CHANGE=True",
        "NO_ALIGNMENT_RETEST=True",
        "",
        "GATE ATTRITION SUMMARY:",
        summary.to_string(index=False),
        "",
        "FIRST-FAILURE COUNTS:",
        failure.to_string(index=False),
        "",
        "CAP80 CLASSIFICATION:",
        classdf.to_string(index=False),
        "",
        "DECISION RULE:",
        "  CAP80 is NOT evidence against the alignment if its PA estimates remain close",
        "  to baseline while q-based admission gates eliminate most objects.",
        "  In that case CAP80 is treated as an over-regularized/inconclusive estimator",
        "  sensitivity test, whereas CAP90 remains the usable robust-estimator check.",
        "",
        "NEXT:",
        "  Proceed to independently calibrated inner r<r50J morphology only after",
        "  confirming the CAP80 failure mode is q-gate dominated rather than PA instability.",
    ]
    (out/"STAGE3C1_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")

    print()
    print((out/"STAGE3C1_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

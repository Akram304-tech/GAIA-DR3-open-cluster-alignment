YHMC STAGE-3C1 ESTIMATOR-GATE DIAGNOSTIC v1.1.1
===================================================

This is a read-only diagnostic.

It explains why CAP80 retained only 5/95 young and 0/95 older controls
despite small baseline-to-CAP80 PA shifts.

It does not:
- recompute morphology,
- recompute alignment,
- change a sample,
- change a gate.

The key distinction is whether CAP80 attrition is driven by:
- q-based admission gates (q84<=qmax or q<round-null), or
- genuine PA instability.

Run:
  call RUN_STAGE3C1_ESTIMATOR_GATE_DIAGNOSTIC_v1_1_1.bat

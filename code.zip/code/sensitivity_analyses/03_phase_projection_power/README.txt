YHMC Stage-7A coordinate-binding recovery v2.5.3
================================================

Implementation-only repair for the Stage-7A failure:
  RuntimeError: Cannot bind center RA/Dec columns.

Cause:
  The frozen morphology sample CSVs intentionally do not retain cluster-center coordinates,
  while the projection audit incorrectly expected them there.

Repair:
  - young centers are joined by exact ID from Stage-0 07_provisional_morphology_ready.csv;
  - control centers are joined by exact ID from Stage-2A 02_MATCHED_OLDER_CONTROLS_FROZEN.csv;
  - exact ID/Name consistency and finite coordinates are required;
  - no alignment outcome participates in the coordinate binding.

No historical stage is rerun. The reconstructed Stage-1B and Stage-2C hashes are rechecked
before Stage-7A executes.

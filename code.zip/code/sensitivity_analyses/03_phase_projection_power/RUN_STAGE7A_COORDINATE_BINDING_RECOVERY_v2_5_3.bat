@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo YHMC STAGE-7A COORDINATE-BINDING RECOVERY v2.5.3
echo IMPLEMENTATION ONLY / REUSES REBUILT HISTORY
echo ============================================================
set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" (
 echo ERROR: Python not found.
 exit /b 1
)
"%PYEXE%" discover_and_run_stage7a_v2_5_3.py
exit /b %ERRORLEVEL%

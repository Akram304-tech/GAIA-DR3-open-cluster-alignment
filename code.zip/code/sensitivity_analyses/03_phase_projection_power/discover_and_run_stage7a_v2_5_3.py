#!/usr/bin/env python
from __future__ import annotations
import hashlib, json, subprocess, sys
from pathlib import Path

EXPECTED_YOUNG="cc1d3ae4ce1cf52387f535da92fbd0dc5d984a3bb2dc750bf6672682e85f65dd"
EXPECTED_CONTROL="124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd"

def sha256(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def find_unique(downloads:Path, marker:str, expected_parent:str):
    hits=[p for p in downloads.rglob(marker) if p.is_file() and p.parent.name==expected_parent]
    if not hits:
        raise FileNotFoundError(f"Cannot find {expected_parent}/{marker} under {downloads}")
    # Prefer rebuilt-history paths, then newest.
    hits=sorted(hits,key=lambda p:(("REBUILT_HISTORY" in str(p)),p.stat().st_mtime),reverse=True)
    return hits[0].parent

def main():
    here=Path(__file__).resolve().parent
    downloads=Path.home()/"Downloads"
    print("="*100)
    print("YHMC STAGE-7A COORDINATE-BINDING RECOVERY v2.5.3")
    print("IMPLEMENTATION ONLY / NO SCIENCE CHANGE")
    print("="*100)

    s0=find_unique(downloads,"07_provisional_morphology_ready.csv","STAGE0_OUTPUT")
    s1b=find_unique(downloads,"02_PRIMARY_PA_SAMPLE_FROZEN.csv","STAGE1B_OUTPUT")
    s1c=find_unique(downloads,"01_alignment_cluster_table_UNBLINDED.csv","STAGE1C_OUTPUT")
    s2a=find_unique(downloads,"02_MATCHED_OLDER_CONTROLS_FROZEN.csv","STAGE2A_OUTPUT")
    s2c=find_unique(downloads,"02_CONTROL_PA_SAMPLE_FROZEN.csv","STAGE2C_OUTPUT")
    s2d=find_unique(downloads,"04_matched_age_contrast_inference.csv","STAGE2D_OUTPUT")
    s3a=find_unique(downloads,"02_global_systematics_summary.csv","STAGE3A_OUTPUT")

    for k,v in [("STAGE0",s0),("STAGE1B",s1b),("STAGE1C",s1c),("STAGE2A",s2a),
                ("STAGE2C",s2c),("STAGE2D",s2d),("STAGE3A",s3a)]:
        print(f"DISCOVERED_{k}={v}")

    hy=sha256(s1b/"02_PRIMARY_PA_SAMPLE_FROZEN.csv")
    hc=sha256(s2c/"02_CONTROL_PA_SAMPLE_FROZEN.csv")
    print(f"YOUNG_FROZEN_SHA256={hy}")
    print(f"CONTROL_FROZEN_SHA256={hc}")
    if hy!=EXPECTED_YOUNG:
        print("HISTORICAL_YOUNG_IDENTITY_GATE=False")
        raise SystemExit(4)
    if hc!=EXPECTED_CONTROL:
        print("HISTORICAL_CONTROL_IDENTITY_GATE=False")
        raise SystemExit(5)
    print("HISTORICAL_YOUNG_IDENTITY_GATE=True")
    print("HISTORICAL_CONTROL_IDENTITY_GATE=True")

    out=here/"STAGE7A_OUTPUT"
    cmd=[
        sys.executable,str(here/"stage7a_reviewer_critical_internal_audit_v2_5_3.py"),
        "--stage0",str(s0),"--stage1b",str(s1b),"--stage1c",str(s1c),
        "--stage2a",str(s2a),"--stage2c",str(s2c),"--stage2d",str(s2d),
        "--stage3a",str(s3a),"--out",str(out)
    ]
    rc=subprocess.run(cmd).returncode
    print()
    print(f"RETURN_CODE={rc}")
    if rc==0:
        print("STAGE7A_COORD_BINDING_RECOVERY_PASS=True")
        print(f"REPORT={out/'STAGE7A_REPORT.txt'}")
    raise SystemExit(rc)

if __name__=="__main__":
    main()

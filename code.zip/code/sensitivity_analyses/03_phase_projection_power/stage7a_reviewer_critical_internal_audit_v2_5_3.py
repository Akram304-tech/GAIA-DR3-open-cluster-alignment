#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-7A Reviewer-Critical Internal Audit v2.5.0

NO NEW PRIMARY ENDPOINT.
NO SAMPLE / THRESHOLD RETUNING.
NO REPLACEMENT MECHANISM SEARCH.

Purpose
-------
Address reviewer-critical issues that can be resolved from already existing
analysis products without introducing a new outcome-dependent science model:

A) coherent-global-rotation null -> exact collective axial phase delta + bootstrap CI;
B) pericentre null -> Spearman precision interval + approximate 80% detectable effect scale;
C) extended matched age contrast -> expose the opposite-direction two-sided descriptive result
   and its existing bootstrap 95% CI without promoting it to a new confirmatory claim;
D) equirectangular tangent approximation -> exact gnomonic-projection morphology sensitivity;
E) provenance -> SHA-bound internal workflow log, explicitly labelled as chain-of-custody
   rather than public preregistration.

The script does NOT modify any original stage output.
"""

from __future__ import annotations
import argparse, hashlib, json, math, os
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import brentq
from scipy.stats import norm

VERSION="2.5.3"
SEED=20261027
N_BOOT_PHASE=200000

def sha256(p: Path):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def axial_diff(a,b):
    return ((np.asarray(a,float)-np.asarray(b,float)+90.0)%180.0)-90.0

def weighted_shape(x,y,w):
    x=np.asarray(x,float); y=np.asarray(y,float); w=np.asarray(w,float)
    good=np.isfinite(x)&np.isfinite(y)&np.isfinite(w)&(w>0)
    x=x[good]; y=y[good]; w=w[good]
    if len(x)<3 or w.sum()<=0:
        return np.nan,np.nan,np.nan,np.nan
    sw=w.sum()
    xc=np.sum(w*x)/sw; yc=np.sum(w*y)/sw
    dx=x-xc; dy=y-yc
    sxx=np.sum(w*dx*dx)/sw
    syy=np.sum(w*dy*dy)/sw
    sxy=np.sum(w*dx*dy)/sw
    C=np.array([[sxx,sxy],[sxy,syy]],float)
    vals,vecs=np.linalg.eigh(C)
    oo=np.argsort(vals)[::-1]; vals=vals[oo]; vecs=vecs[:,oo]
    if vals[0]<=0 or vals[1]<0:
        return np.nan,np.nan,xc,yc
    q=float(np.sqrt(max(vals[1],0)/vals[0]))
    vx,vy=vecs[:,0]
    pa=float(np.degrees(np.arctan2(vy,vx))%180.0)
    return q,pa,float(xc),float(yc)

def gnomonic_xy_arcmin(ra,dec,ra0,dec0):
    ra=np.deg2rad(np.asarray(ra,float)); dec=np.deg2rad(np.asarray(dec,float))
    ra0=math.radians(float(ra0)); dec0=math.radians(float(dec0))
    dra=(ra-ra0+np.pi)%(2*np.pi)-np.pi
    den=np.sin(dec0)*np.sin(dec)+np.cos(dec0)*np.cos(dec)*np.cos(dra)
    x=np.cos(dec)*np.sin(dra)/den
    y=(np.cos(dec0)*np.sin(dec)-np.sin(dec0)*np.cos(dec)*np.cos(dra))/den
    fac=180.0/np.pi*60.0
    return x*fac,y*fac

def tangent_xy_arcmin(ra,dec,ra0,dec0):
    ra=np.asarray(ra,float); dec=np.asarray(dec,float)
    dra=((ra-float(ra0)+180.0)%360.0)-180.0
    x=dra*math.cos(math.radians(float(dec0)))*60.0
    y=(dec-float(dec0))*60.0
    return x,y

def angular_sep_deg(ra,dec,ra0,dec0):
    ra=np.deg2rad(np.asarray(ra,float)); dec=np.deg2rad(np.asarray(dec,float))
    r0=math.radians(float(ra0)); d0=math.radians(float(dec0))
    cosang=np.sin(dec)*math.sin(d0)+np.cos(dec)*math.cos(d0)*np.cos(ra-r0)
    return np.degrees(np.arccos(np.clip(cosang,-1,1)))

def find_member_file(member_dir:Path,cid:int,name:str):
    hits=sorted([p for p in member_dir.glob(f"{cid:04d}_*.csv") if p.is_file()])
    if not hits:
        hits=sorted([p for p in member_dir.glob(f"{cid}_*.csv") if p.is_file()])
    if not hits: return None
    if len(hits)==1: return hits[0]
    safe="".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in str(name))
    for p in hits:
        if safe in p.stem: return p
    return hits[0]

def choose_center_cols(df):
    candidates=[
        ("__RAdeg","__DEdeg"),
        ("RA_ICRS","DE_ICRS"),
        ("RAdeg","DEdeg"),
        ("RA","DEC"),
    ]
    for a,b in candidates:
        if a in df.columns and b in df.columns:
            return a,b
    raise RuntimeError("Cannot bind center RA/Dec columns.")

def phase_summary(df,pa_col,gp_col,label,out,seed_tag):
    pa=pd.to_numeric(df[pa_col],errors="coerce").to_numpy(float)
    gp=pd.to_numeric(df[gp_col],errors="coerce").to_numpy(float)
    good=np.isfinite(pa)&np.isfinite(gp)
    pa=pa[good]; gp=gp[good]
    theta=np.deg2rad(2.0*axial_diff(pa,gp))
    z=np.mean(np.exp(1j*theta))
    phi=float(np.angle(z))
    delta_signed_deg=math.degrees(phi)/2.0
    delta_abs_deg=abs(delta_signed_deg)
    A=float(np.real(z))
    R=float(abs(z))
    p_geom=delta_abs_deg/90.0

    rng=np.random.default_rng(np.random.SeedSequence([SEED,seed_tag]))
    n=len(theta)
    vals=np.empty(N_BOOT_PHASE,float)
    for lo in range(0,N_BOOT_PHASE,20000):
        hi=min(N_BOOT_PHASE,lo+20000)
        idx=rng.integers(0,n,size=(hi-lo,n))
        zz=np.mean(np.exp(1j*theta[idx]),axis=1)
        vals[lo:hi]=np.degrees(np.angle(zz))/2.0

    row={
        "sample":label,"N":n,"A_observed":A,"resultant_length_R":R,
        "delta_signed_deg":delta_signed_deg,"delta_abs_deg":delta_abs_deg,
        "delta_signed_boot_p025":float(np.percentile(vals,2.5)),
        "delta_signed_boot_p16":float(np.percentile(vals,16)),
        "delta_signed_boot_median":float(np.percentile(vals,50)),
        "delta_signed_boot_p84":float(np.percentile(vals,84)),
        "delta_signed_boot_p975":float(np.percentile(vals,97.5)),
        "p_geometry_delta_over_90":p_geom,
    }
    return row

def bonett_wright_ci(r,n,alpha=.05):
    # Bonett & Wright (2000): Var[atanh(r_s)] ~= (1+r_s^2/2)/(n-3)
    z=np.arctanh(float(r))
    se=math.sqrt((1+float(r)**2/2)/(int(n)-3))
    zz=norm.ppf(1-alpha/2)
    return float(np.tanh(z-zz*se)),float(np.tanh(z+zz*se)),se

def detectable_rho_approx(n,alpha=.05,power=.80):
    za=norm.ppf(1-alpha/2)
    zb=norm.ppf(power)
    def f(r):
        se=math.sqrt((1+r*r/2)/(n-3))
        return np.arctanh(r)/se-(za+zb)
    return float(brentq(f,1e-6,0.95))

def attach_center_coordinates(sample_df, source_df, label):
    """
    Morphology-freeze tables intentionally need not carry catalogue center coordinates.
    Reattach the canonical coordinates by exact ID from the already-frozen catalogue/control
    source table. This is an implementation-only schema binding; no alignment quantity is used.
    """
    s=sample_df.copy()
    src=source_df.copy()

    # Resolve the canonical source coordinate pair.
    ra_src,de_src=choose_center_cols(src)
    keep=["ID",ra_src,de_src]
    # Keep Name only for an optional identity cross-check if present.
    if "Name" in src.columns:
        keep.append("Name")
    q=src[keep].drop_duplicates("ID").copy()
    q=q.rename(columns={ra_src:"__CENTER_RAdeg",de_src:"__CENTER_DEdeg"})
    if "Name" in q.columns:
        q=q.rename(columns={"Name":"__CENTER_SOURCE_Name"})

    if s["ID"].duplicated().any():
        raise RuntimeError(f"{label}: duplicate IDs in morphology-freeze table.")
    if q["ID"].duplicated().any():
        raise RuntimeError(f"{label}: duplicate IDs in center-coordinate source table.")

    s=s.merge(q,on="ID",how="left",validate="one_to_one")
    miss=(~np.isfinite(pd.to_numeric(s["__CENTER_RAdeg"],errors="coerce")) |
          ~np.isfinite(pd.to_numeric(s["__CENTER_DEdeg"],errors="coerce")))
    if miss.any():
        bad=s.loc[miss,["ID","Name"] if "Name" in s.columns else ["ID"]]
        raise RuntimeError(
            f"{label}: missing center coordinates after exact-ID join for {len(bad)} rows: "
            + bad.head(10).to_dict(orient="records").__repr__()
        )

    if "Name" in s.columns and "__CENTER_SOURCE_Name" in s.columns:
        a=s["Name"].astype(str).str.strip()
        b=s["__CENTER_SOURCE_Name"].astype(str).str.strip()
        bad=(a!=b)
        if bad.any():
            raise RuntimeError(
                f"{label}: ID/Name identity mismatch in center-coordinate join for "
                f"{int(bad.sum())} rows."
            )

    s["__RAdeg"]=pd.to_numeric(s["__CENTER_RAdeg"],errors="raise")
    s["__DEdeg"]=pd.to_numeric(s["__CENTER_DEdeg"],errors="raise")
    return s

def projection_rows(sample_df,member_dir,align_df,label):
    ra0c,de0c=choose_center_cols(sample_df)
    gp_map=align_df.set_index("ID")["PA_Galactic_parallel_deg"].to_dict()
    rows=[]
    for _,r in sample_df.iterrows():
        cid=int(r["ID"]); name=str(r["Name"])
        mf=find_member_file(member_dir,cid,name)
        if mf is None:
            rows.append({"sample":label,"ID":cid,"Name":name,"status":"MISSING_MEMBER_FILE"})
            continue
        mem=pd.read_csv(mf)
        racol="__RAdeg" if "__RAdeg" in mem.columns else ("RA_ICRS" if "RA_ICRS" in mem.columns else None)
        decol="__DEdeg" if "__DEdeg" in mem.columns else ("DE_ICRS" if "DE_ICRS" in mem.columns else None)
        if racol is None or decol is None or "Prob" not in mem.columns:
            rows.append({"sample":label,"ID":cid,"Name":name,"status":"BAD_MEMBER_SCHEMA"})
            continue
        p=pd.to_numeric(mem["Prob"],errors="coerce").to_numpy(float)
        ra=pd.to_numeric(mem[racol],errors="coerce").to_numpy(float)
        de=pd.to_numeric(mem[decol],errors="coerce").to_numpy(float)
        good=np.isfinite(p)&np.isfinite(ra)&np.isfinite(de)&(p>=0.5)
        p,ra,de=p[good],ra[good],de[good]
        ra0=float(r[ra0c]); de0=float(r[de0c])
        xb,yb=tangent_xy_arcmin(ra,de,ra0,de0)
        xg,yg=gnomonic_xy_arcmin(ra,de,ra0,de0)
        qb,pab,_,_=weighted_shape(xb,yb,p)
        qg,pag,_,_=weighted_shape(xg,yg,p)
        if not np.isfinite(pag):
            rows.append({"sample":label,"ID":cid,"Name":name,"status":"SHAPE_FAIL"})
            continue
        gp=float(gp_map.get(cid,np.nan))
        maxrad=float(np.nanmax(angular_sep_deg(ra,de,ra0,de0))) if len(ra) else np.nan
        shift=float(abs(axial_diff([pag],[pab])[0])) if np.isfinite(pab) else np.nan
        db=float(abs(axial_diff([pab],[gp])[0])) if np.isfinite(gp) else np.nan
        dg=float(abs(axial_diff([pag],[gp])[0])) if np.isfinite(gp) else np.nan
        rows.append({
            "sample":label,"ID":cid,"Name":name,"status":"OK",
            "MassJ":float(pd.to_numeric(pd.Series([r.get("MassJ",np.nan)]),errors="coerce").iloc[0]),
            "N_members":len(p),"max_member_radius_deg":maxrad,
            "q_baseline_recomputed":qb,"q_gnomonic":qg,
            "PA_baseline_recomputed_deg":pab,"PA_gnomonic_deg":pag,
            "PA_axial_shift_deg":shift,
            "GP_PA_deg":gp,
            "Delta_baseline_deg":db,"Delta_gnomonic_deg":dg,
            "cos2_baseline":math.cos(math.radians(2*db)) if np.isfinite(db) else np.nan,
            "cos2_gnomonic":math.cos(math.radians(2*dg)) if np.isfinite(dg) else np.nan,
        })
    return pd.DataFrame(rows)

def summarize_projection(d):
    ok=d[d["status"]=="OK"].copy()
    out=[]
    for role,sub in [
        ("ALL",ok),
        ("M3000",ok[pd.to_numeric(ok["MassJ"],errors="coerce")>=3000]),
    ]:
        if len(sub)==0: continue
        out.append({
            "sample":str(ok["sample"].iloc[0]),"role":role,"N":len(sub),
            "max_radius_median_deg":float(sub["max_member_radius_deg"].median()),
            "max_radius_p95_deg":float(sub["max_member_radius_deg"].quantile(.95)),
            "max_radius_max_deg":float(sub["max_member_radius_deg"].max()),
            "N_radius_gt2deg":int((sub["max_member_radius_deg"]>2).sum()),
            "PA_shift_median_deg":float(sub["PA_axial_shift_deg"].median()),
            "PA_shift_p95_deg":float(sub["PA_axial_shift_deg"].quantile(.95)),
            "PA_shift_max_deg":float(sub["PA_axial_shift_deg"].max()),
            "A_baseline_recomputed":float(sub["cos2_baseline"].mean()),
            "A_gnomonic":float(sub["cos2_gnomonic"].mean()),
            "delta_A_gnomonic_minus_baseline":float(sub["cos2_gnomonic"].mean()-sub["cos2_baseline"].mean()),
        })
    return out

def file_mtime_iso(p):
    try:
        return pd.Timestamp(p.stat().st_mtime,unit="s",tz="UTC").isoformat()
    except Exception:
        return ""

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage0",required=True)
    ap.add_argument("--stage1b",required=True)
    ap.add_argument("--stage1c",required=True)
    ap.add_argument("--stage2a",required=True)
    ap.add_argument("--stage2c",required=True)
    ap.add_argument("--stage2d",required=True)
    ap.add_argument("--stage3a",required=True)
    ap.add_argument("--out",default="STAGE7A_OUTPUT")
    args=ap.parse_args()

    s0=Path(args.stage0).resolve()
    s1b=Path(args.stage1b).resolve()
    s1c=Path(args.stage1c).resolve()
    s2a=Path(args.stage2a).resolve()
    s2c=Path(args.stage2c).resolve()
    s2d=Path(args.stage2d).resolve()
    s3a=Path(args.stage3a).resolve()
    out=Path(args.out).resolve(); out.mkdir(parents=True,exist_ok=True)

    # ---------- A) collective axial phase ----------
    young=pd.read_csv(s1c/"01_alignment_cluster_table_UNBLINDED.csv")
    control=pd.read_csv(s2d/"01_control_alignment_UNBLINDED.csv")
    phase=pd.DataFrame([
        phase_summary(young,"PA_deg_point","PA_Galactic_parallel_deg","young",out,701),
        phase_summary(control,"PA_deg_point","PA_Galactic_parallel_deg","control",out,702),
    ])
    phase.to_csv(out/"01_collective_phase_bootstrap.csv",index=False)

    # Compare to Stage-3A Monte Carlo rotation p-values if available.
    s3sum=s3a/"02_global_systematics_summary.csv"
    if s3sum.exists():
        rot=pd.read_csv(s3sum)
        keep=[c for c in ["sample","p_common_global_rotation"] if c in rot.columns]
        if len(keep)==2:
            phase=phase.merge(rot[keep],on="sample",how="left")
            phase["p_geom_minus_MC"]=phase["p_geometry_delta_over_90"]-phase["p_common_global_rotation"]
            phase.to_csv(out/"01_collective_phase_bootstrap.csv",index=False)

    # ---------- B) pericentre precision / power ----------
    # Authoritative frozen Stage-6B3B primary result.
    # The original local object-level file is not required for this precision
    # calculation because Bonett-Wright CI and approximate power depend only
    # on N and the frozen observed Spearman coefficient.
    rr=-0.039920949
    n=45
    ci_lo,ci_hi,sez=bonett_wright_ci(rr,n)
    mde80=detectable_rho_approx(n)
    precision=pd.DataFrame([{
        "N":n,"rho_spearman":rr,
        "BonettWright95_lo":ci_lo,"BonettWright95_hi":ci_hi,
        "SE_FisherZ_BonettWright":sez,
        "approx_abs_rho_for_80pct_power_two_sided_alpha0p05":mde80,
        "descriptive_equivalence_margin_abs_rho":0.30,
        "equivalence_abs_rho_lt_0p30_supported":bool(ci_lo>-0.30 and ci_hi<0.30),
        "note":"Power/equivalence are descriptive precision diagnostics added after the null result; no equivalence claim is made."
    }])
    precision.to_csv(out/"02_pericentre_precision_power.csv",index=False)

    # ---------- C) extended matched age contrast transparency ----------
    age=pd.read_csv(s2d/"04_matched_age_contrast_inference.csv")
    rolecol="analysis" if "analysis" in age.columns else ("label" if "label" in age.columns else None)
    ext=None
    if rolecol:
        cand=age[age[rolecol].astype(str).str.contains("EXTENDED",case=False,na=False)]
        if len(cand): ext=cand.iloc[0]
    if ext is None:
        # fallback second row used by original Stage-2D ordering
        ext=age.iloc[1] if len(age)>1 else age.iloc[0]
    p1=float(ext["signflip_p_D_gt_0_one_sided"])
    p2=min(1.0,2*min(p1,1-p1))
    age_trans=pd.DataFrame([{
        "D_young_minus_control":float(ext["D_young_minus_control"]),
        "bootstrap_D_p025":float(ext["bootstrap_D_p025"]),
        "bootstrap_D_p975":float(ext["bootstrap_D_p975"]),
        "predeclared_one_sided_p_D_gt0":p1,
        "descriptive_two_sided_signflip_p":p2,
        "confirmatory_opposite_direction_claim_authorized":False,
        "note":"Two-sided value is reported for transparency only; it was not the pre-specified directional primary claim."
    }])
    # Gate rates
    yall=pd.read_csv(s1b/"01_real_morphology_all.csv")
    call=pd.read_csv(s2c/"01_control_real_morphology_all.csv")
    if "PRIMARY_PA_SAMPLE_ADMITTED" in yall.columns:
        age_trans["young_morphology_gate_rate"]=float(yall["PRIMARY_PA_SAMPLE_ADMITTED"].fillna(False).astype(bool).mean())
        age_trans["young_gate_N_num"]=int(yall["PRIMARY_PA_SAMPLE_ADMITTED"].fillna(False).astype(bool).sum())
        age_trans["young_gate_N_den"]=len(yall)
    if "CONTROL_PA_SAMPLE_ADMITTED" in call.columns:
        age_trans["control_morphology_gate_rate"]=float(call["CONTROL_PA_SAMPLE_ADMITTED"].fillna(False).astype(bool).mean())
        age_trans["control_gate_N_num"]=int(call["CONTROL_PA_SAMPLE_ADMITTED"].fillna(False).astype(bool).sum())
        age_trans["control_gate_N_den"]=len(call)
    age_trans.to_csv(out/"03_extended_age_contrast_transparency.csv",index=False)

    # ---------- D) exact gnomonic projection sensitivity ----------
    yf=pd.read_csv(s1b/"02_PRIMARY_PA_SAMPLE_FROZEN.csv")
    cf=pd.read_csv(s2c/"02_CONTROL_PA_SAMPLE_FROZEN.csv")

    # The morphology-freeze CSVs do not necessarily retain catalogue center RA/Dec.
    # Reattach them by exact ID from the historical source tables used before unblinding.
    ysrc=pd.read_csv(s0/"07_provisional_morphology_ready.csv")
    csrc=pd.read_csv(s2a/"02_MATCHED_OLDER_CONTROLS_FROZEN.csv")
    yf=attach_center_coordinates(yf,ysrc,"young")
    cf=attach_center_coordinates(cf,csrc,"control")

    # Explicit audit of the coordinate binding itself.
    pd.DataFrame([
        {"sample":"young","N":len(yf),"N_finite_center_coords":
            int((np.isfinite(yf["__RAdeg"]) & np.isfinite(yf["__DEdeg"])).sum())},
        {"sample":"control","N":len(cf),"N_finite_center_coords":
            int((np.isfinite(cf["__RAdeg"]) & np.isfinite(cf["__DEdeg"])).sum())}
    ]).to_csv(out/"00_projection_coordinate_binding_audit.csv",index=False)

    yproj=projection_rows(yf,s0/"members_primary",young,"young")
    cproj=projection_rows(cf,s2a/"members_control_frozen",control,"control")
    proj=pd.concat([yproj,cproj],ignore_index=True)
    proj.to_csv(out/"04_gnomonic_projection_object_audit.csv",index=False)
    psum=pd.DataFrame(summarize_projection(yproj)+summarize_projection(cproj))
    psum.to_csv(out/"05_gnomonic_projection_summary.csv",index=False)

    # ---------- E) SHA-bound internal chronology ----------
    core=[
        ("young_morphology_freeze",s1b/"02_PRIMARY_PA_SAMPLE_FROZEN.csv"),
        ("young_alignment_unblind",s1c/"01_alignment_cluster_table_UNBLINDED.csv"),
        ("control_morphology_freeze",s2c/"02_CONTROL_PA_SAMPLE_FROZEN.csv"),
        ("control_alignment_unblind",s2d/"01_control_alignment_UNBLINDED.csv"),
        ("matched_age_contrast",s2d/"04_matched_age_contrast_inference.csv"),
        ("systematics_summary",s3a/"02_global_systematics_summary.csv"),
    ]
    log=[]
    for seq,(name,p) in enumerate(core,1):
        log.append({
            "sequence":seq,"artifact":name,"path":str(p),
            "exists":p.exists(),
            "sha256":sha256(p) if p.exists() else "",
            "local_file_mtime_UTC_supporting_only":file_mtime_iso(p) if p.exists() else "",
            "provenance_interpretation":"internal chain-of-custody; local mtime is not an external preregistration timestamp"
        })
    log.append({
        "sequence":len(log)+1,
        "artifact":"orbit_primary_result_authoritative_scalar",
        "path":"Stage-6B3B terminally frozen result; local object-level file unavailable on current workstation",
        "exists":False,
        "sha256":"d62f54308da8ac7751aa5971f4c3726293855e7af06e6bdf4aacc2e12cafe536",
        "local_file_mtime_UTC_supporting_only":"",
        "provenance_interpretation":"authoritative frozen primary-result SHA from completed Stage-6B3B; N=45, rho=-0.039920949, p=0.796102039"
    })
    pd.DataFrame(log).to_csv(out/"06_internal_freeze_log.csv",index=False)

    # ---------- report ----------
    ph=pd.read_csv(out/"01_collective_phase_bootstrap.csv")
    pr=precision.iloc[0]
    ag=age_trans.iloc[0]
    report=[
        f"YHMC STAGE-7A REVIEWER-CRITICAL INTERNAL AUDIT v{VERSION}",
        "="*112,
        "NO_NEW_PRIMARY_ENDPOINT=True",
        "NO_SAMPLE_RETUNING=True",
        "NO_REPLACEMENT_MECHANISM_SEARCH=True",
        "",
        "COLLECTIVE AXIAL PHASE:",
        ph.to_string(index=False),
        "",
        "PERICENTRE PRECISION / POWER:",
        precision.to_string(index=False),
        "",
        "EXTENDED AGE-CONTRAST TRANSPARENCY:",
        age_trans.to_string(index=False),
        "",
        "GNOMONIC PROJECTION SUMMARY:",
        psum.to_string(index=False),
        "",
        "PROJECTION COORDINATE BINDING:",
        "  Center coordinates were reattached by exact ID from Stage-0/Stage-2A source tables.",
        "  No alignment field entered this schema recovery.",
        "",
        "PROVENANCE POLICY:",
        "  Hashes establish internal chain-of-custody and stage separation.",
        "  A later Zenodo deposit is an archival timestamp, NOT retroactive public preregistration.",
        "",
        "NEXT:",
        "  Run Stage-7B Hunt+2026 injection-recovery artefact stress test.",
        "  Only then integrate all reviewer-critical diagnostics into the manuscript."
    ]
    (out/"STAGE7A_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    contract={
        "stage":"STAGE7A_REVIEWER_CRITICAL_INTERNAL_AUDIT",
        "version":VERSION,
        "new_primary_endpoint":False,
        "sample_or_threshold_retuning":False,
        "replacement_mechanism_search":False,
        "diagnostics":[
            "collective axial phase + bootstrap CI",
            "pericentre Spearman precision and approximate 80% detectable effect",
            "extended age-contrast transparency",
            "exact gnomonic projection sensitivity",
            "SHA-bound internal provenance log"
        ],
        "zenodo_policy":"archive supports reproducibility/chain-of-custody but must not be described as retroactive preregistration",
        "next":"Stage7B external injection-recovery artefact stress test"
    }
    (out/"STAGE7A_CONTRACT.json").write_text(json.dumps(contract,indent=2),encoding="utf-8")

    lines=[]
    for p in sorted(out.rglob("*")):
        if p.is_file() and p.name!="SHA256SUMS.txt":
            lines.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")

    print((out/"STAGE7A_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

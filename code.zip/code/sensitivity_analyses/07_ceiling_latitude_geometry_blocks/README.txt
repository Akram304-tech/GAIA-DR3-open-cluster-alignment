Stage-7E v2.9.0 addresses remaining N1--N4 reviewer issues.

It computes: (1) the positive ceiling Dmax=1-Acontrol and compares it with the 80% MDE; (2) matched alternative effects based on median |Delta|, log-odds within 30 deg, and axial von-Mises kappa, with anchor bootstrap CIs and approximate MDEs; (3) common-boundary |b| terciles, matched D within those terciles, and an age-by-|b| interaction equivalent using D_i versus |b|; (4) expected ecliptic/equatorial statistics under the observed Galactic-relative residual distribution at the actual sky positions; (5) joint young+control spatial-kinematic graph sensitivity at 50/5, 100/10, 150/15, and 250/20 pc/km/s, with matched sets inheriting shared physical components.

All are post-unblind sensitivity/precision diagnostics. No primary sample, gate, matching assignment, or endpoint is retuned.


v2.9.1 implementation-only recovery
------------------------------------
The Stage-3A systematics tables write the Galactic reference position angle as:
  PA_Galactic_parallel_recomputed_deg
whereas the v2.9.0 N3 geometry block incorrectly requested:
  PA_Galactic_parallel_deg

v2.9.1 binds:
  cluster PA       -> PA_deg_point
  Galactic PA      -> PA_Galactic_parallel_recomputed_deg
                      (PA_Galactic_parallel_deg accepted as backward-compatible alias)
  ecliptic PA      -> PA_Ecliptic_parallel_deg
  equatorial EW PA -> 0 deg

The selected schema is written to:
  00_coordinate_reference_binding_audit.csv

No scientific rule changes:
- no sample/gate retuning;
- no rematching;
- no change to NBOOT/NPERM;
- no change to ceiling-resistant effects;
- no change to common-|b| binning;
- no change to 50/100/150/250 pc joint-block rules.

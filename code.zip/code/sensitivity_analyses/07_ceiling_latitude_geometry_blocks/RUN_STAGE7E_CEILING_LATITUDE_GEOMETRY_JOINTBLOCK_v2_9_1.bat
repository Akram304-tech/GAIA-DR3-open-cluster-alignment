@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo YHMC STAGE-7E CEILING/LATITUDE/GEOMETRY/JOINT-BLOCK v2.9.1
echo NO RETUNING / NO REMATCHING
echo ============================================================
set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
"%PYEXE%" discover_and_run_stage7e_v2_9_1.py
exit /b %ERRORLEVEL%

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Stage-7E: ceiling, common-latitude, reference-geometry, and joint-block audit.

Post-unblind reviewer sensitivity analysis. No sample threshold, morphology gate,
control assignment, or primary endpoint is changed.
"""
from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import norm, spearmanr
from scipy.special import i0e, i1e
import statsmodels.api as sm

VERSION='2.9.1'; SEED=20261028; NBOOT=100000; NPERM=200000; K=4.74047
YHASH='cc1d3ae4ce1cf52387f535da92fbd0dc5d984a3bb2dc750bf6672682e85f65dd'
CHASH='124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd'
RULES=[('tight_50pc_5kms',50.,5.),('central_100pc_10kms',100.,10.),('loose_150pc_15kms',150.,15.),('very_loose_250pc_20kms',250.,20.)]

def sha(p):
 h=hashlib.sha256();
 with open(p,'rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()

def axial(a,b): return ((np.asarray(a,float)-np.asarray(b,float)+90)%180)-90

def boot(vals,fn,tag):
 rng=np.random.default_rng(np.random.SeedSequence([SEED,tag])); vals=list(vals); n=len(vals); z=np.empty(NBOOT)
 for i in range(NBOOT):
  ix=rng.integers(0,n,n); z[i]=fn([vals[j] for j in ix])
 return float(fn(vals)),float(np.percentile(z,2.5)),float(np.percentile(z,97.5)),float(np.std(z,ddof=1))

def mde(se,two=False):
 za=norm.ppf(.975 if two else .95); zp=norm.ppf(.80); return float((za+zp)*se)

def kappa_from_R(R):
 R=float(np.clip(R,0,0.999999999))
 if R<1e-12:return 0.
 if R<.53: k=2*R+R**3+5*R**5/6
 elif R<.85: k=-.4+1.39*R+.43/(1-R)
 else: k=1/(R**3-4*R**2+3*R)
 for _ in range(12):
  A=float(i1e(k)/i0e(k)); der=1-A/k-A*A if k>0 else .5; k=max(0.,k-(A-R)/der)
 return float(k)

def source_geom(master,df):
 ids=df.ID.astype(int).tolist(); m=master[master.ID.isin(ids)].copy().drop_duplicates('ID').set_index('ID').loc[ids].reset_index()
 def first(cs): return next((c for c in cs if c in m.columns),None)
 ra=first(['__RAdeg','RA_ICRS','RAdeg']); de=first(['__DEdeg','DE_ICRS','DEdeg']); pr=first(['pmRA','pmra']); pdm=first(['pmDE','pmdec']); dist=first(['dist50','Dist50','distance'])
 if not all([ra,de,pr,pdm,dist]): raise RuntimeError('geometry columns missing')
 for c in [ra,de,pr,pdm,dist]: m[c]=pd.to_numeric(m[c],errors='coerce')
 a=np.deg2rad(m[ra].to_numpy()); d=np.deg2rad(m[de].to_numpy()); r=m[dist].to_numpy()
 rh=np.c_[np.cos(d)*np.cos(a),np.cos(d)*np.sin(a),np.sin(d)]; ea=np.c_[-np.sin(a),np.cos(a),np.zeros(len(a))]; ed=np.c_[-np.sin(d)*np.cos(a),-np.sin(d)*np.sin(a),np.cos(d)]
 xyz=r[:,None]*rh; vt=K*(r/1000.)[:,None]*(m[pr].to_numpy()[:,None]*ea+m[pdm].to_numpy()[:,None]*ed)
 return xyz,vt

class UF:
 def __init__(self,n): self.p=list(range(n)); self.s=[1]*n
 def f(self,x):
  while self.p[x]!=x: self.p[x]=self.p[self.p[x]]; x=self.p[x]
  return x
 def u(self,a,b):
  a,b=self.f(a),self.f(b)
  if a==b:return
  if self.s[a]<self.s[b]:a,b=b,a
  self.p[b]=a; self.s[a]+=self.s[b]

def joint_labels(master,union,L,V):
 xyz,vt=source_geom(master,union); n=len(union); uf=UF(n)
 for i in range(n):
  ds=np.sqrt(((xyz[i+1:]-xyz[i])**2).sum(1)); dv=np.sqrt(((vt[i+1:]-vt[i])**2).sum(1));
  for j in np.where((ds<=L)&(dv<=V))[0]+i+1: uf.u(i,int(j))
 roots=[uf.f(i) for i in range(n)]; mp={r:k for k,r in enumerate(sorted(set(roots)))}; return np.array([mp[r] for r in roots])

def block_stats(y,lab,tag):
 y=np.asarray(y,float); lab=np.asarray(lab,int); ub=np.unique(lab); groups=[np.where(lab==b)[0] for b in ub]; sums=np.array([y[g].sum() for g in groups]); sizes=np.array([len(g) for g in groups]); rng=np.random.default_rng(np.random.SeedSequence([SEED,tag]))
 bz=np.empty(NBOOT)
 for lo in range(0,NBOOT,5000):
  m=min(5000,NBOOT-lo); ix=rng.integers(0,len(ub),(m,len(ub))); bz[lo:lo+m]=sums[ix].sum(1)/sizes[ix].sum(1)
 obs=y.mean(); ext1=ext2=0
 for lo in range(0,NPERM,10000):
  m=min(10000,NPERM-lo); sg=rng.choice([-1.,1.],(m,len(ub))); vv=(sg*sums).sum(1)/len(y); ext1+=np.sum(vv>=obs); ext2+=np.sum(np.abs(vv)>=abs(obs))
 return dict(N=len(y),N_blocks=len(ub),N_multiblocks=sum(len(g)>1 for g in groups),max_block_size=max(map(len,groups)),estimate=float(obs),lo95=float(np.percentile(bz,2.5)),hi95=float(np.percentile(bz,97.5)),p_one=float((ext1+1)/(NPERM+1)),p_two=float((ext2+1)/(NPERM+1)))

def bind_systematics_reference_columns(S,label):
 """
 Bind Stage-3A coordinate-reference columns by schema alias only.
 No outcome enters this binding.
 """
 def first(cands):
  return next((c for c in cands if c in S.columns),None)
 pa_col=first(["PA_deg_point"])
 gp_col=first(["PA_Galactic_parallel_recomputed_deg","PA_Galactic_parallel_deg"])
 ep_col=first(["PA_Ecliptic_parallel_deg"])
 missing=[]
 if pa_col is None: missing.append("cluster PA")
 if gp_col is None: missing.append("Galactic reference PA")
 if ep_col is None: missing.append("ecliptic reference PA")
 if missing:
  raise RuntimeError(f"{label}: cannot bind {', '.join(missing)}; available={list(S.columns)}")
 rec=dict(sample=label,cluster_pa_column=pa_col,galactic_reference_column=gp_col,
          ecliptic_reference_column=ep_col,equatorial_reference="0 deg (equatorial east-west)",
          binding_policy="schema alias only; no outcome-dependent selection")
 print(f"REFERENCE_BIND_{label.upper()}: PA={pa_col}; GP={gp_col}; ECL={ep_col}; EQ=0deg",flush=True)
 return pa_col,gp_col,ep_col,rec

def main():
 ap=argparse.ArgumentParser();
 for x in ['stage0','stage1b','stage1c','stage2c','stage2d','stage3a']: ap.add_argument('--'+x,required=True)
 ap.add_argument('--out',default='STAGE7E_OUTPUT'); a=ap.parse_args(); out=Path(a.out).resolve(); out.mkdir(parents=True,exist_ok=True)
 s0,s1b,s1c,s2c,s2d,s3a=map(Path,[a.stage0,a.stage1b,a.stage1c,a.stage2c,a.stage2d,a.stage3a])
 yf=s1b/'02_PRIMARY_PA_SAMPLE_FROZEN.csv'; cf=s2c/'02_CONTROL_PA_SAMPLE_FROZEN.csv'
 if sha(yf)!=YHASH or sha(cf)!=CHASH: raise RuntimeError('historical identity gate failed')
 M=pd.read_csv(s0/'01_cluster_master_raw.csv'); YA=pd.read_csv(s1c/'01_alignment_cluster_table_UNBLINDED.csv'); CA=pd.read_csv(s2d/'01_control_alignment_UNBLINDED.csv'); CF=pd.read_csv(cf); AN=pd.read_csv(s2d/'03_anchor_normalized_young_control_table.csv'); YS=pd.read_csv(s3a/'01_young_systematics_cluster_table.csv'); CS=pd.read_csv(s3a/'01_control_systematics_cluster_table.csv')
 for d in [M,YA,CA,CF,AN,YS,CS]:
  if 'ID' in d.columns: d['ID']=pd.to_numeric(d['ID'],errors='coerce')
 # ---- N1 ceiling and alternative matched effects ----
 pri=AN[pd.to_numeric(AN['MassJ_young'],errors='coerce')>=3000].copy()
 # derive observed A values from D table if needed
 D=float(pd.to_numeric(pri['D_i_young_minus_control'],errors='coerce').mean());
 # Bind per-anchor young and admitted controls directly.
 ycols=['ID','Name','cos2Delta','PA_deg_point','PA_Galactic_parallel_deg','MassJ']; yy=YA[ycols].copy().rename(columns={'ID':'young_ID','Name':'young_Name','cos2Delta':'Yy','PA_deg_point':'PAy','PA_Galactic_parallel_deg':'GPy','MassJ':'MassJ_young'})
 ccols=['ID','Name','cos2Delta_control','PA_deg_point','PA_Galactic_parallel_deg']; cc=CA[ccols].copy().rename(columns={'ID':'control_ID','Name':'control_Name','cos2Delta_control':'Yc','PA_deg_point':'PAc','PA_Galactic_parallel_deg':'GPc'})
 ass=CF[['ID','Name','young_ID','young_Name']].copy().rename(columns={'ID':'control_ID','Name':'control_Name'}).merge(cc,on=['control_ID','control_Name'],how='inner')
 q=yy.merge(ass,on=['young_ID','young_Name'],how='inner'); q=q[pd.to_numeric(q.MassJ_young,errors='coerce')>=3000].copy()
 q['dy_abs']=.5*np.rad2deg(np.arccos(np.clip(pd.to_numeric(q.Yy,errors='coerce'),-1,1))); q['dc_abs']=.5*np.rad2deg(np.arccos(np.clip(pd.to_numeric(q.Yc,errors='coerce'),-1,1)))
 q['dy_signed']=axial(q.PAy,q.GPy); q['dc_signed']=axial(q.PAc,q.GPc)
 anchors=[]
 for aid,g in q.groupby('young_ID'):
  r=g.iloc[0]; anchors.append(dict(young_ID=int(aid),young_Name=r.young_Name,Yy=float(r.Yy),dy_abs=float(r.dy_abs),dy_signed=float(r.dy_signed),Yc=float(g.Yc.mean()),dc_abs=float(g.dc_abs.mean()),dc_signed_list=g.dc_signed.astype(float).tolist(),within_y=float(r.dy_abs<=30),within_c=float((g.dc_abs<=30).mean())))
 anchors=pd.DataFrame(anchors)
 Ac=float(anchors.Yc.mean()); Ay=float(anchors.Yy.mean()); dmax=1-Ac
 # original MDE from per-anchor D_i
 di=(anchors.Yy-anchors.Yc).to_numpy(); sd=float(np.std(di,ddof=1)); mdeA=float((norm.ppf(.95)+norm.ppf(.8))*sd/math.sqrt(len(di)))
 ceil=pd.DataFrame([dict(N=len(di),A_young=Ay,A_control=Ac,D=Ay-Ac,Dmax_positive=1-Ac,MDE80_one_sided_A=mdeA,MDE_over_Dmax=mdeA/dmax,any_feasible_D_has_80pct_power=bool(mdeA<=dmax))]); ceil.to_csv(out/'01_primary_A_ceiling_audit.csv',index=False)
 # Vectorized anchor bootstrap for alternative effects.
 dy=anchors.dy_abs.to_numpy(float); dc=anchors.dc_abs.to_numpy(float); wy=anchors.within_y.to_numpy(float); wc=anchors.within_c.to_numpy(float)
 zy=np.exp(2j*np.deg2rad(anchors.dy_signed.to_numpy(float))); zc=np.array([np.mean(np.exp(2j*np.deg2rad(np.asarray(ls,float)))) for ls in anchors.dc_signed_list],complex)
 def kvec(R):
  R=np.clip(np.asarray(R,float),0,0.999999999); k=np.where(R<.53,2*R+R**3+5*R**5/6,np.where(R<.85,-.4+1.39*R+.43/(1-R),1/(R**3-4*R**2+3*R)))
  for _ in range(8):
   A=i1e(k)/i0e(k); der=np.where(k>1e-10,1-A/k-A*A,.5); k=np.maximum(0,k-(A-R)/der)
  return k
 def point(dy,dc,wy,wc,zy,zc):
  med=np.median(dc)-np.median(dy); py=wy.mean(); pc=wc.mean(); eps=1/(2*len(dy)); py=np.clip(py,eps,1-eps); pc=np.clip(pc,eps,1-eps); lod=np.log(py/(1-py))-np.log(pc/(1-pc)); kd=float(kvec([abs(zy.mean())])[0]-kvec([abs(zc.mean())])[0]); return np.array([med,lod,kd])
 obs=point(dy,dc,wy,wc,zy,zc); rng=np.random.default_rng(SEED+11); bz=np.empty((NBOOT,3)); n=len(dy)
 for lo in range(0,NBOOT,5000):
  m=min(5000,NBOOT-lo); ix=rng.integers(0,n,(m,n)); med=np.median(dc[ix],1)-np.median(dy[ix],1); py=wy[ix].mean(1); pc=wc[ix].mean(1); eps=1/(2*n); py=np.clip(py,eps,1-eps); pc=np.clip(pc,eps,1-eps); lod=np.log(py/(1-py))-np.log(pc/(1-pc)); ky=kvec(np.abs(zy[ix].mean(1))); kc=kvec(np.abs(zc[ix].mean(1))); bz[lo:lo+m]=np.c_[med,lod,ky-kc]
 names=['median_control_minus_young_deg','logodds_within30_young_minus_control','kappa_young_minus_control']; rows=[]
 for j,nm in enumerate(names):
  se=float(np.std(bz[:,j],ddof=1)); rows.append(dict(metric=nm,N=len(dy),estimate=float(obs[j]),lo95=float(np.percentile(bz[:,j],2.5)),hi95=float(np.percentile(bz[:,j],97.5)),bootstrap_SE=se,MDE80_one_sided=float((norm.ppf(.95)+norm.ppf(.8))*se),direction_positive_means='young more aligned'))
 pd.DataFrame(rows).to_csv(out/'02_ceiling_resistant_matched_effects.csv',index=False); anchors.to_csv(out/'03_primary_anchor_alternative_effect_table.csv',index=False)
 # ---- N2 common |b| bins and matched D interaction ----
 mm=M[['ID','Name','GLAT']].drop_duplicates(['ID','Name']); ym=YA[['ID','Name','cos2Delta']].merge(mm,on=['ID','Name']).rename(columns={'cos2Delta':'Y'}); cm=CA[['ID','Name','cos2Delta_control']].merge(mm,on=['ID','Name']).rename(columns={'cos2Delta_control':'Y'}); ym['sample']='young'; cm['sample']='control'; pooled=pd.concat([ym,cm]); pooled['absb']=pd.to_numeric(pooled.GLAT,errors='coerce').abs(); cuts=np.quantile(pooled.absb,[1/3,2/3]);
 def cat(x): return pd.cut(x,[-np.inf,cuts[0],cuts[1],np.inf],labels=['low','mid','high'],include_lowest=True)
 pooled['tercile']=cat(pooled.absb); tr=[]
 for s,g in pooled.groupby('sample'):
  for t,h in g.groupby('tercile',observed=False):
   y=h.Y.to_numpy(float); rng=np.random.default_rng(SEED+20+len(tr)); bb=np.array([y[rng.integers(0,len(y),len(y))].mean() for _ in range(NBOOT)]); tr.append(dict(sample=s,tercile=str(t),N=len(y),A=float(y.mean()),lo95=float(np.percentile(bb,2.5)),hi95=float(np.percentile(bb,97.5)),b_lo=(-np.inf if t=='low' else cuts[0] if t=='mid' else cuts[1]),b_hi=(cuts[0] if t=='low' else cuts[1] if t=='mid' else np.inf)))
 pd.DataFrame(tr).to_csv(out/'04_common_absb_terciles.csv',index=False)
 # matched D terciles based on young-anchor |b| using same common boundaries
 yb=mm.rename(columns={'ID':'young_ID','Name':'young_Name','GLAT':'young_GLAT'}); an=AN.merge(yb,on=['young_ID','young_Name'],how='left'); an['absb']=pd.to_numeric(an.young_GLAT,errors='coerce').abs(); an['tercile']=cat(an.absb); dr=[]
 for t,h in an.groupby('tercile',observed=False):
  x=pd.to_numeric(h.D_i_young_minus_control,errors='coerce').dropna().to_numpy(); rng=np.random.default_rng(SEED+40+len(dr)); bb=np.array([x[rng.integers(0,len(x),len(x))].mean() for _ in range(NBOOT)]) if len(x) else np.array([np.nan]); dr.append(dict(tercile=str(t),N=len(x),D=float(np.mean(x)),lo95=float(np.nanpercentile(bb,2.5)),hi95=float(np.nanpercentile(bb,97.5))))
 pd.DataFrame(dr).to_csv(out/'05_matched_D_by_common_absb_tercile.csv',index=False)
 z=an[['D_i_young_minus_control','absb']].dropna(); X=sm.add_constant((z.absb-z.absb.mean())/z.absb.std(ddof=1)); fit=sm.OLS(z.D_i_young_minus_control,X).fit(cov_type='HC3'); rho=spearmanr(z.D_i_young_minus_control,z.absb)
 pd.DataFrame([dict(N=len(z),interaction_equivalent_slope_per_1SD_absb=float(fit.params.iloc[1]),se_HC3=float(fit.bse.iloc[1]),p_HC3=float(fit.pvalues.iloc[1]),ci95_lo=float(fit.conf_int().iloc[1,0]),ci95_hi=float(fit.conf_int().iloc[1,1]),spearman_rho=float(rho.statistic),spearman_p=float(rho.pvalue))]).to_csv(out/'06_age_by_absb_interaction.csv',index=False)
 # ---- N3 expected non-Galactic controls under actual Galactic-relative residual distribution ----
 geo=[]; binding_rows=[]
 for sample,S in [('young',YS),('control',CS)]:
  pa_col,gp_col,ep_col,binding=bind_systematics_reference_columns(S,sample); binding_rows.append(binding)
  pa=pd.to_numeric(S[pa_col],errors='coerce').to_numpy(); gp=pd.to_numeric(S[gp_col],errors='coerce').to_numpy(); ep=pd.to_numeric(S[ep_col],errors='coerce').to_numpy(); eq=np.zeros(len(S)); res=axial(pa,gp); rng=np.random.default_rng(SEED+70+(0 if sample=='young' else 1)); sims=np.empty((NPERM,2))
  for lo in range(0,NPERM,5000):
   m=min(5000,NPERM-lo); inds=np.array([rng.permutation(len(res)) for _ in range(m)]); syn=gp[None,:]+res[inds]; sims[lo:lo+m,0]=np.cos(np.deg2rad(2*axial(syn,ep[None,:]))).mean(1); sims[lo:lo+m,1]=np.cos(np.deg2rad(2*axial(syn,eq[None,:]))).mean(1)
  obs=[np.cos(np.deg2rad(2*axial(pa,ep))).mean(),np.cos(np.deg2rad(2*axial(pa,eq))).mean()]
  for j,ref in enumerate(['ecliptic','equatorial_EW']):
   mu=float(sims[:,j].mean()); dev=abs(obs[j]-mu); p=(np.sum(np.abs(sims[:,j]-mu)>=dev)+1)/(NPERM+1); geo.append(dict(sample=sample,reference=ref,N=len(S),A_observed=float(obs[j]),A_expected_mean=mu,expected_lo95=float(np.percentile(sims[:,j],2.5)),expected_hi95=float(np.percentile(sims[:,j],97.5)),p_deviation_from_galactic_geometry=float(p)))
 pd.DataFrame(binding_rows).to_csv(out/'00_coordinate_reference_binding_audit.csv',index=False)
 pd.DataFrame(geo).to_csv(out/'07_coordinate_controls_expected_from_galactic_alignment.csv',index=False)
 # ---- N4 joint blocks: all young+controls in one physical graph, matched sets inherit union components ----
 union=pd.concat([YA[['ID','Name']],CA[['ID','Name']]],ignore_index=True).drop_duplicates('ID').reset_index(drop=True); rows=[]; comps=[]; assmap=CF[['ID','young_ID']].copy().rename(columns={'ID':'control_ID'}); ca_ids=set(CA.ID.astype(int)); assmap=assmap[assmap.control_ID.astype(int).isin(ca_ids)]
 for ri,(rn,L,V) in enumerate(RULES):
  lab=joint_labels(M,union,L,V); idlab=dict(zip(union.ID.astype(int),lab));
  for b in sorted(set(lab)):
   mem=union.loc[lab==b,'Name'].astype(str).tolist();
   if len(mem)>1: comps.append(dict(rule=rn,block=int(b),size=len(mem),members=' | '.join(mem)))
  for sample,df,ycol,mask,stag in [
   ('young_all',YA,'cos2Delta',np.ones(len(YA),bool),0),
   ('young_M3000',YA,'cos2Delta',pd.to_numeric(YA.MassJ,errors='coerce')>=3000,1),
   ('control_all',CA,'cos2Delta_control',np.ones(len(CA),bool),2),
   ('control_M3000',CA,'cos2Delta_control',pd.to_numeric(CA.MassJ,errors='coerce')>=3000,3)]:
   d=df[mask].reset_index(drop=True); lbs=np.array([idlab[int(x)] for x in d.ID]); mp={b:i for i,b in enumerate(sorted(set(lbs)))}; z=block_stats(pd.to_numeric(d[ycol],errors='coerce'),[mp[b] for b in lbs],100+ri*10+stag); z.update(rule=rn,L_pc=L,Vt_kms=V,sample=sample); rows.append(z)
  # anchor meta-components: any shared joint physical component links matched sets
  aa=AN.copy().reset_index(drop=True); uf=UF(len(aa)); comp_to_anchors={}
  for i,r in aa.iterrows():
   aset={idlab.get(int(r.young_ID))}; ctr=assmap[assmap.young_ID.astype(int)==int(r.young_ID)].control_ID.astype(int).tolist(); aset |= {idlab.get(c) for c in ctr}; aset.discard(None)
   for c in aset: comp_to_anchors.setdefault(c,[]).append(i)
  for inds in comp_to_anchors.values():
   for j in inds[1:]: uf.u(inds[0],j)
  roots=[uf.f(i) for i in range(len(aa))]; mp={r:i for i,r in enumerate(sorted(set(roots)))}; alab=np.array([mp[r] for r in roots])
  for sample,mask in [('ageD_extended',np.ones(len(aa),bool)),('ageD_primary_M3000',pd.to_numeric(aa.MassJ_young,errors='coerce')>=3000)]:
   d=aa[mask].reset_index(drop=True); lbs=alab[np.asarray(mask)]; mm2={b:i for i,b in enumerate(sorted(set(lbs)))}; z=block_stats(pd.to_numeric(d.D_i_young_minus_control,errors='coerce'),[mm2[b] for b in lbs],200+ri*10+(0 if sample.endswith('extended') else 1)); z.update(rule=rn,L_pc=L,Vt_kms=V,sample=sample); rows.append(z)
 pd.DataFrame(rows).to_csv(out/'08_joint_spatial_kinematic_block_sensitivity.csv',index=False); pd.DataFrame(comps).to_csv(out/'09_joint_block_memberships.csv',index=False)
 # summary/report
 rep=['YHMC STAGE-7E CEILING / LATITUDE / GEOMETRY / JOINT-BLOCK AUDIT v'+VERSION,'='*116,'NO_SAMPLE_RETUNING=True','NO_REMATCHING=True','','COORDINATE REFERENCE BINDING:',pd.read_csv(out/'00_coordinate_reference_binding_audit.csv').to_string(index=False),'', 'PRIMARY A CEILING:',ceil.to_string(index=False),'','CEILING-RESISTANT MATCHED EFFECTS:',pd.DataFrame(rows if False else pd.read_csv(out/'02_ceiling_resistant_matched_effects.csv')).to_string(index=False),'','COMMON |b| TERCILES:',pd.read_csv(out/'04_common_absb_terciles.csv').to_string(index=False),'','MATCHED D BY COMMON |b| TERCILE:',pd.read_csv(out/'05_matched_D_by_common_absb_tercile.csv').to_string(index=False),'','AGE x |b| INTERACTION:',pd.read_csv(out/'06_age_by_absb_interaction.csv').to_string(index=False),'','NON-GALACTIC REFERENCE EXPECTATION UNDER GALACTIC ALIGNMENT:',pd.read_csv(out/'07_coordinate_controls_expected_from_galactic_alignment.csv').to_string(index=False),'','JOINT YOUNG+CONTROL BLOCK SENSITIVITY:',pd.read_csv(out/'08_joint_spatial_kinematic_block_sensitivity.csv').to_string(index=False)]
 (out/'STAGE7E_REPORT.txt').write_text('\n'.join(rep)+'\n',encoding='utf-8')
 contract=dict(stage='STAGE7E_CEILING_LATITUDE_GEOMETRY_JOINTBLOCK_AUDIT',version=VERSION,post_unblind=True,primary_sample_changed=False,gate_retuning=False,rematching=False,block_graph='joint union of admitted young + control clusters; matched-set meta-blocks inherit any shared physical component',rules=[dict(name=n,L_pc=L,Vt_kms=V) for n,L,V in RULES],coordinate_expectation='permute observed signed Galactic residuals over actual sky positions',latitude_bins='common pooled |b| boundaries; matched D stratified by young-anchor latitude',ceiling_alternatives=['median absolute-angle contrast','log-odds within 30 deg','axial von-Mises kappa'])
 (out/'STAGE7E_CONTRACT.json').write_text(json.dumps(contract,indent=2),encoding='utf-8')
 lines=[]
 for fp in sorted(out.glob('*')):
  if fp.is_file() and fp.name!='SHA256SUMS.txt': lines.append(f'{sha(fp)}  {fp.name}')
 (out/'SHA256SUMS.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 print((out/'STAGE7E_REPORT.txt').read_text())

if __name__=='__main__': main()

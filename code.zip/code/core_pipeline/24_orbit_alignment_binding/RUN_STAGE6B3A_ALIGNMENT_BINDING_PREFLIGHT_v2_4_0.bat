@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo YHMC STAGE-6B3A ALIGNMENT BINDING PREFLIGHT v2.4.0
echo HEADERS + IDs ONLY / NO ALIGNMENT VALUES
echo ============================================================
set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
set "STAGE6B1=%USERPROFILE%\Downloads\YHMC_STAGE6B1_ORBIT_MECHANISM_DESIGN_FREEZE_v2_2_0\YHMC_STAGE6B1_ORBIT_MECHANISM_DESIGN_FREEZE_v2_2_0\STAGE6B1_OUTPUT"
set "STAGE6B2R1=%USERPROFILE%\Downloads\YHMC_STAGE6B2R1_FAST_MC_ORBIT_PROXY_PRODUCTION_v2_3_2\YHMC_STAGE6B2R1_FAST_MC_ORBIT_PROXY_PRODUCTION_v2_3_2\STAGE6B2R1_OUTPUT"
"%PYEXE%" stage6b3a_alignment_binding_preflight_v2_4_0.py ^
 --downloads "%USERPROFILE%\Downloads" ^
 --stage6b1 "%STAGE6B1%" ^
 --stage6b2r1 "%STAGE6B2R1%" ^
 --out "%CD%\STAGE6B3A_OUTPUT"
set "RC=%ERRORLEVEL%"
echo.
echo RETURN_CODE=%RC%
if exist "%CD%\STAGE6B3A_OUTPUT\STAGE6B3A_REPORT.txt" echo REPORT=%CD%\STAGE6B3A_OUTPUT\STAGE6B3A_REPORT.txt
exit /b %RC%

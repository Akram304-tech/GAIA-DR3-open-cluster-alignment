
from __future__ import annotations
import argparse, hashlib, json, re
from pathlib import Path
import pandas as pd

VERSION="2.4.0"
EXPECTED_PRIMARY_SHA="46e1c9fa4ab1ff8d557d3aa2f38dd61bd05de0a3abe0664f6e57f4434a634c46"
EXPECTED_NOMINAL_SHA="1513737e70b44214bdffa8addd74d95b0ac52980624b24e0b6486fed9b1b1c92"
EXPECTED_SUMMARY_SHA="29932f41f94a9625125cbd7619a42985feab851cab60143969fc31fc8dfcade9"

def sha256(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1048576),b""):
            h.update(b)
    return h.hexdigest()

def id_col(cols):
    for c in cols:
        if str(c).strip().lower()=="id":
            return c
    for c in ("cluster_id","Cluster_ID","clusterID","clusterId"):
        if c in cols:
            return c
    return None

def align_cols(cols):
    pats=[r"delta",r"theta",r"cos.?2",r"align",r"pa[_\-]?gp",
          r"gp[_\-]?pa",r"plane.*pa",r"gal.*plane",r"a[_\-]?i$"]
    out=[]
    for c in cols:
        lc=str(c).lower()
        if any(re.search(p,lc) for p in pats):
            out.append(str(c))
    return out

def inspect(p,yids,cids):
    try:
        cols=list(pd.read_csv(p,nrows=0).columns)
    except Exception as e:
        return {"path":str(p),"readable_header":False,"error":repr(e)}
    ic=id_col(cols)
    ny=nc=0
    nrows=None
    ok=False
    if ic is not None:
        try:
            s=pd.to_numeric(pd.read_csv(p,usecols=[ic])[ic],errors="coerce").dropna().astype(int)
            ids=set(s.tolist())
            ny=len(ids & yids); nc=len(ids & cids)
            nrows=len(s); ok=True
        except Exception:
            pass
    return {
        "path":str(p),"filename":p.name,"readable_header":True,
        "id_column":"" if ic is None else str(ic),"id_read_ok":ok,
        "n_rows_id_read":nrows,
        "young_primary_id_overlap":ny,"control_primary_id_overlap":nc,
        "alignmentish_columns":" | ".join(align_cols(cols)),
        "all_columns":" | ".join(map(str,cols))
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--downloads",required=True)
    ap.add_argument("--stage6b1",required=True)
    ap.add_argument("--stage6b2r1",required=True)
    ap.add_argument("--out",default="STAGE6B3A_OUTPUT")
    a=ap.parse_args()

    downloads=Path(a.downloads).resolve()
    s1=Path(a.stage6b1).resolve()
    s2=Path(a.stage6b2r1).resolve()
    out=Path(a.out).resolve(); out.mkdir(parents=True,exist_ok=True)

    pf=s1/"01_PRIMARY_HIGH_MASS_6D_SAMPLE_FROZEN.csv"
    nf=s2/"01_PRIMARY_NOMINAL_ORBIT_PROXIES_FROZEN.csv"
    sf=s2/"04_PRIMARY_ORBIT_PROXY_SUMMARY_FROZEN.csv"
    ff=s2/"STAGE6B2R1_FREEZE.json"
    for p in (pf,nf,sf,ff):
        if not p.exists(): raise FileNotFoundError(p)
    if sha256(pf)!=EXPECTED_PRIMARY_SHA: raise RuntimeError("Primary hash mismatch")
    if sha256(nf)!=EXPECTED_NOMINAL_SHA: raise RuntimeError("Nominal orbit hash mismatch")
    if sha256(sf)!=EXPECTED_SUMMARY_SHA: raise RuntimeError("Orbit summary hash mismatch")

    fr=json.loads(ff.read_text(encoding="utf-8"))
    if not fr.get("ORBIT_PROXY_FREEZE_PASS",False): raise RuntimeError("Orbit freeze not PASS")
    if fr.get("alignment_read",True): raise RuntimeError("Alignment firewall violated")

    prim=pd.read_csv(pf,usecols=["ID","sample"])
    prim["ID"]=pd.to_numeric(prim["ID"],errors="raise").astype(int)
    yids=set(prim.loc[prim["sample"].astype(str)=="young","ID"])
    cids=set(prim.loc[prim["sample"].astype(str)=="control","ID"])
    if len(yids)!=22 or len(cids)!=23: raise RuntimeError("Expected 22/23 IDs")

    files=sorted({p for p in downloads.rglob("*.csv")
                  if "STAGE1C" in str(p).upper() or "STAGE2D" in str(p).upper()},
                 key=lambda x:str(x).lower())
    if not files: raise RuntimeError("No STAGE1C/STAGE2D CSV files found under Downloads")

    rdf=pd.DataFrame([inspect(p,yids,cids) for p in files])
    rdf.to_csv(out/"01_ALIGNMENT_FILE_SCHEMA_AND_ID_COVERAGE.csv",index=False)

    has_align=rdf["alignmentish_columns"].fillna("").astype(str).str.len()>0
    ymask=(rdf["readable_header"]==True)&(rdf["id_read_ok"]==True)&(pd.to_numeric(rdf["young_primary_id_overlap"],errors="coerce")>=22)&has_align
    cmask=(rdf["readable_header"]==True)&(rdf["id_read_ok"]==True)&(pd.to_numeric(rdf["control_primary_id_overlap"],errors="coerce")>=23)&has_align
    y=rdf.loc[ymask].copy(); c=rdf.loc[cmask].copy()
    y.to_csv(out/"02_YOUNG_BINDING_CANDIDATES.csv",index=False)
    c.to_csv(out/"03_CONTROL_BINDING_CANDIDATES.csv",index=False)

    unique=(len(y)==1 and len(c)==1)
    pre={
        "stage":"STAGE6B3A_ALIGNMENT_BINDING_PREFLIGHT","version":VERSION,
        "alignment_values_read":False,"association_computed":False,
        "orbit_proxies_already_frozen":True,
        "young_binding_candidate_count":int(len(y)),
        "control_binding_candidate_count":int(len(c)),
        "UNIQUE_BINDING_CANDIDATES":bool(unique)
    }
    if len(y)==1:
        pre["young_candidate_path"]=str(y.iloc[0]["path"])
        pre["young_alignmentish_columns"]=str(y.iloc[0]["alignmentish_columns"])
    if len(c)==1:
        pre["control_candidate_path"]=str(c.iloc[0]["path"])
        pre["control_alignmentish_columns"]=str(c.iloc[0]["alignmentish_columns"])
    (out/"STAGE6B3A_BINDING_PREFLIGHT.json").write_text(json.dumps(pre,indent=2),encoding="utf-8")

    yc = y[["path","id_column","young_primary_id_overlap","control_primary_id_overlap","alignmentish_columns"]].to_string(index=False) if len(y) else "NONE"
    cc = c[["path","id_column","young_primary_id_overlap","control_primary_id_overlap","alignmentish_columns"]].to_string(index=False) if len(c) else "NONE"
    report=f"""YHMC STAGE-6B3A ALIGNMENT-OUTCOME BINDING PREFLIGHT v{VERSION}
================================================================================================
ALIGNMENT_VALUES_READ=False
ASSOCIATION_COMPUTED=False
ORBIT_PROXIES_ALREADY_FROZEN=True
CSV_FILES_SCANNED={len(rdf)}
YOUNG_BINDING_CANDIDATE_COUNT={len(y)}
CONTROL_BINDING_CANDIDATE_COUNT={len(c)}

YOUNG CANDIDATES (HEADER + ID COVERAGE ONLY):
{yc}

CONTROL CANDIDATES (HEADER + ID COVERAGE ONLY):
{cc}

UNIQUE_BINDING_CANDIDATES={unique}

NEXT:
  Freeze the exact existing outcome files/columns without inspecting values,
  then execute the pre-specified Stage-6B3B association once.
"""
    (out/"STAGE6B3A_REPORT.txt").write_text(report,encoding="utf-8")
    print(report)

if __name__=="__main__":
    main()

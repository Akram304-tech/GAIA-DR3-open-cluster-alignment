Stage-6B3A is a binding preflight only.
It scans prior Stage-1C/Stage-2D CSV headers and cluster IDs to identify
the existing object-level alignment outcome source(s). It does not load
alignment values and does not compute any association.

YHMC Stage-6B0R1 Potential-Unit Binding Micropilot v2.1.1
================================================================

Implementation-only repair of Stage-6B0 v2.1.0.

Root cause:
McMillan17 and Irrgang13III have built-in physical conversion scales.
The previous script forced Orbit(ro=8.122, vo=229), which galpy correctly
rejected as physically incompatible.

Repair:
For each potential:
    phys = galpy.util.conversion.get_physical(pot)
    ro = phys["ro"]
    vo = phys["vo"]

The same potential-specific ro/vo are used for:
- observed-coordinate Orbit initialization;
- natural-time conversion.

No alignment is read and no correlation is computed.

The current integration is only a 1-Gyr forward technical micropilot.
Science orbit conventions will be frozen separately in Stage-6B1 only after
this implementation diagnostic passes.

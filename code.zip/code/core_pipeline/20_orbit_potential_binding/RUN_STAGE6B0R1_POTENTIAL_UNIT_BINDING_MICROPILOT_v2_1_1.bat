@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-6B0R1 POTENTIAL-UNIT BINDING MICROPILOT v2.1.1
echo IMPLEMENTATION ONLY / NO ALIGNMENT CORRELATION
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" exit /b 1

set "STAGE6=%USERPROFILE%\Downloads\YHMC_STAGE6_FULLCOLUMN_RECOVERY_v2_0_2\YHMC_STAGE6_FULLCOLUMN_RECOVERY_v2_0_2\STAGE6_FULLCOLUMN_OUTPUT"
set "STAGE1B=%USERPROFILE%\Downloads\YHMC_STAGE1B_REAL_MORPHOLOGY_FREEZE_v0_3_0\YHMC_STAGE1B_REAL_MORPHOLOGY_FREEZE_v0_3_0\STAGE1B_OUTPUT"
set "STAGE2C=%USERPROFILE%\Downloads\YHMC_STAGE2C_CONTROL_REAL_MORPHOLOGY_FREEZE_v0_7_0\YHMC_STAGE2C_CONTROL_REAL_MORPHOLOGY_FREEZE_v0_7_0\STAGE2C_OUTPUT"

"%PYEXE%" -c "import numpy,pandas,astropy,galpy" >nul 2>nul
if errorlevel 1 exit /b 1

"%PYEXE%" stage6b0r1_potential_unit_binding_micropilot_v2_1_1.py ^
 --stage6 "%STAGE6%" ^
 --stage1b "%STAGE1B%" ^
 --stage2c "%STAGE2C%" ^
 --out "%CD%\STAGE6B0R1_OUTPUT"

set "RC=%ERRORLEVEL%"
echo.
echo RETURN_CODE=%RC%
if exist "%CD%\STAGE6B0R1_OUTPUT\STAGE6B0R1_REPORT.txt" echo REPORT=%CD%\STAGE6B0R1_OUTPUT\STAGE6B0R1_REPORT.txt
if exist "%CD%\STAGE6B0R1_OUTPUT\STAGE6B0R1_CONTRACT.json" echo CONTRACT=%CD%\STAGE6B0R1_OUTPUT\STAGE6B0R1_CONTRACT.json
exit /b %RC%

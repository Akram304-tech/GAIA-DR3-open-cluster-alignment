#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-6B0R1 Potential-Unit Binding Micropilot v2.1.1

IMPLEMENTATION-ONLY recovery of Stage-6B0 v2.1.0.

Root cause
----------
McMillan17 and Irrgang13III ship with physical conversion scales turned on.
Stage-6B0 v2.1.0 initialized every Orbit with a common hard-coded
ro=8.122 kpc and vo=229 km/s, which is incompatible with those potentials
and correctly triggered galpy's physical_compatible assertion.

Repair
------
For each potential:
  phys = galpy.util.conversion.get_physical(potential)
  Orbit(..., ro=phys["ro"], vo=phys["vo"], ...)
  time conversion uses the same ro/vo.

MWPotential2014 is treated through the same get_physical interface so the
diagnostic is uniform.

The diagnostic integrates 1 Gyr forward from the observed present-day
phase-space state. This is only an execution/finite-metric micropilot.

NO alignment fields are read.
NO correlation is computed.
NO mechanism inference is made.
NO science orbit proxy is frozen.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

VERSION="2.1.1"

EXPECTED_FULL_SNAPSHOT_SHA="2164adf7ed3e516f035f60c6e6bfc06affbc4d809157c8eb06306d3e78d2cb47"
EXPECTED_YOUNG_SHA="cc1d3ae4ce1cf52387f535da92fbd0dc5d984a3bb2dc750bf6672682e85f65dd"
EXPECTED_CONTROL_SHA="124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd"

def sha256(p):
    h=hashlib.sha256()
    with Path(p).open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage6",required=True)
    ap.add_argument("--stage1b",required=True)
    ap.add_argument("--stage2c",required=True)
    ap.add_argument("--out",default="STAGE6B0R1_OUTPUT")
    args=ap.parse_args()

    s6=Path(args.stage6).resolve()
    s1=Path(args.stage1b).resolve()
    s2=Path(args.stage2c).resolve()
    out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=True)

    snap=s6/"00_HUNT_REFFERT_FULLCOLUMN_SNAPSHOT.csv"
    yf=s1/"02_PRIMARY_PA_SAMPLE_FROZEN.csv"
    cf=s2/"02_CONTROL_PA_SAMPLE_FROZEN.csv"

    for p in [snap,yf,cf]:
        if not p.exists():
            raise FileNotFoundError(p)

    if sha256(snap)!=EXPECTED_FULL_SNAPSHOT_SHA:
        raise RuntimeError("Snapshot hash mismatch.")
    if sha256(yf)!=EXPECTED_YOUNG_SHA:
        raise RuntimeError("Young frozen hash mismatch.")
    if sha256(cf)!=EXPECTED_CONTROL_SHA:
        raise RuntimeError("Control frozen hash mismatch.")

    cat=pd.read_csv(snap,low_memory=False)
    for c in ["ID","MassJ","RA_ICRS","DE_ICRS","dist50","pmRA","pmDE","RV"]:
        if c not in cat.columns:
            raise RuntimeError(f"Missing catalogue field {c}")
    cat["ID"]=pd.to_numeric(cat["ID"],errors="coerce")
    for c in ["MassJ","RA_ICRS","DE_ICRS","dist50","pmRA","pmDE","RV"]:
        cat[c]=pd.to_numeric(cat[c],errors="coerce")

    def bind(f,label):
        d=pd.read_csv(f)
        d["ID"]=pd.to_numeric(d["ID"],errors="coerce")
        if "MassJ" in d.columns:
            d["MassJ"]=pd.to_numeric(d["MassJ"],errors="coerce")
            d=d[d["MassJ"]>=3000].copy()
        x=d[["ID","Name"]].merge(
            cat[["ID","Name","MassJ","RA_ICRS","DE_ICRS","dist50","pmRA","pmDE","RV"]],
            on="ID",how="left",suffixes=("_frozen","_cat"),validate="one_to_one"
        )
        x=x.sort_values("ID").reset_index(drop=True)
        if len(x)<2:
            raise RuntimeError(f"{label}: fewer than 2 high-mass rows")
        return x.iloc[:2].copy()

    young=bind(yf,"young")
    control=bind(cf,"control")
    diag=pd.concat(
        [young.assign(sample="young"),control.assign(sample="control")],
        ignore_index=True
    )

    phase_cols=["RA_ICRS","DE_ICRS","dist50","pmRA","pmDE","RV"]
    if diag[phase_cols].isna().any().any():
        raise RuntimeError("Diagnostic rows lack finite 6D coordinates.")

    import astropy.units as u
    from astropy.coordinates import SkyCoord
    import galpy
    from galpy.orbit import Orbit
    from galpy.util import conversion
    from galpy.potential.mwpotentials import McMillan17, Irrgang13III
    from galpy.potential import MWPotential2014

    potentials={
        "McMillan17":McMillan17,
        "Irrgang13III":Irrgang13III,
        "MWPotential2014":MWPotential2014,
    }

    # Peculiar solar motion only. ro/vo are potential-specific below.
    zo=0.0208
    solarmotion=[11.1,12.24,7.25]

    # Static-potential diagnostic: current phase-space is t=0, integrate
    # forward for 1 Gyr. Internal time units are recomputed for each potential.
    t_gyr=np.linspace(0.0,1.0,2001)

    scale_rows=[]
    for pname,pot in potentials.items():
        phys=conversion.get_physical(pot,include_set=True)
        ro=float(phys["ro"])
        vo=float(phys["vo"])
        scale_rows.append({
            "potential":pname,
            "ro_kpc":ro,
            "vo_kms":vo,
            "roSet":bool(phys.get("roSet",False)),
            "voSet":bool(phys.get("voSet",False)),
            "time_unit_Gyr":float(conversion.time_in_Gyr(vo=vo,ro=ro)),
        })
    scales=pd.DataFrame(scale_rows)
    scales.to_csv(out/"00_POTENTIAL_PHYSICAL_SCALES.csv",index=False)

    print("="*108)
    print(f"YHMC STAGE-6B0R1 POTENTIAL-UNIT BINDING MICROPILOT v{VERSION}")
    print("="*108)
    print("IMPLEMENTATION_ONLY=True")
    print("ALIGNMENT_READ=False")
    print("CORRELATION_COMPUTED=False")
    print("SCIENCE_ORBIT_PROXY_FROZEN=False")
    print(f"GALPY_VERSION={getattr(galpy,'__version__','UNKNOWN')}")
    print()
    print("POTENTIAL PHYSICAL SCALES:")
    print(scales.to_string(index=False))

    rows=[]
    for _,r in diag.iterrows():
        sc=SkyCoord(
            ra=float(r["RA_ICRS"])*u.deg,
            dec=float(r["DE_ICRS"])*u.deg,
            distance=float(r["dist50"])*u.pc,
            pm_ra_cosdec=float(r["pmRA"])*u.mas/u.yr,
            pm_dec=float(r["pmDE"])*u.mas/u.yr,
            radial_velocity=float(r["RV"])*u.km/u.s,
            frame="icrs",
        )

        for pname,pot in potentials.items():
            phys=conversion.get_physical(pot)
            ro=float(phys["ro"])
            vo=float(phys["vo"])
            tunit=float(conversion.time_in_Gyr(vo=vo,ro=ro))
            ts=t_gyr/tunit

            status="PASS"
            method_used=""
            diagnostic_message=""

            try:
                orb=Orbit(
                    sc,
                    ro=ro,
                    vo=vo,
                    zo=zo,
                    solarmotion=solarmotion,
                )

                # Prefer C route if available, but C-extension absence is not
                # a science failure. Fall back to pure-Python dop853.
                try:
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        orb.integrate(ts,pot,method="dop853_c",progressbar=False)
                    method_used="dop853_c"
                except Exception as e_c:
                    orb=Orbit(
                        sc,
                        ro=ro,
                        vo=vo,
                        zo=zo,
                        solarmotion=solarmotion,
                    )
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        orb.integrate(ts,pot,method="dop853",progressbar=False)
                    method_used="dop853"
                    diagnostic_message="C_FALLBACK: "+repr(e_c)

                rperi=float(orb.rperi(use_physical=True))
                rap=float(orb.rap(use_physical=True))
                ecc=float(orb.e())
                zmax=float(orb.zmax(use_physical=True))
                finite=bool(np.all(np.isfinite([rperi,rap,ecc,zmax])))

                if not finite:
                    status="FAIL_NONFINITE_METRICS"

            except Exception as e:
                status="FAIL"
                finite=False
                rperi=rap=ecc=zmax=np.nan
                method_used=""
                diagnostic_message=repr(e)

            row={
                "sample":r["sample"],
                "ID":int(r["ID"]),
                "Name":r["Name_frozen"],
                "potential":pname,
                "potential_ro_kpc":ro,
                "potential_vo_kms":vo,
                "integration_method":method_used,
                "status":status,
                "finite_metrics":finite,
                "rperi_kpc":rperi,
                "rap_kpc":rap,
                "eccentricity":ecc,
                "zmax_kpc":zmax,
                "diagnostic_message":diagnostic_message,
            }
            rows.append(row)
            print(row)

    res=pd.DataFrame(rows)
    res.to_csv(out/"01_ORBIT_MICROPILOT_RESULTS.csv",index=False)

    allpass=bool(
        len(res)==12 and
        (res["status"]=="PASS").all() and
        res["finite_metrics"].all()
    )

    # Cross-potential spread is diagnostic only, not mechanism inference.
    spread=[]
    for (sample,cid,name),g in res.groupby(["sample","ID","Name"]):
        if g["finite_metrics"].all():
            spread.append({
                "sample":sample,
                "ID":int(cid),
                "Name":name,
                "rperi_min_kpc":float(g["rperi_kpc"].min()),
                "rperi_max_kpc":float(g["rperi_kpc"].max()),
                "rap_min_kpc":float(g["rap_kpc"].min()),
                "rap_max_kpc":float(g["rap_kpc"].max()),
                "ecc_min":float(g["eccentricity"].min()),
                "ecc_max":float(g["eccentricity"].max()),
                "zmax_min_kpc":float(g["zmax_kpc"].min()),
                "zmax_max_kpc":float(g["zmax_kpc"].max()),
            })
    spdf=pd.DataFrame(spread)
    spdf.to_csv(out/"02_CROSS_POTENTIAL_DIAGNOSTIC_SPREAD.csv",index=False)

    contract={
        "stage":"STAGE6B0R1_POTENTIAL_UNIT_BINDING_MICROPILOT",
        "version":VERSION,
        "implementation_only":True,
        "root_cause":
            "Stage-6B0 hard-coded Orbit ro/vo were incompatible with potentials carrying their own physical conversion scales.",
        "repair":
            "For each potential use conversion.get_physical(pot) consistently for Orbit initialization and time conversion.",
        "alignment_read":False,
        "correlation_computed":False,
        "science_orbit_proxy_frozen":False,
        "integration_horizon_Gyr":1.0,
        "diagnostic_cluster_count":4,
        "potential_count":3,
        "ALL_INTEGRATIONS_PASS":allpass,
        "next_if_pass":
            "Prospectively freeze Stage-6B1 science orbit design, including potential hierarchy, solar/scale convention, phase-space uncertainty propagation, orbit horizon, and mechanism endpoints before any alignment-orbit association is evaluated.",
        "next_if_fail":
            "Implementation repair only; no mechanism inference."
    }
    (out/"STAGE6B0R1_CONTRACT.json").write_text(
        json.dumps(contract,indent=2),encoding="utf-8"
    )

    report=[
        f"YHMC STAGE-6B0R1 POTENTIAL-UNIT BINDING MICROPILOT v{VERSION}",
        "="*108,
        "IMPLEMENTATION_ONLY=True",
        "ALIGNMENT_READ=False",
        "CORRELATION_COMPUTED=False",
        "SCIENCE_ORBIT_PROXY_FROZEN=False",
        "",
        "POTENTIAL PHYSICAL SCALES:",
        scales.to_string(index=False),
        "",
        "ORBIT DIAGNOSTICS:",
        res.to_string(index=False),
        "",
        "CROSS-POTENTIAL DIAGNOSTIC SPREAD:",
        spdf.to_string(index=False) if len(spdf) else "NONE",
        "",
        f"ALL_INTEGRATIONS_PASS={allpass}",
        "",
        "NEXT:",
        "  PASS -> prospective Stage-6B1 science orbit/mechanism design freeze.",
        "  FAIL -> implementation repair only.",
    ]
    (out/"STAGE6B0R1_REPORT.txt").write_text(
        "\n".join(report)+"\n",encoding="utf-8"
    )

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")

    print()
    print((out/"STAGE6B0R1_REPORT.txt").read_text(encoding="utf-8"))

    if not allpass:
        raise SystemExit(2)

if __name__=="__main__":
    main()

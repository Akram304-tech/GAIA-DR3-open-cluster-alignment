#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-6A1R1 Common-Support Cardinality Match v2.1.1

Outcome-blind redesign after Stage-6A1 full-cardinality match failed the
predeclared balance gate.

NO PA / NO ALIGNMENT / NO MORPHOLOGY.

Scientific principle
--------------------
Do not force all 95 Y1 anchors to match a Y2 population with incomplete
covariate overlap. Instead, restrict inference to the largest prospectively
defined common-support subset that satisfies the SAME Stage-6A1 balance gate:

    max absolute SMD <= 0.25

A frozen caliper grid is searched using covariates only. For each grid:
  1. construct eligible Y1--Y2 pairs under hard pooled-z calipers;
  2. solve an assignment with dummies so unmatched anchors are permitted;
  3. maximize cardinality first, then minimize matching cost;
  4. evaluate post-match balance.

Selection rule (frozen before any Y2 morphology/alignment):
  Choose the passing configuration with the largest N_pairs.
  Ties: smaller max_abs_SMD, then smaller mean pair cost, then earlier grid ID.

Additional acceptance:
  N_pairs >= 40
  max_abs_SMD <= 0.25

If no configuration passes, STOP. Do not perform Y2 morphology.

Covariates
----------
logMass, logDist, logNJ, AV50, |b|, cyclic Galactic longitude.

Frozen caliper grid (absolute pooled-z difference except longitude):
 G0: logMass<=0.75, logDist<=0.50, logNJ<=0.75, AV50<=0.75, |b|<=0.50, dlon<=45 deg
 G1: logMass<=1.00, logDist<=0.60, logNJ<=1.00, AV50<=0.85, |b|<=0.60, dlon<=60 deg
 G2: logMass<=1.00, logDist<=0.75, logNJ<=1.00, AV50<=1.00, |b|<=0.75, dlon<=75 deg
 G3: logMass<=1.25, logDist<=0.90, logNJ<=1.25, AV50<=1.10, |b|<=0.90, dlon<=90 deg
 G4: logMass<=1.50, logDist<=1.00, logNJ<=1.50, AV50<=1.25, |b|<=1.00, dlon<=120 deg

The grid is ordered from stricter to looser support.
"""

from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment

VERSION="2.1.1"
EXPECTED_CONTROL_SHA="124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd"
EXPECTED_FULL_SNAPSHOT_SHA="2164adf7ed3e516f035f60c6e6bfc06affbc4d809157c8eb06306d3e78d2cb47"

AGE_LO=math.log10(5e8)
AGE_HI=math.log10(2e9)
MASS_MIN=1000.0
BALANCE_GATE=0.25
MIN_PAIRS=40

CALIPERS=[
    ("G0",0.75,0.50,0.75,0.75,0.50,45.0),
    ("G1",1.00,0.60,1.00,0.85,0.60,60.0),
    ("G2",1.00,0.75,1.00,1.00,0.75,75.0),
    ("G3",1.25,0.90,1.25,1.10,0.90,90.0),
    ("G4",1.50,1.00,1.50,1.25,1.00,120.0),
]
# tuple: id, logMass, logDist, logNJ, AV50, abs_b, dlon_deg

WEIGHTS={"logMass":1.5,"logDist":1.5,"logNJ":1.0,"AV50":1.0,"abs_b":1.0,"dlon":1.0}

def sha256(p):
    h=hashlib.sha256()
    with Path(p).open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()

def num(df,c): return pd.to_numeric(df[c],errors="coerce")

def base_quality(df):
    typ=df["Type"].astype(str).str.strip().str.lower()
    return (
        (typ=="o") & (num(df,"CST")>=5) & (num(df,"CMDCl50")>=0.5) &
        (num(df,"probJ")>=0.5) & (num(df,"NJ")>=40) &
        np.isfinite(num(df,"rJ")) & (num(df,"rJ")>0) &
        np.isfinite(num(df,"r50J")) & (num(df,"r50J")>0) &
        np.isfinite(num(df,"MassJ")) & (num(df,"MassJ")>0) &
        np.isfinite(num(df,"logAge50"))
    )

def features(df):
    out=pd.DataFrame(index=df.index)
    out["logMass"]=np.log10(num(df,"MassJ"))
    out["logDist"]=np.log10(num(df,"dist50"))
    out["logNJ"]=np.log10(num(df,"NJ"))
    out["AV50"]=num(df,"AV50")
    out["abs_b"]=np.abs(num(df,"GLAT"))
    out["GLON"]=num(df,"GLON")%360.0
    return out

def smd(a,b):
    a=np.asarray(a,float); b=np.asarray(b,float)
    va=np.nanvar(a,ddof=1); vb=np.nanvar(b,ddof=1)
    den=np.sqrt((va+vb)/2.0)
    return float((np.nanmean(a)-np.nanmean(b))/den) if den>0 else 0.0

def solve_grid(A,C,Az,Cz,grid):
    gid,cm,cd,cn,cav,cb,clon=grid
    na,nc=len(A),len(C)

    diffs={}
    for col in ["logMass","logDist","logNJ","AV50","abs_b"]:
        diffs[col]=np.abs(Az[col].to_numpy()[:,None]-Cz[col].to_numpy()[None,:])
    dl=np.abs(A["GLON"].to_numpy()[:,None]-C["GLON"].to_numpy()[None,:])
    dl=np.minimum(dl,360.0-dl)

    eligible=(
        (diffs["logMass"]<=cm) &
        (diffs["logDist"]<=cd) &
        (diffs["logNJ"]<=cn) &
        (diffs["AV50"]<=cav) &
        (diffs["abs_b"]<=cb) &
        (dl<=clon)
    )

    # Real-pair normalized cost.
    cost=np.zeros((na,nc),float)
    cost += WEIGHTS["logMass"]*(diffs["logMass"]/cm)**2
    cost += WEIGHTS["logDist"]*(diffs["logDist"]/cd)**2
    cost += WEIGHTS["logNJ"]*(diffs["logNJ"]/cn)**2
    cost += WEIGHTS["AV50"]*(diffs["AV50"]/cav)**2
    cost += WEIGHTS["abs_b"]*(diffs["abs_b"]/cb)**2
    cost += WEIGHTS["dlon"]*(dl/clon)**2

    # Dummies allow each anchor to remain unmatched.
    # Large dummy penalty ensures maximum cardinality is optimized before cost.
    max_real=50.0
    dummy_penalty=1000.0
    ineligible_penalty=1e9
    M=np.full((na,nc+na),ineligible_penalty,float)
    M[:,:nc]=np.where(eligible,cost,ineligible_penalty)
    for i in range(na):
        M[i,nc+i]=dummy_penalty

    rr,cc=linear_sum_assignment(M)
    real=(cc<nc) & (M[rr,cc]<dummy_penalty)
    rr=rr[real]; cc=cc[real]
    if len(rr)==0:
        return None

    # Unique assignment guaranteed.
    At=A.iloc[rr].reset_index(drop=True)
    Ct=C.iloc[cc].reset_index(drop=True)

    bal=[]
    for col in ["logMass","logDist","logNJ","AV50","abs_b"]:
        v=smd(At[col],Ct[col])
        bal.append((col,v,abs(v)))
    maxs=max(x[2] for x in bal)
    mean_cost=float(np.mean(cost[rr,cc]))
    return {
        "grid_id":gid,"rr":rr,"cc":cc,"N_pairs":len(rr),
        "max_abs_SMD":float(maxs),"mean_pair_cost":mean_cost,
        "balance":bal,"eligible_pairs":int(eligible.sum()),
        "passes":bool(len(rr)>=MIN_PAIRS and maxs<=BALANCE_GATE),
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage6",required=True)
    ap.add_argument("--stage2c",required=True)
    ap.add_argument("--out",default="STAGE6A1R1_OUTPUT")
    args=ap.parse_args()

    s6=Path(args.stage6).resolve()
    s2=Path(args.stage2c).resolve()
    out=Path(args.out).resolve(); out.mkdir(parents=True,exist_ok=True)

    snap=s6/"00_HUNT_REFFERT_FULLCOLUMN_SNAPSHOT.csv"
    cf=s2/"02_CONTROL_PA_SAMPLE_FROZEN.csv"
    if sha256(snap)!=EXPECTED_FULL_SNAPSHOT_SHA: raise RuntimeError("Stage-6 snapshot hash mismatch.")
    if sha256(cf)!=EXPECTED_CONTROL_SHA: raise RuntimeError("Stage-2C control hash mismatch.")

    cat=pd.read_csv(snap,low_memory=False)
    controls=pd.read_csv(cf)
    cat["ID"]=pd.to_numeric(cat["ID"],errors="coerce")
    controls["ID"]=pd.to_numeric(controls["ID"],errors="coerce")
    cat["Name"]=cat["Name"].astype(str).str.strip()
    controls["Name"]=controls["Name"].astype(str).str.strip()
    if cat["ID"].duplicated().any(): raise RuntimeError("Catalogue ID not unique.")

    cols=["ID","Name","Type","CST","CMDCl50","probJ","NJ","rJ","r50J","MassJ",
          "logAge16","logAge50","logAge84","dist50","AV50","GLON","GLAT"]
    src=cat[cols].copy()
    anchors=controls[["ID","Name"]].merge(src,on="ID",how="left",
                                         suffixes=("_frozen","_catalog"),validate="one_to_one")
    if len(anchors)!=95 or anchors["MassJ"].isna().any():
        raise RuntimeError("Could not bind all 95 Y1 anchors.")

    q=base_quality(cat)
    age=(num(cat,"logAge50")>AGE_LO)&(num(cat,"logAge50")<=AGE_HI)
    cand=cat.loc[q&age&(num(cat,"MassJ")>=MASS_MIN),cols].copy()
    if len(cand)!=142: raise RuntimeError(f"Expected 142 Y2 candidates, got {len(cand)}")

    A=features(anchors)
    C=features(cand)
    basics=["logMass","logDist","logNJ","AV50","abs_b"]
    pooled=pd.concat([A[basics],C[basics]],ignore_index=True)
    mu=pooled.mean(); sd=pooled.std(ddof=1).replace(0,1.0)
    Az=(A[basics]-mu)/sd
    Cz=(C[basics]-mu)/sd

    results=[]
    detail={}
    for g in CALIPERS:
        r=solve_grid(A,C,Az,Cz,g)
        if r is None:
            results.append({
                "grid_id":g[0],"N_pairs":0,"eligible_pairs":0,
                "max_abs_SMD":np.nan,"mean_pair_cost":np.nan,"passes":False
            })
            continue
        detail[g[0]]=r
        results.append({
            "grid_id":r["grid_id"],"N_pairs":r["N_pairs"],
            "eligible_pairs":r["eligible_pairs"],
            "max_abs_SMD":r["max_abs_SMD"],
            "mean_pair_cost":r["mean_pair_cost"],
            "passes":r["passes"],
        })
    rdf=pd.DataFrame(results)
    rdf.to_csv(out/"01_CALIPER_GRID_RESULTS.csv",index=False)

    passing=rdf[rdf["passes"]==True].copy()
    if len(passing)==0:
        contract={
            "stage":"STAGE6A1R1_COMMON_SUPPORT_CARDINALITY_MATCH",
            "version":VERSION,"alignment_blind":True,
            "MATCH_ACCEPTED":False,
            "reason":"No frozen caliper configuration achieved N>=40 and max|SMD|<=0.25.",
            "next":"STOP age-extension morphology. Reconsider estimand, not alignment outcome."
        }
        (out/"STAGE6A1R1_FREEZE.json").write_text(json.dumps(contract,indent=2),encoding="utf-8")
        rep=[
            f"YHMC STAGE-6A1R1 COMMON-SUPPORT CARDINALITY MATCH v{VERSION}",
            "="*104,
            "NO_NEW_COHORT_PA=True",
            "NO_NEW_COHORT_ALIGNMENT=True",
            "",
            "CALIPER GRID:",
            rdf.to_string(index=False),
            "",
            "MATCH_ACCEPTED=False",
            "REASON=No prospectively frozen grid achieved N_pairs>=40 and max_abs_SMD<=0.25.",
        ]
        (out/"STAGE6A1R1_REPORT.txt").write_text("\n".join(rep)+"\n",encoding="utf-8")
        print((out/"STAGE6A1R1_REPORT.txt").read_text(encoding="utf-8"))
        return

    # Deterministic selection: max N, min maxSMD, min cost, earliest grid.
    order={g[0]:i for i,g in enumerate(CALIPERS)}
    passing["grid_order"]=passing["grid_id"].map(order)
    passing=passing.sort_values(
        ["N_pairs","max_abs_SMD","mean_pair_cost","grid_order"],
        ascending=[False,True,True,True]
    )
    selected_grid=str(passing.iloc[0]["grid_id"])
    best=detail[selected_grid]

    rr,cc=best["rr"],best["cc"]
    anc=anchors.iloc[rr].reset_index(drop=True)
    sel=cand.iloc[cc].reset_index(drop=True)

    match=pd.DataFrame({
        "anchor_ID":anc["ID"].astype(int),
        "anchor_Name":anc["Name_frozen"],
        "new_ID":sel["ID"].astype(int),
        "new_Name":sel["Name"],
    })
    for c in ["MassJ","logAge16","logAge50","logAge84","dist50","NJ","AV50","GLON","GLAT"]:
        match[f"anchor_{c}"]=anc[c].to_numpy()
        match[f"new_{c}"]=sel[c].to_numpy()

    sel["AGE_INTERVAL_SECURE"]=(
        np.isfinite(num(sel,"logAge16")) & np.isfinite(num(sel,"logAge84")) &
        (num(sel,"logAge16")>AGE_LO) & (num(sel,"logAge84")<=AGE_HI)
    )
    match["new_AGE_INTERVAL_SECURE"]=sel["AGE_INTERVAL_SECURE"].to_numpy(bool)

    # Pairwise diagnostic values.
    Af=features(anc); Sf=features(sel)
    dlon=np.abs(Af["GLON"].to_numpy()-Sf["GLON"].to_numpy())
    dlon=np.minimum(dlon,360.0-dlon)
    match["pair_dlon_deg"]=dlon

    baldf=pd.DataFrame([
        {"covariate":c,"SMD":v,"abs_SMD":av}
        for c,v,av in best["balance"]
    ])

    match.to_csv(out/"02_COMMON_SUPPORT_MATCH_TABLE_FROZEN.csv",index=False)
    sel.to_csv(out/"03_Y2_COMMON_SUPPORT_COHORT_FROZEN.csv",index=False)
    anc.to_csv(out/"04_Y1_COMMON_SUPPORT_ANCHORS_FROZEN.csv",index=False)
    baldf.to_csv(out/"05_SELECTED_MATCH_BALANCE.csv",index=False)

    hm=sha256(out/"02_COMMON_SUPPORT_MATCH_TABLE_FROZEN.csv")
    hs=sha256(out/"03_Y2_COMMON_SUPPORT_COHORT_FROZEN.csv")
    ha=sha256(out/"04_Y1_COMMON_SUPPORT_ANCHORS_FROZEN.csv")

    contract={
        "stage":"STAGE6A1R1_COMMON_SUPPORT_CARDINALITY_MATCH",
        "version":VERSION,
        "alignment_blind":True,
        "selection_rule":"largest passing cardinality; ties min maxSMD, min mean cost, earliest grid",
        "selected_grid":selected_grid,
        "N_pairs":int(best["N_pairs"]),
        "max_abs_SMD":float(best["max_abs_SMD"]),
        "balance_gate":BALANCE_GATE,
        "minimum_pairs":MIN_PAIRS,
        "MATCH_ACCEPTED":True,
        "Y2_cohort_sha256":hs,
        "Y1_anchor_subset_sha256":ha,
        "match_table_sha256":hm,
        "estimand":
            "Age evolution within the covariate-overlap population shared by 100-500 Myr and 0.5-2 Gyr clusters.",
        "next":
            "Acquire member data and independently blind-calibrate PA recovery for exact Y2 common-support identities before any Y2 alignment."
    }
    (out/"STAGE6A1R1_FREEZE.json").write_text(json.dumps(contract,indent=2),encoding="utf-8")

    rep=[
        f"YHMC STAGE-6A1R1 COMMON-SUPPORT CARDINALITY MATCH v{VERSION}",
        "="*104,
        "NO_NEW_COHORT_PA=True",
        "NO_NEW_COHORT_ALIGNMENT=True",
        "",
        "CALIPER GRID:",
        rdf.to_string(index=False),
        "",
        f"SELECTED_GRID={selected_grid}",
        f"N_PAIRS={best['N_pairs']}",
        f"Y2_MASS_GE3000_N={int((num(sel,'MassJ')>=3000).sum())}",
        f"Y2_MASS_GE5000_N={int((num(sel,'MassJ')>=5000).sum())}",
        f"Y2_AGE_INTERVAL_SECURE_N={int(sel['AGE_INTERVAL_SECURE'].sum())}",
        "",
        "SELECTED BALANCE:",
        baldf.to_string(index=False),
        "",
        f"MAX_ABS_SMD={best['max_abs_SMD']:.6f}",
        f"BALANCE_GATE={BALANCE_GATE:.2f}",
        f"MATCH_ACCEPTED=True",
        f"Y2_COHORT_SHA256={hs}",
        f"Y1_ANCHOR_SUBSET_SHA256={ha}",
        f"MATCH_TABLE_SHA256={hm}",
        "",
        "ESTIMAND:",
        "  Common-support 100-500 Myr vs 0.5-2 Gyr age evolution.",
        "",
        "NEXT:",
        "  Stage-6A2 member acquisition + blind PA calibration for exact Y2 common-support cohort.",
    ]
    (out/"STAGE6A1R1_REPORT.txt").write_text("\n".join(rep)+"\n",encoding="utf-8")

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file(): manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")
    print((out/"STAGE6A1R1_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

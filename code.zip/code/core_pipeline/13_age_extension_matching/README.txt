YHMC Stage-6A1R1 Common-Support Cardinality Match v2.1.1
=============================================================

Stage-6A1 proved that forcing all 95 Y1 anchors into a 1:1 Y2 match violates
the predeclared balance gate, especially in |b| and distance.

This outcome-blind redesign changes the estimand to the largest common-support
population. It searches a frozen hard-caliper grid using covariates only.

Acceptance remains:
  N_pairs >= 40
  max absolute SMD <= 0.25

No Y2 morphology, PA, or alignment is read or calculated.

If no frozen grid passes, the age-extension branch stops rather than tuning
against any alignment result.

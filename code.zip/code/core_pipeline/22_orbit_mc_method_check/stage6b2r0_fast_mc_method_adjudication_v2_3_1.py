#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse, json, hashlib
from pathlib import Path
import numpy as np
import pandas as pd

VERSION="2.3.1"
RPERI_MED_MAX=0.01
RPERI_MAX_MAX=0.03
RAP_MED_MAX=0.01
RAP_MAX_MAX=0.03
ECC_MED_MAX=0.01
ECC_MAX_MAX=0.03
ZMAX_MED_MAX=0.03
ZMAX_MAX_MAX=0.10
Z_SUN_KPC=0.0208
SOLAR_MOTION=[11.1,12.24,7.25]

def sha256(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()

def physical_ok(rp,ra,e,z):
    return bool(np.isfinite(rp) and np.isfinite(ra) and np.isfinite(e) and np.isfinite(z)
                and rp>0 and ra>=rp and 0<=e<1 and z>=0)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage6",required=True)
    ap.add_argument("--stage6b0r1",required=True)
    ap.add_argument("--out",default="STAGE6B2R0_OUTPUT")
    args=ap.parse_args()

    s6=Path(args.stage6).resolve()
    sb=Path(args.stage6b0r1).resolve()
    out=Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)

    catf=s6/"00_HUNT_REFFERT_FULLCOLUMN_SNAPSHOT.csv"
    numf=sb/"01_ORBIT_MICROPILOT_RESULTS.csv"
    if not catf.exists(): raise FileNotFoundError(catf)
    if not numf.exists(): raise FileNotFoundError(numf)

    cat=pd.read_csv(catf,low_memory=False)
    num=pd.read_csv(numf)
    cat["ID"]=pd.to_numeric(cat["ID"],errors="raise").astype(int)
    num["ID"]=pd.to_numeric(num["ID"],errors="raise").astype(int)

    if len(num)!=12 or not (num["status"].astype(str)=="PASS").all():
        raise RuntimeError("Expected 12 PASS numerical diagnostic rows from Stage-6B0R1.")

    import astropy.units as u
    from astropy.coordinates import SkyCoord
    from galpy.orbit import Orbit
    from galpy.util import conversion
    from galpy.potential.mwpotentials import McMillan17, Irrgang13III
    from galpy.potential import MWPotential2014

    pots={"McMillan17":McMillan17,"Irrgang13III":Irrgang13III,"MWPotential2014":MWPotential2014}

    src=cat[["ID","RA_ICRS","DE_ICRS","dist50","pmRA","pmDE","RV"]].copy()
    d=num.merge(src,on="ID",how="left",validate="many_to_one")

    rows=[]
    for _,r in d.iterrows():
        pname=str(r["potential"])
        pot=pots[pname]
        ph=conversion.get_physical(pot)
        ro=float(ph["ro"]); vo=float(ph["vo"])

        sc=SkyCoord(
            ra=float(r["RA_ICRS"])*u.deg,
            dec=float(r["DE_ICRS"])*u.deg,
            distance=float(r["dist50"])*u.pc,
            pm_ra_cosdec=float(r["pmRA"])*u.mas/u.yr,
            pm_dec=float(r["pmDE"])*u.mas/u.yr,
            radial_velocity=float(r["RV"])*u.km/u.s,
            frame="icrs",
        )
        o=Orbit(sc, ro=ro, vo=vo, zo=Z_SUN_KPC, solarmotion=SOLAR_MOTION)

        rp=float(o.rperi(analytic=True,pot=pot,type="staeckel",use_physical=True))
        ra=float(o.rap(analytic=True,pot=pot,type="staeckel",use_physical=True))
        ec=float(o.e(analytic=True,pot=pot,type="staeckel"))
        zm=float(o.zmax(analytic=True,pot=pot,type="staeckel",use_physical=True))

        nrp=float(r["rperi_kpc"]); nra=float(r["rap_kpc"])
        nec=float(r["eccentricity"]); nzm=float(r["zmax_kpc"])

        rows.append({
            "sample":r["sample"],"ID":int(r["ID"]),"Name":r["Name"],"potential":pname,
            "physical_ok":physical_ok(rp,ra,ec,zm),
            "numeric_rperi_kpc":nrp,"staeckel_rperi_kpc":rp,
            "rperi_frac_abs_diff":abs(rp-nrp)/abs(nrp),
            "numeric_rap_kpc":nra,"staeckel_rap_kpc":ra,
            "rap_frac_abs_diff":abs(ra-nra)/abs(nra),
            "numeric_ecc":nec,"staeckel_ecc":ec,
            "ecc_abs_diff":abs(ec-nec),
            "numeric_zmax_kpc":nzm,"staeckel_zmax_kpc":zm,
            "zmax_frac_abs_diff":abs(zm-nzm)/max(abs(nzm),1e-12),
        })

    rdf=pd.DataFrame(rows)
    rdf.to_csv(out/"01_NUMERIC_VS_STAECKEL_DIAGNOSTIC.csv",index=False)

    m={
        "all_12_physical": bool(rdf["physical_ok"].all()),
        "rperi_median_frac_abs_diff": float(rdf["rperi_frac_abs_diff"].median()),
        "rperi_max_frac_abs_diff": float(rdf["rperi_frac_abs_diff"].max()),
        "rap_median_frac_abs_diff": float(rdf["rap_frac_abs_diff"].median()),
        "rap_max_frac_abs_diff": float(rdf["rap_frac_abs_diff"].max()),
        "ecc_median_abs_diff": float(rdf["ecc_abs_diff"].median()),
        "ecc_max_abs_diff": float(rdf["ecc_abs_diff"].max()),
        "zmax_median_frac_abs_diff": float(rdf["zmax_frac_abs_diff"].median()),
        "zmax_max_frac_abs_diff": float(rdf["zmax_frac_abs_diff"].max()),
    }

    passed=bool(
        m["all_12_physical"] and
        m["rperi_median_frac_abs_diff"]<=RPERI_MED_MAX and
        m["rperi_max_frac_abs_diff"]<=RPERI_MAX_MAX and
        m["rap_median_frac_abs_diff"]<=RAP_MED_MAX and
        m["rap_max_frac_abs_diff"]<=RAP_MAX_MAX and
        m["ecc_median_abs_diff"]<=ECC_MED_MAX and
        m["ecc_max_abs_diff"]<=ECC_MAX_MAX and
        m["zmax_median_frac_abs_diff"]<=ZMAX_MED_MAX and
        m["zmax_max_frac_abs_diff"]<=ZMAX_MAX_MAX
    )

    contract={
        "stage":"STAGE6B2R0_FAST_MC_METHOD_ADJUDICATION",
        "version":VERSION,
        "performance_only":True,
        "alignment_read":False,
        "correlation_computed":False,
        "primary_nominal_orbit_method_changed":False,
        "candidate_MC_method":"galpy Staeckel analytic fast characterization",
        "diagnostic_rows":12,
        "acceptance":{
            "rperi_median_frac_abs_diff_le":RPERI_MED_MAX,
            "rperi_max_frac_abs_diff_le":RPERI_MAX_MAX,
            "rap_median_frac_abs_diff_le":RAP_MED_MAX,
            "rap_max_frac_abs_diff_le":RAP_MAX_MAX,
            "ecc_median_abs_diff_le":ECC_MED_MAX,
            "ecc_max_abs_diff_le":ECC_MAX_MAX,
            "zmax_median_frac_abs_diff_le":ZMAX_MED_MAX,
            "zmax_max_frac_abs_diff_le":ZMAX_MAX_MAX,
        },
        "observed":m,
        "FAST_MC_METHOD_AUTHORIZED":passed,
        "next_if_pass":"Use full numerical integration for nominal 45x3 orbits; use Staeckel only for 512-draw MC uncertainty layer.",
        "next_if_fail":"Do not use Staeckel MC amendment."
    }
    (out/"STAGE6B2R0_ADJUDICATION.json").write_text(json.dumps(contract,indent=2),encoding="utf-8")

    report=[
        f"YHMC STAGE-6B2R0 FAST-MC METHOD ADJUDICATION v{VERSION}",
        "="*108,
        "PERFORMANCE_ONLY=True",
        "ALIGNMENT_READ=False",
        "CORRELATION_COMPUTED=False",
        "PRIMARY_NOMINAL_METHOD_CHANGED=False",
        "",
        "NUMERIC VS STAECKEL:",
        rdf[["sample","ID","potential","rperi_frac_abs_diff","rap_frac_abs_diff","ecc_abs_diff","zmax_frac_abs_diff"]].to_string(index=False),
        "",
        f"RPERI_MEDIAN_FRAC_DIFF={m['rperi_median_frac_abs_diff']:.8f}",
        f"RPERI_MAX_FRAC_DIFF={m['rperi_max_frac_abs_diff']:.8f}",
        f"RAP_MEDIAN_FRAC_DIFF={m['rap_median_frac_abs_diff']:.8f}",
        f"RAP_MAX_FRAC_DIFF={m['rap_max_frac_abs_diff']:.8f}",
        f"ECC_MEDIAN_ABS_DIFF={m['ecc_median_abs_diff']:.8f}",
        f"ECC_MAX_ABS_DIFF={m['ecc_max_abs_diff']:.8f}",
        f"ZMAX_MEDIAN_FRAC_DIFF={m['zmax_median_frac_abs_diff']:.8f}",
        f"ZMAX_MAX_FRAC_DIFF={m['zmax_max_frac_abs_diff']:.8f}",
        f"FAST_MC_METHOD_AUTHORIZED={passed}",
    ]
    (out/"STAGE6B2R0_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    lines=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            lines.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(lines)+"\n",encoding="utf-8")

    print((out/"STAGE6B2R0_REPORT.txt").read_text(encoding="utf-8"))
    if not passed:
        raise SystemExit(2)

if __name__=="__main__":
    main()

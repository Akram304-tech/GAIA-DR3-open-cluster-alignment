YHMC Stage-6B2R0 Fast-MC Method Adjudication v2.3.1

The original Stage-6B2 numerical MC implementation was active but impractically slow.
This package does not touch alignment outcomes.

It compares galpy's fast Staeckel orbit characterization against the 12 numerical
diagnostic orbits already frozen in Stage-6B0R1.

If strict agreement gates pass, only the secondary 512-draw uncertainty layer may
switch to Staeckel. The nominal 45 x 3 science orbits remain full 1-Gyr numerical
integrations, so the primary McMillan17 nominal rperi endpoint is unchanged.

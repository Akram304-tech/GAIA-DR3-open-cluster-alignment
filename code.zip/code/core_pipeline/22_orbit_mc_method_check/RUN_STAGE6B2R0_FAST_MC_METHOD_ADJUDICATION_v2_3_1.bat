@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-6B2R0 FAST-MC METHOD ADJUDICATION v2.3.1
echo PERFORMANCE ONLY / NO ALIGNMENT
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" exit /b 1

set "STAGE6=%USERPROFILE%\Downloads\YHMC_STAGE6_FULLCOLUMN_RECOVERY_v2_0_2\YHMC_STAGE6_FULLCOLUMN_RECOVERY_v2_0_2\STAGE6_FULLCOLUMN_OUTPUT"
set "STAGE6B0R1=%USERPROFILE%\Downloads\YHMC_STAGE6B0R1_POTENTIAL_UNIT_BINDING_MICROPILOT_v2_1_1\YHMC_STAGE6B0R1_POTENTIAL_UNIT_BINDING_MICROPILOT_v2_1_1\STAGE6B0R1_OUTPUT"

"%PYEXE%" -c "import numpy,pandas,astropy,galpy" >nul 2>nul
if errorlevel 1 exit /b 1

"%PYEXE%" stage6b2r0_fast_mc_method_adjudication_v2_3_1.py ^
 --stage6 "%STAGE6%" ^
 --stage6b0r1 "%STAGE6B0R1%" ^
 --out "%CD%\STAGE6B2R0_OUTPUT"

set "RC=%ERRORLEVEL%"
echo.
echo RETURN_CODE=%RC%
if exist "%CD%\STAGE6B2R0_OUTPUT\STAGE6B2R0_REPORT.txt" echo REPORT=%CD%\STAGE6B2R0_OUTPUT\STAGE6B2R0_REPORT.txt
if exist "%CD%\STAGE6B2R0_OUTPUT\STAGE6B2R0_ADJUDICATION.json" echo ADJUDICATION=%CD%\STAGE6B2R0_OUTPUT\STAGE6B2R0_ADJUDICATION.json
exit /b %RC%

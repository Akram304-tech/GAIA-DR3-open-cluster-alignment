#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-4A blind inner-r50J synthetic PA calibration v1.2.0

Purpose
-------
Independently calibrate projected-shape / PA recovery for the INNER region

    angular separation from catalogue centre <= r50J

for the exact already-frozen:
  * 95 young Stage-1B PA-resolved identities
  * 95 older-control Stage-2C PA-resolved identities

No REAL inner q, PA, Galactic-plane PA, Delta-theta, or alignment statistic
is computed in this stage.

Catalogue definition
--------------------
Hunt & Reffert (2024) r50J is in degrees and is the radius containing 50%
of members within the best-fitting Jacobi radius.

Inner readiness
---------------
Technical precondition only:
  N_inner >= 20
  Neff_inner >= 10

These criteria do NOT assert PA reliability. PA reliability is established
only by this synthetic-recovery calibration.

Synthetic design
----------------
For each eligible object:
  * retain actual inner-member angular radii;
  * retain membership-probability weights;
  * randomize polar angles;
  * impose known q_true and random axial PA_true;
  * recover q and PA with the SAME membership-weighted second-moment
    estimator used in the baseline outer analysis.

Frozen reliability rule
-----------------------
At each q_true:
  P68(|DeltaPA|) <= 20 deg
  median(|DeltaPA|) <= 10 deg
  |median(q_rec-q_true)| <= 0.05

q_max_PA_reliable is the roundest passing q for which all more-elongated
tested q values also pass.

Later Stage-4B inner real-morphology gate (pre-declared here)
-------------------------------------------------------------
  1) INNER_PA_CALIBRATABLE == True
  2) q84_inner_real <= q_max_inner_PA_reliable
  3) q_inner_point < q_inner_round_null_p05
  4) inner bootstrap P68(|DeltaPA|) <= 20 deg
"""

from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "1.2.0"
SEED = 20260912

Q_GRID = [1.00, 0.98, 0.96, 0.94, 0.92, 0.90, 0.85, 0.80, 0.70, 0.60]
N_REP = 250

MIN_N_INNER = 20
MIN_NEFF_INNER = 10.0
PA_P68_MAX = 20.0
PA_MED_MAX = 10.0
Q_BIAS_MED_MAX = 0.05

EXPECTED_YOUNG_SHA256 = "cc1d3ae4ce1cf52387f535da92fbd0dc5d984a3bb2dc750bf6672682e85f65dd"
EXPECTED_CONTROL_SHA256 = "124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd"
EXPECTED_CONTROL_LIST_SHA256 = "b31d69d0e90359f9d2a5e0d31db2ce20a3b7b9f5888862de9a15e8cb89ee7c6a"

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()

def safe_name(s):
    return "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in str(s))

def find_member_file(member_dir: Path, cid: int, name: str):
    hits = sorted(member_dir.glob(f"{int(cid):04d}_*.csv"))
    if not hits:
        return None
    if len(hits) == 1:
        return hits[0]
    sn = safe_name(name)
    for p in hits:
        if sn in p.stem:
            return p
    return hits[0]

def neff(w):
    w = np.asarray(w, dtype=float)
    w = w[np.isfinite(w) & (w > 0)]
    if len(w) == 0 or np.square(w).sum() <= 0:
        return 0.0
    return float(w.sum()**2 / np.square(w).sum())

def angular_sep_deg(ra, dec, ra0, dec0):
    """Stable spherical angular separation in degrees."""
    ra = np.deg2rad(np.asarray(ra, dtype=float))
    dec = np.deg2rad(np.asarray(dec, dtype=float))
    ra0 = math.radians(float(ra0))
    dec0 = math.radians(float(dec0))
    sd = np.sin((dec-dec0)/2.0)
    sr = np.sin((ra-ra0)/2.0)
    a = sd*sd + math.cos(dec0)*np.cos(dec)*sr*sr
    a = np.clip(a, 0.0, 1.0)
    return np.rad2deg(2.0*np.arcsin(np.sqrt(a)))

def tangent_xy_arcmin(ra, dec, ra0, dec0):
    ra = np.asarray(ra, dtype=float)
    dec = np.asarray(dec, dtype=float)
    dra = ((ra - float(ra0) + 180.0) % 360.0) - 180.0
    x = dra * math.cos(math.radians(float(dec0))) * 60.0
    y = (dec - float(dec0)) * 60.0
    return x, y

def weighted_shape(x, y, w):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    w = np.asarray(w, dtype=float)
    good = np.isfinite(x) & np.isfinite(y) & np.isfinite(w) & (w > 0)
    x, y, w = x[good], y[good], w[good]
    if len(x) < 3 or w.sum() <= 0:
        return np.nan, np.nan

    sw = w.sum()
    xc = np.sum(w*x)/sw
    yc = np.sum(w*y)/sw
    dx, dy = x-xc, y-yc

    sxx = np.sum(w*dx*dx)/sw
    syy = np.sum(w*dy*dy)/sw
    sxy = np.sum(w*dx*dy)/sw
    C = np.array([[sxx, sxy], [sxy, syy]], dtype=float)

    vals, vecs = np.linalg.eigh(C)
    order = np.argsort(vals)[::-1]
    vals = vals[order]
    vecs = vecs[:, order]
    if vals[0] <= 0 or vals[1] < 0:
        return np.nan, np.nan

    q = float(np.sqrt(max(vals[1], 0.0)/vals[0]))
    vx, vy = vecs[:, 0]
    pa = float(np.degrees(np.arctan2(vy, vx)) % 180.0)
    return q, pa

def axial_diff_deg(a, b):
    return ((float(a) - float(b) + 90.0) % 180.0) - 90.0

def pct(a, p):
    a = np.asarray(a, dtype=float)
    a = a[np.isfinite(a)]
    return float(np.percentile(a, p)) if len(a) else np.nan

def med(a):
    a = np.asarray(a, dtype=float)
    a = a[np.isfinite(a)]
    return float(np.median(a)) if len(a) else np.nan

def calibrate_object(r, w, cid, population_tag, nrep):
    records = []
    poptag = 1 if population_tag == "young" else 2

    for qi, qtrue in enumerate(Q_GRID):
        rng = np.random.default_rng(
            np.random.SeedSequence([SEED, int(cid), poptag, qi, nrep, 50])
        )
        qrec = np.full(nrep, np.nan)
        pae = np.full(nrep, np.nan)

        for k in range(nrep):
            theta = rng.uniform(0.0, 2.0*np.pi, size=len(r))
            phi = rng.uniform(0.0, np.pi)

            x0 = r*np.cos(theta)
            y0 = qtrue*r*np.sin(theta)

            cp = math.cos(phi)
            sp = math.sin(phi)
            x = cp*x0 - sp*y0
            y = sp*x0 + cp*y0

            qr, pr = weighted_shape(x, y, w)
            qrec[k] = qr
            if qtrue < 0.999 and np.isfinite(pr):
                pae[k] = abs(axial_diff_deg(pr, math.degrees(phi) % 180.0))

        qb = qrec - qtrue
        rec = {
            "q_true": qtrue,
            "N_rep": nrep,
            "qrec_median": med(qrec),
            "qrec_p05": pct(qrec, 5),
            "qrec_p16": pct(qrec, 16),
            "qrec_p84": pct(qrec, 84),
            "qrec_p95": pct(qrec, 95),
            "qbias_median": med(qb),
            "qbias_abs_p68": pct(np.abs(qb), 68),
        }

        if qtrue < 0.999:
            rec["pa_abs_median_deg"] = med(pae)
            rec["pa_abs_p68_deg"] = pct(pae, 68)
            rec["pa_abs_p95_deg"] = pct(pae, 95)
            rec["pa_reliable_at_q"] = bool(
                np.isfinite(rec["pa_abs_p68_deg"])
                and rec["pa_abs_p68_deg"] <= PA_P68_MAX
                and rec["pa_abs_median_deg"] <= PA_MED_MAX
                and abs(rec["qbias_median"]) <= Q_BIAS_MED_MAX
            )
        else:
            rec["pa_abs_median_deg"] = np.nan
            rec["pa_abs_p68_deg"] = np.nan
            rec["pa_abs_p95_deg"] = np.nan
            rec["pa_reliable_at_q"] = False

        records.append(rec)

    g = pd.DataFrame(records)
    roundrow = g[np.isclose(g["q_true"], 1.0)].iloc[0]
    nonround = g[g["q_true"] < 0.999].sort_values("q_true")
    passmap = {float(r.q_true): bool(r.pa_reliable_at_q) for r in nonround.itertuples()}
    qvals = sorted(passmap)
    reliable = []
    for q in qvals:
        if all(passmap[qq] for qq in qvals if qq <= q):
            reliable.append(q)

    gate = {
        "q_inner_round_null_p05": float(roundrow["qrec_p05"]),
        "q_inner_round_null_p16": float(roundrow["qrec_p16"]),
        "q_inner_round_null_median": float(roundrow["qrec_median"]),
        "q_max_inner_PA_reliable": max(reliable) if reliable else np.nan,
        "INNER_PA_CALIBRATABLE": bool(len(reliable) > 0),
    }
    return g, gate

def prepare_young(y, stage0_master):
    cols = ["ID", "Name", "r50J", "__RAdeg", "__DEdeg", "MassJ", "logAge50"]
    src = stage0_master[cols].copy()
    if src.duplicated(["ID", "Name"]).any():
        raise RuntimeError("Stage-0 source has duplicate ID+Name keys.")
    base = y[["ID", "Name"]].merge(src, on=["ID", "Name"], how="left", validate="one_to_one")
    return base

def prepare_control(c, stage2a_controls):
    cols = ["ID", "Name", "r50J", "__RAdeg", "__DEdeg", "MassJ", "logAge50"]
    src = stage2a_controls[cols].copy()
    if src.duplicated(["ID", "Name"]).any():
        raise RuntimeError("Stage-2A controls have duplicate ID+Name keys.")
    base = c[["ID", "Name"]].merge(src, on=["ID", "Name"], how="left", validate="one_to_one")
    return base

def process_population(base, member_dir, label, nrep):
    audit = []
    qgrid_rows = []
    gate_rows = []

    for ii, row in base.reset_index(drop=True).iterrows():
        cid = int(row["ID"])
        name = str(row["Name"])
        r50j = pd.to_numeric(pd.Series([row["r50J"]]), errors="coerce").iloc[0]

        if not np.isfinite(r50j) or r50j <= 0:
            audit.append({
                "population": label, "ID": cid, "Name": name,
                "status": "BAD_R50J"
            })
            print(f"{label:7s} {ii+1:3d}/{len(base):3d} {name}: BAD_R50J")
            continue

        mf = find_member_file(member_dir, cid, name)
        if mf is None:
            audit.append({
                "population": label, "ID": cid, "Name": name,
                "status": "MISSING_MEMBER_FILE"
            })
            print(f"{label:7s} {ii+1:3d}/{len(base):3d} {name}: MISSING_MEMBER_FILE")
            continue

        m = pd.read_csv(mf)
        need = {"Prob", "__RAdeg", "__DEdeg"}
        missing = sorted(need - set(m.columns))
        if missing:
            audit.append({
                "population": label, "ID": cid, "Name": name,
                "status": "BAD_MEMBER_SCHEMA", "missing": ";".join(missing)
            })
            print(f"{label:7s} {ii+1:3d}/{len(base):3d} {name}: BAD_MEMBER_SCHEMA")
            continue

        p = pd.to_numeric(m["Prob"], errors="coerce").to_numpy(float)
        ra = pd.to_numeric(m["__RAdeg"], errors="coerce").to_numpy(float)
        de = pd.to_numeric(m["__DEdeg"], errors="coerce").to_numpy(float)

        good = np.isfinite(p) & np.isfinite(ra) & np.isfinite(de) & (p >= 0.5)
        p, ra, de = p[good], ra[good], de[good]

        sep = angular_sep_deg(ra, de, row["__RAdeg"], row["__DEdeg"])
        inner = np.isfinite(sep) & (sep <= float(r50j))
        p, ra, de, sep = p[inner], ra[inner], de[inner], sep[inner]

        nin = len(p)
        nein = neff(p)
        ready = bool(nin >= MIN_N_INNER and nein >= MIN_NEFF_INNER)

        audit.append({
            "population": label,
            "ID": cid, "Name": name,
            "MassJ": row["MassJ"], "logAge50": row["logAge50"],
            "r50J_deg": r50j,
            "N_inner_P50": nin,
            "Neff_inner_P50": nein,
            "INNER_TECHNICALLY_READY": ready,
            "status": "OK" if ready else "INNER_TOO_FEW",
        })

        if not ready:
            print(
                f"{label:7s} {ii+1:3d}/{len(base):3d} {name}: "
                f"INNER_TOO_FEW N={nin}, Neff={nein:.1f}"
            )
            continue

        x, y = tangent_xy_arcmin(ra, de, row["__RAdeg"], row["__DEdeg"])
        rr = np.hypot(x, y)
        finite = np.isfinite(rr) & np.isfinite(p) & (p > 0)
        rr, p = rr[finite], p[finite]

        qgrid, gate = calibrate_object(rr, p, cid, label, nrep)
        qgrid.insert(0, "population", label)
        qgrid.insert(1, "ID", cid)
        qgrid.insert(2, "Name", name)
        qgrid["MassJ"] = row["MassJ"]
        qgrid["logAge50"] = row["logAge50"]
        qgrid["N_inner"] = len(rr)
        qgrid["Neff_inner"] = neff(p)
        qgrid_rows.append(qgrid)

        gate_rows.append({
            "population": label,
            "ID": cid, "Name": name,
            "MassJ": row["MassJ"], "logAge50": row["logAge50"],
            "r50J_deg": r50j,
            "N_inner": len(rr), "Neff_inner": neff(p),
            **gate,
            "LATER_STAGE4B_REAL_GATE":
                "INNER_PA_CALIBRATABLE AND q84_inner<=qmax_inner AND "
                "qpoint_inner<qroundnull05_inner AND bootPA68_inner<=20deg"
        })

        print(
            f"{label:7s} {ii+1:3d}/{len(base):3d} {name}: "
            f"N={len(rr)}, Neff={neff(p):.1f}, "
            f"qmax={gate['q_max_inner_PA_reliable']}"
        )

    audit_df = pd.DataFrame(audit)
    qgrid_df = pd.concat(qgrid_rows, ignore_index=True) if qgrid_rows else pd.DataFrame()
    gate_df = pd.DataFrame(gate_rows)
    return audit_df, qgrid_df, gate_df

def coverage_table(gate):
    rows = []
    for population in ["young", "control"]:
        g = gate[gate["population"] == population].copy()
        for m in [1000, 3000, 5000, 10000]:
            s = g[pd.to_numeric(g["MassJ"], errors="coerce") >= m]
            rows.append({
                "population": population,
                "MassJ_threshold_Msun": m,
                "N_inner_calibrated": len(s),
                "N_inner_PA_calibratable":
                    int(s["INNER_PA_CALIBRATABLE"].sum()) if len(s) else 0,
                "fraction_inner_PA_calibratable":
                    float(s["INNER_PA_CALIBRATABLE"].mean()) if len(s) else np.nan,
                "median_inner_Neff":
                    med(s["Neff_inner"]) if len(s) else np.nan,
                "median_inner_qmax_reliable":
                    med(s["q_max_inner_PA_reliable"]) if len(s) else np.nan,
            })
    return pd.DataFrame(rows)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage0", required=True)
    ap.add_argument("--stage1b", required=True)
    ap.add_argument("--stage2a", required=True)
    ap.add_argument("--stage2c", required=True)
    ap.add_argument("--out", default="STAGE4A_OUTPUT")
    ap.add_argument("--nrep", type=int, default=N_REP)
    args = ap.parse_args()

    stage0 = Path(args.stage0).expanduser().resolve()
    stage1b = Path(args.stage1b).expanduser().resolve()
    stage2a = Path(args.stage2a).expanduser().resolve()
    stage2c = Path(args.stage2c).expanduser().resolve()
    out = Path(args.out).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)

    yf = stage1b / "02_PRIMARY_PA_SAMPLE_FROZEN.csv"
    cf = stage2c / "02_CONTROL_PA_SAMPLE_FROZEN.csv"
    cfull = stage2a / "02_MATCHED_OLDER_CONTROLS_FROZEN.csv"
    s0 = stage0 / "07_provisional_morphology_ready.csv"

    for p in [yf, cf, cfull, s0]:
        if not p.exists():
            raise FileNotFoundError(p)

    hy = sha256(yf)
    hc = sha256(cf)
    hcf = sha256(cfull)
    if hy != EXPECTED_YOUNG_SHA256:
        raise RuntimeError(f"Young frozen sample hash mismatch: {hy}")
    if hc != EXPECTED_CONTROL_SHA256:
        raise RuntimeError(f"Control frozen PA sample hash mismatch: {hc}")
    if hcf != EXPECTED_CONTROL_LIST_SHA256:
        raise RuntimeError(f"Stage-2A full control-list hash mismatch: {hcf}")

    young = prepare_young(pd.read_csv(yf), pd.read_csv(s0))
    control = prepare_control(pd.read_csv(cf), pd.read_csv(cfull))

    if young[["r50J", "__RAdeg", "__DEdeg"]].isna().any().any():
        raise RuntimeError("Young r50J/coordinate join incomplete.")
    if control[["r50J", "__RAdeg", "__DEdeg"]].isna().any().any():
        raise RuntimeError("Control r50J/coordinate join incomplete.")

    print("="*98)
    print(f"YHMC STAGE-4A INNER r<r50J SYNTHETIC PA CALIBRATION v{VERSION}")
    print("="*98)
    print("CHAIN_OF_CUSTODY=PASS")
    print(f"YOUNG_FROZEN_SHA256={hy}")
    print(f"CONTROL_FROZEN_SHA256={hc}")
    print(f"STAGE2A_CONTROL_LIST_SHA256={hcf}")
    print(f"YOUNG_IDENTITIES={len(young)} CONTROL_IDENTITIES={len(control)}")
    print(f"Q_GRID={Q_GRID}")
    print(f"N_REP={args.nrep}")
    print(f"INNER_READINESS=N>={MIN_N_INNER}, Neff>={MIN_NEFF_INNER}")
    print("REAL_INNER_MORPHOLOGY_COMPUTED=False")
    print("INNER_ALIGNMENT_COMPUTED=False")

    ya, yq, yg = process_population(
        young, stage0/"members_primary", "young", args.nrep
    )
    ca, cq, cg = process_population(
        control, stage2a/"members_control_frozen", "control", args.nrep
    )

    audit = pd.concat([ya, ca], ignore_index=True)
    qgrid = pd.concat([yq, cq], ignore_index=True)
    gate = pd.concat([yg, cg], ignore_index=True)

    audit.to_csv(out/"01_inner_input_readiness_audit.csv", index=False)
    qgrid.to_csv(out/"02_inner_qgrid_recovery.csv", index=False)
    gate.to_csv(out/"03_inner_cluster_specific_PA_gate.csv", index=False)

    cov = coverage_table(gate)
    cov.to_csv(out/"04_inner_calibration_coverage.csv", index=False)

    global_rows = []
    if len(qgrid):
        for (population, q), g in qgrid.groupby(["population", "q_true"]):
            global_rows.append({
                "population": population,
                "q_true": q,
                "N_clusters": int(g["ID"].nunique()),
                "median_qbias_median": med(g["qbias_median"]),
                "median_PA_abs_median_deg": med(g["pa_abs_median_deg"]),
                "median_PA_abs_p68_deg": med(g["pa_abs_p68_deg"]),
                "fraction_reliable_at_q":
                    float(g["pa_reliable_at_q"].fillna(False).astype(bool).mean())
                    if q < 0.999 else np.nan,
            })
    pd.DataFrame(global_rows).to_csv(
        out/"05_inner_global_qgrid_summary.csv", index=False
    )

    freeze = {
        "stage": "STAGE4A_INNER_R50J_SYNTHETIC_PA_CALIBRATION",
        "version": VERSION,
        "seed": SEED,
        "young_frozen_sha256": hy,
        "control_frozen_sha256": hc,
        "stage2a_control_list_sha256": hcf,
        "inner_region_definition":
            "spherical angular separation from catalogue centre <= r50J (r50J in degrees)",
        "membership_cut": "Prob>=0.5; source member files already restricted to inrj=1",
        "technical_readiness": {
            "min_N_inner": MIN_N_INNER,
            "min_Neff_inner": MIN_NEFF_INNER,
        },
        "q_grid": Q_GRID,
        "n_rep": args.nrep,
        "estimator": "membership-probability weighted second central moments",
        "synthetic_design":
            "actual inner-member radii and weights, randomized polar angles, imposed q_true and random PA_true",
        "frozen_reliability_rule": {
            "P68_abs_DeltaPA_deg_max": PA_P68_MAX,
            "median_abs_DeltaPA_deg_max": PA_MED_MAX,
            "abs_median_q_bias_max": Q_BIAS_MED_MAX,
            "monotonic_requirement":
                "q_max passes only if all more-elongated tested q values pass",
        },
        "predeclared_stage4b_gate": [
            "INNER_PA_CALIBRATABLE == True",
            "q84_inner_real <= q_max_inner_PA_reliable",
            "q_inner_point < q_inner_round_null_p05",
            "inner bootstrap P68(|DeltaPA|) <= 20 deg",
        ],
        "real_inner_q_computed": False,
        "real_inner_PA_computed": False,
        "inner_alignment_computed": False,
        "next_stage":
            "Stage-4B real inner morphology freeze only; no inner Galactic-plane alignment before sample hash freeze.",
    }
    (out/"STAGE4A_FREEZE.json").write_text(
        json.dumps(freeze, indent=2), encoding="utf-8"
    )

    def status_counts(pop):
        a = audit[audit["population"] == pop]
        g = gate[gate["population"] == pop]
        return {
            "N_identity": len(young) if pop=="young" else len(control),
            "N_ready": int((a["status"]=="OK").sum()),
            "N_calibrated": len(g),
            "N_PA_calibratable":
                int(g["INNER_PA_CALIBRATABLE"].sum()) if len(g) else 0,
        }

    ys = status_counts("young")
    cs = status_counts("control")

    report = [
        f"YHMC STAGE-4A INNER r<r50J SYNTHETIC PA CALIBRATION v{VERSION}",
        "="*98,
        "CHAIN_OF_CUSTODY=PASS",
        f"YOUNG_FROZEN_SHA256={hy}",
        f"CONTROL_FROZEN_SHA256={hc}",
        f"Stage-2A full control list SHA256={hcf}",
        "",
        "INNER REGION:",
        "  spherical angular separation from catalogue centre <= r50J",
        "  r50J is used in degrees",
        "  Prob>=0.5; source member files are already inrj=1",
        f"  technical readiness: N_inner>={MIN_N_INNER}, Neff_inner>={MIN_NEFF_INNER}",
        "",
        "YOUNG:",
        f"  frozen identities = {ys['N_identity']}",
        f"  inner technically ready = {ys['N_ready']}",
        f"  inner calibrated = {ys['N_calibrated']}",
        f"  inner PA-calibratable = {ys['N_PA_calibratable']}",
        "",
        "OLDER CONTROLS:",
        f"  frozen identities = {cs['N_identity']}",
        f"  inner technically ready = {cs['N_ready']}",
        f"  inner calibrated = {cs['N_calibrated']}",
        f"  inner PA-calibratable = {cs['N_PA_calibratable']}",
        "",
        "INNER CALIBRATION COVERAGE:",
        cov.to_string(index=False),
        "",
        "BLINDING:",
        "  Real inner q: NOT COMPUTED",
        "  Real inner PA: NOT COMPUTED",
        "  Inner Galactic-plane PA: NOT COMPUTED",
        "  Inner Delta-theta: NOT COMPUTED",
        "  Inner alignment A: NOT COMPUTED",
        "",
        "NEXT_STAGE:",
        "  Stage-4B real inner morphology freeze using this exact calibration.",
        "  Only after the admitted inner sample is SHA256-frozen may Stage-4C",
        "  compute inner Galactic-plane alignment and inner-vs-outer contrasts.",
    ]
    (out/"STAGE4A_REPORT.txt").write_text(
        "\n".join(report)+"\n", encoding="utf-8"
    )

    manifest = []
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text(
        "\n".join(manifest)+"\n", encoding="utf-8"
    )

    print()
    print((out/"STAGE4A_REPORT.txt").read_text(encoding="utf-8"))

if __name__ == "__main__":
    main()

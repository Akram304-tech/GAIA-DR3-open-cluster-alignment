@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-4A INNER r50J SYNTHETIC PA CALIBRATION v1.2.0
echo BLIND / NO REAL INNER PA / NO INNER ALIGNMENT
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" (
  echo ERROR: Miniconda Python not found.
  exit /b 1
)

set "STAGE0=%USERPROFILE%\Downloads\YHMC_STAGE0_PREFLIGHT_v0_1_2\YHMC_STAGE0_PREFLIGHT_v0_1_2\STAGE0_OUTPUT"
set "STAGE1B=%USERPROFILE%\Downloads\YHMC_STAGE1B_REAL_MORPHOLOGY_FREEZE_v0_3_0\YHMC_STAGE1B_REAL_MORPHOLOGY_FREEZE_v0_3_0\STAGE1B_OUTPUT"
set "STAGE2A=%USERPROFILE%\Downloads\YHMC_STAGE2A_MATCHED_OLDER_CONTROL_FREEZE_v0_5_0\YHMC_STAGE2A_MATCHED_OLDER_CONTROL_FREEZE_v0_5_0\STAGE2A_OUTPUT"
set "STAGE2C=%USERPROFILE%\Downloads\YHMC_STAGE2C_CONTROL_REAL_MORPHOLOGY_FREEZE_v0_7_0\YHMC_STAGE2C_CONTROL_REAL_MORPHOLOGY_FREEZE_v0_7_0\STAGE2C_OUTPUT"

echo PYEXE=%PYEXE%
"%PYEXE%" --version

"%PYEXE%" -c "import numpy,pandas" >nul 2>nul
if errorlevel 1 (
  "%PYEXE%" -m pip install numpy pandas
  if errorlevel 1 exit /b 1
)

"%PYEXE%" stage4a_inner_r50j_synthetic_pa_calibration_v1_2_0.py ^
 --stage0 "%STAGE0%" ^
 --stage1b "%STAGE1B%" ^
 --stage2a "%STAGE2A%" ^
 --stage2c "%STAGE2C%" ^
 --out "%CD%\STAGE4A_OUTPUT"

set "RC=%ERRORLEVEL%"
echo.
echo RETURN_CODE=%RC%
if "%RC%"=="0" (
  echo REPORT=%CD%\STAGE4A_OUTPUT\STAGE4A_REPORT.txt
  echo GATE=%CD%\STAGE4A_OUTPUT\03_inner_cluster_specific_PA_gate.csv
  echo FREEZE=%CD%\STAGE4A_OUTPUT\STAGE4A_FREEZE.json
)
exit /b %RC%

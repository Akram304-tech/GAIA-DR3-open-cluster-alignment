YHMC STAGE-4A INNER r<r50J SYNTHETIC PA CALIBRATION v1.2.0
================================================================

Purpose
-------
Blindly calibrate PA reliability for the inner r<r50J region before any
real inner morphology or inner Galactic-plane alignment is measured.

r50J
----
Hunt & Reffert (2024) define r50J as the radius containing 50% of members
within the best-fitting Jacobi radius. The catalogue unit is degrees.

Inner member selection
----------------------
- source files already contain inrj=1, Prob>=0.5 members;
- calculate spherical separation from the catalogue cluster centre;
- retain sep <= r50J.

Technical readiness
-------------------
N_inner >= 20
Neff_inner >= 10

These are only technical prerequisites. The synthetic recovery calibration
determines whether a usable PA regime exists.

Run
---
call RUN_STAGE4A_INNER_R50J_SYNTHETIC_PA_CALIBRATION_v1_2_0.bat

Outputs
-------
STAGE4A_OUTPUT\STAGE4A_REPORT.txt
STAGE4A_OUTPUT\01_inner_input_readiness_audit.csv
STAGE4A_OUTPUT\02_inner_qgrid_recovery.csv
STAGE4A_OUTPUT\03_inner_cluster_specific_PA_gate.csv
STAGE4A_OUTPUT\04_inner_calibration_coverage.csv
STAGE4A_OUTPUT\05_inner_global_qgrid_summary.csv
STAGE4A_OUTPUT\STAGE4A_FREEZE.json

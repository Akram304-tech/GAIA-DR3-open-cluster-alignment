YHMC STAGE-2C CONTROL REAL MORPHOLOGY FREEZE v0.7.0
=======================================================

Purpose
-------
Measure real control q and PA, apply the pre-frozen Stage-2B recovery gate,
then hash the admitted control sample before any Galactic-plane alignment.

This stage DOES NOT compute alignment.

Run
---
call RUN_STAGE2C_CONTROL_REAL_MORPHOLOGY_FREEZE_v0_7_0.bat

Main outputs
------------
STAGE2C_OUTPUT\STAGE2C_REPORT.txt
STAGE2C_OUTPUT\01_control_real_morphology_all.csv
STAGE2C_OUTPUT\02_CONTROL_PA_SAMPLE_FROZEN.csv
STAGE2C_OUTPUT\03_anchor_control_coverage.csv
STAGE2C_OUTPUT\04_control_gate_attrition_by_mass.csv
STAGE2C_OUTPUT\05_control_morphology_descriptive_summary.csv
STAGE2C_OUTPUT\STAGE2C_FREEZE.json

The output control sample retains its original Stage-2A young-anchor identity.
An anchor-normalized weight is frozen before alignment:
  1 / N_admitted_controls_for_that_young_anchor

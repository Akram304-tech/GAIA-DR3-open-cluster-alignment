#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-2C real older-control morphology freeze v0.7.0

Purpose
-------
Measure REAL projected morphology (q, PA) for the exact frozen Stage-2A
older controls, apply the Stage-2B pre-calibrated morphology-only PA gate,
and freeze/hash the admitted control sample BEFORE any Galactic-plane
alignment is computed.

This stage intentionally does NOT compute:
  - local Galactic-plane PA
  - Delta theta
  - cos(2 Delta theta)
  - control alignment statistic A
  - young-vs-control alignment difference

Gate (identical logic to Stage-1B)
----------------------------------
A control is admitted only if ALL:
  1) Stage-2B PA_CALIBRATABLE == True
  2) q84_real <= q_max_PA_reliable
  3) q_point_real < q_round_null_p05
  4) bootstrap P68(|Delta PA|) <= 20 deg

Additionally, the original Stage-2A young-to-control matching map is
attached AFTER admission. No alignment quantity is involved.
"""

from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "0.7.0"
SEED = 20260912
N_BOOT = 2000
BOOT_PA_P68_MAX = 20.0

EXPECTED_CONTROL_LIST_SHA256 = "b31d69d0e90359f9d2a5e0d31db2ce20a3b7b9f5888862de9a15e8cb89ee7c6a"
EXPECTED_MATCH_TABLE_SHA256 = "ee17d8f92f1cc7b97537faafab1de077ff003e869dcd161b92be44e50239e5db"

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()

def safe_name(s):
    return "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in str(s))

def find_member_file(member_dir: Path, cid: int, name: str):
    hits = sorted([p for p in member_dir.glob(f"{cid:04d}_*.csv") if p.is_file()])
    if not hits:
        return None
    if len(hits) == 1:
        return hits[0]
    sn = safe_name(name)
    for p in hits:
        if sn in p.stem:
            return p
    return hits[0]

def tangent_xy_arcmin(ra, dec, ra0, dec0):
    ra = np.asarray(ra, dtype=float)
    dec = np.asarray(dec, dtype=float)
    dra = ((ra - float(ra0) + 180.0) % 360.0) - 180.0
    x = dra * math.cos(math.radians(float(dec0))) * 60.0
    y = (dec - float(dec0)) * 60.0
    return x, y

def weighted_shape(x, y, w):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    w = np.asarray(w, dtype=float)
    good = np.isfinite(x) & np.isfinite(y) & np.isfinite(w) & (w > 0)
    x, y, w = x[good], y[good], w[good]
    if len(x) < 3 or w.sum() <= 0:
        return np.nan, np.nan, np.nan, np.nan

    sw = w.sum()
    xc = float(np.sum(w*x)/sw)
    yc = float(np.sum(w*y)/sw)
    dx, dy = x-xc, y-yc

    sxx = np.sum(w*dx*dx)/sw
    syy = np.sum(w*dy*dy)/sw
    sxy = np.sum(w*dx*dy)/sw
    C = np.array([[sxx, sxy],[sxy, syy]], dtype=float)

    vals, vecs = np.linalg.eigh(C)
    order = np.argsort(vals)[::-1]
    vals = vals[order]
    vecs = vecs[:, order]
    if vals[0] <= 0 or vals[1] < 0:
        return np.nan, np.nan, xc, yc

    q = float(np.sqrt(max(vals[1], 0.0)/vals[0]))
    vx, vy = vecs[:, 0]
    pa = float(np.degrees(np.arctan2(vy, vx)) % 180.0)
    return q, pa, xc, yc

def axial_signed_diff_deg(a, b):
    return ((np.asarray(a, dtype=float) - float(b) + 90.0) % 180.0) - 90.0

def weighted_neff(w):
    w = np.asarray(w, dtype=float)
    w = w[np.isfinite(w) & (w > 0)]
    if len(w) == 0:
        return 0.0
    return float(w.sum()**2 / np.square(w).sum())

def pct(a, p):
    a = np.asarray(a, dtype=float)
    a = a[np.isfinite(a)]
    return float(np.percentile(a, p)) if len(a) else np.nan

def med(a):
    a = np.asarray(a, dtype=float)
    a = a[np.isfinite(a)]
    return float(np.median(a)) if len(a) else np.nan

def bootstrap_shape(x, y, w, nboot, rng):
    n = len(x)
    qs = np.full(nboot, np.nan)
    pas = np.full(nboot, np.nan)
    for k in range(nboot):
        idx = rng.integers(0, n, size=n)
        q, pa, _, _ = weighted_shape(x[idx], y[idx], w[idx])
        qs[k] = q
        pas[k] = pa
    return qs, pas

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage2a", required=True)
    ap.add_argument("--stage2b", required=True)
    ap.add_argument("--out", default="STAGE2C_OUTPUT")
    ap.add_argument("--nboot", type=int, default=N_BOOT)
    args = ap.parse_args()

    stage2a = Path(args.stage2a).expanduser().resolve()
    stage2b = Path(args.stage2b).expanduser().resolve()
    out = Path(args.out).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)

    controls_file = stage2a / "02_MATCHED_OLDER_CONTROLS_FROZEN.csv"
    matches_file = stage2a / "01_young_to_control_matches.csv"
    member_dir = stage2a / "members_control_frozen"
    gate_file = stage2b / "03_control_specific_PA_gate.csv"
    freeze_file = stage2b / "STAGE2B_FREEZE.json"

    for p in [controls_file, matches_file, gate_file, freeze_file]:
        if not p.exists():
            raise FileNotFoundError(p)
    if not member_dir.is_dir():
        raise FileNotFoundError(member_dir)

    control_hash = sha256(controls_file)
    match_hash = sha256(matches_file)
    gate_hash = sha256(gate_file)
    freeze_hash = sha256(freeze_file)

    if control_hash != EXPECTED_CONTROL_LIST_SHA256:
        raise RuntimeError(
            "CONTROL LIST CHAIN-OF-CUSTODY FAIL\n"
            f"Expected {EXPECTED_CONTROL_LIST_SHA256}\nActual   {control_hash}"
        )
    if match_hash != EXPECTED_MATCH_TABLE_SHA256:
        raise RuntimeError(
            "MATCH TABLE CHAIN-OF-CUSTODY FAIL\n"
            f"Expected {EXPECTED_MATCH_TABLE_SHA256}\nActual   {match_hash}"
        )

    bfreeze = json.loads(freeze_file.read_text(encoding="utf-8"))
    if bfreeze.get("control_list_sha256") != control_hash:
        raise RuntimeError("Stage-2B freeze does not bind to the current control list.")
    if bfreeze.get("match_table_sha256") != match_hash:
        raise RuntimeError("Stage-2B freeze does not bind to the current match table.")
    if not bfreeze.get("control_alignment_blinding", False):
        raise RuntimeError("Stage-2B freeze does not assert control-alignment blinding.")

    controls = pd.read_csv(controls_file)
    gate = pd.read_csv(gate_file)
    matches = pd.read_csv(matches_file)

    required_controls = {"ID","Name","MassJ","logAge50","__RAdeg","__DEdeg"}
    miss = sorted(required_controls - set(controls.columns))
    if miss:
        raise RuntimeError("Frozen controls missing columns: " + ", ".join(miss))

    required_gate = {
        "ID","Name","q_round_null_p05","q_round_null_p16",
        "q_round_null_median","q_max_PA_reliable","PA_CALIBRATABLE"
    }
    miss = sorted(required_gate - set(gate.columns))
    if miss:
        raise RuntimeError("Stage-2B gate missing columns: " + ", ".join(miss))

    if controls.duplicated(["ID","Name"]).any():
        raise RuntimeError("Frozen controls contain duplicate ID+Name.")
    if gate.duplicated(["ID","Name"]).any():
        raise RuntimeError("Stage-2B gate contains duplicate ID+Name.")

    merged = controls.merge(
        gate[[
            "ID","Name","q_round_null_p05","q_round_null_p16",
            "q_round_null_median","q_max_PA_reliable","PA_CALIBRATABLE"
        ]],
        on=["ID","Name"], how="inner", validate="one_to_one"
    )
    if len(merged) != len(controls):
        raise RuntimeError(f"Control/gate merge mismatch: {len(controls)} -> {len(merged)}")

    print("="*90)
    print(f"YHMC STAGE-2C CONTROL REAL MORPHOLOGY FREEZE v{VERSION}")
    print("NO CONTROL GALACTIC-PLANE ALIGNMENT COMPUTED")
    print("="*90)
    print(f"CONTROL_LIST_SHA256={control_hash}")
    print(f"MATCH_TABLE_SHA256={match_hash}")
    print(f"STAGE2B_GATE_SHA256={gate_hash}")
    print(f"STAGE2B_FREEZE_SHA256={freeze_hash}")
    print(f"INPUT_CONTROLS={len(merged)}")
    print(f"N_BOOT={args.nboot}")
    print(f"SEED={SEED}")
    print("FROZEN_GATE:")
    print("  PA_CALIBRATABLE")
    print("  q84_real <= q_max_PA_reliable")
    print("  q_point_real < q_round_null_p05")
    print(f"  bootstrap P68(|DeltaPA|) <= {BOOT_PA_P68_MAX:.1f} deg")

    rows = []
    for ii, row in merged.reset_index(drop=True).iterrows():
        cid = int(row["ID"])
        name = str(row["Name"])
        mf = find_member_file(member_dir, cid, name)

        if mf is None:
            rows.append({"ID":cid,"Name":name,"status":"MISSING_MEMBER_FILE"})
            print(f"{ii+1:3d}/{len(merged):3d} {name}: MISSING_MEMBER_FILE")
            continue

        mem = pd.read_csv(mf)
        req = {"Prob","__RAdeg","__DEdeg"}
        miss = sorted(req - set(mem.columns))
        if miss:
            rows.append({
                "ID":cid,"Name":name,"status":"BAD_MEMBER_SCHEMA",
                "missing":";".join(miss)
            })
            print(f"{ii+1:3d}/{len(merged):3d} {name}: BAD_MEMBER_SCHEMA")
            continue

        p = pd.to_numeric(mem["Prob"],errors="coerce").to_numpy(float)
        ra = pd.to_numeric(mem["__RAdeg"],errors="coerce").to_numpy(float)
        de = pd.to_numeric(mem["__DEdeg"],errors="coerce").to_numpy(float)
        good = np.isfinite(p)&np.isfinite(ra)&np.isfinite(de)&(p>=0.5)
        p,ra,de = p[good],ra[good],de[good]

        x,y = tangent_xy_arcmin(ra,de,row["__RAdeg"],row["__DEdeg"])
        good2 = np.isfinite(x)&np.isfinite(y)&np.isfinite(p)&(p>0)
        x,y,p = x[good2],y[good2],p[good2]

        q,pa,xc,yc = weighted_shape(x,y,p)
        ne = weighted_neff(p)
        if not np.isfinite(q) or not np.isfinite(pa):
            rows.append({"ID":cid,"Name":name,"status":"SHAPE_FAIL"})
            print(f"{ii+1:3d}/{len(merged):3d} {name}: SHAPE_FAIL")
            continue

        rng = np.random.default_rng(np.random.SeedSequence([SEED,cid,args.nboot,2]))
        qb,pab = bootstrap_shape(x,y,p,args.nboot,rng)
        dpa = np.abs(axial_signed_diff_deg(pab,pa))

        q05,q16,q50,q84,q95 = [pct(qb,pctv) for pctv in (5,16,50,84,95)]
        pa_med = med(dpa)
        pa_p68 = pct(dpa,68)
        pa_p95 = pct(dpa,95)

        pa_cal = bool(row["PA_CALIBRATABLE"])
        qmax = float(row["q_max_PA_reliable"]) if pd.notna(row["q_max_PA_reliable"]) else np.nan
        qnull05 = float(row["q_round_null_p05"]) if pd.notna(row["q_round_null_p05"]) else np.nan

        g1 = pa_cal
        g2 = bool(np.isfinite(q84) and np.isfinite(qmax) and q84 <= qmax)
        g3 = bool(np.isfinite(qnull05) and q < qnull05)
        g4 = bool(np.isfinite(pa_p68) and pa_p68 <= BOOT_PA_P68_MAX)
        admitted = bool(g1 and g2 and g3 and g4)

        rows.append({
            "ID":cid,"Name":name,"status":"OK",
            "MassJ":row["MassJ"],"logAge50":row["logAge50"],
            "__RAdeg":row["__RAdeg"],"__DEdeg":row["__DEdeg"],
            "N_members":len(x),"Neff":ne,
            "q_point":q,"epsilon_point":1.0-q,
            "q_boot_p05":q05,"q_boot_p16":q16,"q_boot_median":q50,
            "q_boot_p84":q84,"q_boot_p95":q95,
            "PA_deg_point":pa,
            "PA_boot_abs_median_deg":pa_med,
            "PA_boot_abs_p68_deg":pa_p68,
            "PA_boot_abs_p95_deg":pa_p95,
            "weighted_centroid_x_arcmin":xc,
            "weighted_centroid_y_arcmin":yc,
            "q_round_null_p05":qnull05,
            "q_round_null_p16":row["q_round_null_p16"],
            "q_round_null_median":row["q_round_null_median"],
            "q_max_PA_reliable":qmax,
            "gate1_PA_CALIBRATABLE":g1,
            "gate2_q84_le_qmax":g2,
            "gate3_qpoint_lt_roundnull_p05":g3,
            "gate4_bootPA_p68_le20":g4,
            "CONTROL_PA_SAMPLE_ADMITTED":admitted,
            "CONTROL_ALIGNMENT_NOT_COMPUTED":True,
        })
        print(f"{ii+1:3d}/{len(merged):3d} {name}: q={q:.3f}, PAerr68={pa_p68:.1f}, admitted={admitted}")

    res = pd.DataFrame(rows)
    res.to_csv(out/"01_control_real_morphology_all.csv",index=False)

    good = res[res["status"]=="OK"].copy()
    admitted = good[good["CONTROL_PA_SAMPLE_ADMITTED"]==True].copy()

    # Attach original matching identity AFTER morphology admission.
    match_cols = [
        "young_ID","young_Name","control_ID","control_Name",
        "control_rank_within_young","match_cost"
    ]
    miss = sorted(set(match_cols)-set(matches.columns))
    if miss:
        raise RuntimeError("Match table missing columns: "+", ".join(miss))

    amap = matches[match_cols].copy()
    if amap.duplicated(["control_ID","control_Name"]).any():
        raise RuntimeError("A frozen control maps to more than one young anchor.")

    admitted = admitted.merge(
        amap,
        left_on=["ID","Name"],
        right_on=["control_ID","control_Name"],
        how="left",
        validate="one_to_one",
        indicator=True
    )
    if not (admitted["_merge"]=="both").all():
        bad=admitted.loc[admitted["_merge"]!="both",["ID","Name","_merge"]]
        raise RuntimeError("Admitted control lost match identity:\n"+bad.to_string(index=False))
    admitted=admitted.drop(columns=["_merge"])

    # Freeze an anchor-normalized weight determined solely by admission counts.
    n_per_anchor = admitted.groupby(["young_ID","young_Name"])["ID"].transform("count")
    admitted["anchor_normalized_weight"] = 1.0 / n_per_anchor
    admitted["admitted_controls_for_anchor"] = n_per_anchor.astype(int)

    admitted.to_csv(out/"02_CONTROL_PA_SAMPLE_FROZEN.csv",index=False)

    # Anchor coverage audit: no alignment is used.
    anchor = matches[["young_ID","young_Name"]].drop_duplicates().copy()
    acount = admitted.groupby(["young_ID","young_Name"]).size().rename("N_admitted_controls").reset_index()
    anchor = anchor.merge(acount,on=["young_ID","young_Name"],how="left")
    anchor["N_admitted_controls"] = anchor["N_admitted_controls"].fillna(0).astype(int)
    anchor["HAS_AT_LEAST_ONE_ADMITTED_CONTROL"] = anchor["N_admitted_controls"]>=1
    anchor.to_csv(out/"03_anchor_control_coverage.csv",index=False)

    # Gate attrition by mass.
    gate_rows=[]
    for m in [1000,3000,5000,10000]:
        s=good[pd.to_numeric(good["MassJ"],errors="coerce")>=m]
        gate_rows.append({
            "MassJ_threshold_Msun":m,
            "N_real_morphology_OK":len(s),
            "N_gate1_PA_calibratable":int(s["gate1_PA_CALIBRATABLE"].sum()) if len(s) else 0,
            "N_gate2_q84_le_qmax":int(s["gate2_q84_le_qmax"].sum()) if len(s) else 0,
            "N_gate3_significantly_elongated":int(s["gate3_qpoint_lt_roundnull_p05"].sum()) if len(s) else 0,
            "N_gate4_bootPA_p68_le20":int(s["gate4_bootPA_p68_le20"].sum()) if len(s) else 0,
            "N_CONTROL_PA_SAMPLE_ADMITTED":int(s["CONTROL_PA_SAMPLE_ADMITTED"].sum()) if len(s) else 0,
        })
    gate_summary=pd.DataFrame(gate_rows)
    gate_summary.to_csv(out/"04_control_gate_attrition_by_mass.csv",index=False)

    # Morphology-only summary.
    desc=[]
    for m in [1000,3000,5000,10000]:
        s=good[pd.to_numeric(good["MassJ"],errors="coerce")>=m]
        a=admitted[pd.to_numeric(admitted["MassJ"],errors="coerce")>=m]
        desc.append({
            "MassJ_threshold_Msun":m,
            "N_all":len(s),
            "median_q_all":med(s["q_point"]) if len(s) else np.nan,
            "median_epsilon_all":med(s["epsilon_point"]) if len(s) else np.nan,
            "N_admitted":len(a),
            "median_q_admitted":med(a["q_point"]) if len(a) else np.nan,
            "median_epsilon_admitted":med(a["epsilon_point"]) if len(a) else np.nan,
        })
    pd.DataFrame(desc).to_csv(out/"05_control_morphology_descriptive_summary.csv",index=False)

    # Hash before any control alignment stage.
    admitted_hash=sha256(out/"02_CONTROL_PA_SAMPLE_FROZEN.csv")
    anchor_hash=sha256(out/"03_anchor_control_coverage.csv")

    freeze_record={
        "stage":"STAGE2C_CONTROL_REAL_MORPHOLOGY_FREEZE",
        "version":VERSION,
        "seed":SEED,
        "n_boot":args.nboot,
        "input_control_list_sha256":control_hash,
        "input_match_table_sha256":match_hash,
        "input_stage2b_gate_sha256":gate_hash,
        "input_stage2b_freeze_sha256":freeze_hash,
        "region":"r<rJ only; inrj=1 and Prob>=0.5",
        "estimator":"membership-probability weighted second central moments",
        "selection_gate":{
            "gate1":"Stage-2B PA_CALIBRATABLE == True",
            "gate2":"q_boot_p84 <= q_max_PA_reliable",
            "gate3":"q_point < q_round_null_p05",
            "gate4":f"bootstrap P68(|DeltaPA|) <= {BOOT_PA_P68_MAX:.1f} deg",
            "all_required":True,
        },
        "match_attachment":
            "Original Stage-2A young-anchor mapping attached after morphology admission only",
        "anchor_normalized_weight":
            "1 / number of admitted controls for the same young anchor; defined before alignment",
        "alignment_blinding":[
            "No local Galactic-plane PA computed",
            "No Delta-theta computed",
            "No cos(2 Delta-theta) computed",
            "No control A computed",
            "No young-control A difference computed",
        ],
        "next_stage":
            "Stage-2D may unblind control alignment only for the hashed frozen control PA sample."
    }
    (out/"STAGE2C_FREEZE.json").write_text(json.dumps(freeze_record,indent=2),encoding="utf-8")
    freeze_out_hash=sha256(out/"STAGE2C_FREEZE.json")

    nanchors_total=len(anchor)
    nanchors_any=int(anchor["HAS_AT_LEAST_ONE_ADMITTED_CONTROL"].sum())
    nanchors_two=int((anchor["N_admitted_controls"]==2).sum())
    nanchors_one=int((anchor["N_admitted_controls"]==1).sum())
    nanchors_zero=int((anchor["N_admitted_controls"]==0).sum())

    report=[
        f"YHMC STAGE-2C CONTROL REAL MORPHOLOGY FREEZE v{VERSION}",
        "="*90,
        "CONTROL_CHAIN_OF_CUSTODY=PASS",
        f"CONTROL_LIST_SHA256={control_hash}",
        f"MATCH_TABLE_SHA256={match_hash}",
        f"STAGE2B_GATE_SHA256={gate_hash}",
        f"STAGE2B_FREEZE_SHA256={freeze_hash}",
        f"Input frozen controls: {len(merged)}",
        f"Real morphology successful: {len(good)}",
        f"Frozen admitted controls: {len(admitted)}",
        f"N_BOOT={args.nboot}",
        "",
        "FROZEN MORPHOLOGY-ONLY GATE:",
        "  1) PA_CALIBRATABLE == True",
        "  2) q84_real <= q_max_PA_reliable",
        "  3) q_point_real < q_round_null_p05",
        f"  4) bootstrap P68(|DeltaPA|) <= {BOOT_PA_P68_MAX:.1f} deg",
        "",
        "GATE ATTRITION BY MASS:",
        gate_summary.to_string(index=False),
        "",
        "YOUNG-ANCHOR COVERAGE AFTER CONTROL MORPHOLOGY GATE:",
        f"  total young anchors = {nanchors_total}",
        f"  anchors with >=1 admitted control = {nanchors_any}",
        f"  anchors with 2 admitted controls = {nanchors_two}",
        f"  anchors with 1 admitted control = {nanchors_one}",
        f"  anchors with 0 admitted controls = {nanchors_zero}",
        "",
        f"CONTROL_PA_SAMPLE_SHA256={admitted_hash}",
        f"ANCHOR_COVERAGE_SHA256={anchor_hash}",
        f"FREEZE_JSON_SHA256={freeze_out_hash}",
        "",
        "BLINDING STATUS:",
        "  Control Galactic-plane PA: NOT COMPUTED",
        "  Control Delta-theta: NOT COMPUTED",
        "  Control alignment A: NOT COMPUTED",
        "  Young-control difference: NOT COMPUTED",
        "",
        "NEXT_STAGE:",
        "  Stage-2D unblind control alignment for this exact frozen sample and compare",
        "  with the already-frozen young result, including anchor-normalized analysis.",
    ]
    (out/"STAGE2C_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")

    print()
    print((out/"STAGE2C_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

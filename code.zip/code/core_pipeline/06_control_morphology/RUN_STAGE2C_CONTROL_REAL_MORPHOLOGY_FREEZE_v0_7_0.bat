@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-2C CONTROL REAL MORPHOLOGY FREEZE v0.7.0
echo NO CONTROL GALACTIC-PLANE ALIGNMENT COMPUTED
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" (
  echo ERROR: Miniconda Python not found.
  exit /b 1
)

set "STAGE2A=%USERPROFILE%\Downloads\YHMC_STAGE2A_MATCHED_OLDER_CONTROL_FREEZE_v0_5_0\YHMC_STAGE2A_MATCHED_OLDER_CONTROL_FREEZE_v0_5_0\STAGE2A_OUTPUT"
set "STAGE2B=%USERPROFILE%\Downloads\YHMC_STAGE2B_CONTROL_SYNTHETIC_PA_CALIBRATION_v0_6_0\YHMC_STAGE2B_CONTROL_SYNTHETIC_PA_CALIBRATION_v0_6_0\STAGE2B_OUTPUT"

if not exist "%STAGE2A%\02_MATCHED_OLDER_CONTROLS_FROZEN.csv" (
  echo ERROR: Stage-2A frozen controls not found.
  exit /b 1
)
if not exist "%STAGE2B%\03_control_specific_PA_gate.csv" (
  echo ERROR: Stage-2B control PA gate not found.
  exit /b 1
)

echo PYEXE=%PYEXE%
"%PYEXE%" --version
echo STAGE2A=%STAGE2A%
echo STAGE2B=%STAGE2B%

"%PYEXE%" -c "import numpy,pandas" >nul 2>nul
if errorlevel 1 (
  "%PYEXE%" -m pip install numpy pandas
  if errorlevel 1 exit /b 1
)

"%PYEXE%" stage2c_control_real_morphology_freeze_v0_7_0.py --stage2a "%STAGE2A%" --stage2b "%STAGE2B%" --out "%CD%\STAGE2C_OUTPUT"
set "RC=%ERRORLEVEL%"

echo.
echo RETURN_CODE=%RC%
if "%RC%"=="0" (
  echo REPORT=%CD%\STAGE2C_OUTPUT\STAGE2C_REPORT.txt
  echo CONTROL_SAMPLE=%CD%\STAGE2C_OUTPUT\02_CONTROL_PA_SAMPLE_FROZEN.csv
  echo FREEZE=%CD%\STAGE2C_OUTPUT\STAGE2C_FREEZE.json
)
exit /b %RC%

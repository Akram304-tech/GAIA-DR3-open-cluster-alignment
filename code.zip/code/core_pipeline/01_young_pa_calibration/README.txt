YHMC STAGE-1A SYNTHETIC MORPHOLOGY/PA CALIBRATION v0.2.0
================================================================

Purpose
-------
Calibrate shape and PA recovery BEFORE examining any real Galactic-plane
alignment signal.

This stage is intentionally blind:
- no real cluster PA is reported;
- no local Galactic-plane PA is computed;
- no Delta-theta is computed;
- no alignment statistic A is computed.

The calibration keeps each cluster's real radial sampling and membership
weights, randomizes all angular directions, imposes a known axis ratio q,
and measures how well the chosen estimator recovers q and PA.

Default Stage-0 input
---------------------
C:\Users\asus_\Downloads\YHMC_STAGE0_PREFLIGHT_v0_1_2\
YHMC_STAGE0_PREFLIGHT_v0_1_2\STAGE0_OUTPUT

Run
---
call RUN_STAGE1A_SYNTHETIC_PA_CALIBRATION_v0_2_0.bat

Main outputs
------------
STAGE1A_OUTPUT\STAGE1A_REPORT.txt
STAGE1A_OUTPUT\01_input_sample_audit.csv
STAGE1A_OUTPUT\02_cluster_qgrid_recovery.csv
STAGE1A_OUTPUT\03_cluster_specific_PA_gate.csv
STAGE1A_OUTPUT\04_global_qgrid_summary.csv
STAGE1A_OUTPUT\05_mass_threshold_calibration_coverage.csv
STAGE1A_OUTPUT\STAGE1A_FREEZE.json
STAGE1A_OUTPUT\SHA256SUMS.txt

Interpretation
--------------
q_max_PA_reliable is cluster-specific.

The intended conservative Stage-1B real-data gate is:
  q84_real <= q_max_PA_reliable
  AND q_real < q_round_null_p05

Do not compute Galactic-plane alignment until this gate has been reviewed
and frozen.

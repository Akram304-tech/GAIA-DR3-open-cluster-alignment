@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-1A SYNTHETIC PA CALIBRATION v0.2.0
echo BLIND MORPHOLOGY / NO REAL ALIGNMENT INFERENCE
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"

if not exist "%PYEXE%" (
  echo ERROR: Miniconda Python not found.
  exit /b 1
)

set "STAGE0=%USERPROFILE%\Downloads\YHMC_STAGE0_PREFLIGHT_v0_1_2\YHMC_STAGE0_PREFLIGHT_v0_1_2\STAGE0_OUTPUT"

if not exist "%STAGE0%\07_provisional_morphology_ready.csv" (
  echo ERROR: Stage-0 output not found at:
  echo   %STAGE0%
  echo.
  echo You may run manually with:
  echo   "%PYEXE%" stage1a_synthetic_pa_calibration_v0_2_0.py --stage0 "FULL_PATH_TO_STAGE0_OUTPUT"
  exit /b 1
)

echo PYEXE=%PYEXE%
"%PYEXE%" --version
echo STAGE0=%STAGE0%

"%PYEXE%" -c "import numpy,pandas,matplotlib" >nul 2>nul
if errorlevel 1 (
  "%PYEXE%" -m pip install numpy pandas matplotlib
  if errorlevel 1 exit /b 1
)

"%PYEXE%" stage1a_synthetic_pa_calibration_v0_2_0.py --stage0 "%STAGE0%" --out "%CD%\STAGE1A_OUTPUT"
set "RC=%ERRORLEVEL%"

echo.
echo RETURN_CODE=%RC%
if "%RC%"=="0" (
  echo REPORT=%CD%\STAGE1A_OUTPUT\STAGE1A_REPORT.txt
  echo GATE=%CD%\STAGE1A_OUTPUT\03_cluster_specific_PA_gate.csv
  echo FREEZE=%CD%\STAGE1A_OUTPUT\STAGE1A_FREEZE.json
)
exit /b %RC%

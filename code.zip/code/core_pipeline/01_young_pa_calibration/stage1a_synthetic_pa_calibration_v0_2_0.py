#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-1A synthetic morphology + PA recovery calibration v0.2.0

Purpose
-------
Blindly calibrate the weighted second-moment shape estimator before
examining real cluster position angles relative to the Galactic plane.

This stage DOES NOT calculate real cluster PA, Galactic-plane PA,
Delta-theta, or the alignment statistic A.

Inputs
------
STAGE0_OUTPUT from YHMC Stage-0 v0.1.2:
  07_provisional_morphology_ready.csv
  members_primary/*.csv

Synthetic design
----------------
For each real cluster:
  * keep its actual member count;
  * keep each member's observed radius from the catalogue centre;
  * keep each member's membership probability weight;
  * erase all real angular morphology by assigning a fresh uniform angle;
  * impose a known q_true and a random PA_true;
  * recover q and PA with the exact weighted second-moment estimator.

Thus the calibration uses the real radial/weight sampling without exposing
the real orientation signal.

Frozen provisional PA-reliability rule
--------------------------------------
At a given q_true, a cluster is PA-reliable if:
  P68(|Delta PA|) <= 20 deg
  median(|Delta PA|) <= 10 deg
  |median(q_rec - q_true)| <= 0.05

The cluster-specific q_max_reliable is the roundest q_true for which that
criterion and all more-elongated tested q values pass.

For later real-data Stage-1B, the intended conservative gate is:
  q84_real <= q_max_reliable
plus significant elongation against the q_true=1 synthetic null.

No science inference is performed here.
"""

from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "0.2.0"
SEED = 20260912
Q_GRID = [1.00, 0.98, 0.96, 0.94, 0.92, 0.90, 0.85, 0.80, 0.70, 0.60]
N_REP = 250

PA_P68_MAX = 20.0
PA_MED_MAX = 10.0
Q_BIAS_MED_MAX = 0.05

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()

def weighted_neff(w):
    w = np.asarray(w, dtype=float)
    w = w[np.isfinite(w) & (w > 0)]
    if len(w) == 0:
        return 0.0
    return float(w.sum() ** 2 / np.square(w).sum())

def tangent_xy_arcmin(ra, dec, ra0, dec0):
    """Small-angle tangent coordinates in arcmin, robust to RA wrap."""
    ra = np.asarray(ra, dtype=float)
    dec = np.asarray(dec, dtype=float)
    dra = ((ra - float(ra0) + 180.0) % 360.0) - 180.0
    x = dra * math.cos(math.radians(float(dec0))) * 60.0
    y = (dec - float(dec0)) * 60.0
    return x, y

def weighted_shape(x, y, w):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    w = np.asarray(w, dtype=float)

    good = np.isfinite(x) & np.isfinite(y) & np.isfinite(w) & (w > 0)
    x, y, w = x[good], y[good], w[good]
    if len(x) < 3 or w.sum() <= 0:
        return np.nan, np.nan

    sw = w.sum()
    xc = np.sum(w * x) / sw
    yc = np.sum(w * y) / sw
    dx = x - xc
    dy = y - yc

    sxx = np.sum(w * dx * dx) / sw
    syy = np.sum(w * dy * dy) / sw
    sxy = np.sum(w * dx * dy) / sw
    C = np.array([[sxx, sxy], [sxy, syy]], dtype=float)

    vals, vecs = np.linalg.eigh(C)
    order = np.argsort(vals)[::-1]
    vals = vals[order]
    vecs = vecs[:, order]

    if vals[0] <= 0 or vals[1] < 0:
        return np.nan, np.nan

    q = float(np.sqrt(max(vals[1], 0.0) / vals[0]))
    vx, vy = vecs[:, 0]
    pa = float(np.degrees(np.arctan2(vy, vx)) % 180.0)
    return q, pa

def axial_signed_diff_deg(a, b):
    """Signed axial angle a-b in [-90,90)."""
    return ((float(a) - float(b) + 90.0) % 180.0) - 90.0

def pct(a, p):
    a = np.asarray(a, dtype=float)
    a = a[np.isfinite(a)]
    return float(np.percentile(a, p)) if len(a) else np.nan

def med(a):
    a = np.asarray(a, dtype=float)
    a = a[np.isfinite(a)]
    return float(np.median(a)) if len(a) else np.nan

def synth_one(r, w, q_true, rng):
    """
    Keep observed radial sampling and weights, erase angle, impose q_true
    and a random axial orientation.
    """
    theta = rng.uniform(0.0, 2.0 * np.pi, size=len(r))
    phi = rng.uniform(0.0, np.pi)

    # r acts as elliptical semi-major radius.
    x0 = r * np.cos(theta)
    y0 = q_true * r * np.sin(theta)

    c = math.cos(phi)
    s = math.sin(phi)
    x = c * x0 - s * y0
    y = s * x0 + c * y0

    q_rec, pa_rec = weighted_shape(x, y, w)
    pa_true = math.degrees(phi) % 180.0
    return q_rec, pa_rec, pa_true

def safe_name(s):
    return "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in str(s))

def find_member_file(member_dir: Path, cid: int, name: str):
    exact_prefix = f"{cid:04d}_"
    hits = [p for p in member_dir.glob(f"{exact_prefix}*.csv") if p.is_file()]
    if len(hits) == 1:
        return hits[0]
    if len(hits) > 1:
        # Prefer a name-compatible file if duplicates exist.
        sn = safe_name(name)
        for p in hits:
            if sn in p.stem:
                return p
        return sorted(hits)[0]
    return None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage0", required=True, help="Path to Stage-0 STAGE0_OUTPUT")
    ap.add_argument("--out", default="STAGE1A_OUTPUT", help="Output directory")
    ap.add_argument("--nrep", type=int, default=N_REP)
    args = ap.parse_args()

    stage0 = Path(args.stage0).expanduser().resolve()
    out = Path(args.out).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)

    sample_file = stage0 / "07_provisional_morphology_ready.csv"
    member_dir = stage0 / "members_primary"

    if not sample_file.exists():
        raise FileNotFoundError(f"Missing Stage-0 sample: {sample_file}")
    if not member_dir.is_dir():
        raise FileNotFoundError(f"Missing Stage-0 member directory: {member_dir}")

    sample = pd.read_csv(sample_file)
    required = {"ID","Name","MassJ","logAge50","__RAdeg","__DEdeg"}
    miss = sorted(required - set(sample.columns))
    if miss:
        raise RuntimeError("Stage-0 sample missing columns: " + ", ".join(miss))

    print("=" * 82)
    print(f"YHMC STAGE-1A SYNTHETIC MORPHOLOGY/PA CALIBRATION v{VERSION}")
    print("BLIND: no real PA, Galactic-plane PA, Delta-theta, or alignment A is computed")
    print("=" * 82)
    print(f"STAGE0={stage0}")
    print(f"INPUT_CLUSTERS={len(sample)}")
    print(f"Q_GRID={Q_GRID}")
    print(f"N_REP={args.nrep}")
    print(f"SEED={SEED}")

    # Deterministic RNG streams by cluster ID and q index.
    audit = []
    summaries = []

    for ii, row in sample.reset_index(drop=True).iterrows():
        cid = int(row["ID"])
        name = str(row["Name"])
        mf = find_member_file(member_dir, cid, name)

        if mf is None:
            audit.append({
                "ID": cid, "Name": name, "member_file": "",
                "status": "MISSING_MEMBER_FILE"
            })
            print(f"{ii+1:3d}/{len(sample):3d} {name}: MISSING MEMBER FILE")
            continue

        mem = pd.read_csv(mf)
        needed = {"Prob","__RAdeg","__DEdeg"}
        missing = sorted(needed - set(mem.columns))
        if missing:
            audit.append({
                "ID": cid, "Name": name, "member_file": str(mf),
                "status": "BAD_MEMBER_SCHEMA", "missing": ";".join(missing)
            })
            print(f"{ii+1:3d}/{len(sample):3d} {name}: BAD MEMBER SCHEMA")
            continue

        p = pd.to_numeric(mem["Prob"], errors="coerce").to_numpy(float)
        ra = pd.to_numeric(mem["__RAdeg"], errors="coerce").to_numpy(float)
        de = pd.to_numeric(mem["__DEdeg"], errors="coerce").to_numpy(float)

        good = np.isfinite(p) & np.isfinite(ra) & np.isfinite(de) & (p >= 0.5)
        p, ra, de = p[good], ra[good], de[good]

        x, y = tangent_xy_arcmin(ra, de, row["__RAdeg"], row["__DEdeg"])
        r = np.hypot(x, y)
        g2 = np.isfinite(r) & np.isfinite(p) & (p > 0)
        r, p = r[g2], p[g2]

        n = len(r)
        ne = weighted_neff(p)
        if n < 20 or ne < 10:
            audit.append({
                "ID": cid, "Name": name, "member_file": str(mf),
                "status": "TOO_FEW_VALID_MEMBERS", "N": n, "Neff": ne
            })
            print(f"{ii+1:3d}/{len(sample):3d} {name}: TOO FEW VALID MEMBERS")
            continue

        audit.append({
            "ID": cid, "Name": name, "member_file": str(mf),
            "status": "OK", "N": n, "Neff": ne,
            "r_arcmin_median": float(np.median(r)),
            "r_arcmin_p90": float(np.percentile(r, 90)),
            "MassJ": float(row["MassJ"]) if pd.notna(row["MassJ"]) else np.nan,
            "logAge50": float(row["logAge50"]) if pd.notna(row["logAge50"]) else np.nan,
        })

        for q_idx, q_true in enumerate(Q_GRID):
            seed_seq = np.random.SeedSequence([SEED, cid, q_idx, args.nrep])
            rng = np.random.default_rng(seed_seq)

            q_rec = np.empty(args.nrep, dtype=float)
            pa_abs = np.full(args.nrep, np.nan, dtype=float)

            for k in range(args.nrep):
                qr, par, pat = synth_one(r, p, q_true, rng)
                q_rec[k] = qr
                if q_true < 0.999 and np.isfinite(par):
                    pa_abs[k] = abs(axial_signed_diff_deg(par, pat))

            q_bias = q_rec - q_true

            rec = {
                "ID": cid,
                "Name": name,
                "MassJ": float(row["MassJ"]) if pd.notna(row["MassJ"]) else np.nan,
                "logAge50": float(row["logAge50"]) if pd.notna(row["logAge50"]) else np.nan,
                "N": n,
                "Neff": ne,
                "q_true": q_true,
                "N_rep": args.nrep,
                "qrec_median": med(q_rec),
                "qrec_p05": pct(q_rec, 5),
                "qrec_p16": pct(q_rec, 16),
                "qrec_p84": pct(q_rec, 84),
                "qrec_p95": pct(q_rec, 95),
                "qbias_median": med(q_bias),
                "qbias_abs_median": med(np.abs(q_bias)),
                "qbias_abs_p68": pct(np.abs(q_bias), 68),
            }

            if q_true < 0.999:
                rec.update({
                    "pa_abs_median_deg": med(pa_abs),
                    "pa_abs_p68_deg": pct(pa_abs, 68),
                    "pa_abs_p95_deg": pct(pa_abs, 95),
                })
                rec["pa_reliable_at_q"] = bool(
                    np.isfinite(rec["pa_abs_p68_deg"]) and
                    rec["pa_abs_p68_deg"] <= PA_P68_MAX and
                    rec["pa_abs_median_deg"] <= PA_MED_MAX and
                    abs(rec["qbias_median"]) <= Q_BIAS_MED_MAX
                )
            else:
                rec.update({
                    "pa_abs_median_deg": np.nan,
                    "pa_abs_p68_deg": np.nan,
                    "pa_abs_p95_deg": np.nan,
                    "pa_reliable_at_q": False,
                })
            summaries.append(rec)

        print(f"{ii+1:3d}/{len(sample):3d} {name}: N={n}, Neff={ne:.1f}")

    audit_df = pd.DataFrame(audit)
    sum_df = pd.DataFrame(summaries)

    audit_df.to_csv(out / "01_input_sample_audit.csv", index=False)
    sum_df.to_csv(out / "02_cluster_qgrid_recovery.csv", index=False)

    # Build cluster-specific q reliability thresholds.
    gate_rows = []
    for cid, g in sum_df.groupby("ID", sort=False):
        g = g.sort_values("q_true")
        name = str(g["Name"].iloc[0])
        ne = float(g["Neff"].iloc[0])
        n = int(g["N"].iloc[0])
        mass = float(g["MassJ"].iloc[0])
        age = float(g["logAge50"].iloc[0])

        round_row = g[np.isclose(g["q_true"], 1.0)]
        q_round_p05 = float(round_row["qrec_p05"].iloc[0]) if len(round_row) else np.nan
        q_round_p16 = float(round_row["qrec_p16"].iloc[0]) if len(round_row) else np.nan
        q_round_med = float(round_row["qrec_median"].iloc[0]) if len(round_row) else np.nan

        nonround = g[g["q_true"] < 0.999].copy().sort_values("q_true")
        # Candidate roundest q for which it and ALL more elongated q points pass.
        pass_map = {float(r.q_true): bool(r.pa_reliable_at_q) for r in nonround.itertuples()}
        qvals = sorted(pass_map)
        reliable_candidates = []
        for q in qvals:
            more_elongated_or_equal = [qq for qq in qvals if qq <= q]
            if all(pass_map[qq] for qq in more_elongated_or_equal):
                reliable_candidates.append(q)
        qmax = max(reliable_candidates) if reliable_candidates else np.nan

        gate_rows.append({
            "ID": int(cid),
            "Name": name,
            "MassJ": mass,
            "logAge50": age,
            "N": n,
            "Neff": ne,
            "q_round_null_p05": q_round_p05,
            "q_round_null_p16": q_round_p16,
            "q_round_null_median": q_round_med,
            "q_max_PA_reliable": qmax,
            "PA_CALIBRATABLE": bool(np.isfinite(qmax)),
            "LATER_REAL_GATE_PROPOSED":
                "q84_real<=q_max_PA_reliable AND q_real<q_round_null_p05"
        })

    gate_df = pd.DataFrame(gate_rows).sort_values(["PA_CALIBRATABLE","Neff"], ascending=[False,False])
    gate_df.to_csv(out / "03_cluster_specific_PA_gate.csv", index=False)

    # Aggregate global recovery by q_true.
    global_rows = []
    for q, g in sum_df.groupby("q_true"):
        global_rows.append({
            "q_true": q,
            "N_clusters": int(g["ID"].nunique()),
            "median_qbias_median": med(g["qbias_median"]),
            "median_qbias_abs_p68": med(g["qbias_abs_p68"]),
            "median_PA_abs_median_deg": med(g["pa_abs_median_deg"]),
            "median_PA_abs_p68_deg": med(g["pa_abs_p68_deg"]),
            "fraction_cluster_q_reliable":
                float(pd.to_numeric(g["pa_reliable_at_q"], errors="coerce").fillna(False).mean())
                if q < 0.999 else np.nan,
        })
    pd.DataFrame(global_rows).sort_values("q_true", ascending=False).to_csv(
        out / "04_global_qgrid_summary.csv", index=False
    )

    # Coverage by mass threshold.
    coverage = []
    for m in [1000, 3000, 5000, 10000]:
        s = gate_df[gate_df["MassJ"] >= m]
        coverage.append({
            "MassJ_threshold_Msun": m,
            "N_calibrated": int(len(s)),
            "N_PA_calibratable": int(s["PA_CALIBRATABLE"].sum()) if len(s) else 0,
            "fraction_PA_calibratable": float(s["PA_CALIBRATABLE"].mean()) if len(s) else np.nan,
            "median_Neff": med(s["Neff"]) if len(s) else np.nan,
            "median_qmax_reliable": med(s["q_max_PA_reliable"]) if len(s) else np.nan,
        })
    coverage_df = pd.DataFrame(coverage)
    coverage_df.to_csv(out / "05_mass_threshold_calibration_coverage.csv", index=False)

    # Freeze record.
    config = {
        "stage": "STAGE1A_SYNTHETIC_MORPHOLOGY_PA_CALIBRATION",
        "version": VERSION,
        "seed": SEED,
        "q_grid": Q_GRID,
        "n_rep": args.nrep,
        "estimator": "membership-probability weighted second central moments",
        "synthetic_geometry":
            "actual member radii + actual Prob weights; randomized polar angles; imposed q_true; random PA_true",
        "pa_error_definition":
            "absolute axial difference in degrees, modulo 180 and folded to [0,90]",
        "pa_reliability_rule": {
            "p68_abs_deltaPA_deg_max": PA_P68_MAX,
            "median_abs_deltaPA_deg_max": PA_MED_MAX,
            "abs_median_q_bias_max": Q_BIAS_MED_MAX,
            "monotonic_requirement":
                "candidate q passes only if all tested more-elongated q values also pass",
        },
        "later_real_data_gate_proposed":
            "q84_real <= cluster-specific q_max_PA_reliable AND q_real < q_round_null_p05",
        "science_blinding":
            "No real PA, Galactic-plane PA, Delta-theta, or alignment A computed in Stage-1A.",
    }
    (out / "STAGE1A_FREEZE.json").write_text(json.dumps(config, indent=2), encoding="utf-8")

    # Optional compact figures.
    try:
        import matplotlib.pyplot as plt

        ok = gate_df[gate_df["PA_CALIBRATABLE"]].copy()
        fig = plt.figure(figsize=(7.2, 5.4))
        ax = fig.add_subplot(111)
        ax.scatter(ok["Neff"], ok["q_max_PA_reliable"], s=24)
        ax.set_xlabel(r"$N_{\rm eff}$")
        ax.set_ylabel(r"$q_{\rm max}$ with reliable PA recovery")
        ax.set_ylim(0.55, 1.0)
        ax.grid(alpha=0.25)
        fig.tight_layout()
        fig.savefig(out / "FIG01_Neff_vs_qmax_PA_reliable.pdf", bbox_inches="tight")
        fig.savefig(out / "FIG01_Neff_vs_qmax_PA_reliable.png", dpi=220, bbox_inches="tight")
        plt.close(fig)

        gr = pd.read_csv(out / "04_global_qgrid_summary.csv").sort_values("q_true")
        fig = plt.figure(figsize=(7.2, 5.4))
        ax = fig.add_subplot(111)
        x = gr["q_true"].to_numpy(float)
        y = gr["median_PA_abs_p68_deg"].to_numpy(float)
        ax.plot(x, y, marker="o")
        ax.axhline(PA_P68_MAX, linestyle="--")
        ax.set_xlabel(r"Injected $q_{\rm true}$")
        ax.set_ylabel(r"Median cluster $P_{68}(|\Delta {\rm PA}|)$ [deg]")
        ax.set_xlim(0.58, 1.0)
        ax.grid(alpha=0.25)
        fig.tight_layout()
        fig.savefig(out / "FIG02_global_PA_recovery.pdf", bbox_inches="tight")
        fig.savefig(out / "FIG02_global_PA_recovery.png", dpi=220, bbox_inches="tight")
        plt.close(fig)
    except Exception as e:
        (out / "FIGURE_WARNING.txt").write_text(str(e), encoding="utf-8")

    # Report.
    n_ok = int((audit_df["status"] == "OK").sum()) if len(audit_df) else 0
    n_cal = int(gate_df["PA_CALIBRATABLE"].sum()) if len(gate_df) else 0
    report = [
        f"YHMC STAGE-1A SYNTHETIC MORPHOLOGY/PA CALIBRATION v{VERSION}",
        "=" * 82,
        f"STAGE0={stage0}",
        f"Input provisional morphology-ready clusters: {len(sample)}",
        f"Successfully calibrated clusters: {n_ok}",
        f"Clusters with at least one reliable PA q-grid regime: {n_cal}",
        f"Q_GRID={Q_GRID}",
        f"N_REP={args.nrep}",
        f"SEED={SEED}",
        "",
        "FROZEN PA-RELIABILITY RULE:",
        f"  P68(|DeltaPA|) <= {PA_P68_MAX:.1f} deg",
        f"  median(|DeltaPA|) <= {PA_MED_MAX:.1f} deg",
        f"  |median(q_rec-q_true)| <= {Q_BIAS_MED_MAX:.3f}",
        "  q_max is accepted only when all more-elongated tested q values also pass.",
        "",
        "PROPOSED STAGE-1B REAL-DATA PA GATE:",
        "  q84_real <= q_max_PA_reliable",
        "  AND q_real < q_round_null_p05",
        "",
        "MASS-THRESHOLD CALIBRATION COVERAGE:",
        coverage_df.to_string(index=False),
        "",
        "SCIENCE BLINDING:",
        "  No real cluster PA, Galactic-plane PA, Delta-theta, or A was computed.",
        "",
        "NEXT_STAGE:",
        "  Review Stage-1A calibration. If PASS, freeze gate and run Stage-1B real morphology only;",
        "  compute Galactic-plane alignment only after the morphology sample is frozen.",
    ]
    (out / "STAGE1A_REPORT.txt").write_text("\n".join(report) + "\n", encoding="utf-8")

    manifest = []
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out / "SHA256SUMS.txt").write_text("\n".join(manifest) + "\n", encoding="utf-8")

    print()
    print((out / "STAGE1A_REPORT.txt").read_text(encoding="utf-8"))

if __name__ == "__main__":
    main()

@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-3A ALIGNMENT SYSTEMATICS AUDIT v0.9.1
echo DERIVED SKY-GEOMETRY PATCH / NO SAMPLE CHANGES
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" (
  echo ERROR: Miniconda Python not found.
  exit /b 1
)

set "STAGE1B=%USERPROFILE%\Downloads\YHMC_STAGE1B_REAL_MORPHOLOGY_FREEZE_v0_3_0\YHMC_STAGE1B_REAL_MORPHOLOGY_FREEZE_v0_3_0\STAGE1B_OUTPUT"
set "STAGE0=%USERPROFILE%\Downloads\YHMC_STAGE0_PREFLIGHT_v0_1_2\YHMC_STAGE0_PREFLIGHT_v0_1_2\STAGE0_OUTPUT"
set "STAGE2C=%USERPROFILE%\Downloads\YHMC_STAGE2C_CONTROL_REAL_MORPHOLOGY_FREEZE_v0_7_0\YHMC_STAGE2C_CONTROL_REAL_MORPHOLOGY_FREEZE_v0_7_0\STAGE2C_OUTPUT"
set "STAGE2D=%USERPROFILE%\Downloads\YHMC_STAGE2D_CONTROL_ALIGNMENT_MATCHED_CONTRAST_v0_8_0\YHMC_STAGE2D_CONTROL_ALIGNMENT_MATCHED_CONTRAST_v0_8_0\STAGE2D_OUTPUT"

echo PYEXE=%PYEXE%
"%PYEXE%" --version

"%PYEXE%" -c "import numpy,pandas,astropy" >nul 2>nul
if errorlevel 1 (
  "%PYEXE%" -m pip install numpy pandas astropy
  if errorlevel 1 exit /b 1
)

"%PYEXE%" stage3a_alignment_systematics_audit_v0_9_1.py ^
 --stage1b "%STAGE1B%" ^
 --stage0 "%STAGE0%" ^
 --stage2c "%STAGE2C%" ^
 --stage2d "%STAGE2D%" ^
 --out "%CD%\STAGE3A_OUTPUT"

set "RC=%ERRORLEVEL%"
echo.
echo RETURN_CODE=%RC%
if "%RC%"=="0" (
  echo REPORT=%CD%\STAGE3A_OUTPUT\STAGE3A_REPORT.txt
  echo SUMMARY=%CD%\STAGE3A_OUTPUT\02_global_systematics_summary.csv
  echo MASS_AUDIT=%CD%\STAGE3A_OUTPUT\03_mass_threshold_permutation_audit.csv
)
exit /b %RC%

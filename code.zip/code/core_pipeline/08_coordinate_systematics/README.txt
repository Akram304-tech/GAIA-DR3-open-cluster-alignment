YHMC STAGE-3A ALIGNMENT SYSTEMATICS AUDIT v0.9.1
====================================================

Patch
-----
v0.9.0 stopped because the Stage-2C frozen control sample does not carry
GLON/GLAT columns.

v0.9.1 does NOT alter the frozen sample. Instead it derives:
- Galactic longitude and latitude,
- local Galactic-plane tangent PA,
- local ecliptic-plane tangent PA,

directly from each frozen object's canonical ICRS __RAdeg/__DEdeg using
Astropy.

This is preferable for the audit because the sky geometry is independently
reconstructed rather than propagated from an earlier catalogue table.

Run
---
call RUN_STAGE3A_ALIGNMENT_SYSTEMATICS_AUDIT_v0_9_1.bat

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-3A alignment-systematics audit v0.9.1

Patch from v0.9.0
-----------------
The Stage-2C frozen control PA sample intentionally retained canonical ICRS
coordinates but not GLON/GLAT. v0.9.1 derives Galactic longitude/latitude
directly from each frozen object's __RAdeg/__DEdeg using Astropy.

This avoids modifying any frozen sample and makes the sky-geometry audit
independent of catalogue-propagated Galactic-coordinate fields.

No sample membership is changed.
"""

from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "0.9.1"
SEED = 20260912
N_PERM = 500000
N_ROT = 500000
N_SECTORS = 8

EXPECTED_YOUNG_FROZEN_SHA256 = "cc1d3ae4ce1cf52387f535da92fbd0dc5d984a3bb2dc750bf6672682e85f65dd"
EXPECTED_CONTROL_FROZEN_SHA256 = "124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd"
EXPECTED_STAGE2C_FREEZE_SHA256 = "92e32489305078fe9d090b175d1e124ffbe8cc2eab8d448369f19fe83884bd97"

def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()

def axial_signed_diff_deg(a,b):
    return ((np.asarray(a,float)-np.asarray(b,float)+90.0)%180.0)-90.0

def A_from_pa(pa, refpa):
    pa=np.asarray(pa,float); refpa=np.asarray(refpa,float)
    if len(pa)==0:
        return np.nan
    d=np.abs(axial_signed_diff_deg(pa,refpa))
    return float(np.mean(np.cos(np.deg2rad(2.0*d))))

def derive_sky_geometry(df):
    """Derive GLON/GLAT and local Galactic/ecliptic tangent PAs from frozen ICRS."""
    from astropy.coordinates import SkyCoord, BarycentricMeanEcliptic
    from astropy.time import Time
    import astropy.units as u

    out=df.copy()
    ra=pd.to_numeric(out["__RAdeg"],errors="coerce").to_numpy(float)
    de=pd.to_numeric(out["__DEdeg"],errors="coerce").to_numpy(float)
    if not (np.isfinite(ra).all() and np.isfinite(de).all()):
        raise RuntimeError("Non-finite frozen ICRS coordinates.")

    c=SkyCoord(ra=ra*u.deg,dec=de*u.deg,frame="icrs")
    g=c.galactic
    out["GLON_DERIVED"]=g.l.deg
    out["GLAT_DERIVED"]=g.b.deg

    eps=1e-3*u.deg
    gp=SkyCoord(l=g.l+eps,b=g.b,frame="galactic").icrs
    gm=SkyCoord(l=g.l-eps,b=g.b,frame="galactic").icrs

    ef=BarycentricMeanEcliptic(equinox=Time("J2000"))
    e=c.transform_to(ef)
    ep=SkyCoord(lon=e.lon+eps,lat=e.lat,frame=ef).icrs
    em=SkyCoord(lon=e.lon-eps,lat=e.lat,frame=ef).icrs

    cosdec=np.cos(np.deg2rad(de))

    def local_pa(p,m):
        dra_p=((p.ra.deg-ra+180.0)%360.0)-180.0
        dra_m=((m.ra.deg-ra+180.0)%360.0)-180.0
        xp=dra_p*cosdec
        xm=dra_m*cosdec
        yp=p.dec.deg-de
        ym=m.dec.deg-de
        dx=xp-xm
        dy=yp-ym
        pa=np.degrees(np.arctan2(dy,dx))%180.0
        return pa

    out["PA_Galactic_parallel_recomputed_deg"]=local_pa(gp,gm)
    out["PA_Ecliptic_parallel_deg"]=local_pa(ep,em)

    if not np.isfinite(out["PA_Galactic_parallel_recomputed_deg"]).all():
        raise RuntimeError("Non-finite derived Galactic-plane tangent PA.")
    if not np.isfinite(out["PA_Ecliptic_parallel_deg"]).all():
        raise RuntimeError("Non-finite derived ecliptic tangent PA.")
    return out

def permutation_null(pa, refpa, nperm, rng, chunk=20000):
    pa=np.asarray(pa,float)
    refpa=np.asarray(refpa,float)
    n=len(pa)
    vals=[]
    remain=nperm
    while remain>0:
        k=min(chunk,remain)
        # Random permutations from random-key ordering.
        idx=np.argsort(rng.random((k,n)),axis=1)
        pp=pa[idx]
        d=np.abs(((pp-refpa[None,:]+90.0)%180.0)-90.0)
        vals.append(np.mean(np.cos(np.deg2rad(2*d)),axis=1))
        remain-=k
    return np.concatenate(vals)

def rotation_null(pa, refpa, nrot, rng, chunk=50000):
    pa=np.asarray(pa,float)
    refpa=np.asarray(refpa,float)
    vals=[]
    remain=nrot
    while remain>0:
        k=min(chunk,remain)
        alpha=rng.uniform(0.0,180.0,size=k)
        pp=(pa[None,:]+alpha[:,None])%180.0
        d=np.abs(((pp-refpa[None,:]+90.0)%180.0)-90.0)
        vals.append(np.mean(np.cos(np.deg2rad(2*d)),axis=1))
        remain-=k
    return np.concatenate(vals)

def p_upper(obs,null):
    return float((1+np.count_nonzero(null>=obs))/(len(null)+1))

def pct(x,p):
    x=np.asarray(x,float)
    return float(np.percentile(x,p)) if len(x) else np.nan

def sample_audit(df,label):
    pa=df["PA_deg_point"].to_numpy(float)
    gp=df["PA_Galactic_parallel_recomputed_deg"].to_numpy(float)
    ep=df["PA_Ecliptic_parallel_deg"].to_numpy(float)
    eq=np.zeros(len(df),dtype=float)

    A_gal=A_from_pa(pa,gp)
    A_ecl=A_from_pa(pa,ep)
    A_eq=A_from_pa(pa,eq)

    tag=1 if label=="young" else 2
    rngp=np.random.default_rng(np.random.SeedSequence([SEED,tag,11]))
    rngr=np.random.default_rng(np.random.SeedSequence([SEED,tag,12]))
    perm=permutation_null(pa,gp,N_PERM,rngp)
    rot=rotation_null(pa,gp,N_ROT,rngr)

    return {
        "sample":label,
        "N":len(df),
        "A_Galactic":A_gal,
        "A_Ecliptic":A_ecl,
        "A_Equatorial_EW":A_eq,
        "p_PA_position_permutation":p_upper(A_gal,perm),
        "perm_null_p95":pct(perm,95),
        "perm_null_p99":pct(perm,99),
        "p_common_global_rotation":p_upper(A_gal,rot),
        "rotation_null_p95":pct(rot,95),
        "rotation_null_p99":pct(rot,99),
        "specificity_Gal_minus_Ecl":A_gal-A_ecl,
        "specificity_Gal_minus_Equatorial":A_gal-A_eq,
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage1b",required=True)
    ap.add_argument("--stage0",required=True)
    ap.add_argument("--stage2c",required=True)
    ap.add_argument("--stage2d",required=True)
    ap.add_argument("--out",default="STAGE3A_OUTPUT")
    args=ap.parse_args()

    stage1b=Path(args.stage1b).expanduser().resolve()
    stage0=Path(args.stage0).expanduser().resolve()
    stage2c=Path(args.stage2c).expanduser().resolve()
    stage2d=Path(args.stage2d).expanduser().resolve()
    out=Path(args.out).expanduser().resolve()
    out.mkdir(parents=True,exist_ok=True)

    young_file=stage1b/"02_PRIMARY_PA_SAMPLE_FROZEN.csv"
    stage0_file=stage0/"07_provisional_morphology_ready.csv"
    control_file=stage2c/"02_CONTROL_PA_SAMPLE_FROZEN.csv"
    freeze2c=stage2c/"STAGE2C_FREEZE.json"
    anchor_file=stage2d/"03_anchor_normalized_young_control_table.csv"

    for p in [young_file,stage0_file,control_file,freeze2c,anchor_file]:
        if not p.exists():
            raise FileNotFoundError(p)

    hy=sha256(young_file)
    hc=sha256(control_file)
    hf=sha256(freeze2c)

    if hy!=EXPECTED_YOUNG_FROZEN_SHA256:
        raise RuntimeError(f"Young frozen hash mismatch: {hy}")
    if hc!=EXPECTED_CONTROL_FROZEN_SHA256:
        raise RuntimeError(f"Control frozen hash mismatch: {hc}")
    if hf!=EXPECTED_STAGE2C_FREEZE_SHA256:
        raise RuntimeError(f"Stage2C freeze hash mismatch: {hf}")

    y=pd.read_csv(young_file)
    s0=pd.read_csv(stage0_file)
    c=pd.read_csv(control_file)

    # Young frozen file lacks canonical coordinates; attach them by strict ID+Name join.
    coord=s0[["ID","Name","__RAdeg","__DEdeg"]].copy()
    if coord.duplicated(["ID","Name"]).any():
        raise RuntimeError("Stage0 coordinate source duplicates.")
    y=y.merge(coord,on=["ID","Name"],how="left",validate="one_to_one",indicator=True)
    if len(y)==0 or not (y["_merge"]=="both").all():
        raise RuntimeError("Young coordinate join failed.")
    y=y.drop(columns="_merge")

    # Control frozen sample must already retain canonical ICRS.
    for col in ["__RAdeg","__DEdeg"]:
        if col not in c.columns:
            raise RuntimeError(f"Control sample missing canonical ICRS field {col}")

    print("="*96)
    print(f"YHMC STAGE-3A ALIGNMENT SYSTEMATICS AUDIT v{VERSION}")
    print("="*96)
    print(f"YOUNG_HASH={hy}")
    print(f"CONTROL_HASH={hc}")
    print(f"STAGE2C_FREEZE_HASH={hf}")
    print("CHAIN_OF_CUSTODY=PASS")
    print("SKY_GEOMETRY_SOURCE=derived independently from frozen ICRS coordinates")

    y=derive_sky_geometry(y)
    c=derive_sky_geometry(c)

    # Recomputed deltas and independent reference controls.
    for df,label in [(y,"young"),(c,"control")]:
        df["Delta_Galactic_recomputed_deg"]=np.abs(
            axial_signed_diff_deg(df["PA_deg_point"],df["PA_Galactic_parallel_recomputed_deg"])
        )
        df["Delta_Ecliptic_deg"]=np.abs(
            axial_signed_diff_deg(df["PA_deg_point"],df["PA_Ecliptic_parallel_deg"])
        )
        df["Delta_Equatorial_EW_deg"]=np.abs(
            axial_signed_diff_deg(df["PA_deg_point"],0.0)
        )
        df.to_csv(out/f"01_{label}_systematics_cluster_table.csv",index=False)

    summaries=pd.DataFrame([sample_audit(y,"young"),sample_audit(c,"control")])
    summaries.to_csv(out/"02_global_systematics_summary.csv",index=False)

    # Mass-threshold position-permutation audits.
    mass_rows=[]
    for label,df in [("young",y),("control",c)]:
        for m in [1000,3000,5000,10000]:
            s=df[pd.to_numeric(df["MassJ"],errors="coerce")>=m].copy()
            obs=A_from_pa(s["PA_deg_point"],s["PA_Galactic_parallel_recomputed_deg"]) if len(s) else np.nan
            if len(s)<2:
                mass_rows.append({
                    "sample":label,"MassJ_threshold_Msun":m,"N":len(s),
                    "A_Galactic":obs,"p_PA_position_permutation":np.nan,
                    "perm_p95":np.nan,"perm_p99":np.nan,
                })
                continue
            rng=np.random.default_rng(np.random.SeedSequence([SEED,100 if label=="young" else 200,m]))
            null=permutation_null(
                s["PA_deg_point"].to_numpy(float),
                s["PA_Galactic_parallel_recomputed_deg"].to_numpy(float),
                N_PERM,rng
            )
            mass_rows.append({
                "sample":label,"MassJ_threshold_Msun":m,"N":len(s),
                "A_Galactic":obs,
                "p_PA_position_permutation":p_upper(obs,null),
                "perm_p95":pct(null,95),
                "perm_p99":pct(null,99),
            })
    pd.DataFrame(mass_rows).to_csv(out/"03_mass_threshold_permutation_audit.csv",index=False)

    # Galactic-longitude sector jackknife using DERIVED longitude.
    sector_rows=[]
    edges=np.linspace(0,360,N_SECTORS+1)
    for label,df in [("young",y),("control",c)]:
        glon=pd.to_numeric(df["GLON_DERIVED"],errors="coerce").to_numpy(float)%360.0
        for k in range(N_SECTORS):
            in_sector=(glon>=edges[k])&(glon<edges[k+1])
            s=df.loc[~in_sector]
            sector_rows.append({
                "sample":label,
                "removed_sector_index":k,
                "removed_lon_lo":edges[k],
                "removed_lon_hi":edges[k+1],
                "N_removed":int(np.count_nonzero(in_sector)),
                "N_remaining":len(s),
                "A_Galactic_remaining":A_from_pa(
                    s["PA_deg_point"],s["PA_Galactic_parallel_recomputed_deg"]
                ),
            })
    sector_df=pd.DataFrame(sector_rows)
    sector_df.to_csv(out/"04_longitude_sector_jackknife.csv",index=False)

    # Latitude split using derived b.
    lat_rows=[]
    for label,df in [("young",y),("control",c)]:
        ab=np.abs(pd.to_numeric(df["GLAT_DERIVED"],errors="coerce").to_numpy(float))
        cut=float(np.median(ab))
        for grp,mask in [("low_absb",ab<=cut),("high_absb",ab>cut)]:
            s=df.loc[mask]
            lat_rows.append({
                "sample":label,"group":grp,"absb_median_split_deg":cut,
                "N":len(s),
                "A_Galactic":A_from_pa(
                    s["PA_deg_point"],s["PA_Galactic_parallel_recomputed_deg"]
                ) if len(s) else np.nan,
                "median_absb_deg":float(np.median(np.abs(s["GLAT_DERIVED"]))) if len(s) else np.nan,
            })
    pd.DataFrame(lat_rows).to_csv(out/"05_latitude_split_audit.csv",index=False)

    # Matched D longitude jackknife; keep Stage-2D D_i unchanged, only derive young sector.
    anchor=pd.read_csv(anchor_file)
    ygl=y[["ID","Name","GLON_DERIVED"]].rename(
        columns={"ID":"young_ID","Name":"young_Name","GLON_DERIVED":"GLON_young_derived"}
    )
    anchor=anchor.merge(ygl,on=["young_ID","young_Name"],how="left",validate="one_to_one")
    if anchor["GLON_young_derived"].isna().any():
        raise RuntimeError("Anchor derived-longitude join failed.")
    anchor["sector"]=np.floor(
        (anchor["GLON_young_derived"].to_numpy(float)%360.0)/(360.0/N_SECTORS)
    ).astype(int)

    djack=[]
    for role,mask0 in [
        ("PRIMARY_M3000",pd.to_numeric(anchor["MassJ_young"],errors="coerce")>=3000),
        ("EXTENDED",np.ones(len(anchor),dtype=bool)),
    ]:
        a0=anchor.loc[mask0].copy()
        for k in range(N_SECTORS):
            s=a0[a0["sector"]!=k]
            djack.append({
                "ROLE":role,"removed_sector_index":k,
                "N_removed":int(np.count_nonzero(a0["sector"]==k)),
                "N_remaining":len(s),
                "D_remaining":float(s["D_i_young_minus_control"].mean()) if len(s) else np.nan,
            })
    djack_df=pd.DataFrame(djack)
    djack_df.to_csv(out/"06_matched_D_longitude_jackknife.csv",index=False)

    # Absolute PA anisotropy diagnostic.
    pa_diag=[]
    for label,df in [("young",y),("control",c)]:
        pa=pd.to_numeric(df["PA_deg_point"],errors="coerce").to_numpy(float)%180.0
        mc=float(np.mean(np.cos(np.deg2rad(2*pa))))
        ms=float(np.mean(np.sin(np.deg2rad(2*pa))))
        pa_diag.append({
            "sample":label,"N":len(pa),
            "mean_cos2PA":mc,"mean_sin2PA":ms,
            "R2_absolute_PA":float(np.hypot(mc,ms)),
        })
    pa_diag_df=pd.DataFrame(pa_diag)
    pa_diag_df.to_csv(out/"07_absolute_PA_anisotropy.csv",index=False)

    # Independent coordinate consistency audit: derived vs catalogue young GLON/GLAT when available.
    coord_audit=[]
    if "GLON" in s0.columns and "GLAT" in s0.columns:
        tmp=y[["ID","Name","GLON_DERIVED","GLAT_DERIVED"]].merge(
            s0[["ID","Name","GLON","GLAT"]],on=["ID","Name"],how="left",validate="one_to_one"
        )
        dg=((tmp["GLON_DERIVED"]-pd.to_numeric(tmp["GLON"],errors="coerce")+180)%360)-180
        db=tmp["GLAT_DERIVED"]-pd.to_numeric(tmp["GLAT"],errors="coerce")
        coord_audit=[{
            "sample":"young",
            "max_abs_dGLON_deg":float(np.nanmax(np.abs(dg))),
            "max_abs_dGLAT_deg":float(np.nanmax(np.abs(db))),
            "median_abs_dGLON_deg":float(np.nanmedian(np.abs(dg))),
            "median_abs_dGLAT_deg":float(np.nanmedian(np.abs(db))),
        }]
    pd.DataFrame(coord_audit).to_csv(out/"08_coordinate_consistency_audit.csv",index=False)

    contract={
        "stage":"STAGE3A_ALIGNMENT_SYSTEMATICS_AUDIT",
        "version":VERSION,
        "young_frozen_sha256":hy,
        "control_frozen_sha256":hc,
        "stage2c_freeze_sha256":hf,
        "sky_geometry_source":"independently derived from frozen ICRS coordinates",
        "n_position_permutations":N_PERM,
        "n_global_rotations":N_ROT,
        "n_longitude_sectors":N_SECTORS,
        "sample_membership_changes":False,
        "primary_systematics_question":
            "Does measured PA retain a specific association with local Galactic-plane direction after preserving empirical PA and sky-position marginals?"
    }
    (out/"STAGE3A_AUDIT_CONTRACT.json").write_text(json.dumps(contract,indent=2),encoding="utf-8")

    sy=summaries[summaries["sample"]=="young"].iloc[0]
    sc=summaries[summaries["sample"]=="control"].iloc[0]

    def f(x,n=4):
        try:
            return f"{float(x):.{n}f}" if np.isfinite(float(x)) else "NA"
        except Exception:
            return "NA"

    # Jackknife ranges make the terminal report immediately diagnostic.
    yj=sector_df[sector_df["sample"]=="young"]["A_Galactic_remaining"]
    cj=sector_df[sector_df["sample"]=="control"]["A_Galactic_remaining"]
    dp=djack_df[djack_df["ROLE"]=="PRIMARY_M3000"]["D_remaining"]
    de=djack_df[djack_df["ROLE"]=="EXTENDED"]["D_remaining"]

    report=[
        f"YHMC STAGE-3A ALIGNMENT SYSTEMATICS AUDIT v{VERSION}",
        "="*96,
        "CHAIN_OF_CUSTODY=PASS",
        "SKY_GEOMETRY_SOURCE=independently derived from frozen ICRS coordinates",
        f"Young frozen N={len(y)}",
        f"Control frozen N={len(c)}",
        "",
        "YOUNG SAMPLE",
        f"  A_Galactic = {f(sy['A_Galactic'])}",
        f"  PA-position permutation p = {f(sy['p_PA_position_permutation'],6)}",
        f"  common-global-rotation p = {f(sy['p_common_global_rotation'],6)}",
        f"  A_Ecliptic = {f(sy['A_Ecliptic'])}",
        f"  A_Equatorial_EW = {f(sy['A_Equatorial_EW'])}",
        f"  A_Gal - A_Ecl = {f(sy['specificity_Gal_minus_Ecl'])}",
        f"  A_Gal - A_Equatorial = {f(sy['specificity_Gal_minus_Equatorial'])}",
        f"  longitude-jackknife A range = [{f(yj.min())}, {f(yj.max())}]",
        "",
        "OLDER CONTROL SAMPLE",
        f"  A_Galactic = {f(sc['A_Galactic'])}",
        f"  PA-position permutation p = {f(sc['p_PA_position_permutation'],6)}",
        f"  common-global-rotation p = {f(sc['p_common_global_rotation'],6)}",
        f"  A_Ecliptic = {f(sc['A_Ecliptic'])}",
        f"  A_Equatorial_EW = {f(sc['A_Equatorial_EW'])}",
        f"  A_Gal - A_Ecl = {f(sc['specificity_Gal_minus_Ecl'])}",
        f"  A_Gal - A_Equatorial = {f(sc['specificity_Gal_minus_Equatorial'])}",
        f"  longitude-jackknife A range = [{f(cj.min())}, {f(cj.max())}]",
        "",
        "MATCHED AGE-CONTRAST JACKKNIFE",
        f"  primary D range after removing one longitude sector = [{f(dp.min())}, {f(dp.max())}]",
        f"  extended D range after removing one longitude sector = [{f(de.min())}, {f(de.max())}]",
        "",
        "DECISION GUIDE",
        "  A Galactic-specific signal should show:",
        "    1) small PA-position permutation p;",
        "    2) Galactic A substantially above ecliptic/equatorial control A;",
        "    3) stable sign/amplitude under Galactic-longitude sector jackknife.",
        "  If these fail, the original uniform-angle null is insufficient and",
        "  coordinate/catalogue-selection geometry becomes the leading explanation.",
        "",
        "NEXT:",
        "  Membership-threshold (P>=0.7/0.8/0.9), estimator, and radial-region",
        "  robustness are required before any manuscript-level physical claim.",
    ]
    (out/"STAGE3A_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")

    print()
    print((out/"STAGE3A_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

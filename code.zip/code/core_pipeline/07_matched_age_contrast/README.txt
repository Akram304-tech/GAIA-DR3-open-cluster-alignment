YHMC STAGE-2D CONTROL ALIGNMENT + MATCHED AGE CONTRAST v0.8.0
=================================================================

This is the FIRST stage authorized to compute older-control alignment.

Pre-frozen PRIMARY age test:
  young anchors with MassJ_young >= 3000 Msun
  and at least one admitted matched older control.

For each anchor:
  D_i = cos(2 Delta_young) - mean[cos(2 Delta_control)]

Primary endpoint:
  D = mean(D_i)

Alternative:
  D > 0

Test:
  paired random sign-flip test + anchor bootstrap CI.

Extended confirmation:
  same paired test for all anchors with >=1 admitted control.

Standalone older-control A is also reported as a systematics check.

Run:
  call RUN_STAGE2D_CONTROL_ALIGNMENT_MATCHED_CONTRAST_v0_8_0.bat

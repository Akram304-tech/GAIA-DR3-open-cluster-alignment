@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-2D CONTROL ALIGNMENT + MATCHED CONTRAST v0.8.0
echo FIRST CONTROL ALIGNMENT UNBLIND
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" (
  echo ERROR: Miniconda Python not found.
  exit /b 1
)

set "STAGE2C=%USERPROFILE%\Downloads\YHMC_STAGE2C_CONTROL_REAL_MORPHOLOGY_FREEZE_v0_7_0\YHMC_STAGE2C_CONTROL_REAL_MORPHOLOGY_FREEZE_v0_7_0\STAGE2C_OUTPUT"
set "STAGE1C=%USERPROFILE%\Downloads\YHMC_STAGE1C_ALIGNMENT_UNBLIND_v0_4_2\YHMC_STAGE1C_ALIGNMENT_UNBLIND_v0_4_2\STAGE1C_OUTPUT"
set "STAGE1B=%USERPROFILE%\Downloads\YHMC_STAGE1B_REAL_MORPHOLOGY_FREEZE_v0_3_0\YHMC_STAGE1B_REAL_MORPHOLOGY_FREEZE_v0_3_0\STAGE1B_OUTPUT"

if not exist "%STAGE2C%\02_CONTROL_PA_SAMPLE_FROZEN.csv" (
  echo ERROR: Stage-2C frozen control PA sample not found.
  exit /b 1
)
if not exist "%STAGE1C%\01_alignment_cluster_table_UNBLINDED.csv" (
  echo ERROR: Stage-1C young alignment table not found.
  exit /b 1
)
if not exist "%STAGE1B%\02_PRIMARY_PA_SAMPLE_FROZEN.csv" (
  echo ERROR: Stage-1B frozen young sample not found.
  exit /b 1
)

echo PYEXE=%PYEXE%
"%PYEXE%" --version
echo STAGE2C=%STAGE2C%
echo STAGE1C=%STAGE1C%
echo STAGE1B=%STAGE1B%

"%PYEXE%" -c "import numpy,pandas,astropy,matplotlib" >nul 2>nul
if errorlevel 1 (
  "%PYEXE%" -m pip install numpy pandas astropy matplotlib
  if errorlevel 1 exit /b 1
)

"%PYEXE%" stage2d_control_alignment_matched_contrast_v0_8_0.py --stage2c "%STAGE2C%" --stage1c "%STAGE1C%" --stage1b "%STAGE1B%" --out "%CD%\STAGE2D_OUTPUT"
set "RC=%ERRORLEVEL%"

echo.
echo RETURN_CODE=%RC%
if "%RC%"=="0" (
  echo REPORT=%CD%\STAGE2D_OUTPUT\STAGE2D_REPORT.txt
  echo MATCHED=%CD%\STAGE2D_OUTPUT\04_matched_age_contrast_inference.csv
  echo CONTRACT=%CD%\STAGE2D_OUTPUT\STAGE2D_UNBLIND_CONTRACT.json
)
exit /b %RC%

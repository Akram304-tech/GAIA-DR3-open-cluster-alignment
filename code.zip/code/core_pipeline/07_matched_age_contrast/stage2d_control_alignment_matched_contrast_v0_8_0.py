#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-2D older-control alignment unblind + matched age contrast v0.8.0

FIRST authorized stage to compute older-control Galactic-plane alignment.

Pre-frozen hierarchy
--------------------
PRIMARY AGE-CONTRAST TEST:
  Young anchors with MassJ_young >= 3000 Msun AND >=1 admitted matched control.
  For anchor i:
      Y_i = cos(2 Delta_theta_young)
      C_i = mean_j cos(2 Delta_theta_control_ij)
      D_i = Y_i - C_i
  Endpoint:
      D = mean_i D_i
  Alternative:
      H1: D > 0  (young clusters are more strongly plane-aligned)

EXTENDED CONFIRMATION:
  Same anchor-normalized paired contrast for all young anchors with >=1
  admitted matched control.

STANDALONE CONTROL CHECK:
  A_control = mean cos(2 Delta_theta_control)
  reported at the pre-existing 1000, 3000, 5000, 10000 Msun thresholds.

No post-unblinding sample or threshold changes are allowed.
"""

from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "0.8.0"
SEED = 20260912

EXPECTED_CONTROL_SAMPLE_SHA256 = "124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd"
EXPECTED_ANCHOR_COVERAGE_SHA256 = "cc8230555bb965a75b78dd2ac88e7ce6388bd4bf74240b97fc6c19633dab8bf8"
EXPECTED_STAGE2C_FREEZE_SHA256 = "92e32489305078fe9d090b175d1e124ffbe8cc2eab8d448369f19fe83884bd97"
EXPECTED_YOUNG_FROZEN_SHA256 = "cc1d3ae4ce1cf52387f535da92fbd0dc5d984a3bb2dc750bf6672682e85f65dd"

PRIMARY_YOUNG_MASS = 3000.0
CONTROL_THRESHOLDS = [1000.0, 3000.0, 5000.0, 10000.0]

N_NULL = 500000
N_BOOT = 200000
N_SIGNFLIP = 500000

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()

def axial_signed_diff_deg(a, b):
    return ((np.asarray(a, dtype=float) - np.asarray(b, dtype=float) + 90.0) % 180.0) - 90.0

def pct(a,p):
    a=np.asarray(a,dtype=float)
    a=a[np.isfinite(a)]
    return float(np.percentile(a,p)) if len(a) else np.nan

def local_galactic_parallel_pa_east_of_x(ra_deg, dec_deg, eps_deg=1e-3):
    from astropy.coordinates import SkyCoord
    import astropy.units as u
    c=SkyCoord(ra=float(ra_deg)*u.deg,dec=float(dec_deg)*u.deg,frame="icrs")
    g=c.galactic
    gp=SkyCoord(l=(g.l+eps_deg*u.deg),b=g.b,frame="galactic").icrs
    gm=SkyCoord(l=(g.l-eps_deg*u.deg),b=g.b,frame="galactic").icrs

    def xy(obj):
        dra=((obj.ra.deg-c.ra.deg+180.0)%360.0)-180.0
        x=dra*math.cos(math.radians(c.dec.deg))
        y=obj.dec.deg-c.dec.deg
        return x,y

    xp,yp=xy(gp); xm,ym=xy(gm)
    dx=xp-xm; dy=yp-ym
    if not np.isfinite(dx) or not np.isfinite(dy) or (dx==0 and dy==0):
        return np.nan
    return float(np.degrees(np.arctan2(dy,dx))%180.0)

def chunked_null_A(n, nsim, rng, chunk=25000):
    vals=[]
    rem=nsim
    while rem>0:
        k=min(chunk,rem)
        d=rng.uniform(0.0,90.0,size=(k,n))
        vals.append(np.mean(np.cos(np.deg2rad(2*d)),axis=1))
        rem-=k
    return np.concatenate(vals)

def chunked_boot_mean(x, nsim, rng, chunk=25000):
    x=np.asarray(x,float)
    n=len(x)
    vals=[]
    rem=nsim
    while rem>0:
        k=min(chunk,rem)
        idx=rng.integers(0,n,size=(k,n))
        vals.append(np.mean(x[idx],axis=1))
        rem-=k
    return np.concatenate(vals)

def signflip_test(d, nsim, rng, chunk=25000):
    d=np.asarray(d,float)
    n=len(d)
    obs=float(np.mean(d))
    vals=[]
    rem=nsim
    while rem>0:
        k=min(chunk,rem)
        signs=rng.choice(np.array([-1.0,1.0]),size=(k,n))
        vals.append(np.mean(signs*d[None,:],axis=1))
        rem-=k
    vals=np.concatenate(vals)
    p_one=float((1+np.count_nonzero(vals>=obs))/(len(vals)+1))
    p_two=float((1+np.count_nonzero(np.abs(vals)>=abs(obs)))/(len(vals)+1))
    return obs,p_one,p_two,vals

def standalone_control_inference(df, threshold, seed_tag):
    s=df[pd.to_numeric(df["MassJ"],errors="coerce")>=threshold].copy()
    n=len(s)
    if n==0:
        return {"MassJ_threshold_Msun":threshold,"N":0,"A_control":np.nan}
    x=s["cos2Delta_control"].to_numpy(float)
    A=float(np.mean(x))
    delta=s["Delta_theta_control_deg"].to_numpy(float)
    rng_null=np.random.default_rng(np.random.SeedSequence([SEED,int(threshold),seed_tag,1]))
    rng_boot=np.random.default_rng(np.random.SeedSequence([SEED,int(threshold),seed_tag,2]))

    if n>=2:
        nullA=chunked_null_A(n,N_NULL,rng_null)
        ppar=float((1+np.count_nonzero(nullA>=A))/(N_NULL+1))
        ptwo=float((1+np.count_nonzero(np.abs(nullA)>=abs(A)))/(N_NULL+1))
        boot=chunked_boot_mean(x,N_BOOT,rng_boot)
        b16,b50,b84=[pct(boot,p) for p in (16,50,84)]
        b025,b975=[pct(boot,p) for p in (2.5,97.5)]
    else:
        ppar=ptwo=np.nan
        b16=b50=b84=b025=b975=np.nan

    return {
        "MassJ_threshold_Msun":threshold,
        "N":n,
        "A_control":A,
        "bootstrap_A_p025":b025,
        "bootstrap_A_p16":b16,
        "bootstrap_A_median":b50,
        "bootstrap_A_p84":b84,
        "bootstrap_A_p975":b975,
        "null_p_parallel_one_sided":ppar,
        "null_p_two_sided":ptwo,
        "median_Delta_theta_deg":float(np.median(delta)),
        "fraction_Delta_le30":float(np.mean(delta<=30.0)),
    }

def paired_inference(anchor_df, label, seed_tag):
    n=len(anchor_df)
    if n==0:
        return {
            "ROLE":label,"N_anchors":0,
            "A_young":np.nan,"A_control_anchor":np.nan,"D_young_minus_control":np.nan
        }

    y=anchor_df["cos2Delta_young"].to_numpy(float)
    c=anchor_df["cos2Delta_control_anchor_mean"].to_numpy(float)
    d=y-c

    rng_sign=np.random.default_rng(np.random.SeedSequence([SEED,seed_tag,1]))
    rng_boot=np.random.default_rng(np.random.SeedSequence([SEED,seed_tag,2]))

    D,p1,p2,_=signflip_test(d,N_SIGNFLIP,rng_sign)

    bootD=chunked_boot_mean(d,N_BOOT,rng_boot)
    d16,d50,d84=[pct(bootD,p) for p in (16,50,84)]
    d025,d975=[pct(bootD,p) for p in (2.5,97.5)]

    return {
        "ROLE":label,
        "N_anchors":n,
        "A_young":float(np.mean(y)),
        "A_control_anchor":float(np.mean(c)),
        "D_young_minus_control":D,
        "bootstrap_D_p025":d025,
        "bootstrap_D_p16":d16,
        "bootstrap_D_median":d50,
        "bootstrap_D_p84":d84,
        "bootstrap_D_p975":d975,
        "signflip_p_D_gt_0_one_sided":p1,
        "signflip_p_two_sided":p2,
        "median_D_i":float(np.median(d)),
        "fraction_D_i_gt0":float(np.mean(d>0)),
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage2c",required=True)
    ap.add_argument("--stage1c",required=True)
    ap.add_argument("--stage1b",required=True)
    ap.add_argument("--out",default="STAGE2D_OUTPUT")
    args=ap.parse_args()

    stage2c=Path(args.stage2c).expanduser().resolve()
    stage1c=Path(args.stage1c).expanduser().resolve()
    stage1b=Path(args.stage1b).expanduser().resolve()
    out=Path(args.out).expanduser().resolve()
    out.mkdir(parents=True,exist_ok=True)

    control_file=stage2c/"02_CONTROL_PA_SAMPLE_FROZEN.csv"
    anchor_cov_file=stage2c/"03_anchor_control_coverage.csv"
    freeze_file=stage2c/"STAGE2C_FREEZE.json"
    young_align_file=stage1c/"01_alignment_cluster_table_UNBLINDED.csv"
    young_contract_file=stage1c/"STAGE1C_UNBLIND_CONTRACT.json"
    young_frozen_file=stage1b/"02_PRIMARY_PA_SAMPLE_FROZEN.csv"

    for p in [control_file,anchor_cov_file,freeze_file,young_align_file,young_contract_file,young_frozen_file]:
        if not p.exists(): raise FileNotFoundError(p)

    control_hash=sha256(control_file)
    anchor_hash=sha256(anchor_cov_file)
    freeze_hash=sha256(freeze_file)
    young_frozen_hash=sha256(young_frozen_file)
    young_align_hash=sha256(young_align_file)
    young_contract_hash=sha256(young_contract_file)

    print("="*94)
    print(f"YHMC STAGE-2D CONTROL ALIGNMENT + MATCHED AGE CONTRAST v{VERSION}")
    print("="*94)
    print(f"CONTROL_PA_SAMPLE_SHA256={control_hash}")
    print(f"ANCHOR_COVERAGE_SHA256={anchor_hash}")
    print(f"STAGE2C_FREEZE_SHA256={freeze_hash}")
    print(f"YOUNG_FROZEN_SAMPLE_SHA256={young_frozen_hash}")

    if control_hash!=EXPECTED_CONTROL_SAMPLE_SHA256:
        raise RuntimeError(
            "CONTROL SAMPLE CHAIN-OF-CUSTODY FAIL\n"
            f"Expected {EXPECTED_CONTROL_SAMPLE_SHA256}\nActual   {control_hash}"
        )
    if anchor_hash!=EXPECTED_ANCHOR_COVERAGE_SHA256:
        raise RuntimeError(
            "ANCHOR COVERAGE CHAIN-OF-CUSTODY FAIL\n"
            f"Expected {EXPECTED_ANCHOR_COVERAGE_SHA256}\nActual   {anchor_hash}"
        )
    if freeze_hash!=EXPECTED_STAGE2C_FREEZE_SHA256:
        raise RuntimeError(
            "STAGE2C FREEZE CHAIN-OF-CUSTODY FAIL\n"
            f"Expected {EXPECTED_STAGE2C_FREEZE_SHA256}\nActual   {freeze_hash}"
        )
    if young_frozen_hash!=EXPECTED_YOUNG_FROZEN_SHA256:
        raise RuntimeError(
            "YOUNG FROZEN SAMPLE CHAIN-OF-CUSTODY FAIL\n"
            f"Expected {EXPECTED_YOUNG_FROZEN_SHA256}\nActual   {young_frozen_hash}"
        )

    cfreeze=json.loads(freeze_file.read_text(encoding="utf-8"))
    if not any("No control A computed" in x for x in cfreeze.get("alignment_blinding",[])):
        raise RuntimeError("Stage-2C freeze does not prove control-alignment blinding.")

    ycontract=json.loads(young_contract_file.read_text(encoding="utf-8"))
    if ycontract.get("input_primary_sha256")!=EXPECTED_YOUNG_FROZEN_SHA256:
        raise RuntimeError("Stage-1C contract is not bound to the expected young frozen sample.")
    if float(ycontract.get("pre_frozen_primary_mass_threshold_Msun",np.nan))!=PRIMARY_YOUNG_MASS:
        raise RuntimeError("Stage-1C primary mass threshold mismatch.")

    controls=pd.read_csv(control_file)
    young=pd.read_csv(young_align_file)
    young_frozen=pd.read_csv(young_frozen_file)

    # Verify young alignment table identity is exactly the frozen young sample.
    kf=young_frozen[["ID","Name"]].copy().sort_values(["ID","Name"]).reset_index(drop=True)
    ka=young[["ID","Name"]].copy().sort_values(["ID","Name"]).reset_index(drop=True)
    if not kf.equals(ka):
        raise RuntimeError("Stage-1C young alignment table does not have the exact Stage-1B frozen identities.")

    reqc={
        "ID","Name","MassJ","__RAdeg","__DEdeg","PA_deg_point",
        "young_ID","young_Name","anchor_normalized_weight",
        "CONTROL_PA_SAMPLE_ADMITTED"
    }
    miss=sorted(reqc-set(controls.columns))
    if miss: raise RuntimeError("Control frozen sample missing columns: "+", ".join(miss))
    if not controls["CONTROL_PA_SAMPLE_ADMITTED"].fillna(False).astype(bool).all():
        raise RuntimeError("Control frozen sample contains a non-admitted row.")

    reqy={"ID","Name","MassJ","Delta_theta_deg","cos2Delta"}
    miss=sorted(reqy-set(young.columns))
    if miss: raise RuntimeError("Young alignment table missing columns: "+", ".join(miss))

    print("CHAIN_OF_CUSTODY=PASS")
    print(f"FROZEN_CONTROLS_N={len(controls)}")
    print(f"FROZEN_YOUNG_N={len(young)}")
    print(f"PRIMARY_YOUNG_MASS_THRESHOLD={PRIMARY_YOUNG_MASS:.0f} Msun")

    # First authorized control unblinding.
    ras=pd.to_numeric(controls["__RAdeg"],errors="coerce").to_numpy(float)
    des=pd.to_numeric(controls["__DEdeg"],errors="coerce").to_numpy(float)
    gp=np.array([local_galactic_parallel_pa_east_of_x(r,d) for r,d in zip(ras,des)],float)
    if not np.isfinite(gp).all():
        raise RuntimeError("Non-finite control Galactic-plane PA.")

    controls=controls.copy()
    controls["PA_Galactic_parallel_deg"]=gp
    controls["Delta_theta_control_deg"]=np.abs(axial_signed_diff_deg(
        controls["PA_deg_point"].to_numpy(float),gp
    ))
    controls["cos2Delta_control"]=np.cos(
        np.deg2rad(2.0*controls["Delta_theta_control_deg"].to_numpy(float))
    )
    controls.to_csv(out/"01_control_alignment_UNBLINDED.csv",index=False)

    # Standalone older-control alignment.
    standalone=[]
    for j,m in enumerate(CONTROL_THRESHOLDS):
        standalone.append(standalone_control_inference(controls,m,300+j))
    stand=pd.DataFrame(standalone)
    stand["ROLE"]=stand["MassJ_threshold_Msun"].map({
        1000.0:"CONTROL_FULL",
        3000.0:"CONTROL_PRIMARY_MASS_ANALOGUE",
        5000.0:"CONTROL_NESTED_ROBUSTNESS",
        10000.0:"CONTROL_DESCRIPTIVE_IF_SMALL_N",
    })
    stand.to_csv(out/"02_control_alignment_by_mass.csv",index=False)

    # Build anchor-normalized table.
    # One row per young anchor with >=1 admitted control.
    control_anchor=(
        controls.groupby(["young_ID","young_Name"],as_index=False)
        .agg(
            N_admitted_controls=("ID","size"),
            cos2Delta_control_anchor_mean=("cos2Delta_control","mean"),
            Delta_control_anchor_mean_deg=("Delta_theta_control_deg","mean"),
            control_mass_mean=("MassJ","mean"),
        )
    )

    ysmall=young[["ID","Name","MassJ","Delta_theta_deg","cos2Delta"]].rename(columns={
        "ID":"young_ID","Name":"young_Name","MassJ":"MassJ_young",
        "Delta_theta_deg":"Delta_theta_young_deg","cos2Delta":"cos2Delta_young"
    })
    anchor=ysmall.merge(control_anchor,on=["young_ID","young_Name"],how="inner",validate="one_to_one")
    anchor["D_i_young_minus_control"]=anchor["cos2Delta_young"]-anchor["cos2Delta_control_anchor_mean"]
    anchor.to_csv(out/"03_anchor_normalized_young_control_table.csv",index=False)

    # Pre-frozen paired hierarchy.
    primary_anchor=anchor[pd.to_numeric(anchor["MassJ_young"],errors="coerce")>=PRIMARY_YOUNG_MASS].copy()
    extended_anchor=anchor.copy()

    pres=paired_inference(primary_anchor,"PRIMARY_MATCHED_AGE_CONTRAST",501)
    eres=paired_inference(extended_anchor,"EXTENDED_MATCHED_AGE_CONTRAST",502)
    paired=pd.DataFrame([pres,eres])
    paired.to_csv(out/"04_matched_age_contrast_inference.csv",index=False)

    # Secondary pair-preserving bootstrap by anchor is already represented by bootstrap D.
    # Leave-one-anchor-out sensitivity.
    loo=[]
    for label,s in [
        ("PRIMARY_MATCHED_AGE_CONTRAST",primary_anchor),
        ("EXTENDED_MATCHED_AGE_CONTRAST",extended_anchor),
    ]:
        if len(s)>=3:
            d=s["D_i_young_minus_control"].to_numpy(float)
            for k in range(len(s)):
                rr=s.iloc[k]
                loo.append({
                    "ROLE":label,
                    "left_out_young_ID":rr["young_ID"],
                    "left_out_young_Name":rr["young_Name"],
                    "D_leave_one_out":float(np.mean(np.delete(d,k))),
                })
    pd.DataFrame(loo).to_csv(out/"05_leave_one_anchor_out_D.csv",index=False)

    # Compare standalone A values descriptively at 1000 and 3000.
    young_summ=[]
    for m in [1000.0,3000.0]:
        s=young[pd.to_numeric(young["MassJ"],errors="coerce")>=m]
        young_summ.append({
            "MassJ_threshold_Msun":m,
            "N_young":len(s),
            "A_young":float(s["cos2Delta"].mean()) if len(s) else np.nan,
            "median_Delta_young_deg":float(s["Delta_theta_deg"].median()) if len(s) else np.nan,
        })
    ysum=pd.DataFrame(young_summ)
    comparison=ysum.merge(
        stand[["MassJ_threshold_Msun","N","A_control","median_Delta_theta_deg"]],
        on="MassJ_threshold_Msun",how="left"
    ).rename(columns={"N":"N_control","median_Delta_theta_deg":"median_Delta_control_deg"})
    comparison["A_young_minus_control_unpaired"]=comparison["A_young"]-comparison["A_control"]
    comparison.to_csv(out/"06_unpaired_young_control_descriptive.csv",index=False)

    contract={
        "stage":"STAGE2D_CONTROL_ALIGNMENT_MATCHED_CONTRAST",
        "version":VERSION,
        "control_pa_sample_sha256":control_hash,
        "anchor_coverage_sha256":anchor_hash,
        "stage2c_freeze_sha256":freeze_hash,
        "young_frozen_sample_sha256":young_frozen_hash,
        "young_alignment_table_sha256":young_align_hash,
        "young_stage1c_contract_sha256":young_contract_hash,
        "primary_age_contrast":{
            "anchor_eligibility":"young MassJ >= 3000 Msun and >=1 admitted matched control",
            "endpoint":"mean_i[cos2Delta_young_i - mean_j(cos2Delta_control_ij)]",
            "alternative":"D > 0",
            "test":"paired random sign-flip",
        },
        "extended_age_contrast":{
            "anchor_eligibility":"all young anchors with >=1 admitted matched control",
            "same_endpoint":True,
        },
        "standalone_control_thresholds_Msun":CONTROL_THRESHOLDS,
        "no_post_unblinding_sample_or_threshold_changes":True,
    }
    (out/"STAGE2D_UNBLIND_CONTRACT.json").write_text(json.dumps(contract,indent=2),encoding="utf-8")

    def fmt(x,nd=4):
        try:
            return f"{float(x):.{nd}f}" if np.isfinite(float(x)) else "NA"
        except Exception:
            return "NA"

    p=paired.iloc[0]
    e=paired.iloc[1]
    c1000=stand[stand["MassJ_threshold_Msun"]==1000].iloc[0]
    c3000=stand[stand["MassJ_threshold_Msun"]==3000].iloc[0]

    report=[
        f"YHMC STAGE-2D CONTROL ALIGNMENT + MATCHED AGE CONTRAST v{VERSION}",
        "="*94,
        "CHAIN_OF_CUSTODY=PASS",
        f"CONTROL_PA_SAMPLE_SHA256={control_hash}",
        f"STAGE2C_FREEZE_SHA256={freeze_hash}",
        f"YOUNG_FROZEN_SAMPLE_SHA256={young_frozen_hash}",
        f"Frozen controls N={len(controls)}",
        f"Young anchors with >=1 admitted control N={len(anchor)}",
        "",
        "PRIMARY MATCHED AGE-CONTRAST TEST",
        f"  Eligibility: young MassJ >= {PRIMARY_YOUNG_MASS:.0f} Msun and >=1 admitted matched control",
        f"  N anchors = {int(p['N_anchors'])}",
        f"  A_young = {fmt(p['A_young'])}",
        f"  A_control_anchor = {fmt(p['A_control_anchor'])}",
        f"  D = A_young - A_control_anchor = {fmt(p['D_young_minus_control'])}",
        f"  bootstrap 68% CI(D) = [{fmt(p['bootstrap_D_p16'])}, {fmt(p['bootstrap_D_p84'])}]",
        f"  bootstrap 95% CI(D) = [{fmt(p['bootstrap_D_p025'])}, {fmt(p['bootstrap_D_p975'])}]",
        f"  one-sided sign-flip p(D>0) = {fmt(p['signflip_p_D_gt_0_one_sided'],6)}",
        f"  two-sided sign-flip p = {fmt(p['signflip_p_two_sided'],6)}",
        f"  fraction anchors with D_i>0 = {fmt(p['fraction_D_i_gt0'],3)}",
        "",
        "EXTENDED MATCHED AGE-CONTRAST",
        f"  N anchors = {int(e['N_anchors'])}",
        f"  A_young = {fmt(e['A_young'])}",
        f"  A_control_anchor = {fmt(e['A_control_anchor'])}",
        f"  D = {fmt(e['D_young_minus_control'])}",
        f"  bootstrap 68% CI(D) = [{fmt(e['bootstrap_D_p16'])}, {fmt(e['bootstrap_D_p84'])}]",
        f"  one-sided sign-flip p(D>0) = {fmt(e['signflip_p_D_gt_0_one_sided'],6)}",
        f"  fraction anchors with D_i>0 = {fmt(e['fraction_D_i_gt0'],3)}",
        "",
        "STANDALONE OLDER-CONTROL ALIGNMENT",
        f"  MassJ>=1000: N={int(c1000['N'])}, A={fmt(c1000['A_control'])}, "
        f"p_parallel={fmt(c1000['null_p_parallel_one_sided'],6)}, "
        f"median Delta={fmt(c1000['median_Delta_theta_deg'],2)} deg",
        f"  MassJ>=3000: N={int(c3000['N'])}, A={fmt(c3000['A_control'])}, "
        f"p_parallel={fmt(c3000['null_p_parallel_one_sided'],6)}, "
        f"median Delta={fmt(c3000['median_Delta_theta_deg'],2)} deg",
        "",
        "ALL CONTROL MASS THRESHOLDS:",
        stand[[
            "MassJ_threshold_Msun","N","A_control","null_p_parallel_one_sided",
            "bootstrap_A_p16","bootstrap_A_p84","median_Delta_theta_deg",
            "fraction_Delta_le30","ROLE"
        ]].to_string(index=False),
        "",
        "INTERPRETATION RULE:",
        "  The pre-frozen matched primary D test governs the age-dependence claim.",
        "  Standalone older-control A is a systematics check, not a substitute endpoint.",
        "  Monte-Carlo p-values are bounded by their simulation resolution.",
        "",
        "NEXT_STAGE:",
        "  If primary D>0 is supported, independently calibrate r<r50J inner morphology",
        "  and then test radial dependence; regardless of outcome, run selection-function",
        "  and sky-geometry audits before manuscript-level causal interpretation.",
    ]
    (out/"STAGE2D_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    try:
        import matplotlib.pyplot as plt

        fig=plt.figure(figsize=(7.2,5.4))
        ax=fig.add_subplot(111)
        ax.scatter(anchor["cos2Delta_control_anchor_mean"],anchor["cos2Delta_young"],s=28)
        lo=min(anchor["cos2Delta_control_anchor_mean"].min(),anchor["cos2Delta_young"].min())
        hi=max(anchor["cos2Delta_control_anchor_mean"].max(),anchor["cos2Delta_young"].max())
        ax.plot([lo,hi],[lo,hi],linestyle="--")
        ax.set_xlabel(r"Matched older control $\overline{\cos(2\Delta\theta)}$")
        ax.set_ylabel(r"Young anchor $\cos(2\Delta\theta)$")
        ax.grid(alpha=0.25)
        fig.tight_layout()
        fig.savefig(out/"FIG01_matched_young_vs_control_cos2Delta.pdf",bbox_inches="tight")
        fig.savefig(out/"FIG01_matched_young_vs_control_cos2Delta.png",dpi=220,bbox_inches="tight")
        plt.close(fig)

        fig=plt.figure(figsize=(7.2,5.4))
        ax=fig.add_subplot(111)
        ax.hist(anchor["D_i_young_minus_control"],bins=15)
        ax.axvline(0,linestyle="--")
        ax.set_xlabel(r"$D_i=\cos2\Delta\theta_{\rm young}-\overline{\cos2\Delta\theta}_{\rm control}$")
        ax.set_ylabel("Number of anchors")
        fig.tight_layout()
        fig.savefig(out/"FIG02_anchor_D_distribution.pdf",bbox_inches="tight")
        fig.savefig(out/"FIG02_anchor_D_distribution.png",dpi=220,bbox_inches="tight")
        plt.close(fig)
    except Exception as e:
        (out/"FIGURE_WARNING.txt").write_text(str(e),encoding="utf-8")

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")

    print()
    print((out/"STAGE2D_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

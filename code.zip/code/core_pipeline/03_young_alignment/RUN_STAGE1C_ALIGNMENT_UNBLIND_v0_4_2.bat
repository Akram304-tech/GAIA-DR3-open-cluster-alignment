@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-1C ALIGNMENT UNBLIND v0.4.2
echo PANDAS UNDERSCORE-COLUMN PATCH
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" (
  echo ERROR: Miniconda Python not found.
  exit /b 1
)

set "STAGE1B=%USERPROFILE%\Downloads\YHMC_STAGE1B_REAL_MORPHOLOGY_FREEZE_v0_3_0\YHMC_STAGE1B_REAL_MORPHOLOGY_FREEZE_v0_3_0\STAGE1B_OUTPUT"
set "STAGE0=%USERPROFILE%\Downloads\YHMC_STAGE0_PREFLIGHT_v0_1_2\YHMC_STAGE0_PREFLIGHT_v0_1_2\STAGE0_OUTPUT"

if not exist "%STAGE1B%\02_PRIMARY_PA_SAMPLE_FROZEN.csv" (
  echo ERROR: Stage-1B primary sample not found.
  exit /b 1
)
if not exist "%STAGE0%\07_provisional_morphology_ready.csv" (
  echo ERROR: Stage-0 coordinate source not found.
  exit /b 1
)

echo PYEXE=%PYEXE%
"%PYEXE%" --version
echo STAGE1B=%STAGE1B%
echo STAGE0=%STAGE0%

"%PYEXE%" -c "import numpy,pandas,astropy,matplotlib" >nul 2>nul
if errorlevel 1 (
  "%PYEXE%" -m pip install numpy pandas astropy matplotlib
  if errorlevel 1 exit /b 1
)

"%PYEXE%" stage1c_alignment_unblind_v0_4_2.py --stage1b "%STAGE1B%" --stage0 "%STAGE0%" --out "%CD%\STAGE1C_OUTPUT"
set "RC=%ERRORLEVEL%"

echo.
echo RETURN_CODE=%RC%
if "%RC%"=="0" (
  echo REPORT=%CD%\STAGE1C_OUTPUT\STAGE1C_REPORT.txt
  echo TABLE=%CD%\STAGE1C_OUTPUT\01_alignment_cluster_table_UNBLINDED.csv
  echo CONTRACT=%CD%\STAGE1C_OUTPUT\STAGE1C_UNBLIND_CONTRACT.json
)
exit /b %RC%

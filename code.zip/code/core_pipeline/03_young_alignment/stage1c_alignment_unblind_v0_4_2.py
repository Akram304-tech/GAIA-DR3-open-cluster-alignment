#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-1C Galactic-plane alignment unblinding v0.4.2

Patch from v0.4.1
-----------------
Fixes pandas.itertuples() name mangling for columns beginning with underscores
(__RAdeg/__DEdeg). The frozen Stage-1B sample and Stage-0 coordinate join
remain unchanged and are re-verified before unblinding.
"""

from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "0.4.2"
SEED = 20260912

EXPECTED_PRIMARY_SHA256 = "cc1d3ae4ce1cf52387f535da92fbd0dc5d984a3bb2dc750bf6672682e85f65dd"
EXPECTED_FREEZE_SHA256 = "05f2e12d898bcdaf47b510a3c1d9873b136de852a2acecb71d21d4cc1b24c058"

PRIMARY_MASS = 3000.0
EXTENDED_MASS = 1000.0
MASS_THRESHOLDS = [1000.0, 3000.0, 5000.0, 10000.0]

N_NULL = 300000
N_BOOT = 100000
N_MEAS = 100000

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()

def axial_signed_diff_deg(a, b):
    return ((np.asarray(a, dtype=float) - np.asarray(b, dtype=float) + 90.0) % 180.0) - 90.0

def percentile(a, p):
    a = np.asarray(a, dtype=float)
    a = a[np.isfinite(a)]
    return float(np.percentile(a, p)) if len(a) else np.nan

def local_galactic_parallel_pa_east_of_x(ra_deg, dec_deg, eps_deg=1e-3):
    from astropy.coordinates import SkyCoord
    import astropy.units as u

    c = SkyCoord(ra=float(ra_deg)*u.deg, dec=float(dec_deg)*u.deg, frame="icrs")
    g = c.galactic
    gp = SkyCoord(l=(g.l + eps_deg*u.deg), b=g.b, frame="galactic").icrs
    gm = SkyCoord(l=(g.l - eps_deg*u.deg), b=g.b, frame="galactic").icrs

    def xy(obj):
        dra = ((obj.ra.deg - c.ra.deg + 180.0) % 360.0) - 180.0
        x = dra * math.cos(math.radians(c.dec.deg))
        y = obj.dec.deg - c.dec.deg
        return x, y

    xp, yp = xy(gp)
    xm, ym = xy(gm)
    dx = xp - xm
    dy = yp - ym
    if not np.isfinite(dx) or not np.isfinite(dy) or (dx == 0 and dy == 0):
        return np.nan
    return float(np.degrees(np.arctan2(dy, dx)) % 180.0)

def chunked_null_A(n, nsim, rng, chunk=20000):
    vals = []
    remaining = nsim
    while remaining > 0:
        k = min(chunk, remaining)
        d = rng.uniform(0.0, 90.0, size=(k, n))
        vals.append(np.mean(np.cos(np.deg2rad(2.0*d)), axis=1))
        remaining -= k
    return np.concatenate(vals)

def chunked_boot_A(cos2, nsim, rng, chunk=20000):
    cos2 = np.asarray(cos2, dtype=float)
    n = len(cos2)
    vals = []
    remaining = nsim
    while remaining > 0:
        k = min(chunk, remaining)
        idx = rng.integers(0, n, size=(k, n))
        vals.append(np.mean(cos2[idx], axis=1))
        remaining -= k
    return np.concatenate(vals)

def chunked_measurement_A(pa, pa_gp, sigma_deg, nsim, rng, chunk=10000):
    pa = np.asarray(pa, dtype=float)
    pa_gp = np.asarray(pa_gp, dtype=float)
    sigma = np.asarray(sigma_deg, dtype=float)
    n = len(pa)
    vals = []
    remaining = nsim
    while remaining > 0:
        k = min(chunk, remaining)
        err = rng.normal(0.0, sigma[None, :], size=(k, n))
        pa_s = (pa[None, :] + err) % 180.0
        d = np.abs(axial_signed_diff_deg(pa_s, pa_gp[None, :]))
        vals.append(np.mean(np.cos(np.deg2rad(2.0*d)), axis=1))
        remaining -= k
    return np.concatenate(vals)

def subset_inference(df, threshold, seed_tag):
    s = df[pd.to_numeric(df["MassJ"], errors="coerce") >= threshold].copy()
    n = len(s)
    if n == 0:
        return {"MassJ_threshold_Msun": threshold, "N": 0, "A_obs": np.nan}

    delta = s["Delta_theta_deg"].to_numpy(float)
    cos2 = np.cos(np.deg2rad(2.0*delta))
    Aobs = float(np.mean(cos2))
    median_delta = float(np.median(delta))
    f15 = float(np.mean(delta <= 15.0))
    f30 = float(np.mean(delta <= 30.0))
    f45 = float(np.mean(delta <= 45.0))

    seedseq = np.random.SeedSequence([SEED, int(threshold), seed_tag])
    r_null, r_boot, r_meas = [np.random.default_rng(ss) for ss in seedseq.spawn(3)]

    if n >= 2:
        nullA = chunked_null_A(n, N_NULL, r_null)
        p_parallel = float((1 + np.count_nonzero(nullA >= Aobs)) / (N_NULL + 1))
        p_twosided = float((1 + np.count_nonzero(np.abs(nullA) >= abs(Aobs))) / (N_NULL + 1))

        bootA = chunked_boot_A(cos2, N_BOOT, r_boot)
        boot16, boot50, boot84 = [percentile(bootA, p) for p in (16,50,84)]
        boot025, boot975 = [percentile(bootA, p) for p in (2.5,97.5)]

        sigma = pd.to_numeric(s["PA_boot_abs_p68_deg"], errors="coerce").to_numpy(float)
        pa = s["PA_deg_point"].to_numpy(float)
        pa_gp = s["PA_Galactic_parallel_deg"].to_numpy(float)
        measA = chunked_measurement_A(pa, pa_gp, sigma, N_MEAS, r_meas)
        meas16, meas50, meas84 = [percentile(measA, p) for p in (16,50,84)]
        prob_A_positive_meas = float(np.mean(measA > 0.0))
    else:
        p_parallel = p_twosided = np.nan
        boot16 = boot50 = boot84 = boot025 = boot975 = np.nan
        meas16 = meas50 = meas84 = prob_A_positive_meas = np.nan

    return {
        "MassJ_threshold_Msun": threshold,
        "N": n,
        "A_obs": Aobs,
        "bootstrap_A_p025": boot025,
        "bootstrap_A_p16": boot16,
        "bootstrap_A_median": boot50,
        "bootstrap_A_p84": boot84,
        "bootstrap_A_p975": boot975,
        "null_p_parallel_one_sided": p_parallel,
        "null_p_two_sided": p_twosided,
        "measurementMC_A_p16": meas16,
        "measurementMC_A_median": meas50,
        "measurementMC_A_p84": meas84,
        "measurementMC_P_A_gt_0": prob_A_positive_meas,
        "median_Delta_theta_deg": median_delta,
        "fraction_Delta_le15": f15,
        "fraction_Delta_le30": f30,
        "fraction_Delta_le45": f45,
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage1b", required=True)
    ap.add_argument("--stage0", required=True)
    ap.add_argument("--out", default="STAGE1C_OUTPUT")
    args = ap.parse_args()

    stage1b = Path(args.stage1b).expanduser().resolve()
    stage0 = Path(args.stage0).expanduser().resolve()
    out = Path(args.out).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)

    primary_file = stage1b / "02_PRIMARY_PA_SAMPLE_FROZEN.csv"
    freeze_file = stage1b / "STAGE1B_FREEZE.json"
    coord_file = stage0 / "07_provisional_morphology_ready.csv"

    for p in [primary_file, freeze_file, coord_file]:
        if not p.exists():
            raise FileNotFoundError(p)

    actual_primary_hash = sha256(primary_file)
    actual_freeze_hash = sha256(freeze_file)
    coord_hash = sha256(coord_file)

    print("="*90)
    print(f"YHMC STAGE-1C GALACTIC-PLANE ALIGNMENT UNBLIND v{VERSION}")
    print("="*90)
    print(f"PRIMARY_FILE_SHA256={actual_primary_hash}")
    print(f"FREEZE_JSON_SHA256={actual_freeze_hash}")
    print(f"STAGE0_COORD_SOURCE_SHA256={coord_hash}")

    if actual_primary_hash != EXPECTED_PRIMARY_SHA256:
        raise RuntimeError(
            "CHAIN-OF-CUSTODY FAIL: primary sample hash differs.\n"
            f"Expected {EXPECTED_PRIMARY_SHA256}\nActual   {actual_primary_hash}"
        )
    if actual_freeze_hash != EXPECTED_FREEZE_SHA256:
        raise RuntimeError(
            "CHAIN-OF-CUSTODY FAIL: Stage-1B freeze JSON hash differs.\n"
            f"Expected {EXPECTED_FREEZE_SHA256}\nActual   {actual_freeze_hash}"
        )
    print("STAGE1B_CHAIN_OF_CUSTODY=PASS")

    frozen = pd.read_csv(primary_file)
    coords = pd.read_csv(coord_file)

    frozen_required = {
        "ID","Name","MassJ","logAge50","q_point","PA_deg_point",
        "PA_boot_abs_p68_deg","PRIMARY_PA_SAMPLE_ADMITTED"
    }
    missing = sorted(frozen_required - set(frozen.columns))
    if missing:
        raise RuntimeError("Frozen sample missing required morphology columns: " + ", ".join(missing))

    coord_required = {"ID","Name","__RAdeg","__DEdeg"}
    missing_c = sorted(coord_required - set(coords.columns))
    if missing_c:
        raise RuntimeError("Stage-0 coordinate source missing columns: " + ", ".join(missing_c))

    if frozen.duplicated(["ID","Name"]).any():
        raise RuntimeError("Frozen sample has duplicate ID+Name keys.")
    if coords.duplicated(["ID","Name"]).any():
        raise RuntimeError("Stage-0 coordinate source has duplicate ID+Name keys.")

    coord_small = coords[["ID","Name","__RAdeg","__DEdeg"]].copy()
    merged = frozen.merge(coord_small, on=["ID","Name"], how="left", validate="one_to_one", indicator=True)

    if len(merged) != len(frozen):
        raise RuntimeError(f"Coordinate join changed row count: {len(frozen)} -> {len(merged)}")
    if not (merged["_merge"] == "both").all():
        bad = merged.loc[merged["_merge"] != "both", ["ID","Name","_merge"]]
        raise RuntimeError("Coordinate join failed for rows:\n" + bad.to_string(index=False))
    merged = merged.drop(columns=["_merge"])

    if merged[["__RAdeg","__DEdeg"]].isna().any().any():
        raise RuntimeError("Coordinate join produced missing RA/Dec.")

    if not merged["PRIMARY_PA_SAMPLE_ADMITTED"].fillna(False).astype(bool).all():
        raise RuntimeError("Frozen sample contains a non-admitted row.")

    print(f"COORDINATE_JOIN=PASS ({len(merged)}/{len(frozen)} exact ID+Name matches)")
    print(f"FROZEN_SAMPLE_N={len(merged)}")
    print(f"PRIMARY_MASS_THRESHOLD={PRIMARY_MASS:.0f} Msun")
    print("PRIMARY_HYPOTHESIS=parallel alignment, A>0")

    # v0.4.2 patch: use direct column arrays, avoiding itertuples name mangling.
    ras = pd.to_numeric(merged["__RAdeg"], errors="coerce").to_numpy(float)
    des = pd.to_numeric(merged["__DEdeg"], errors="coerce").to_numpy(float)
    gp_pa = np.array(
        [local_galactic_parallel_pa_east_of_x(ra, de) for ra, de in zip(ras, des)],
        dtype=float
    )
    merged["PA_Galactic_parallel_deg"] = gp_pa

    if not np.isfinite(gp_pa).all():
        raise RuntimeError("Non-finite local Galactic-plane PA encountered.")

    delta = np.abs(axial_signed_diff_deg(
        merged["PA_deg_point"].to_numpy(float),
        merged["PA_Galactic_parallel_deg"].to_numpy(float)
    ))
    merged["Delta_theta_deg"] = delta
    merged["cos2Delta"] = np.cos(np.deg2rad(2.0*delta))
    merged.to_csv(out/"01_alignment_cluster_table_UNBLINDED.csv", index=False)

    rows = []
    for j, threshold in enumerate(MASS_THRESHOLDS):
        rows.append(subset_inference(merged, threshold, 100+j))
    summ = pd.DataFrame(rows)
    summ["ROLE"] = summ["MassJ_threshold_Msun"].map({
        1000.0: "EXTENDED_CONFIRMATION",
        3000.0: "PRIMARY",
        5000.0: "NESTED_ROBUSTNESS",
        10000.0: "DESCRIPTIVE_IF_SMALL_N",
    })
    summ.to_csv(out/"02_alignment_inference_by_mass.csv", index=False)

    primary = summ[summ["MassJ_threshold_Msun"] == PRIMARY_MASS].iloc[0]
    extended = summ[summ["MassJ_threshold_Msun"] == EXTENDED_MASS].iloc[0]

    loo_rows = []
    for threshold, role in [(PRIMARY_MASS,"PRIMARY"),(EXTENDED_MASS,"EXTENDED_CONFIRMATION")]:
        s = merged[pd.to_numeric(merged["MassJ"],errors="coerce")>=threshold].copy()
        if len(s) >= 3:
            allcos = s["cos2Delta"].to_numpy(float)
            for k in range(len(s)):
                rr = s.iloc[k]
                loo_rows.append({
                    "ROLE": role,
                    "MassJ_threshold_Msun": threshold,
                    "left_out_ID": rr["ID"],
                    "left_out_Name": rr["Name"],
                    "A_leave_one_out": float(np.mean(np.delete(allcos,k))),
                })
    pd.DataFrame(loo_rows).to_csv(out/"03_leave_one_out_A.csv", index=False)

    contract = {
        "stage":"STAGE1C_GALACTIC_PLANE_ALIGNMENT_UNBLIND",
        "version":VERSION,
        "input_primary_sha256":actual_primary_hash,
        "input_freeze_sha256":actual_freeze_hash,
        "stage0_coordinate_source_sha256":coord_hash,
        "coordinate_join_contract":"strict one-to-one ID+Name; frozen Stage-1B rows unchanged",
        "pre_frozen_primary_mass_threshold_Msun":PRIMARY_MASS,
        "extended_confirmation_mass_threshold_Msun":EXTENDED_MASS,
        "primary_endpoint":"A = mean(cos(2*Delta_theta))",
        "primary_alternative":"A > 0, preferentially parallel",
        "null":"random axial orientation => Delta_theta Uniform(0,90 deg), A=0",
        "local_plane_definition":"tangent to increasing Galactic longitude at fixed Galactic latitude",
        "PA_convention":"Stage-1B east-x/north-y tangent basis, modulo 180",
        "null_monte_carlo_draws":N_NULL,
        "cluster_bootstrap_draws":N_BOOT,
        "measurement_sensitivity_draws":N_MEAS,
        "no_post_unblinding_sample_changes_allowed":True,
    }
    (out/"STAGE1C_UNBLIND_CONTRACT.json").write_text(json.dumps(contract,indent=2),encoding="utf-8")

    def fmt(x, nd=4):
        try:
            return f"{float(x):.{nd}f}" if np.isfinite(float(x)) else "NA"
        except Exception:
            return "NA"

    report = [
        f"YHMC STAGE-1C GALACTIC-PLANE ALIGNMENT UNBLIND v{VERSION}",
        "="*90,
        "STAGE1B_CHAIN_OF_CUSTODY=PASS",
        f"INPUT_PRIMARY_SHA256={actual_primary_hash}",
        f"INPUT_FREEZE_SHA256={actual_freeze_hash}",
        f"STAGE0_COORD_SOURCE_SHA256={coord_hash}",
        f"COORDINATE_JOIN=PASS ({len(merged)}/{len(frozen)} exact ID+Name matches)",
        f"Frozen PA-resolved sample N={len(merged)}",
        "",
        "PRE-FROZEN PRIMARY TEST",
        f"  MassJ >= {PRIMARY_MASS:.0f} Msun",
        f"  N = {int(primary['N'])}",
        f"  A_obs = {fmt(primary['A_obs'])}",
        f"  cluster-bootstrap 68% CI = [{fmt(primary['bootstrap_A_p16'])}, {fmt(primary['bootstrap_A_p84'])}]",
        f"  cluster-bootstrap 95% CI = [{fmt(primary['bootstrap_A_p025'])}, {fmt(primary['bootstrap_A_p975'])}]",
        f"  one-sided random-orientation p(A_null >= A_obs) = {fmt(primary['null_p_parallel_one_sided'],6)}",
        f"  two-sided random-orientation p = {fmt(primary['null_p_two_sided'],6)}",
        f"  measurement-MC A median = {fmt(primary['measurementMC_A_median'])}",
        f"  measurement-MC 68% interval = [{fmt(primary['measurementMC_A_p16'])}, {fmt(primary['measurementMC_A_p84'])}]",
        f"  median Delta_theta = {fmt(primary['median_Delta_theta_deg'],2)} deg",
        f"  fraction Delta<=30 deg = {fmt(primary['fraction_Delta_le30'],3)}",
        "",
        "EXTENDED CONFIRMATION",
        f"  MassJ >= {EXTENDED_MASS:.0f} Msun",
        f"  N = {int(extended['N'])}",
        f"  A_obs = {fmt(extended['A_obs'])}",
        f"  cluster-bootstrap 68% CI = [{fmt(extended['bootstrap_A_p16'])}, {fmt(extended['bootstrap_A_p84'])}]",
        f"  one-sided random-orientation p = {fmt(extended['null_p_parallel_one_sided'],6)}",
        f"  median Delta_theta = {fmt(extended['median_Delta_theta_deg'],2)} deg",
        f"  fraction Delta<=30 deg = {fmt(extended['fraction_Delta_le30'],3)}",
        "",
        "ALL PRE-FROZEN MASS THRESHOLDS",
        summ[[
            "MassJ_threshold_Msun","N","A_obs",
            "null_p_parallel_one_sided","bootstrap_A_p16","bootstrap_A_p84",
            "median_Delta_theta_deg","fraction_Delta_le30","ROLE"
        ]].to_string(index=False),
        "",
        "INTERPRETATION RULE:",
        "  Primary claim is determined by the pre-frozen MassJ>=3000 Msun test.",
        "  MassJ>=1000 is extended confirmation and cannot replace the primary.",
        "  No post-unblinding threshold/sample changes are allowed.",
        "",
        "NEXT_STAGE:",
        "  Build independently frozen older matched controls and separately calibrate",
        "  r<r50J morphology before age/radial physical interpretation.",
    ]
    (out/"STAGE1C_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    try:
        import matplotlib.pyplot as plt
        for threshold, tag in [(PRIMARY_MASS,"PRIMARY_M3000"),(EXTENDED_MASS,"EXTENDED_M1000")]:
            s=merged[pd.to_numeric(merged["MassJ"],errors="coerce")>=threshold]
            fig=plt.figure(figsize=(7.2,5.4))
            ax=fig.add_subplot(111)
            ax.hist(s["Delta_theta_deg"],bins=np.linspace(0,90,10),density=True)
            ax.axhline(1/90.0,linestyle="--")
            ax.set_xlabel(r"$\Delta\theta$ [deg]")
            ax.set_ylabel("Probability density")
            ax.set_xlim(0,90)
            fig.tight_layout()
            fig.savefig(out/f"FIG01_{tag}_Delta_distribution.pdf",bbox_inches="tight")
            fig.savefig(out/f"FIG01_{tag}_Delta_distribution.png",dpi=220,bbox_inches="tight")
            plt.close(fig)

        fig=plt.figure(figsize=(7.2,5.4))
        ax=fig.add_subplot(111)
        ax.scatter(merged["MassJ"],merged["cos2Delta"],s=26)
        ax.axhline(0,linestyle="--")
        ax.set_xscale("log")
        ax.set_xlabel(r"$M_J\ [M_\odot]$")
        ax.set_ylabel(r"$\cos(2\Delta\theta)$")
        ax.set_ylim(-1.05,1.05)
        ax.grid(alpha=0.25)
        fig.tight_layout()
        fig.savefig(out/"FIG02_cos2Delta_vs_MassJ.pdf",bbox_inches="tight")
        fig.savefig(out/"FIG02_cos2Delta_vs_MassJ.png",dpi=220,bbox_inches="tight")
        plt.close(fig)
    except Exception as e:
        (out/"FIGURE_WARNING.txt").write_text(str(e),encoding="utf-8")

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")

    print()
    print((out/"STAGE1C_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

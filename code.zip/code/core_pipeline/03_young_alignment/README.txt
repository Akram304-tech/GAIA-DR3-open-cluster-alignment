YHMC STAGE-1C GALACTIC-PLANE ALIGNMENT UNBLIND v0.4.2
=================================================================

v0.4.2 fixes only one implementation issue from v0.4.1:
pandas.itertuples() renames columns beginning with underscores, so __RAdeg
and __DEdeg could not be accessed as tuple attributes.

The patch reads those columns directly from the DataFrame arrays.

The frozen Stage-1B sample remains byte-for-byte unchanged and is checked
against the same SHA256 before any unblinding.

Run:
  call RUN_STAGE1C_ALIGNMENT_UNBLIND_v0_4_2.bat

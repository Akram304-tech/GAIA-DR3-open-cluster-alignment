@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-6B3C MECHANISM TERMINAL CLOSURE v2.4.2
echo NO NEW INFERENCE
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"

set "STAGE6B3B=%USERPROFILE%\Downloads\YHMC_STAGE6B3B_MECHANISM_ASSOCIATION_UNBLIND_v2_4_1\YHMC_STAGE6B3B_MECHANISM_ASSOCIATION_UNBLIND_v2_4_1\STAGE6B3B_OUTPUT"

"%PYEXE%" stage6b3c_mechanism_terminal_closure_v2_4_2.py ^
 --stage6b3b "%STAGE6B3B%" ^
 --out "%CD%\STAGE6B3C_OUTPUT"

set "RC=%ERRORLEVEL%"
echo.
echo RETURN_CODE=%RC%
if exist "%CD%\STAGE6B3C_OUTPUT\STAGE6B3C_REPORT.txt" echo REPORT=%CD%\STAGE6B3C_OUTPUT\STAGE6B3C_REPORT.txt
if exist "%CD%\STAGE6B3C_OUTPUT\STAGE6B3C_TERMINAL_CLOSURE.json" echo CLOSURE=%CD%\STAGE6B3C_OUTPUT\STAGE6B3C_TERMINAL_CLOSURE.json
exit /b %RC%

YHMC Stage-6B3C Mechanism Terminal Closure v2.4.2

This stage adds no inference. It locks the already-unblinded primary orbital
mechanism result and prevents post-hoc replacement of the null primary endpoint.

It also writes manuscript-safe wording and a claim-discipline note.

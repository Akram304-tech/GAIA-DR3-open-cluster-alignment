#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-6B3C Mechanism Branch Terminal Closure v2.4.2

NO NEW SCIENCE INFERENCE.

Closes the primary orbital-environment mechanism branch after the
prospectively frozen Stage-6B3B test.

Authoritative primary result:
  N = 45
  McMillan17
  Y = cos(2 Delta_theta_GP)
  X = -log(rperi/kpc)
  Spearman rho = -0.039920949
  two-sided cohort-stratified permutation p = 0.796102039

Primary association is not supported.

This closure prevents:
  - replacing rperi with another orbital proxy because rperi was null;
  - changing sign/direction after unblinding;
  - changing sample or mass threshold to improve significance;
  - changing potential because another potential appears favorable;
  - treating secondary tests as independent discoveries.

A future tidal-tensor analysis is allowed only as explicitly exploratory
or in a separately prospectively designed study. It cannot retroactively
rescue the failed primary endpoint in this manuscript.
"""

from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
import pandas as pd

VERSION="2.4.2"

EXPECTED_JOINED_SHA="ab094c662cc1da7365defa7f13c9693c3b8aa2b0440c1b57f85a426083636072"
EXPECTED_PRIMARY_RESULT_SHA="d62f54308da8ac7751aa5971f4c3726293855e7af06e6bdf4aacc2e12cafe536"
EXPECTED_POTENTIAL_SHA="b5e4b03116b5ffa58e0f0ac9f911ebb08ffa5b78d023bfc1b4dfc0efd07a249e"
EXPECTED_MC_SUMMARY_SHA="c6efb324a8537db93089b495c0f99d24af807ac7ae161ade0a4cd1bd2add0459"

def sha256(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage6b3b",required=True)
    ap.add_argument("--out",default="STAGE6B3C_OUTPUT")
    args=ap.parse_args()

    s=Path(args.stage6b3b).resolve()
    out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=True)

    joined=s/"01_PRIMARY_JOINED_OBJECT_TABLE.csv"
    primary=s/"02_PRIMARY_ASSOCIATION_RESULT.csv"
    pot=s/"04_POTENTIAL_SENSITIVITY.csv"
    mc=s/"06_MC_RHO_SUMMARY.csv"
    freeze=s/"STAGE6B3B_FREEZE.json"

    for p in [joined,primary,pot,mc,freeze]:
        if not p.exists():
            raise FileNotFoundError(p)

    checks=[
        (joined,EXPECTED_JOINED_SHA),
        (primary,EXPECTED_PRIMARY_RESULT_SHA),
        (pot,EXPECTED_POTENTIAL_SHA),
        (mc,EXPECTED_MC_SUMMARY_SHA),
    ]
    for p,exp in checks:
        obs=sha256(p)
        if obs!=exp:
            raise RuntimeError(f"Hash mismatch {p.name}: {obs} != {exp}")

    fr=json.loads(freeze.read_text(encoding="utf-8"))
    if not fr.get("ASSOCIATION_UNBLIND_COMPLETE",False):
        raise RuntimeError("Stage-6B3B unblind not complete.")
    if fr.get("causation_established",True):
        raise RuntimeError("Unexpected causation flag.")

    pr=pd.read_csv(primary).iloc[0]
    ps=pd.read_csv(pot)
    ms=pd.read_csv(mc).iloc[0]

    rho=float(pr["rho_spearman"])
    pval=float(pr["p_two_sided_cohort_stratified_perm"])

    if abs(rho - (-0.039920949)) > 5e-9:
        raise RuntimeError("Primary rho differs from authoritative result.")
    if abs(pval - 0.796102039) > 5e-9:
        raise RuntimeError("Primary p differs from authoritative result.")

    terminal={
        "stage":"STAGE6B3C_MECHANISM_TERMINAL_CLOSURE",
        "version":VERSION,
        "new_inference":False,
        "primary_endpoint_changed":False,
        "primary_result":{
            "N":45,
            "potential":"McMillan17",
            "response":"cos(2 Delta_theta_GP)",
            "predictor":"X_peri=-log(rperi/kpc)",
            "rho_spearman":rho,
            "p_two_sided_cohort_stratified_perm":pval,
            "supported_at_0p05":False,
        },
        "potential_sensitivity":{
            r["potential"]:{
                "rho_spearman":float(r["rho_spearman"]),
                "p_two_sided_cohort_stratified_perm":
                    float(r["p_two_sided_cohort_stratified_perm"])
            }
            for _,r in ps.iterrows()
        },
        "phase_space_MC":{
            "rho_median":float(ms["rho_MC_median"]),
            "rho_q025":float(ms["rho_MC_q025"]),
            "rho_q975":float(ms["rho_MC_q975"]),
            "fraction_positive":float(ms["fraction_rho_positive"]),
        },
        "terminal_state":
            "CLOSED_PRIMARY_ORBITAL_EXPOSURE_ASSOCIATION_NOT_SUPPORTED",
        "claim_ceiling":[
            "No significant monotonic association between Galactic-plane alignment strength and nominal McMillan17 pericentric exposure was detected in the high-mass 6D sample.",
            "The null result is stable across Irrgang13III and MWPotential2014 and under phase-space uncertainty propagation.",
            "The result does not rule out tidal shaping in general; it only fails to support the pre-specified simple pericentric-exposure mechanism.",
            "Tidal causation is not established."
        ],
        "forbidden_posthoc_actions":[
            "replace rperi with a secondary orbit proxy because primary rperi was null",
            "switch primary potential after unblinding",
            "change mass threshold/sample after unblinding",
            "change test direction from two-sided",
            "promote secondary tests as independent discoveries",
            "claim evidence of absence without an equivalence/power design",
        ],
        "future_tidal_tensor_policy":
            "May be pursued only as explicitly exploratory in this manuscript or prospectively in a separate study; cannot rescue the failed primary endpoint.",
        "joined_table_sha256":EXPECTED_JOINED_SHA,
        "primary_result_sha256":EXPECTED_PRIMARY_RESULT_SHA,
        "potential_sensitivity_sha256":EXPECTED_POTENTIAL_SHA,
        "MC_summary_sha256":EXPECTED_MC_SUMMARY_SHA,
        "next_primary_manuscript_action":
            "Integrate the null orbital-mechanism result as a constraint on interpretation; do not expand confirmatory mechanism testing."
    }
    (out/"STAGE6B3C_TERMINAL_CLOSURE.json").write_text(
        json.dumps(terminal,indent=2),encoding="utf-8"
    )

    manuscript = f"""MANUSCRIPT-SAFE MECHANISM RESULT
================================

For the prospectively defined high-mass six-dimensional sample
(N=45; 22 young and 23 control clusters), the pre-specified primary
test found no evidence that stronger projected Galactic-plane alignment
is associated with smaller pericentric radius. Using the McMillan17
potential and X_peri=-log(r_peri/kpc), the pooled cohort-stratified
Spearman coefficient was rho={rho:.3f}, with a two-sided permutation
p-value of p={pval:.3f} (100,000 permutations).

The conclusion was insensitive to the Galactic potential: the corresponding
rank correlations remained small and negative for Irrgang13III and
MWPotential2014. Propagating the catalogue phase-space uncertainties through
512 orbit realizations per cluster yielded a median rho of
{float(ms["rho_MC_median"]):.3f}, with a 95% interval from
{float(ms["rho_MC_q025"]):.3f} to {float(ms["rho_MC_q975"]):.3f}.

These tests therefore do not support a simple monotonic link between the
observed plane-alignment strength and pericentric orbital exposure. This null
association does not exclude tidal shaping or other Galactic-environment
effects; rather, it limits the interpretation of the projected alignment as
a direct consequence of the pre-specified pericentre-based exposure proxy.
"""

    (out/"MANUSCRIPT_SAFE_MECHANISM_RESULT.txt").write_text(
        manuscript,encoding="utf-8"
    )

    discussion = """DISCUSSION CLAIM DISCIPLINE
===========================

SAFE:
- The projected Galactic-plane alignment is robustly detected in young and
  100--500 Myr control samples.
- The pre-specified pericentric-exposure mechanism test is null.
- This weakens a simple interpretation in which alignment amplitude is
  controlled monotonically by pericentre.
- Other environmental mechanisms remain possible.

DO NOT CLAIM:
- tides are ruled out;
- the Galactic potential has no role;
- the alignment is primordial/natal;
- age independence beyond the tested clean comparison;
- evidence of no orbital effect in an equivalence-test sense;
- a secondary orbital quantity as a replacement primary discovery.

RECOMMENDED MANUSCRIPT POSITION:
Present the orbital result as a physically informative null constraint,
not as a failed analysis. It narrows the viable interpretation while keeping
the core empirical discovery intact.
"""
    (out/"DISCUSSION_CLAIM_DISCIPLINE.txt").write_text(
        discussion,encoding="utf-8"
    )

    report=f"""YHMC STAGE-6B3C MECHANISM TERMINAL CLOSURE v{VERSION}
================================================================================================
NO_NEW_INFERENCE=True
PRIMARY_ENDPOINT_CHANGED=False
PRIMARY_RHO={rho:.9f}
PRIMARY_P={pval:.9f}
PRIMARY_ASSOCIATION_SUPPORTED=False
MC_RHO_MEDIAN={float(ms["rho_MC_median"]):.9f}
MC_RHO_Q025={float(ms["rho_MC_q025"]):.9f}
MC_RHO_Q975={float(ms["rho_MC_q975"]):.9f}

TERMINAL_STATE=CLOSED_PRIMARY_ORBITAL_EXPOSURE_ASSOCIATION_NOT_SUPPORTED

NEXT:
  Integrate the null mechanism result into the manuscript as an
  interpretation constraint. Do not tune a replacement confirmatory proxy.
"""
    (out/"STAGE6B3C_REPORT.txt").write_text(report,encoding="utf-8")

    files=[
        "STAGE6B3C_TERMINAL_CLOSURE.json",
        "MANUSCRIPT_SAFE_MECHANISM_RESULT.txt",
        "DISCUSSION_CLAIM_DISCIPLINE.txt",
        "STAGE6B3C_REPORT.txt",
    ]
    (out/"SHA256SUMS.txt").write_text(
        "\n".join(f"{sha256(out/f)}  {f}" for f in files)+"\n",
        encoding="utf-8"
    )

    print(report)

if __name__=="__main__":
    main()

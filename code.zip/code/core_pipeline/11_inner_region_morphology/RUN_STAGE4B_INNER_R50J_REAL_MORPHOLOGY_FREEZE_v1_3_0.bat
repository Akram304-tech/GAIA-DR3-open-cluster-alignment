@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-4B INNER r50J REAL MORPHOLOGY FREEZE v1.3.0
echo NO INNER GALACTIC-PLANE ALIGNMENT
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" (
  echo ERROR: Miniconda Python not found.
  exit /b 1
)

set "STAGE0=%USERPROFILE%\Downloads\YHMC_STAGE0_PREFLIGHT_v0_1_2\YHMC_STAGE0_PREFLIGHT_v0_1_2\STAGE0_OUTPUT"
set "STAGE1B=%USERPROFILE%\Downloads\YHMC_STAGE1B_REAL_MORPHOLOGY_FREEZE_v0_3_0\YHMC_STAGE1B_REAL_MORPHOLOGY_FREEZE_v0_3_0\STAGE1B_OUTPUT"
set "STAGE2A=%USERPROFILE%\Downloads\YHMC_STAGE2A_MATCHED_OLDER_CONTROL_FREEZE_v0_5_0\YHMC_STAGE2A_MATCHED_OLDER_CONTROL_FREEZE_v0_5_0\STAGE2A_OUTPUT"
set "STAGE2C=%USERPROFILE%\Downloads\YHMC_STAGE2C_CONTROL_REAL_MORPHOLOGY_FREEZE_v0_7_0\YHMC_STAGE2C_CONTROL_REAL_MORPHOLOGY_FREEZE_v0_7_0\STAGE2C_OUTPUT"
set "STAGE4A=%USERPROFILE%\Downloads\YHMC_STAGE4A_INNER_R50J_SYNTHETIC_PA_CALIBRATION_v1_2_0\YHMC_STAGE4A_INNER_R50J_SYNTHETIC_PA_CALIBRATION_v1_2_0\STAGE4A_OUTPUT"

echo PYEXE=%PYEXE%
"%PYEXE%" --version

"%PYEXE%" -c "import numpy,pandas" >nul 2>nul
if errorlevel 1 (
  "%PYEXE%" -m pip install numpy pandas
  if errorlevel 1 exit /b 1
)

"%PYEXE%" stage4b_inner_r50j_real_morphology_freeze_v1_3_0.py ^
 --stage0 "%STAGE0%" ^
 --stage1b "%STAGE1B%" ^
 --stage2a "%STAGE2A%" ^
 --stage2c "%STAGE2C%" ^
 --stage4a "%STAGE4A%" ^
 --out "%CD%\STAGE4B_OUTPUT"

set "RC=%ERRORLEVEL%"
echo.
echo RETURN_CODE=%RC%
if "%RC%"=="0" (
  echo REPORT=%CD%\STAGE4B_OUTPUT\STAGE4B_REPORT.txt
  echo YOUNG_INNER=%CD%\STAGE4B_OUTPUT\03_YOUNG_INNER_PA_SAMPLE_FROZEN.csv
  echo CONTROL_INNER=%CD%\STAGE4B_OUTPUT\04_CONTROL_INNER_PA_SAMPLE_FROZEN.csv
  echo FREEZE=%CD%\STAGE4B_OUTPUT\STAGE4B_FREEZE.json
)
exit /b %RC%

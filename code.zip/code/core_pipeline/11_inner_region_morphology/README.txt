YHMC STAGE-4B INNER r<r50J REAL MORPHOLOGY FREEZE v1.3.0
==========================================================

Purpose
-------
Compute real inner q and PA using the exact Stage-4A blind calibration,
apply the pre-frozen inner morphology gate, and SHA256-freeze the admitted
young/control inner PA samples BEFORE any inner alignment is calculated.

No Galactic-plane alignment is computed here.

Run
---
call RUN_STAGE4B_INNER_R50J_REAL_MORPHOLOGY_FREEZE_v1_3_0.bat

Main outputs
------------
STAGE4B_OUTPUT\STAGE4B_REPORT.txt
STAGE4B_OUTPUT\03_YOUNG_INNER_PA_SAMPLE_FROZEN.csv
STAGE4B_OUTPUT\04_CONTROL_INNER_PA_SAMPLE_FROZEN.csv
STAGE4B_OUTPUT\05_inner_anchor_coverage_FROZEN.csv
STAGE4B_OUTPUT\06_inner_gate_attrition_by_mass.csv
STAGE4B_OUTPUT\STAGE4B_FREEZE.json

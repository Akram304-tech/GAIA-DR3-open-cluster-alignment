#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-4B inner-r50J real morphology freeze v1.3.0

Purpose
-------
Measure REAL inner-region projected morphology for the exact frozen young
and older-control identities, using the independently frozen Stage-4A
cluster-specific calibration.

This stage DOES NOT compute:
  - local Galactic-plane PA
  - inner Delta-theta
  - inner cos(2 Delta-theta)
  - inner alignment A
  - inner-vs-outer alignment contrast

Inner region
------------
spherical angular separation from catalogue centre <= r50J

Frozen Stage-4A gate
--------------------
1) INNER_PA_CALIBRATABLE == True
2) q84_inner_real <= q_max_inner_PA_reliable
3) q_inner_point < q_inner_round_null_p05
4) bootstrap P68(|DeltaPA_inner|) <= 20 deg

The admitted young and control inner-PA samples are SHA256-frozen before
any inner alignment is permitted.
"""

from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "1.3.0"
SEED = 20260912
N_BOOT = 2000
BOOT_PA_P68_MAX = 20.0

EXPECTED_YOUNG_SHA256 = "cc1d3ae4ce1cf52387f535da92fbd0dc5d984a3bb2dc750bf6672682e85f65dd"
EXPECTED_CONTROL_SHA256 = "124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd"
EXPECTED_CONTROL_LIST_SHA256 = "b31d69d0e90359f9d2a5e0d31db2ce20a3b7b9f5888862de9a15e8cb89ee7c6a"

def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def safe_name(s):
    return "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in str(s))

def find_member_file(member_dir: Path, cid: int, name: str):
    hits=sorted(member_dir.glob(f"{int(cid):04d}_*.csv"))
    if not hits:
        return None
    if len(hits)==1:
        return hits[0]
    sn=safe_name(name)
    for p in hits:
        if sn in p.stem:
            return p
    return hits[0]

def angular_sep_deg(ra,dec,ra0,dec0):
    ra=np.deg2rad(np.asarray(ra,float))
    dec=np.deg2rad(np.asarray(dec,float))
    ra0=math.radians(float(ra0))
    dec0=math.radians(float(dec0))
    sd=np.sin((dec-dec0)/2.0)
    sr=np.sin((ra-ra0)/2.0)
    a=sd*sd+math.cos(dec0)*np.cos(dec)*sr*sr
    a=np.clip(a,0.0,1.0)
    return np.rad2deg(2*np.arcsin(np.sqrt(a)))

def tangent_xy_arcmin(ra,dec,ra0,dec0):
    ra=np.asarray(ra,float); dec=np.asarray(dec,float)
    dra=((ra-float(ra0)+180.0)%360.0)-180.0
    x=dra*math.cos(math.radians(float(dec0)))*60.0
    y=(dec-float(dec0))*60.0
    return x,y

def weighted_shape(x,y,w):
    x=np.asarray(x,float); y=np.asarray(y,float); w=np.asarray(w,float)
    g=np.isfinite(x)&np.isfinite(y)&np.isfinite(w)&(w>0)
    x,y,w=x[g],y[g],w[g]
    if len(x)<3 or w.sum()<=0:
        return np.nan,np.nan,np.nan,np.nan
    sw=w.sum()
    xc=np.sum(w*x)/sw
    yc=np.sum(w*y)/sw
    dx=x-xc; dy=y-yc
    sxx=np.sum(w*dx*dx)/sw
    syy=np.sum(w*dy*dy)/sw
    sxy=np.sum(w*dx*dy)/sw
    C=np.array([[sxx,sxy],[sxy,syy]],float)
    vals,vecs=np.linalg.eigh(C)
    order=np.argsort(vals)[::-1]
    vals=vals[order]; vecs=vecs[:,order]
    if vals[0]<=0 or vals[1]<0:
        return np.nan,np.nan,xc,yc
    q=float(np.sqrt(max(vals[1],0.0)/vals[0]))
    vx,vy=vecs[:,0]
    pa=float(np.degrees(np.arctan2(vy,vx))%180.0)
    return q,pa,float(xc),float(yc)

def axial_diff(a,b):
    return ((np.asarray(a,float)-float(b)+90.0)%180.0)-90.0

def neff(w):
    w=np.asarray(w,float)
    w=w[np.isfinite(w)&(w>0)]
    return float(w.sum()**2/np.square(w).sum()) if len(w) and np.square(w).sum()>0 else 0.0

def pct(x,p):
    x=np.asarray(x,float)
    x=x[np.isfinite(x)]
    return float(np.percentile(x,p)) if len(x) else np.nan

def med(x):
    x=np.asarray(x,float)
    x=x[np.isfinite(x)]
    return float(np.median(x)) if len(x) else np.nan

def bootstrap_shape(x,y,w,nboot,rng):
    n=len(x)
    qs=np.full(nboot,np.nan)
    pas=np.full(nboot,np.nan)
    for k in range(nboot):
        idx=rng.integers(0,n,size=n)
        qs[k],pas[k],_,_=weighted_shape(x[idx],y[idx],w[idx])
    return qs,pas

def prepare_young(y,stage0):
    cols=["ID","Name","r50J","__RAdeg","__DEdeg","MassJ","logAge50"]
    src=stage0[cols].copy()
    if src.duplicated(["ID","Name"]).any():
        raise RuntimeError("Stage-0 source has duplicate ID+Name.")
    return y[["ID","Name","PA_deg_point"]].merge(
        src,on=["ID","Name"],how="left",validate="one_to_one"
    )

def prepare_control(c,stage2a):
    cols=["ID","Name","r50J","__RAdeg","__DEdeg","MassJ","logAge50"]
    src=stage2a[cols].copy()
    if src.duplicated(["ID","Name"]).any():
        raise RuntimeError("Stage-2A full control source has duplicate ID+Name.")
    keep=["ID","Name","PA_deg_point","young_ID","young_Name"]
    return c[keep].merge(src,on=["ID","Name"],how="left",validate="one_to_one")

def process_population(base,gate,member_dir,label,nboot):
    gsub=gate[gate["population"]==label].copy()
    required_gate={
        "ID","Name","q_inner_round_null_p05",
        "q_max_inner_PA_reliable","INNER_PA_CALIBRATABLE"
    }
    miss=sorted(required_gate-set(gsub.columns))
    if miss:
        raise RuntimeError(f"Stage-4A gate missing for {label}: {miss}")
    if gsub.duplicated(["ID","Name"]).any():
        raise RuntimeError(f"Stage-4A {label} gate duplicate ID+Name.")

    merged=base.merge(
        gsub[[
            "ID","Name","q_inner_round_null_p05",
            "q_inner_round_null_p16","q_inner_round_null_median",
            "q_max_inner_PA_reliable","INNER_PA_CALIBRATABLE",
            "N_inner","Neff_inner"
        ]],
        on=["ID","Name"],how="inner",validate="one_to_one"
    )
    if len(merged)!=len(base):
        raise RuntimeError(f"{label}: base/gate identity mismatch {len(base)} -> {len(merged)}")

    rows=[]
    for ii,r in merged.reset_index(drop=True).iterrows():
        cid=int(r["ID"]); name=str(r["Name"])
        mf=find_member_file(member_dir,cid,name)
        if mf is None:
            rows.append({"population":label,"ID":cid,"Name":name,"status":"MISSING_MEMBER_FILE"})
            continue
        m=pd.read_csv(mf)
        need={"Prob","__RAdeg","__DEdeg"}
        missing=sorted(need-set(m.columns))
        if missing:
            rows.append({
                "population":label,"ID":cid,"Name":name,
                "status":"BAD_MEMBER_SCHEMA","missing":";".join(missing)
            })
            continue

        p=pd.to_numeric(m["Prob"],errors="coerce").to_numpy(float)
        ra=pd.to_numeric(m["__RAdeg"],errors="coerce").to_numpy(float)
        de=pd.to_numeric(m["__DEdeg"],errors="coerce").to_numpy(float)
        good=np.isfinite(p)&np.isfinite(ra)&np.isfinite(de)&(p>=0.5)
        p,ra,de=p[good],ra[good],de[good]

        sep=angular_sep_deg(ra,de,r["__RAdeg"],r["__DEdeg"])
        inner=np.isfinite(sep)&(sep<=float(r["r50J"]))
        p,ra,de=p[inner],ra[inner],de[inner]

        x,y=tangent_xy_arcmin(ra,de,r["__RAdeg"],r["__DEdeg"])
        ok=np.isfinite(x)&np.isfinite(y)&np.isfinite(p)&(p>0)
        x,y,p=x[ok],y[ok],p[ok]

        if len(x)<20 or neff(p)<10:
            rows.append({
                "population":label,"ID":cid,"Name":name,
                "status":"INNER_READINESS_CHANGED",
                "N_inner_real":len(x),"Neff_inner_real":neff(p)
            })
            print(f"{label:7s} {ii+1:3d}/{len(merged):3d} {name}: READINESS_CHANGED")
            continue

        q,pa,xc,yc=weighted_shape(x,y,p)
        if not np.isfinite(q) or not np.isfinite(pa):
            rows.append({"population":label,"ID":cid,"Name":name,"status":"SHAPE_FAIL"})
            print(f"{label:7s} {ii+1:3d}/{len(merged):3d} {name}: SHAPE_FAIL")
            continue

        rng=np.random.default_rng(
            np.random.SeedSequence([SEED,cid,1 if label=="young" else 2,nboot,61])
        )
        qb,pab=bootstrap_shape(x,y,p,nboot,rng)
        dpa=np.abs(axial_diff(pab,pa))

        q05,q16,q50,q84,q95=[pct(qb,pv) for pv in (5,16,50,84,95)]
        pa_med=med(dpa)
        pa68=pct(dpa,68)
        pa95=pct(dpa,95)

        pa_cal=bool(r["INNER_PA_CALIBRATABLE"])
        qmax=float(r["q_max_inner_PA_reliable"])
        qnull=float(r["q_inner_round_null_p05"])

        g1=pa_cal
        g2=bool(np.isfinite(q84) and np.isfinite(qmax) and q84<=qmax)
        g3=bool(np.isfinite(qnull) and q<qnull)
        g4=bool(np.isfinite(pa68) and pa68<=BOOT_PA_P68_MAX)
        admitted=bool(g1 and g2 and g3 and g4)

        row={
            "population":label,
            "ID":cid,"Name":name,
            "status":"OK",
            "MassJ":r["MassJ"],"logAge50":r["logAge50"],
            "__RAdeg":r["__RAdeg"],"__DEdeg":r["__DEdeg"],
            "r50J_deg":r["r50J"],
            "N_inner":len(x),"Neff_inner":neff(p),
            "q_inner_point":q,"epsilon_inner_point":1.0-q,
            "q_inner_boot_p05":q05,"q_inner_boot_p16":q16,
            "q_inner_boot_median":q50,"q_inner_boot_p84":q84,
            "q_inner_boot_p95":q95,
            "PA_inner_deg_point":pa,
            "PA_inner_boot_abs_median_deg":pa_med,
            "PA_inner_boot_abs_p68_deg":pa68,
            "PA_inner_boot_abs_p95_deg":pa95,
            "inner_weighted_centroid_x_arcmin":xc,
            "inner_weighted_centroid_y_arcmin":yc,
            "q_inner_round_null_p05":qnull,
            "q_inner_round_null_p16":r["q_inner_round_null_p16"],
            "q_inner_round_null_median":r["q_inner_round_null_median"],
            "q_max_inner_PA_reliable":qmax,
            "gate1_INNER_PA_CALIBRATABLE":g1,
            "gate2_inner_q84_le_qmax":g2,
            "gate3_inner_qpoint_lt_roundnull_p05":g3,
            "gate4_inner_bootPA_p68_le20":g4,
            "INNER_PA_SAMPLE_ADMITTED":admitted,
            "INNER_ALIGNMENT_NOT_COMPUTED":True,
            "PA_outer_baseline_deg":r["PA_deg_point"],
            "abs_inner_outer_PA_difference_deg":
                abs(float(axial_diff(pa,r["PA_deg_point"]))),
        }
        if label=="control":
            row["young_ID"]=r["young_ID"]
            row["young_Name"]=r["young_Name"]
        rows.append(row)

        print(
            f"{label:7s} {ii+1:3d}/{len(merged):3d} {name}: "
            f"q={q:.3f}, PAerr68={pa68:.1f}, admitted={admitted}"
        )

    return pd.DataFrame(rows)

def gate_summary(df,label):
    good=df[df["status"]=="OK"].copy()
    rows=[]
    for m in [1000,3000,5000,10000]:
        s=good[pd.to_numeric(good["MassJ"],errors="coerce")>=m]
        rows.append({
            "population":label,
            "MassJ_threshold_Msun":m,
            "N_real_inner_morphology_OK":len(s),
            "N_gate1_inner_PA_calibratable":
                int(s["gate1_INNER_PA_CALIBRATABLE"].sum()) if len(s) else 0,
            "N_gate2_inner_q84_le_qmax":
                int(s["gate2_inner_q84_le_qmax"].sum()) if len(s) else 0,
            "N_gate3_inner_significantly_elongated":
                int(s["gate3_inner_qpoint_lt_roundnull_p05"].sum()) if len(s) else 0,
            "N_gate4_inner_bootPA_p68_le20":
                int(s["gate4_inner_bootPA_p68_le20"].sum()) if len(s) else 0,
            "N_INNER_PA_SAMPLE_ADMITTED":
                int(s["INNER_PA_SAMPLE_ADMITTED"].sum()) if len(s) else 0,
        })
    return pd.DataFrame(rows)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage0",required=True)
    ap.add_argument("--stage1b",required=True)
    ap.add_argument("--stage2a",required=True)
    ap.add_argument("--stage2c",required=True)
    ap.add_argument("--stage4a",required=True)
    ap.add_argument("--out",default="STAGE4B_OUTPUT")
    ap.add_argument("--nboot",type=int,default=N_BOOT)
    args=ap.parse_args()

    stage0=Path(args.stage0).resolve()
    stage1b=Path(args.stage1b).resolve()
    stage2a=Path(args.stage2a).resolve()
    stage2c=Path(args.stage2c).resolve()
    stage4a=Path(args.stage4a).resolve()
    out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=True)

    yf=stage1b/"02_PRIMARY_PA_SAMPLE_FROZEN.csv"
    cf=stage2c/"02_CONTROL_PA_SAMPLE_FROZEN.csv"
    cfull=stage2a/"02_MATCHED_OLDER_CONTROLS_FROZEN.csv"
    s0=stage0/"07_provisional_morphology_ready.csv"
    gatef=stage4a/"03_inner_cluster_specific_PA_gate.csv"
    freezef=stage4a/"STAGE4A_FREEZE.json"

    for p in [yf,cf,cfull,s0,gatef,freezef]:
        if not p.exists():
            raise FileNotFoundError(p)

    hy=sha256(yf)
    hc=sha256(cf)
    hcf=sha256(cfull)
    hgate=sha256(gatef)
    hfreeze=sha256(freezef)

    if hy!=EXPECTED_YOUNG_SHA256:
        raise RuntimeError("Young frozen hash mismatch.")
    if hc!=EXPECTED_CONTROL_SHA256:
        raise RuntimeError("Control frozen hash mismatch.")
    if hcf!=EXPECTED_CONTROL_LIST_SHA256:
        raise RuntimeError("Stage-2A full control-list hash mismatch.")

    f4a=json.loads(freezef.read_text(encoding="utf-8"))
    if f4a.get("stage")!="STAGE4A_INNER_R50J_SYNTHETIC_PA_CALIBRATION":
        raise RuntimeError("Unexpected Stage-4A freeze stage.")
    if f4a.get("version")!="1.2.0":
        raise RuntimeError("Unexpected Stage-4A freeze version.")
    if f4a.get("young_frozen_sha256")!=hy or f4a.get("control_frozen_sha256")!=hc:
        raise RuntimeError("Stage-4A freeze not bound to current frozen identities.")
    if f4a.get("real_inner_PA_computed",True) or f4a.get("inner_alignment_computed",True):
        raise RuntimeError("Stage-4A blinding assertion failed.")

    y=prepare_young(pd.read_csv(yf),pd.read_csv(s0))
    c=prepare_control(pd.read_csv(cf),pd.read_csv(cfull))
    gate=pd.read_csv(gatef)

    print("="*100)
    print(f"YHMC STAGE-4B INNER r<r50J REAL MORPHOLOGY FREEZE v{VERSION}")
    print("="*100)
    print("CHAIN_OF_CUSTODY=PASS")
    print(f"YOUNG_FROZEN_SHA256={hy}")
    print(f"CONTROL_FROZEN_SHA256={hc}")
    print(f"STAGE4A_GATE_SHA256={hgate}")
    print(f"STAGE4A_FREEZE_SHA256={hfreeze}")
    print(f"N_BOOT={args.nboot}")
    print("INNER_ALIGNMENT_COMPUTED=False")

    yr=process_population(
        y,gate,stage0/"members_primary","young",args.nboot
    )
    cr=process_population(
        c,gate,stage2a/"members_control_frozen","control",args.nboot
    )

    yr.to_csv(out/"01_young_inner_real_morphology_all.csv",index=False)
    cr.to_csv(out/"02_control_inner_real_morphology_all.csv",index=False)

    ya=yr[(yr["status"]=="OK")&(yr["INNER_PA_SAMPLE_ADMITTED"]==True)].copy()
    ca=cr[(cr["status"]=="OK")&(cr["INNER_PA_SAMPLE_ADMITTED"]==True)].copy()

    ya.to_csv(out/"03_YOUNG_INNER_PA_SAMPLE_FROZEN.csv",index=False)
    ca.to_csv(out/"04_CONTROL_INNER_PA_SAMPLE_FROZEN.csv",index=False)

    # Pre-freeze control-anchor coverage for later matched radial comparison.
    young_ids=y[["ID","Name"]].rename(columns={"ID":"young_ID","Name":"young_Name"})
    cc=ca.groupby(["young_ID","young_Name"]).size().rename("N_admitted_inner_controls").reset_index()
    coverage=young_ids.merge(cc,on=["young_ID","young_Name"],how="left")
    coverage["N_admitted_inner_controls"]=coverage["N_admitted_inner_controls"].fillna(0).astype(int)

    yi=ya[["ID","Name"]].rename(columns={"ID":"young_ID","Name":"young_Name"})
    yi["YOUNG_INNER_ADMITTED"]=True
    coverage=coverage.merge(yi,on=["young_ID","young_Name"],how="left")
    coverage["YOUNG_INNER_ADMITTED"]=coverage["YOUNG_INNER_ADMITTED"].fillna(False).astype(bool)
    coverage["HAS_ADMITTED_INNER_CONTROL"]=coverage["N_admitted_inner_controls"]>=1
    coverage["RADIAL_MATCH_READY"]=coverage["YOUNG_INNER_ADMITTED"]&coverage["HAS_ADMITTED_INNER_CONTROL"]
    coverage.to_csv(out/"05_inner_anchor_coverage_FROZEN.csv",index=False)

    gs=pd.concat([gate_summary(yr,"young"),gate_summary(cr,"control")],ignore_index=True)
    gs.to_csv(out/"06_inner_gate_attrition_by_mass.csv",index=False)

    # Morphology-only descriptive diagnostics; still no Galactic-plane alignment.
    desc=[]
    for label,df,adm in [("young",yr,ya),("control",cr,ca)]:
        ok=df[df.status=="OK"]
        for m in [1000,3000,5000,10000]:
            s=ok[pd.to_numeric(ok.MassJ,errors="coerce")>=m]
            a=adm[pd.to_numeric(adm.MassJ,errors="coerce")>=m]
            desc.append({
                "population":label,"MassJ_threshold_Msun":m,
                "N_shape_OK":len(s),
                "median_q_inner_all":med(s.q_inner_point) if len(s) else np.nan,
                "N_inner_admitted":len(a),
                "median_q_inner_admitted":med(a.q_inner_point) if len(a) else np.nan,
                "median_abs_inner_outer_PA_diff_deg":
                    med(a.abs_inner_outer_PA_difference_deg) if len(a) else np.nan,
            })
    pd.DataFrame(desc).to_csv(out/"07_inner_morphology_descriptive_summary.csv",index=False)

    hyin=sha256(out/"03_YOUNG_INNER_PA_SAMPLE_FROZEN.csv")
    hcin=sha256(out/"04_CONTROL_INNER_PA_SAMPLE_FROZEN.csv")
    hcov=sha256(out/"05_inner_anchor_coverage_FROZEN.csv")

    freeze={
        "stage":"STAGE4B_INNER_R50J_REAL_MORPHOLOGY_FREEZE",
        "version":VERSION,
        "seed":SEED,
        "n_boot":args.nboot,
        "young_outer_frozen_sha256":hy,
        "control_outer_frozen_sha256":hc,
        "stage4a_gate_sha256":hgate,
        "stage4a_freeze_sha256":hfreeze,
        "inner_region":"spherical sep from catalogue centre <= r50J",
        "membership_cut":"Prob>=0.5",
        "estimator":"membership-probability weighted second central moments",
        "frozen_gate":[
            "INNER_PA_CALIBRATABLE == True",
            "q84_inner_real <= q_max_inner_PA_reliable",
            "q_inner_point < q_inner_round_null_p05",
            "inner bootstrap P68(|DeltaPA|) <= 20 deg",
        ],
        "young_inner_pa_sample_sha256":hyin,
        "control_inner_pa_sample_sha256":hcin,
        "inner_anchor_coverage_sha256":hcov,
        "alignment_blinding":[
            "No local Galactic-plane PA computed",
            "No inner Delta-theta computed",
            "No inner cos(2Delta) computed",
            "No inner A computed",
            "No inner-vs-outer A contrast computed",
        ],
        "next_stage":
            "Stage-4C may compute inner alignment only for these exact hashed admitted samples."
    }
    (out/"STAGE4B_FREEZE.json").write_text(json.dumps(freeze,indent=2),encoding="utf-8")
    houtfreeze=sha256(out/"STAGE4B_FREEZE.json")

    nrad=int(coverage["RADIAL_MATCH_READY"].sum())
    report=[
        f"YHMC STAGE-4B INNER r<r50J REAL MORPHOLOGY FREEZE v{VERSION}",
        "="*100,
        "CHAIN_OF_CUSTODY=PASS",
        f"YOUNG_FROZEN_SHA256={hy}",
        f"CONTROL_FROZEN_SHA256={hc}",
        f"STAGE4A_GATE_SHA256={hgate}",
        f"STAGE4A_FREEZE_SHA256={hfreeze}",
        f"N_BOOT={args.nboot}",
        "",
        f"Young real inner morphology successful: {int((yr.status=='OK').sum())}",
        f"Young inner PA sample admitted: {len(ya)}",
        f"Control real inner morphology successful: {int((cr.status=='OK').sum())}",
        f"Control inner PA sample admitted: {len(ca)}",
        f"Young anchors ready for matched inner young-control comparison: {nrad}",
        "",
        "INNER GATE ATTRITION BY MASS:",
        gs.to_string(index=False),
        "",
        f"YOUNG_INNER_PA_SAMPLE_SHA256={hyin}",
        f"CONTROL_INNER_PA_SAMPLE_SHA256={hcin}",
        f"INNER_ANCHOR_COVERAGE_SHA256={hcov}",
        f"STAGE4B_FREEZE_SHA256={houtfreeze}",
        "",
        "BLINDING STATUS:",
        "  Inner Galactic-plane PA: NOT COMPUTED",
        "  Inner Delta-theta: NOT COMPUTED",
        "  Inner alignment A: NOT COMPUTED",
        "  Inner-vs-outer alignment contrast: NOT COMPUTED",
        "",
        "NEXT_STAGE:",
        "  Stage-4C inner alignment unblind + paired inner-vs-outer radial test.",
    ]
    (out/"STAGE4B_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")

    print()
    print((out/"STAGE4B_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

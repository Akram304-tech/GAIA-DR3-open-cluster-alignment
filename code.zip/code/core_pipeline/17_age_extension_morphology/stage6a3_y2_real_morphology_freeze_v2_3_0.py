#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-6A3 Y2 Real Morphology Freeze v2.3.0

Authorized only by Stage-6A2 blind PA calibration.

This stage computes REAL projected morphology for the exact 142 Y2 candidates:
  - probability-weighted axis ratio q
  - axial major-axis PA
  - 2000 member-resampling bootstrap realizations
  - q84
  - P68(|Delta PA_boot|)

It applies the already frozen Stage-1B-style real morphology gate:
  G1: PA_CALIBRATABLE from Stage-6A2
  G2: q84_real <= q_max_PA_reliable
  G3: q_point < q_round_null_p05
  G4: P68(|Delta PA_boot|) <= 20 deg

The overlap weights are carried as metadata but are NOT used in morphology,
bootstrap, or admission.

STRICTLY CLOSED IN THIS STAGE
-----------------------------
- local Galactic-plane PA
- Delta theta
- alignment statistic A
- random-orientation or PA-position permutation inference
- any Y1 vs Y2 age-alignment contrast

Thus the admitted Y2 identity list is frozen before any alignment outcome
is available.

Bootstrap
---------
N_BOOT = 2000.
Rows are resampled with replacement within each cluster. The sampled member's
catalogue membership probability remains its weight in the weighted second
central moments. Bootstrap PA differences are axial in [0,90] deg.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

VERSION="2.3.0"

EXPECTED_Y2_EXACT_SHA="3dd7c13de6f136846f8bdca5b98f5cd9e72332581bb071c525cd95e0b9a52430"
EXPECTED_MEMBER_SHA="8de99096df34c5d8a8e58d22c36e1615a85ad8b5e9c97b31b7eb42d409a148a6"
EXPECTED_CAL_SUMMARY_SHA="d30469b8da744825bbb6fc8d6382e9d1ec86a4a656b0049d9e7afca4e5a6aaaa"
EXPECTED_CAL_GRID_SHA="b9f2f2f390b9b1295ed25e88adeb3cdb380dfe1fd7b7cf47d688333da7ef8da3"

N_BOOT=2000
BASE_SEED=20260912
BOOT_BATCH=200
PA_BOOT_P68_MAX=20.0

def sha256(p):
    h=hashlib.sha256()
    with Path(p).open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def num(s):
    return pd.to_numeric(s,errors="coerce")

def tangent_xy(ra,dec,ra0,dec0):
    dra=(np.asarray(ra,float)-float(ra0)+180.0)%360.0-180.0
    x=dra*np.cos(np.deg2rad(float(dec0)))
    y=np.asarray(dec,float)-float(dec0)
    return x,y

def axial_diff_deg(a,b):
    d=np.abs(np.asarray(a,float)-np.asarray(b,float))%180.0
    return np.minimum(d,180.0-d)

def shape_pa_single(x,y,w):
    x=np.asarray(x,float); y=np.asarray(y,float); w=np.asarray(w,float)
    sw=float(np.sum(w))
    if not np.isfinite(sw) or sw<=0:
        return np.nan,np.nan
    mx=float(np.sum(w*x)/sw)
    my=float(np.sum(w*y)/sw)
    dx=x-mx; dy=y-my
    sxx=float(np.sum(w*dx*dx)/sw)
    syy=float(np.sum(w*dy*dy)/sw)
    sxy=float(np.sum(w*dx*dy)/sw)
    S=np.array([[sxx,sxy],[sxy,syy]],float)
    vals,vecs=np.linalg.eigh(S)
    l2=max(float(vals[0]),0.0)
    l1=max(float(vals[1]),np.finfo(float).tiny)
    q=float(np.sqrt(l2/l1))
    v=vecs[:,1]
    pa=float(np.degrees(np.arctan2(v[0],v[1]))%180.0)
    return q,pa

def shape_pa_batch_variable_weights(x,y,w):
    """
    x,y,w each shape (B,N), where bootstrap rows carry their sampled weights.
    """
    sw=np.sum(w,axis=1)
    mx=np.sum(w*x,axis=1)/sw
    my=np.sum(w*y,axis=1)/sw
    dx=x-mx[:,None]; dy=y-my[:,None]
    sxx=np.sum(w*dx*dx,axis=1)/sw
    syy=np.sum(w*dy*dy,axis=1)/sw
    sxy=np.sum(w*dx*dy,axis=1)/sw

    mats=np.empty((len(sw),2,2),float)
    mats[:,0,0]=sxx
    mats[:,1,1]=syy
    mats[:,0,1]=sxy
    mats[:,1,0]=sxy

    vals,vecs=np.linalg.eigh(mats)
    l2=np.maximum(vals[:,0],0.0)
    l1=np.maximum(vals[:,1],np.finfo(float).tiny)
    q=np.sqrt(l2/l1)
    v=vecs[:,:,1]
    pa=np.degrees(np.arctan2(v[:,0],v[:,1]))%180.0
    return q,pa

def bootstrap_cluster(cid,x,y,w,pa_point):
    rng=np.random.default_rng(np.random.SeedSequence([BASE_SEED,int(cid),230]))
    n=len(x)
    qb=[]
    pab=[]
    remaining=N_BOOT
    while remaining>0:
        b=min(BOOT_BATCH,remaining)
        idx=rng.integers(0,n,size=(b,n))
        xb=x[idx]
        yb=y[idx]
        wb=w[idx]
        q,pa=shape_pa_batch_variable_weights(xb,yb,wb)
        qb.append(q)
        pab.append(pa)
        remaining-=b
    qb=np.concatenate(qb)
    pab=np.concatenate(pab)
    dpa=axial_diff_deg(pab,pa_point)
    return {
        "q_boot16":float(np.percentile(qb,16)),
        "q_boot50":float(np.percentile(qb,50)),
        "q_boot84":float(np.percentile(qb,84)),
        "PA_boot_p50_abs_diff_deg":float(np.percentile(dpa,50)),
        "PA_boot_p68_abs_diff_deg":float(np.percentile(dpa,68)),
        "PA_boot_p90_abs_diff_deg":float(np.percentile(dpa,90)),
        "N_boot_finite":int(np.isfinite(qb).sum() & np.isfinite(pab).sum()),
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage6a2",required=True)
    ap.add_argument("--out",default="STAGE6A3_OUTPUT")
    args=ap.parse_args()

    s=Path(args.stage6a2).resolve()
    out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=True)

    y2f=s/"00_Y2_CANDIDATES_EXACT_FROZEN.csv"
    memf=s/"02_Y2_MEMBERS_BASELINE_INRJ1_PGE0p5.csv"
    calf=s/"03_Y2_BLIND_CALIBRATION_SUMMARY_FROZEN.csv"
    gridf=s/"04_Y2_BLIND_CALIBRATION_GRID.csv"

    for p in [y2f,memf,calf,gridf]:
        if not p.exists():
            raise FileNotFoundError(p)

    checks={
        str(y2f): (sha256(y2f),EXPECTED_Y2_EXACT_SHA),
        str(memf): (sha256(memf),EXPECTED_MEMBER_SHA),
        str(calf): (sha256(calf),EXPECTED_CAL_SUMMARY_SHA),
        str(gridf): (sha256(gridf),EXPECTED_CAL_GRID_SHA),
    }
    for name,(obs,exp) in checks.items():
        if obs!=exp:
            raise RuntimeError(f"Input hash mismatch for {name}: {obs} != {exp}")

    y2=pd.read_csv(y2f)
    mem=pd.read_csv(memf,low_memory=False)
    cal=pd.read_csv(calf)

    y2["ID"]=pd.to_numeric(y2["ID"],errors="raise").astype(int)
    mem["ID"]=pd.to_numeric(mem["ID"],errors="raise").astype(int)
    cal["ID"]=pd.to_numeric(cal["ID"],errors="raise").astype(int)

    if len(y2)!=142 or len(cal)!=142:
        raise RuntimeError(f"Expected Y2/calibration 142/142, got {len(y2)}/{len(cal)}")
    if y2["ID"].duplicated().any() or cal["ID"].duplicated().any():
        raise RuntimeError("Duplicate cluster ID.")

    ccols=[
        "ID","calibration_status","PA_CALIBRATABLE",
        "q_max_PA_reliable","q_round_null_p05"
    ]
    meta=y2.merge(cal[ccols],on="ID",how="left",validate="one_to_one")
    if meta["q_max_PA_reliable"].isna().any():
        raise RuntimeError("Missing q_max in a Y2 cluster despite Stage-6A2 142/142 calibratable.")

    print("="*108)
    print(f"YHMC STAGE-6A3 Y2 REAL MORPHOLOGY FREEZE v{VERSION}")
    print("="*108)
    print("REAL_Q_COMPUTED=True")
    print("REAL_PA_COMPUTED=True")
    print("GALACTIC_PLANE_PA_COMPUTED=False")
    print("DELTA_THETA_COMPUTED=False")
    print("ALIGNMENT_COMPUTED=False")
    print(f"Y2_EXACT_N={len(meta)}")
    print(f"N_BOOT={N_BOOT}")

    rows=[]
    for k,r in meta.sort_values("ID").reset_index(drop=True).iterrows():
        cid=int(r["ID"])
        g=mem[mem["ID"]==cid].copy()
        if len(g)<3:
            raise RuntimeError(f"Cluster ID={cid} has fewer than 3 baseline members.")

        ra=num(g["RAdeg"]).to_numpy(float)
        dec=num(g["DEdeg"]).to_numpy(float)
        w=num(g["Prob"]).to_numpy(float)
        good=np.isfinite(ra)&np.isfinite(dec)&np.isfinite(w)&(w>0)
        ra=ra[good]; dec=dec[good]; w=w[good]
        if len(ra)<3:
            raise RuntimeError(f"Cluster ID={cid} has fewer than 3 finite weighted members.")

        # Same projection-origin convention as Stage-6A2.
        ra0=float(np.median(ra))
        dec0=float(np.median(dec))
        x,y=tangent_xy(ra,dec,ra0,dec0)

        qpt,papt=shape_pa_single(x,y,w)
        if not np.isfinite(qpt) or not np.isfinite(papt):
            raise RuntimeError(f"Non-finite point morphology ID={cid}")

        b=bootstrap_cluster(cid,x,y,w,papt)

        qmax=float(r["q_max_PA_reliable"])
        qround=float(r["q_round_null_p05"])
        g1=bool(r["PA_CALIBRATABLE"])
        g2=bool(b["q_boot84"]<=qmax)
        g3=bool(qpt<qround)
        g4=bool(b["PA_boot_p68_abs_diff_deg"]<=PA_BOOT_P68_MAX)
        admitted=bool(g1 and g2 and g3 and g4)

        # First-failure registry.
        if not g1:
            ff="GATE1_PA_CALIBRATABLE"
        elif not g2:
            ff="GATE2_Q84_LE_QMAX"
        elif not g3:
            ff="GATE3_QPOINT_LT_ROUNDNULL"
        elif not g4:
            ff="GATE4_BOOT_PA_P68_LE20"
        else:
            ff="ADMITTED"

        rows.append({
            "ID":cid,
            "Name":r.get("Name_catalog",""),
            "MassJ":float(r["MassJ"]),
            "logAge16":float(r["logAge16"]) if np.isfinite(r["logAge16"]) else np.nan,
            "logAge50":float(r["logAge50"]),
            "logAge84":float(r["logAge84"]) if np.isfinite(r["logAge84"]) else np.nan,
            "overlap_weight_norm_PRE_MORPH":float(r["overlap_weight_norm"]),
            "N_members_baseline":len(ra),
            "q_point_real":qpt,
            "PA_point_real_deg":papt,
            "q_boot16":b["q_boot16"],
            "q_boot50":b["q_boot50"],
            "q_boot84":b["q_boot84"],
            "PA_boot_p50_abs_diff_deg":b["PA_boot_p50_abs_diff_deg"],
            "PA_boot_p68_abs_diff_deg":b["PA_boot_p68_abs_diff_deg"],
            "PA_boot_p90_abs_diff_deg":b["PA_boot_p90_abs_diff_deg"],
            "q_max_PA_reliable":qmax,
            "q_round_null_p05":qround,
            "GATE1_PA_CALIBRATABLE":g1,
            "GATE2_Q84_LE_QMAX":g2,
            "GATE3_QPOINT_LT_ROUNDNULL":g3,
            "GATE4_BOOT_PA_P68_LE20":g4,
            "MORPHOLOGY_ADMITTED":admitted,
            "FIRST_FAILURE":ff,
        })

        if (k+1)%10==0 or k+1==len(meta):
            print(
                f"MORPHOLOGY={k+1}/{len(meta)} ID={cid} "
                f"q={qpt:.4f} q84={b['q_boot84']:.4f} "
                f"PAerr68={b['PA_boot_p68_abs_diff_deg']:.2f} "
                f"admit={admitted}"
            )

    rdf=pd.DataFrame(rows)
    rdf.to_csv(out/"01_Y2_REAL_MORPHOLOGY_ALL.csv",index=False)

    admitted=rdf[rdf["MORPHOLOGY_ADMITTED"]==True].copy().reset_index(drop=True)
    admitted.to_csv(out/"02_Y2_PA_SAMPLE_FROZEN.csv",index=False)

    # Gate attrition by nested mass thresholds.
    gate_rows=[]
    for mt in [1000,3000,5000,10000]:
        x=rdf[rdf["MassJ"]>=mt]
        gate_rows.append({
            "MassJ_threshold":mt,
            "N_total":len(x),
            "N_gate1":int(x["GATE1_PA_CALIBRATABLE"].sum()),
            "N_gate2":int(x["GATE2_Q84_LE_QMAX"].sum()),
            "N_gate3":int(x["GATE3_QPOINT_LT_ROUNDNULL"].sum()),
            "N_gate4":int(x["GATE4_BOOT_PA_P68_LE20"].sum()),
            "N_admitted":int(x["MORPHOLOGY_ADMITTED"].sum()),
            "median_q_point":float(x["q_point_real"].median()) if len(x) else np.nan,
            "median_q84":float(x["q_boot84"].median()) if len(x) else np.nan,
            "median_PAerr68_deg":
                float(x["PA_boot_p68_abs_diff_deg"].median()) if len(x) else np.nan,
        })
    gdf=pd.DataFrame(gate_rows)
    gdf.to_csv(out/"03_Y2_MORPHOLOGY_GATE_ATTRITION.csv",index=False)

    fdf=(
        rdf.groupby("FIRST_FAILURE",dropna=False)
        .size().rename("N").reset_index()
        .sort_values(["N","FIRST_FAILURE"],ascending=[False,True])
    )
    fdf.to_csv(out/"04_Y2_FIRST_FAILURE_COUNTS.csv",index=False)

    h_all=sha256(out/"01_Y2_REAL_MORPHOLOGY_ALL.csv")
    h_adm=sha256(out/"02_Y2_PA_SAMPLE_FROZEN.csv")
    h_gate=sha256(out/"03_Y2_MORPHOLOGY_GATE_ATTRITION.csv")

    contract={
        "stage":"STAGE6A3_Y2_REAL_MORPHOLOGY_FREEZE",
        "version":VERSION,
        "inputs":{
            "Y2_exact_sha256":EXPECTED_Y2_EXACT_SHA,
            "member_snapshot_sha256":EXPECTED_MEMBER_SHA,
            "calibration_summary_sha256":EXPECTED_CAL_SUMMARY_SHA,
            "calibration_grid_sha256":EXPECTED_CAL_GRID_SHA,
        },
        "N_boot":N_BOOT,
        "base_seed":BASE_SEED,
        "gate":{
            "G1":"PA_CALIBRATABLE",
            "G2":"q_boot84 <= q_max_PA_reliable",
            "G3":"q_point < q_round_null_p05",
            "G4":"PA_boot_p68_abs_diff_deg <= 20",
        },
        "overlap_weight_used_for_admission":False,
        "real_q_computed":True,
        "real_PA_computed":True,
        "galactic_plane_PA_computed":False,
        "delta_theta_computed":False,
        "alignment_computed":False,
        "N_total":int(len(rdf)),
        "N_admitted":int(len(admitted)),
        "all_morphology_sha256":h_all,
        "PA_sample_frozen_sha256":h_adm,
        "gate_attrition_sha256":h_gate,
        "next":
            "Stage-6A4 post-morphology overlap-balance/ESS audit. "
            "Use only pre-existing overlap weights restricted to admitted Y2; "
            "do not refit or retune the propensity model. "
            "Alignment remains closed until Stage-6A4 passes."
    }
    (out/"STAGE6A3_FREEZE.json").write_text(
        json.dumps(contract,indent=2),encoding="utf-8"
    )

    report=[
        f"YHMC STAGE-6A3 Y2 REAL MORPHOLOGY FREEZE v{VERSION}",
        "="*108,
        "REAL_Q_COMPUTED=True",
        "REAL_PA_COMPUTED=True",
        "GALACTIC_PLANE_PA_COMPUTED=False",
        "DELTA_THETA_COMPUTED=False",
        "ALIGNMENT_COMPUTED=False",
        f"Y2_TOTAL_N={len(rdf)}",
        f"Y2_ADMITTED_N={len(admitted)}",
        "",
        "MASS / GATE ATTRITION:",
        gdf.to_string(index=False),
        "",
        "FIRST FAILURE COUNTS:",
        fdf.to_string(index=False),
        "",
        f"ALL_MORPHOLOGY_SHA256={h_all}",
        f"PA_SAMPLE_FROZEN_SHA256={h_adm}",
        f"GATE_ATTRITION_SHA256={h_gate}",
        "",
        "NEXT:",
        "  Stage-6A4 post-morphology overlap-balance audit.",
        "  Existing overlap weights will only be restricted/renormalized;",
        "  propensity model refitting/tuning is NOT authorized.",
        "  Galactic alignment remains CLOSED.",
    ]
    (out/"STAGE6A3_REPORT.txt").write_text(
        "\n".join(report)+"\n",encoding="utf-8"
    )

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")

    print()
    print((out/"STAGE6A3_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

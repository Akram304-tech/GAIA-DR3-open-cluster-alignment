YHMC Stage-6A3 Y2 Real Morphology Freeze v2.3.0
===================================================

Inputs are hash-bound to Stage-6A2 v2.2.1.

Computes:
  real q
  real axial PA
  2000 member-resampling bootstraps

Frozen admission gate:
  G1 PA-calibratable
  G2 q84 <= cluster-specific q_max
  G3 q_point < circular roundness-null p05
  G4 bootstrap P68(|dPA|) <= 20 deg

Does NOT compute:
  local Galactic-plane PA
  Delta theta
  alignment A
  any age-alignment contrast

Overlap weights are metadata only and do not influence morphology admission.

The next stage is a post-morphology balance audit. It is already frozen that
the existing overlap weights may only be restricted and renormalized; the
propensity model will not be refit after seeing morphology admissions.

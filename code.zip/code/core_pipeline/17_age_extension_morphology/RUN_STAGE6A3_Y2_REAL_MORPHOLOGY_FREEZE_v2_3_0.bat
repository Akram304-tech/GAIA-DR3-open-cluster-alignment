@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-6A3 Y2 REAL MORPHOLOGY FREEZE v2.3.0
echo REAL Q/PA ONLY / GALACTIC ALIGNMENT CLOSED
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" exit /b 1

set "STAGE6A2=%USERPROFILE%\Downloads\YHMC_STAGE6A2_Y2_BLIND_PA_CALIBRATION_v2_2_1\YHMC_STAGE6A2_Y2_BLIND_PA_CALIBRATION_v2_2_1\STAGE6A2_OUTPUT"

"%PYEXE%" -c "import numpy,pandas" >nul 2>nul
if errorlevel 1 exit /b 1

"%PYEXE%" stage6a3_y2_real_morphology_freeze_v2_3_0.py ^
 --stage6a2 "%STAGE6A2%" ^
 --out "%CD%\STAGE6A3_OUTPUT"

set "RC=%ERRORLEVEL%"
echo.
echo RETURN_CODE=%RC%
if "%RC%"=="0" (
 echo REPORT=%CD%\STAGE6A3_OUTPUT\STAGE6A3_REPORT.txt
 echo PA_SAMPLE=%CD%\STAGE6A3_OUTPUT\02_Y2_PA_SAMPLE_FROZEN.csv
 echo FREEZE=%CD%\STAGE6A3_OUTPUT\STAGE6A3_FREEZE.json
)
exit /b %RC%

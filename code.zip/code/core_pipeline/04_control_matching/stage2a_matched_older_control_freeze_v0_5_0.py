#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-2A matched older-control construction v0.5.0

Goal
----
Construct and freeze an older (100-500 Myr) comparison sample BEFORE any
control-cluster morphology or alignment is measured.

Young anchors
-------------
The exact 95-object Stage-1B frozen PA-resolved young sample is used ONLY
for matching covariates. Its alignment results are not read.

Older control pool
------------------
Type=o
8.0 < logAge50 <= log10(5e8)=8.69897
MassJ >= 1000 Msun
same Stage-0 cluster-quality cuts:
  CST>=5, CMDCl50>=0.5, probJ>=0.5, NJ>=40, valid rJ/r50J/coordinates

Matching
--------
2 unique older controls per young anchor, without replacement, using
minimum-cost optimal assignment over observational/selection covariates:
  log10(MassJ), log10(dist50), log10(NJ), AV50, |GLAT|, Galactic longitude.

No morphology, PA, Delta-theta, or alignment value enters the matching.

The selected control list is hashed/frozen before member-level morphology
calibration in Stage-2B.
"""

from __future__ import annotations
import argparse, hashlib, io, json, math, time
from pathlib import Path

import numpy as np
import pandas as pd
import requests
from scipy.optimize import linear_sum_assignment

VERSION = "0.5.0"
SEED = 20260912
AGE_LO = 8.0
AGE_HI = math.log10(5e8)
MASS_MIN = 1000.0
N_CONTROL_PER_YOUNG = 2

EXPECTED_YOUNG_SHA256 = "cc1d3ae4ce1cf52387f535da92fbd0dc5d984a3bb2dc750bf6672682e85f65dd"

TAP = "https://tapvizier.cds.unistra.fr/TAPVizieR/tap/sync"
MEMBER_TABLE = '"J/A+A/686/A42/members"'

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()

def tap_query(adql: str, timeout=240, retries=4):
    payload={"REQUEST":"doQuery","LANG":"ADQL","FORMAT":"csv","QUERY":adql}
    last=None
    for k in range(retries):
        try:
            r=requests.post(TAP,data=payload,timeout=timeout)
            if r.status_code!=200:
                raise RuntimeError(f"HTTP {r.status_code}\n{r.text[:8000]}\nADQL={adql}")
            txt=r.text
            if txt.lstrip().startswith("<?xml") or "QUERY_STATUS" in txt[:3000]:
                raise RuntimeError("TAP XML/error:\n"+txt[:8000])
            return pd.read_csv(io.StringIO(txt))
        except Exception as e:
            last=e
            if k+1<retries:
                time.sleep(min(2**k,12))
    raise RuntimeError(f"TAP failed after {retries}: {last}")

def circular_lon_sep_deg(a,b):
    d=np.abs(np.asarray(a,float)-np.asarray(b,float))
    return np.minimum(d,360.0-d)

def robust_scale(x):
    x=np.asarray(x,float)
    x=x[np.isfinite(x)]
    if len(x)==0:
        return 1.0
    q25,q75=np.percentile(x,[25,75])
    s=(q75-q25)/1.349
    if not np.isfinite(s) or s<=0:
        s=np.std(x)
    return float(s if np.isfinite(s) and s>0 else 1.0)

def smd(a,b):
    a=np.asarray(a,float); b=np.asarray(b,float)
    a=a[np.isfinite(a)]; b=b[np.isfinite(b)]
    if len(a)<2 or len(b)<2: return np.nan
    sp=np.sqrt((np.var(a,ddof=1)+np.var(b,ddof=1))/2)
    return float((np.mean(b)-np.mean(a))/sp) if sp>0 else 0.0

def canon_coords(df):
    if "__RAdeg" in df.columns and "__DEdeg" in df.columns:
        return df
    pairs=[("RAdeg","DEdeg"),("RA_ICRS","DE_ICRS"),("_RA_icrs","_DE_icrs")]
    for ra,de in pairs:
        if ra in df.columns and de in df.columns:
            df=df.copy()
            df["__RAdeg"]=pd.to_numeric(df[ra],errors="coerce")
            df["__DEdeg"]=pd.to_numeric(df[de],errors="coerce")
            return df
    raise RuntimeError("No usable coordinate pair.")

def safe_name(s):
    return "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in str(s))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage0",required=True)
    ap.add_argument("--stage1b",required=True)
    ap.add_argument("--out",default="STAGE2A_OUTPUT")
    args=ap.parse_args()

    stage0=Path(args.stage0).expanduser().resolve()
    stage1b=Path(args.stage1b).expanduser().resolve()
    out=Path(args.out).expanduser().resolve()
    out.mkdir(parents=True,exist_ok=True)

    master_file=stage0/"01_cluster_master_raw.csv"
    young_file=stage1b/"02_PRIMARY_PA_SAMPLE_FROZEN.csv"
    if not master_file.exists(): raise FileNotFoundError(master_file)
    if not young_file.exists(): raise FileNotFoundError(young_file)

    young_hash=sha256(young_file)
    if young_hash!=EXPECTED_YOUNG_SHA256:
        raise RuntimeError(
            "Young anchor chain-of-custody fail.\n"
            f"Expected {EXPECTED_YOUNG_SHA256}\nActual   {young_hash}"
        )

    master=pd.read_csv(master_file)
    master=canon_coords(master)
    young=pd.read_csv(young_file)

    # Join young matching covariates from Stage-0 master.
    covars=["ID","Name","MassJ","dist50","NJ","AV50","GLON","GLAT","CST","CMDCl50","probJ","logAge50"]
    miss=[c for c in covars if c not in master.columns]
    if miss: raise RuntimeError("Master missing columns: "+", ".join(miss))
    if master.duplicated(["ID","Name"]).any():
        raise RuntimeError("Master has duplicate ID+Name.")
    ycov=young[["ID","Name"]].merge(master[covars],on=["ID","Name"],how="left",validate="one_to_one")
    if ycov[covars[2:]].isna().any().any():
        bad=ycov[ycov[covars[2:]].isna().any(axis=1)][["ID","Name"]]
        raise RuntimeError("Young matching covariates missing:\n"+bad.to_string(index=False))

    # Numeric conversion.
    for c in ["MassJ","dist50","NJ","AV50","GLON","GLAT","CST","CMDCl50","probJ","logAge50",
              "rJ","r50J","__RAdeg","__DEdeg"]:
        if c in master.columns:
            master[c]=pd.to_numeric(master[c],errors="coerce")

    is_open=master["Type"].astype(str).str.strip().eq("o")
    older=master["logAge50"].notna()&(master["logAge50"]>AGE_LO)&(master["logAge50"]<=AGE_HI)
    quality=(
        is_open & older &
        master["MassJ"].notna()&(master["MassJ"]>=MASS_MIN) &
        master["CST"].notna()&(master["CST"]>=5) &
        master["CMDCl50"].notna()&(master["CMDCl50"]>=0.5) &
        master["probJ"].notna()&(master["probJ"]>=0.5) &
        master["NJ"].notna()&(master["NJ"]>=40) &
        master["rJ"].notna()&(master["rJ"]>0) &
        master["r50J"].notna()&(master["r50J"]>0) &
        master["__RAdeg"].notna()&master["__DEdeg"].notna() &
        master["dist50"].notna()&(master["dist50"]>0) &
        master["AV50"].notna() &
        master["GLON"].notna()&master["GLAT"].notna()
    )
    pool=master.loc[quality].copy()

    # Exclude any young IDs defensively.
    pool=pool[~pool["ID"].isin(set(young["ID"]))].copy()
    need=len(young)*N_CONTROL_PER_YOUNG
    if len(pool)<need:
        raise RuntimeError(f"Older control pool too small: {len(pool)} < required {need}")

    print("="*88)
    print(f"YHMC STAGE-2A MATCHED OLDER CONTROL FREEZE v{VERSION}")
    print("="*88)
    print(f"YOUNG_CHAIN_OF_CUSTODY=PASS {young_hash}")
    print(f"YOUNG_ANCHORS={len(young)}")
    print(f"OLDER_POOL={len(pool)}")
    print(f"CONTROL_RATIO={N_CONTROL_PER_YOUNG}:1")
    print(f"TARGET_CONTROLS={need}")
    print("ALIGNMENT_FIELDS_USED_IN_MATCHING=0")

    # Feature transforms.
    def feature_df(df):
        z=pd.DataFrame(index=df.index)
        z["logMass"]=np.log10(pd.to_numeric(df["MassJ"],errors="coerce"))
        z["logDist"]=np.log10(pd.to_numeric(df["dist50"],errors="coerce"))
        z["logNJ"]=np.log10(pd.to_numeric(df["NJ"],errors="coerce"))
        z["AV"]=pd.to_numeric(df["AV50"],errors="coerce")
        z["absB"]=np.abs(pd.to_numeric(df["GLAT"],errors="coerce"))
        z["GLON"]=pd.to_numeric(df["GLON"],errors="coerce")%360
        return z

    Y=feature_df(ycov)
    C=feature_df(pool)

    # Robust scales based on union, with fixed scientifically motivated weights.
    scales={}
    for col in ["logMass","logDist","logNJ","AV","absB"]:
        scales[col]=robust_scale(pd.concat([Y[col],C[col]],ignore_index=True).to_numpy())
    scales["GLON"]=45.0

    weights={
        "logMass":1.5,
        "logDist":1.5,
        "logNJ":1.0,
        "AV":1.0,
        "absB":1.0,
        "GLON":1.0,
    }

    # Expand each young anchor into 2 matching slots.
    slot_yidx=np.repeat(np.arange(len(Y)),N_CONTROL_PER_YOUNG)
    nslots=len(slot_yidx)
    cost=np.zeros((nslots,len(C)),dtype=float)

    for sidx, yi in enumerate(slot_yidx):
        cost[sidx] += weights["logMass"]*((C["logMass"].to_numpy()-Y.iloc[yi]["logMass"])/scales["logMass"])**2
        cost[sidx] += weights["logDist"]*((C["logDist"].to_numpy()-Y.iloc[yi]["logDist"])/scales["logDist"])**2
        cost[sidx] += weights["logNJ"]*((C["logNJ"].to_numpy()-Y.iloc[yi]["logNJ"])/scales["logNJ"])**2
        cost[sidx] += weights["AV"]*((C["AV"].to_numpy()-Y.iloc[yi]["AV"])/scales["AV"])**2
        cost[sidx] += weights["absB"]*((C["absB"].to_numpy()-Y.iloc[yi]["absB"])/scales["absB"])**2
        dlon=circular_lon_sep_deg(C["GLON"].to_numpy(),Y.iloc[yi]["GLON"])
        cost[sidx] += weights["GLON"]*(dlon/scales["GLON"])**2

    row_ind,col_ind=linear_sum_assignment(cost)
    if len(row_ind)!=nslots:
        raise RuntimeError("Optimal assignment did not fill all young-control slots.")

    matches=[]
    control_indices=[]
    for rr,cc in zip(row_ind,col_ind):
        yi=slot_yidx[rr]
        yrow=ycov.iloc[yi]
        crow=pool.iloc[cc]
        control_indices.append(cc)
        matches.append({
            "young_ID":int(yrow["ID"]),
            "young_Name":str(yrow["Name"]),
            "control_ID":int(crow["ID"]),
            "control_Name":str(crow["Name"]),
            "match_cost":float(cost[rr,cc]),
            "d_logMass":float(np.log10(crow["MassJ"])-np.log10(yrow["MassJ"])),
            "d_logDist":float(np.log10(crow["dist50"])-np.log10(yrow["dist50"])),
            "d_logNJ":float(np.log10(crow["NJ"])-np.log10(yrow["NJ"])),
            "d_AV":float(crow["AV50"]-yrow["AV50"]),
            "d_absB":float(abs(crow["GLAT"])-abs(yrow["GLAT"])),
            "d_GLON_deg":float(circular_lon_sep_deg(crow["GLON"],yrow["GLON"])),
        })
    match_df=pd.DataFrame(matches).sort_values(["young_ID","match_cost"])
    match_df["control_rank_within_young"]=match_df.groupby(["young_ID","young_Name"]).cumcount()+1
    match_df.to_csv(out/"01_young_to_control_matches.csv",index=False)

    selected_ids=match_df["control_ID"].astype(int).tolist()
    if len(selected_ids)!=len(set(selected_ids)):
        raise RuntimeError("Control matching unexpectedly reused a control.")
    controls=pool[pool["ID"].isin(selected_ids)].copy()
    if len(controls)!=need:
        raise RuntimeError(f"Frozen control row mismatch: {len(controls)} != {need}")

    # Order controls by matching table for stable provenance.
    order={cid:i for i,cid in enumerate(selected_ids)}
    controls["_freeze_order"]=controls["ID"].map(order)
    controls=controls.sort_values("_freeze_order").drop(columns="_freeze_order")
    controls.to_csv(out/"02_MATCHED_OLDER_CONTROLS_FROZEN.csv",index=False)

    # Covariate balance (young anchors compared to all matched controls).
    Csel=feature_df(controls)
    balance=[]
    for col in ["logMass","logDist","logNJ","AV","absB"]:
        balance.append({
            "covariate":col,
            "young_mean":float(np.mean(Y[col])),
            "control_mean":float(np.mean(Csel[col])),
            "young_sd":float(np.std(Y[col],ddof=1)),
            "control_sd":float(np.std(Csel[col],ddof=1)),
            "SMD_control_minus_young":smd(Y[col],Csel[col]),
        })
    # Longitude: report circular pair separations from actual matched pairs instead of SMD.
    balance_df=pd.DataFrame(balance)
    balance_df.to_csv(out/"03_covariate_balance.csv",index=False)

    # Match diagnostics.
    diag=pd.DataFrame([{
        "N_young":len(young),
        "N_control_pool":len(pool),
        "N_selected_controls":len(controls),
        "control_ratio":N_CONTROL_PER_YOUNG,
        "median_match_cost":float(match_df["match_cost"].median()),
        "p90_match_cost":float(match_df["match_cost"].quantile(0.90)),
        "max_match_cost":float(match_df["match_cost"].max()),
        "median_abs_dlogMass":float(match_df["d_logMass"].abs().median()),
        "median_abs_dlogDist":float(match_df["d_logDist"].abs().median()),
        "median_abs_dAV":float(match_df["d_AV"].abs().median()),
        "median_dGLON_deg":float(match_df["d_GLON_deg"].median()),
        "p90_dGLON_deg":float(match_df["d_GLON_deg"].quantile(0.90)),
    }])
    diag.to_csv(out/"04_match_diagnostics.csv",index=False)

    # Freeze hashes BEFORE querying members/morphology.
    control_hash=sha256(out/"02_MATCHED_OLDER_CONTROLS_FROZEN.csv")
    match_hash=sha256(out/"01_young_to_control_matches.csv")

    # Query members only after control identities are frozen.
    member_dir=out/"members_control_frozen"
    member_dir.mkdir(exist_ok=True)
    member_audit=[]
    for j,r in enumerate(controls.itertuples(index=False),start=1):
        cid=int(r.ID); name=str(r.Name)
        q=f'SELECT * FROM {MEMBER_TABLE} WHERE "ID"={cid} AND "inrj"=1 AND "Prob">=0.5'
        try:
            mem=tap_query(q)
            # Canonicalize member coordinates.
            if "__RAdeg" not in mem.columns:
                pairs=[("RAdeg","DEdeg"),("RA_ICRS","DE_ICRS"),("_RA_icrs","_DE_icrs")]
                found=False
                for ra,de in pairs:
                    if ra in mem.columns and de in mem.columns:
                        mem["__RAdeg"]=pd.to_numeric(mem[ra],errors="coerce")
                        mem["__DEdeg"]=pd.to_numeric(mem[de],errors="coerce")
                        found=True
                        break
                if not found:
                    raise RuntimeError("No member RA/Dec coordinate pair.")
            safe=safe_name(name)
            fp=member_dir/f"{cid:04d}_{safe}.csv"
            mem.to_csv(fp,index=False)
            p=pd.to_numeric(mem["Prob"],errors="coerce")
            ne=float(p.sum()**2/(p.pow(2).sum())) if len(p) and p.pow(2).sum()>0 else 0.0
            member_audit.append({
                "ID":cid,"Name":name,"query_ok":True,
                "N_P50_inrj":len(mem),"Neff_P50_inrj":ne,"error":""
            })
        except Exception as e:
            member_audit.append({
                "ID":cid,"Name":name,"query_ok":False,
                "N_P50_inrj":0,"Neff_P50_inrj":0.0,"error":str(e)
            })
        print(f"{j:3d}/{len(controls):3d} {name}")

    ma=pd.DataFrame(member_audit)
    ma.to_csv(out/"05_control_member_audit.csv",index=False)

    freeze={
        "stage":"STAGE2A_MATCHED_OLDER_CONTROL_FREEZE",
        "version":VERSION,
        "young_anchor_sha256":young_hash,
        "control_list_sha256":control_hash,
        "match_table_sha256":match_hash,
        "age_control_range_logyr":[AGE_LO,AGE_HI],
        "age_control_range_Myr":[100,500],
        "mass_min_Msun":MASS_MIN,
        "control_ratio":N_CONTROL_PER_YOUNG,
        "matching_covariates":[
            "log10(MassJ)","log10(dist50)","log10(NJ)","AV50","abs(GLAT)","cyclic GLON"
        ],
        "matching_weights":weights,
        "matching_scales":scales,
        "matching_algorithm":"minimum-cost linear sum assignment, unique controls, no replacement",
        "alignment_information_used":False,
        "control_morphology_used":False,
        "next_stage":
            "Stage-2B blind synthetic PA calibration for frozen older controls; no control alignment permitted before morphology gate freeze."
    }
    (out/"STAGE2A_FREEZE.json").write_text(json.dumps(freeze,indent=2),encoding="utf-8")

    n_query_ok=int(ma["query_ok"].sum()) if len(ma) else 0
    max_abs_smd=float(balance_df["SMD_control_minus_young"].abs().max()) if len(balance_df) else np.nan
    report=[
        f"YHMC STAGE-2A MATCHED OLDER CONTROL FREEZE v{VERSION}",
        "="*88,
        f"YOUNG_CHAIN_OF_CUSTODY=PASS",
        f"YOUNG_ANCHOR_SHA256={young_hash}",
        f"Young anchors: {len(young)}",
        f"Older quality pool: {len(pool)}",
        f"Frozen unique older controls: {len(controls)} ({N_CONTROL_PER_YOUNG}:1)",
        f"Age range: 100-500 Myr",
        f"CONTROL_LIST_SHA256={control_hash}",
        f"MATCH_TABLE_SHA256={match_hash}",
        "",
        "MATCH DIAGNOSTICS:",
        diag.to_string(index=False),
        "",
        "COVARIATE BALANCE:",
        balance_df.to_string(index=False),
        f"Max absolute SMD (non-longitude covariates) = {max_abs_smd:.4f}",
        "",
        f"Member queries successful: {n_query_ok}/{len(controls)}",
        "",
        "BLINDING:",
        "  Control morphology: NOT COMPUTED",
        "  Control PA: NOT COMPUTED",
        "  Control Galactic-plane alignment: NOT COMPUTED",
        "",
        "NEXT_STAGE:",
        "  Stage-2B blind synthetic PA calibration on these frozen older controls.",
    ]
    (out/"STAGE2A_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")

    print()
    print((out/"STAGE2A_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

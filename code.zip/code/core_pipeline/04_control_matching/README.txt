YHMC STAGE-2A MATCHED OLDER CONTROL FREEZE v0.5.0
======================================================

Purpose
-------
Build an older 100-500 Myr control sample without looking at control
morphology or alignment.

Young anchors
-------------
Exact 95-object Stage-1B frozen young PA-resolved sample.

Controls
--------
2 unique older controls per young cluster, matched without replacement.

Matching covariates
-------------------
- log10(MassJ)
- log10(dist50)
- log10(NJ)
- AV50
- |GLAT|
- cyclic Galactic longitude

These variables target observational/selection comparability.
No shape, PA, Delta-theta, or alignment quantity is used.

Run
---
call RUN_STAGE2A_MATCHED_OLDER_CONTROL_FREEZE_v0_5_0.bat

Main outputs
------------
STAGE2A_OUTPUT\STAGE2A_REPORT.txt
STAGE2A_OUTPUT\01_young_to_control_matches.csv
STAGE2A_OUTPUT\02_MATCHED_OLDER_CONTROLS_FROZEN.csv
STAGE2A_OUTPUT\03_covariate_balance.csv
STAGE2A_OUTPUT\04_match_diagnostics.csv
STAGE2A_OUTPUT\05_control_member_audit.csv
STAGE2A_OUTPUT\STAGE2A_FREEZE.json

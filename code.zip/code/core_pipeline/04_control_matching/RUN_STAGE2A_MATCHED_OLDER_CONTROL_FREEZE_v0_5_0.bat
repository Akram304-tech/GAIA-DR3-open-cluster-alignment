@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-2A MATCHED OLDER CONTROL FREEZE v0.5.0
echo CONTROL IDENTITIES FROZEN BEFORE MORPHOLOGY/ALIGNMENT
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" (
  echo ERROR: Miniconda Python not found.
  exit /b 1
)

set "STAGE0=%USERPROFILE%\Downloads\YHMC_STAGE0_PREFLIGHT_v0_1_2\YHMC_STAGE0_PREFLIGHT_v0_1_2\STAGE0_OUTPUT"
set "STAGE1B=%USERPROFILE%\Downloads\YHMC_STAGE1B_REAL_MORPHOLOGY_FREEZE_v0_3_0\YHMC_STAGE1B_REAL_MORPHOLOGY_FREEZE_v0_3_0\STAGE1B_OUTPUT"

if not exist "%STAGE0%\01_cluster_master_raw.csv" (
  echo ERROR: Stage-0 master not found.
  exit /b 1
)
if not exist "%STAGE1B%\02_PRIMARY_PA_SAMPLE_FROZEN.csv" (
  echo ERROR: Stage-1B frozen young sample not found.
  exit /b 1
)

echo PYEXE=%PYEXE%
"%PYEXE%" --version
echo STAGE0=%STAGE0%
echo STAGE1B=%STAGE1B%

"%PYEXE%" -c "import numpy,pandas,requests,scipy" >nul 2>nul
if errorlevel 1 (
  "%PYEXE%" -m pip install numpy pandas requests scipy
  if errorlevel 1 exit /b 1
)

"%PYEXE%" stage2a_matched_older_control_freeze_v0_5_0.py --stage0 "%STAGE0%" --stage1b "%STAGE1B%" --out "%CD%\STAGE2A_OUTPUT"
set "RC=%ERRORLEVEL%"

echo.
echo RETURN_CODE=%RC%
if "%RC%"=="0" (
  echo REPORT=%CD%\STAGE2A_OUTPUT\STAGE2A_REPORT.txt
  echo CONTROLS=%CD%\STAGE2A_OUTPUT\02_MATCHED_OLDER_CONTROLS_FROZEN.csv
  echo FREEZE=%CD%\STAGE2A_OUTPUT\STAGE2A_FREEZE.json
)
exit /b %RC%

YHMC Stage-6A2 Y2 Blind PA Calibration v2.2.1
=================================================

Implementation-only coordinate-binding recovery of v2.2.0.

Root cause
----------
The CDS member table contains RAdeg/DEdeg, but Astroquery/VizieR may expose
the positional fields as RA_ICRS/DE_ICRS and also computed _RA.icrs/_DE.icrs.
The v2.2.0 literal RAdeg/DEdeg request was silently omitted.

Repair
------
1. Query 10 rows with columns=["**"] to discover the actual schema.
2. Prefer RA_ICRS/DE_ICRS.
3. Fall back only to computed _RA.icrs/_DE.icrs if necessary.
4. Rename the successful coordinate pair to canonical RAdeg/DEdeg.
5. Require all 1,291,929 member rows and >1.2 million finite coordinate rows.

Unchanged
---------
- Exact validated Y2 design SHA.
- N=142 Y2 candidates.
- inrj=1 and Prob>=0.5.
- q_true grid.
- N_REP=250.
- random seed.
- PA reliability thresholds.
- q_max definition.
- roundness-null definition.
- no real q, no real PA, no Galactic-plane PA, no alignment.

This patch therefore changes implementation only, not science.

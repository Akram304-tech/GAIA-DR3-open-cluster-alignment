#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-6A2 Y2 Blind PA Calibration v2.2.1

Scope
-----
Exact 0.5--2 Gyr Y2 candidate cohort authorized by the numerically validated
Stage-6A1R3 overlap-weight design.

This stage:
  1. acquires Hunt & Reffert (2024) member rows;
     v2.2.1 repairs only VizieR RA/Dec alias binding (RA_ICRS/DE_ICRS);
  2. keeps inrj=1 and Prob>=0.5;
  3. constructs only observed radial sampling + weights;
  4. runs blind synthetic PA-recovery calibration;
  5. freezes cluster-specific q_max and circular-roundness null.

This stage does NOT compute:
  - real-data q
  - real-data PA
  - Galactic-plane PA
  - Delta theta
  - alignment A
  - age-alignment contrast

The overlap weights are not used to decide morphology/calibratability.

Synthetic calibration protocol
------------------------------
q_true grid:
  1.00, .98, .96, .94, .92, .90, .85, .80, .70, .60
N_REP = 250 per q_true.

For each synthetic realization:
  - preserve observed member radius about the probability-weighted centroid;
  - preserve each membership-probability weight;
  - randomize polar angle;
  - impose q_true by minor-axis compression;
  - choose random axial PA in [0,180);
  - recover q and PA with the same weighted second central moments.

A non-circular q_true point is PA-reliable if:
  P68(|Delta PA|) <= 20 deg
  median(|Delta PA|) <= 10 deg
  |median(q_rec-q_true)| <= 0.05

q_max is the roundest q_true for which that point AND every more elongated
tested value pass. Circular q_true=1 simulations define q_round_null_p05.

No real morphology gate is applied here.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

VERSION="2.2.1"

MEMBERS_CATALOG="J/A+A/686/A42/members"

EXPECTED_VALIDATED_DESIGN_SHA="177cbd6ef1220157809a7e4585e2b85373ce49a9d50b90ff55dd7fe61102c8d3"
Q_GRID=np.array([1.00,0.98,0.96,0.94,0.92,0.90,0.85,0.80,0.70,0.60],float)
N_REP=250
BASE_SEED=20260912

PA_P68_MAX=20.0
PA_MEDIAN_MAX=10.0
Q_BIAS_ABS_MAX=0.05

def sha256(p):
    h=hashlib.sha256()
    with Path(p).open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def num(s):
    return pd.to_numeric(s,errors="coerce")

def neff(w):
    w=np.asarray(w,float)
    return float(w.sum()**2/np.square(w).sum())

def axial_diff_deg(a,b):
    d=np.abs(np.asarray(a,float)-np.asarray(b,float))%180.0
    return np.minimum(d,180.0-d)

def tangent_xy(ra,dec,ra0,dec0):
    # Small-angle local tangent-plane coordinates in degrees.
    dra=(np.asarray(ra,float)-float(ra0)+180.0)%360.0-180.0
    x=dra*np.cos(np.deg2rad(float(dec0)))
    y=np.asarray(dec,float)-float(dec0)
    return x,y

def weighted_centroid(x,y,w):
    sw=np.sum(w)
    return float(np.sum(w*x)/sw), float(np.sum(w*y)/sw)

def batch_shape_pa(x,y,w):
    """
    x,y shape (R,N); w shape (N,).
    Return q (R,), PA east of north in [0,180).
    """
    sw=float(np.sum(w))
    mx=np.sum(x*w[None,:],axis=1)/sw
    my=np.sum(y*w[None,:],axis=1)/sw
    dx=x-mx[:,None]
    dy=y-my[:,None]
    sxx=np.sum(w[None,:]*dx*dx,axis=1)/sw
    syy=np.sum(w[None,:]*dy*dy,axis=1)/sw
    sxy=np.sum(w[None,:]*dx*dy,axis=1)/sw

    mats=np.empty((len(sxx),2,2),float)
    mats[:,0,0]=sxx
    mats[:,1,1]=syy
    mats[:,0,1]=sxy
    mats[:,1,0]=sxy
    vals,vecs=np.linalg.eigh(mats)
    l2=np.maximum(vals[:,0],0.0)
    l1=np.maximum(vals[:,1],np.finfo(float).tiny)
    q=np.sqrt(l2/l1)
    v=vecs[:,:,1]
    # eigenvector sign irrelevant; axial PA east of north.
    pa=(np.degrees(np.arctan2(v[:,0],v[:,1]))%180.0)
    return q,pa

def fetch_member_columns():
    """
    Robust VizieR coordinate binding.

    The CDS ReadMe labels the member coordinates RAdeg/DEdeg, but VizieR/
    astroquery may expose the original positional columns as RA_ICRS/DE_ICRS
    and may also append computed _RA.icrs/_DE.icrs columns.

    Stage-6A2 v2.2.0 requested RAdeg/DEdeg literally; VizieR silently omitted
    them and returned only ID, Name, GaiaDR3, inrj, Prob.  This implementation
    first probes the actual all-column schema on 10 rows, then performs the
    full 1,291,929-row download with only seven columns using the coordinate
    aliases actually supported by the service.
    """
    from astroquery.vizier import Vizier

    # Lightweight schema probe.
    probe_v = Vizier(columns=["**"], row_limit=10)
    probe_v.TIMEOUT = 180
    probe_tabs = probe_v.get_catalogs(MEMBERS_CATALOG)
    if not probe_tabs:
        raise RuntimeError(f"No VizieR schema probe result for {MEMBERS_CATALOG}")
    probe = probe_tabs[0]
    probe_cols = list(map(str, probe.colnames))
    print(f"MEMBER_SCHEMA_PROBE_COLUMNS={len(probe_cols)}")
    print("MEMBER_SCHEMA_PROBE=" + ",".join(probe_cols))

    # Prefer the original catalogue coordinate field mapping; use the
    # computed ICRS coordinates only as an implementation fallback.
    coordinate_pairs = []
    if "RA_ICRS" in probe_cols and "DE_ICRS" in probe_cols:
        coordinate_pairs.append(("RA_ICRS", "DE_ICRS"))
    if "_RA.icrs" in probe_cols and "_DE.icrs" in probe_cols:
        coordinate_pairs.append(("_RA.icrs", "_DE.icrs"))

    # Some VizieR instances accept these even if the small probe labels differ.
    for pair in [("RA_ICRS","DE_ICRS"), ("_RA.icrs","_DE.icrs")]:
        if pair not in coordinate_pairs:
            coordinate_pairs.append(pair)

    errors = []
    for ra_req, de_req in coordinate_pairs:
        try:
            cols = ["ID","Name","GaiaDR3","inrj","Prob",ra_req,de_req]
            v = Vizier(columns=cols, row_limit=-1)
            v.TIMEOUT = 300
            tabs = v.get_catalogs(MEMBERS_CATALOG)
            if not tabs:
                errors.append(f"{ra_req}/{de_req}: no table")
                continue
            t = tabs[0]
            got = list(map(str, t.colnames))
            print(f"MEMBER_COORD_REQUEST={ra_req},{de_req}")
            print(f"MEMBER_ROWS_RETURNED={len(t)}")
            print("MEMBER_COLUMNS=" + ",".join(got))

            if len(t) != 1291929:
                errors.append(
                    f"{ra_req}/{de_req}: row count {len(t)} != 1291929"
                )
                continue

            df = t.to_pandas()
            df.columns = [str(c).strip() for c in df.columns]

            # Identify actual returned coordinate columns.
            ra_candidates = [
                ra_req, "RA_ICRS", "_RA.icrs", "RAdeg"
            ]
            de_candidates = [
                de_req, "DE_ICRS", "_DE.icrs", "DEdeg"
            ]
            ra_got = next((c for c in ra_candidates if c in df.columns), None)
            de_got = next((c for c in de_candidates if c in df.columns), None)
            if ra_got is None or de_got is None:
                errors.append(
                    f"{ra_req}/{de_req}: coordinates absent in returned {got}"
                )
                continue

            # Canonical names expected by all downstream Stage-6A2 logic.
            df = df.rename(columns={ra_got:"RAdeg", de_got:"DEdeg"})

            required = ["ID","Name","GaiaDR3","inrj","Prob","RAdeg","DEdeg"]
            miss = [c for c in required if c not in df.columns]
            if miss:
                errors.append(f"{ra_req}/{de_req}: canonical miss {miss}")
                continue

            # Numeric coordinate sanity before science-neutral use.
            ra_num = pd.to_numeric(df["RAdeg"], errors="coerce")
            de_num = pd.to_numeric(df["DEdeg"], errors="coerce")
            finite = np.isfinite(ra_num) & np.isfinite(de_num)
            nfinite = int(finite.sum())
            print(f"MEMBER_COORD_SOURCE={ra_got},{de_got}")
            print(f"MEMBER_FINITE_COORD_ROWS={nfinite}")
            if nfinite < 1200000:
                errors.append(
                    f"{ra_req}/{de_req}: unexpectedly low finite coordinates {nfinite}"
                )
                continue

            df["RAdeg"] = ra_num
            df["DEdeg"] = de_num
            return df

        except Exception as e:
            errors.append(f"{ra_req}/{de_req}: {repr(e)}")

    raise RuntimeError(
        "Could not bind member ICRS coordinates after schema probe. "
        + " | ".join(errors)
    )

def calibrate_one(cid,r,w):
    cid=int(cid)
    r=np.asarray(r,float)
    w=np.asarray(w,float)

    rows=[]
    reliable={}
    round_p05=np.nan

    # Deterministic per-cluster independent stream.
    ss=np.random.SeedSequence([BASE_SEED,cid,220])
    child=ss.spawn(len(Q_GRID))

    for iq,qtrue in enumerate(Q_GRID):
        rng=np.random.default_rng(child[iq])
        # R x N random polar angles and R random true PAs.
        phi=rng.uniform(0.0,2.0*np.pi,size=(N_REP,len(r)))
        pa_true=rng.uniform(0.0,180.0,size=N_REP)
        pa_rad=np.deg2rad(pa_true)

        u=r[None,:]*np.cos(phi)
        v=(qtrue*r)[None,:]*np.sin(phi)

        # Major-axis unit=(sin PA, cos PA), minor=(cos PA,-sin PA)
        sp=np.sin(pa_rad)[:,None]
        cp=np.cos(pa_rad)[:,None]
        x=u*sp+v*cp
        y=u*cp-v*sp

        qrec,parec=batch_shape_pa(x,y,w)
        dpa=axial_diff_deg(parec,pa_true)

        med_pa=float(np.median(dpa))
        p68_pa=float(np.percentile(dpa,68))
        med_q_bias=float(np.median(qrec-qtrue))
        pass_here=bool(
            (qtrue<1.0) and
            (p68_pa<=PA_P68_MAX) and
            (med_pa<=PA_MEDIAN_MAX) and
            (abs(med_q_bias)<=Q_BIAS_ABS_MAX)
        )

        if qtrue==1.0:
            round_p05=float(np.percentile(qrec,5))

        rows.append({
            "ID":cid,
            "q_true":float(qtrue),
            "N_rep":N_REP,
            "median_abs_PA_error_deg":med_pa,
            "p68_abs_PA_error_deg":p68_pa,
            "median_q_bias":med_q_bias,
            "abs_median_q_bias":abs(med_q_bias),
            "individual_PA_reliable":pass_here if qtrue<1.0 else False,
            "qrec_median":float(np.median(qrec)),
            "qrec_p05":float(np.percentile(qrec,5)),
            "qrec_p95":float(np.percentile(qrec,95)),
        })
        if qtrue<1.0:
            reliable[float(qtrue)]=pass_here

    # qmax requires q and every MORE ELONGATED tested q (smaller q) to pass.
    noncirc=sorted([float(q) for q in Q_GRID if q<1.0])
    valid=[]
    for q in noncirc:
        subset=[qq for qq in noncirc if qq<=q]
        if all(reliable.get(qq,False) for qq in subset):
            valid.append(q)
    qmax=max(valid) if valid else np.nan

    return rows,qmax,round_p05

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage6a1r3",required=True)
    ap.add_argument("--out",default="STAGE6A2_OUTPUT")
    args=ap.parse_args()

    s=Path(args.stage6a1r3).resolve()
    out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=True)

    design=s/"05_NUMERICALLY_VALIDATED_OVERLAP_DESIGN.csv"
    if not design.exists():
        raise FileNotFoundError(design)
    if sha256(design)!=EXPECTED_VALIDATED_DESIGN_SHA:
        raise RuntimeError(
            f"Validated design hash mismatch: {sha256(design)}"
        )

    d=pd.read_csv(design)
    y2=d[d["cohort"].astype(str)=="Y2_0p5_2G"].copy()
    if len(y2)!=142:
        raise RuntimeError(f"Expected exact Y2 N=142, found {len(y2)}.")
    y2["ID"]=pd.to_numeric(y2["ID"],errors="raise").astype(int)
    if y2["ID"].duplicated().any():
        raise RuntimeError("Duplicate Y2 cluster ID in validated design.")
    y2.to_csv(out/"00_Y2_CANDIDATES_EXACT_FROZEN.csv",index=False)
    hy2=sha256(out/"00_Y2_CANDIDATES_EXACT_FROZEN.csv")

    print("="*108)
    print(f"YHMC STAGE-6A2 Y2 BLIND PA CALIBRATION v{VERSION}")
    print("="*108)
    print("NO_REAL_Q=True")
    print("NO_REAL_PA=True")
    print("NO_GALACTIC_PLANE_PA=True")
    print("NO_ALIGNMENT=True")
    print(f"VALIDATED_DESIGN_SHA256={EXPECTED_VALIDATED_DESIGN_SHA}")
    print(f"Y2_EXACT_N={len(y2)}")
    print(f"Y2_EXACT_SHA256={hy2}")

    members=fetch_member_columns()
    # Normalize.
    required=["ID","Name","inrj","Prob","RAdeg","DEdeg"]
    miss=[c for c in required if c not in members.columns]
    if miss:
        raise RuntimeError(f"Member table missing required columns {miss}")
    members["ID"]=pd.to_numeric(members["ID"],errors="coerce")
    members["inrj"]=pd.to_numeric(members["inrj"],errors="coerce")
    members["Prob"]=pd.to_numeric(members["Prob"],errors="coerce")
    members["RAdeg"]=pd.to_numeric(members["RAdeg"],errors="coerce")
    members["DEdeg"]=pd.to_numeric(members["DEdeg"],errors="coerce")
    if "GaiaDR3" in members.columns:
        members["GaiaDR3"]=members["GaiaDR3"].astype(str)

    ids=set(y2["ID"].tolist())
    m=members[members["ID"].isin(ids)].copy()
    if m.empty:
        raise RuntimeError("No member rows matched Y2 IDs.")
    # Preserve only required Y2 member snapshot.
    m.to_csv(out/"01_Y2_MEMBER_ROWS_RAW.csv",index=False)

    sel=m[
        (m["inrj"]==1) &
        (m["Prob"]>=0.5) &
        np.isfinite(m["Prob"]) &
        np.isfinite(m["RAdeg"]) &
        np.isfinite(m["DEdeg"])
    ].copy()
    sel.to_csv(out/"02_Y2_MEMBERS_BASELINE_INRJ1_PGE0p5.csv",index=False)
    hm=sha256(out/"02_Y2_MEMBERS_BASELINE_INRJ1_PGE0p5.csv")

    summary=[]
    gridrows=[]

    # Cluster-by-cluster blind calibration.
    for k,row in y2.sort_values("ID").reset_index(drop=True).iterrows():
        cid=int(row["ID"])
        name=str(row.get("Name_catalog",""))
        g=sel[sel["ID"]==cid].copy()

        n=len(g)
        status="PASS"
        message=""
        qmax=np.nan
        roundp05=np.nan
        n_eff=np.nan
        medr=np.nan
        p90r=np.nan

        if n<3:
            status="FAIL_INSUFFICIENT_MEMBERS"
            message=f"N={n}<3"
        else:
            w=g["Prob"].to_numpy(float)
            ra=g["RAdeg"].to_numpy(float)
            dec=g["DEdeg"].to_numpy(float)

            # Stable projection center: probability-weighted circular RA is overkill
            # for cluster scales; use the member median as a projection origin,
            # then compute the weighted centroid in the tangent plane.
            ra0=float(np.median(ra))
            dec0=float(np.median(dec))
            x,y=tangent_xy(ra,dec,ra0,dec0)
            cx,cy=weighted_centroid(x,y,w)
            r=np.sqrt((x-cx)**2+(y-cy)**2)
            n_eff=neff(w)
            medr=float(np.median(r))
            p90r=float(np.percentile(r,90))

            if not np.all(np.isfinite(r)) or n_eff<=2.0:
                status="FAIL_NUMERIC_MEMBER_GEOMETRY"
                message=f"N_eff={n_eff}"
            else:
                rows,qmax,roundp05=calibrate_one(cid,r,w)
                for rr in rows:
                    rr["Name"]=name
                    rr["N_members"]=n
                    rr["N_eff"]=n_eff
                gridrows.extend(rows)

        summary.append({
            "ID":cid,
            "Name":name,
            "MassJ":float(row["MassJ"]),
            "logAge50":float(row["logAge50"]),
            "overlap_weight_norm":float(row["overlap_weight_norm"]),
            "N_members_baseline":int(n),
            "N_eff":n_eff,
            "median_radius_deg_blind":medr,
            "p90_radius_deg_blind":p90r,
            "calibration_status":status,
            "PA_CALIBRATABLE":bool(np.isfinite(qmax)),
            "q_max_PA_reliable":qmax,
            "q_round_null_p05":roundp05,
            "message":message,
        })

        if (k+1)%10==0 or k+1==len(y2):
            print(f"CALIBRATED={k+1}/{len(y2)} ID={cid} status={status} qmax={qmax}")

    sdf=pd.DataFrame(summary)
    gdf=pd.DataFrame(gridrows)

    sdf.to_csv(out/"03_Y2_BLIND_CALIBRATION_SUMMARY_FROZEN.csv",index=False)
    gdf.to_csv(out/"04_Y2_BLIND_CALIBRATION_GRID.csv",index=False)

    n_pass=int((sdf["calibration_status"]=="PASS").sum())
    n_cal=int(sdf["PA_CALIBRATABLE"].sum())

    cov=[]
    for mt in [1000,3000,5000,10000]:
        x=sdf[sdf["MassJ"]>=mt]
        xc=x[x["PA_CALIBRATABLE"]==True]
        cov.append({
            "MassJ_threshold":mt,
            "N_candidates":len(x),
            "N_calibration_PASS":int((x["calibration_status"]=="PASS").sum()),
            "N_PA_calibratable":len(xc),
            "median_N_members":float(x["N_members_baseline"].median()) if len(x) else np.nan,
            "median_N_eff":float(x["N_eff"].median()) if len(x) else np.nan,
            "median_qmax":float(xc["q_max_PA_reliable"].median()) if len(xc) else np.nan,
        })
    cdf=pd.DataFrame(cov)
    cdf.to_csv(out/"05_Y2_BLIND_CALIBRATION_COVERAGE.csv",index=False)

    hs=sha256(out/"03_Y2_BLIND_CALIBRATION_SUMMARY_FROZEN.csv")
    hg=sha256(out/"04_Y2_BLIND_CALIBRATION_GRID.csv")

    contract={
        "stage":"STAGE6A2_Y2_BLIND_PA_CALIBRATION",
        "version":VERSION,
        "validated_overlap_design_sha256":EXPECTED_VALIDATED_DESIGN_SHA,
        "Y2_exact_n":142,
        "Y2_exact_sha256":hy2,
        "baseline_member_rule":"inrj=1 and Prob>=0.5",
        "member_snapshot_sha256":hm,
        "q_grid":Q_GRID.tolist(),
        "N_REP_per_q":N_REP,
        "base_seed":BASE_SEED,
        "reliability_rules":{
            "p68_abs_PA_error_deg_le":PA_P68_MAX,
            "median_abs_PA_error_deg_le":PA_MEDIAN_MAX,
            "abs_median_q_bias_le":Q_BIAS_ABS_MAX,
            "qmax_monotonic_more_elongated_required":True,
        },
        "real_q_computed":False,
        "real_PA_computed":False,
        "galactic_plane_PA_computed":False,
        "alignment_computed":False,
        "N_calibration_PASS":n_pass,
        "N_PA_calibratable":n_cal,
        "calibration_summary_sha256":hs,
        "calibration_grid_sha256":hg,
        "next":
            "Run Stage-6A3 real Y2 morphology freeze using only these pre-frozen calibration gates. Do not compute Galactic alignment."
    }
    (out/"STAGE6A2_FREEZE.json").write_text(json.dumps(contract,indent=2),encoding="utf-8")

    report=[
        f"YHMC STAGE-6A2 Y2 BLIND PA CALIBRATION v{VERSION}",
        "="*108,
        "NO_REAL_Q=True",
        "NO_REAL_PA=True",
        "NO_GALACTIC_PLANE_PA=True",
        "NO_ALIGNMENT=True",
        f"Y2_EXACT_N={len(sdf)}",
        f"Y2_MEMBER_ROWS_SELECTED={len(sel)}",
        f"N_CALIBRATION_PASS={n_pass}",
        f"N_PA_CALIBRATABLE={n_cal}",
        "",
        "MASS COVERAGE:",
        cdf.to_string(index=False),
        "",
        f"Y2_EXACT_SHA256={hy2}",
        f"MEMBER_SNAPSHOT_SHA256={hm}",
        f"CALIBRATION_SUMMARY_SHA256={hs}",
        f"CALIBRATION_GRID_SHA256={hg}",
        "",
        "NEXT:",
        "  Stage-6A3 real morphology freeze only.",
        "  Galactic-plane PA / Delta theta / alignment remain CLOSED.",
    ]
    (out/"STAGE6A2_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")

    print()
    print((out/"STAGE6A2_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

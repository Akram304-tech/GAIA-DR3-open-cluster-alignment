@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-6A2 Y2 BLIND PA CALIBRATION v2.2.1
echo COORDINATE-BINDING RECOVERY / NO REAL Q / NO ALIGNMENT
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" exit /b 1

set "STAGE6A1R3=%USERPROFILE%\Downloads\YHMC_STAGE6A1R3_NUMERICAL_SOLVER_ADJUDICATION_v2_1_3\YHMC_STAGE6A1R3_NUMERICAL_SOLVER_ADJUDICATION_v2_1_3\STAGE6A1R3_OUTPUT"

"%PYEXE%" -c "import numpy,pandas,astroquery,astropy" >nul 2>nul
if errorlevel 1 (
  "%PYEXE%" -m pip install numpy pandas astropy astroquery
  if errorlevel 1 exit /b 1
)

"%PYEXE%" stage6a2_y2_blind_pa_calibration_v2_2_1.py ^
 --stage6a1r3 "%STAGE6A1R3%" ^
 --out "%CD%\STAGE6A2_OUTPUT"

set "RC=%ERRORLEVEL%"
echo.
echo RETURN_CODE=%RC%
if "%RC%"=="0" (
 echo REPORT=%CD%\STAGE6A2_OUTPUT\STAGE6A2_REPORT.txt
 echo CALIBRATION=%CD%\STAGE6A2_OUTPUT\03_Y2_BLIND_CALIBRATION_SUMMARY_FROZEN.csv
 echo FREEZE=%CD%\STAGE6A2_OUTPUT\STAGE6A2_FREEZE.json
)
exit /b %RC%

YHMC Stage-6B2R1 Fast-MC Orbit-Proxy Production v2.3.2
========================================================

This is the authorized performance recovery after Stage-6B2R0 PASS.

UNCHANGED PRIMARY SCIENCE:
- exact 45-object Stage-6B1 primary sample;
- McMillan17 primary potential;
- full numerical 1-Gyr nominal orbit;
- primary metric rperi;
- X_peri = -log(rperi/kpc).

PERFORMANCE AMENDMENT ONLY:
- 512-draw phase-space uncertainty layer uses galpy Staeckel analytic
  characterization validated against the 12 numerical Stage-6B0R1 orbits.

Production:
- nominal rows: 135;
- MC rows: 69120;
- checkpoint per object x potential.

Alignment firewall:
No PA or alignment file is read.
No association statistic is computed.

When ORBIT_PROXY_FREEZE_PASS=True, Stage-6B3 may perform the pre-specified
alignment/orbit association analysis.

@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-6B2R1 FAST-MC ORBIT-PROXY PRODUCTION v2.3.2
echo NUMERICAL NOMINAL + VALIDATED FAST MC / NO ALIGNMENT
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" exit /b 1

set "STAGE6B1=%USERPROFILE%\Downloads\YHMC_STAGE6B1_ORBIT_MECHANISM_DESIGN_FREEZE_v2_2_0\YHMC_STAGE6B1_ORBIT_MECHANISM_DESIGN_FREEZE_v2_2_0\STAGE6B1_OUTPUT"
set "STAGE6B2R0=%USERPROFILE%\Downloads\YHMC_STAGE6B2R0_FAST_MC_METHOD_ADJUDICATION_v2_3_1\YHMC_STAGE6B2R0_FAST_MC_METHOD_ADJUDICATION_v2_3_1\STAGE6B2R0_OUTPUT"

"%PYEXE%" -c "import numpy,pandas,astropy,galpy" >nul 2>nul
if errorlevel 1 exit /b 1

"%PYEXE%" stage6b2r1_fast_mc_orbit_proxy_production_v2_3_2.py ^
 --stage6b1 "%STAGE6B1%" ^
 --stage6b2r0 "%STAGE6B2R0%" ^
 --out "%CD%\STAGE6B2R1_OUTPUT"

set "RC=%ERRORLEVEL%"
echo.
echo RETURN_CODE=%RC%
if exist "%CD%\STAGE6B2R1_OUTPUT\STAGE6B2R1_REPORT.txt" echo REPORT=%CD%\STAGE6B2R1_OUTPUT\STAGE6B2R1_REPORT.txt
if exist "%CD%\STAGE6B2R1_OUTPUT\STAGE6B2R1_FREEZE.json" echo FREEZE=%CD%\STAGE6B2R1_OUTPUT\STAGE6B2R1_FREEZE.json
if exist "%CD%\STAGE6B2R1_OUTPUT\04_PRIMARY_ORBIT_PROXY_SUMMARY_FROZEN.csv" echo SUMMARY=%CD%\STAGE6B2R1_OUTPUT\04_PRIMARY_ORBIT_PROXY_SUMMARY_FROZEN.csv
exit /b %RC%

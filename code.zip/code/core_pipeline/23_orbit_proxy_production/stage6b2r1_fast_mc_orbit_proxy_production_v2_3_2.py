#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-6B2R1 Fast-MC Orbit-Proxy Production v2.3.2

FULL PRIMARY ORBIT PRODUCTION AFTER STAGE-6B2R0 PERFORMANCE ADJUDICATION.

SCIENCE DESIGN UNCHANGED
------------------------
Primary sample:
  exact Stage-6B1 45 high-mass morphology-resolved 6D clusters.

Potentials:
  McMillan17 (PRIMARY)
  Irrgang13III
  MWPotential2014

Nominal science orbits:
  FULL numerical 1-Gyr integration, 2001 output times.
  rperi, rap, eccentricity, zmax.
  X_peri = -log(rperi/kpc).

Phase-space uncertainty:
  512 deterministic draws/object/potential.
  Same Stage-6B1 uncertainty model.
  ONLY this secondary uncertainty layer uses the independently validated
  galpy Staeckel analytic orbit characterization authorized by Stage-6B2R0.

Alignment firewall:
  NO PA/alignment file is read.
  NO Delta theta, cos(2 Delta theta), A, correlation, regression, or p-value
  is computed.

Checkpointing:
  Each object x potential cell is saved atomically.
  Reruns reuse validated complete cells.

Acceptance:
  nominal rows = 45 x 3 = 135, all physical;
  MC rows = 45 x 3 x 512 = 69120, all physical;
  exactly 512 MC rows per object x potential.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

VERSION="2.3.2"

EXPECTED_PRIMARY_SHA="46e1c9fa4ab1ff8d557d3aa2f38dd61bd05de0a3abe0664f6e57f4434a634c46"
EXPECTED_PRIMARY_N=45
EXPECTED_YOUNG_N=22
EXPECTED_CONTROL_N=23

N_MC=512
BASE_SEED=20260912
HORIZON_GYR=1.0
N_TIME=2001

POTENTIAL_NAMES=["McMillan17","Irrgang13III","MWPotential2014"]
PRIMARY_POTENTIAL="McMillan17"

Z_SUN_KPC=0.0208
SOLAR_MOTION=[11.1,12.24,7.25]

def sha256(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def num(x):
    return pd.to_numeric(x,errors="coerce")

def atomic_csv(df,path):
    path=Path(path)
    tmp=path.with_suffix(path.suffix+".tmp")
    df.to_csv(tmp,index=False)
    os.replace(tmp,path)

def physical_ok(rp,ra,e,z):
    rp=np.asarray(rp,float)
    ra=np.asarray(ra,float)
    e=np.asarray(e,float)
    z=np.asarray(z,float)
    return (
        np.isfinite(rp)&np.isfinite(ra)&np.isfinite(e)&np.isfinite(z)&
        (rp>0)&(ra>=rp)&(e>=0)&(e<1)&(z>=0)
    )

def sample_split_normal_distance(rng,d16,d50,d84,n):
    lo=float(d50-d16)
    hi=float(d84-d50)
    if not (d16>0 and d16<d50<d84 and lo>0 and hi>0):
        raise RuntimeError("Invalid distance quantiles.")
    out=np.empty(n,float)
    filled=0
    while filled<n:
        z=rng.normal(size=max(64,n-filled))
        sig=np.where(z<0,lo,hi)
        vals=(d50+z*sig)
        vals=vals[vals>0]
        take=min(len(vals),n-filled)
        if take:
            out[filled:filled+take]=vals[:take]
            filled+=take
    return out

def numeric_nominal(sc,pot,ro,vo,t_internal):
    from galpy.orbit import Orbit

    o=Orbit(sc,ro=ro,vo=vo,zo=Z_SUN_KPC,solarmotion=SOLAR_MOTION)
    method="dop853_c"
    fallback=False
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            o.integrate(t_internal,pot,method="dop853_c",progressbar=False)
    except Exception:
        fallback=True
        method="dop853"
        o=Orbit(sc,ro=ro,vo=vo,zo=Z_SUN_KPC,solarmotion=SOLAR_MOTION)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            o.integrate(t_internal,pot,method="dop853",progressbar=False)

    rp=float(np.asarray(o.rperi(use_physical=True)))
    ra=float(np.asarray(o.rap(use_physical=True)))
    ec=float(np.asarray(o.e()))
    zm=float(np.asarray(o.zmax(use_physical=True)))
    return rp,ra,ec,zm,method,fallback

def fast_mc_metrics(sc,pot,ro,vo):
    from galpy.orbit import Orbit

    o=Orbit(sc,ro=ro,vo=vo,zo=Z_SUN_KPC,solarmotion=SOLAR_MOTION)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        rp=np.atleast_1d(np.asarray(
            o.rperi(analytic=True,pot=pot,type="staeckel",use_physical=True),
            float
        ))
        ra=np.atleast_1d(np.asarray(
            o.rap(analytic=True,pot=pot,type="staeckel",use_physical=True),
            float
        ))
        ec=np.atleast_1d(np.asarray(
            o.e(analytic=True,pot=pot,type="staeckel"),
            float
        ))
        zm=np.atleast_1d(np.asarray(
            o.zmax(analytic=True,pot=pot,type="staeckel",use_physical=True),
            float
        ))
    return rp,ra,ec,zm

def checkpoint_valid(path,cid,pname):
    p=Path(path)
    if not p.exists():
        return False
    try:
        d=pd.read_csv(p)
        req=[
            "ID","potential","draw_index",
            "rperi_kpc","rap_kpc","eccentricity","zmax_kpc","X_peri"
        ]
        if any(c not in d.columns for c in req):
            return False
        if len(d)!=N_MC:
            return False
        if not (pd.to_numeric(d["ID"],errors="coerce")==int(cid)).all():
            return False
        if not (d["potential"].astype(str)==str(pname)).all():
            return False
        di=pd.to_numeric(d["draw_index"],errors="coerce").astype(int)
        if di.tolist()!=list(range(N_MC)):
            return False
        ok=physical_ok(
            d["rperi_kpc"],d["rap_kpc"],
            d["eccentricity"],d["zmax_kpc"]
        )
        if not np.all(ok):
            return False
        xx=-np.log(pd.to_numeric(d["rperi_kpc"],errors="coerce").to_numpy(float))
        xo=pd.to_numeric(d["X_peri"],errors="coerce").to_numpy(float)
        if not np.allclose(xx,xo,rtol=0,atol=1e-12):
            return False
        return True
    except Exception:
        return False

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage6b1",required=True)
    ap.add_argument("--stage6b2r0",required=True)
    ap.add_argument("--out",default="STAGE6B2R1_OUTPUT")
    args=ap.parse_args()

    s1=Path(args.stage6b1).resolve()
    s0=Path(args.stage6b2r0).resolve()
    out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=True)
    chk=out/"CHECKPOINTS"
    chk.mkdir(parents=True,exist_ok=True)

    primary_f=s1/"01_PRIMARY_HIGH_MASS_6D_SAMPLE_FROZEN.csv"
    design_f=s1/"STAGE6B1_DESIGN_FREEZE.json"
    adjud_f=s0/"STAGE6B2R0_ADJUDICATION.json"

    for p in [primary_f,design_f,adjud_f]:
        if not p.exists():
            raise FileNotFoundError(p)

    if sha256(primary_f)!=EXPECTED_PRIMARY_SHA:
        raise RuntimeError("Stage-6B1 primary sample hash mismatch.")

    design=json.loads(design_f.read_text(encoding="utf-8"))
    adjud=json.loads(adjud_f.read_text(encoding="utf-8"))

    if not bool(adjud.get("FAST_MC_METHOD_AUTHORIZED",False)):
        raise RuntimeError("Stage-6B2R0 did not authorize Staeckel fast MC.")
    if bool(adjud.get("alignment_read",True)):
        raise RuntimeError("Stage-6B2R0 alignment firewall invariant violated.")

    d=pd.read_csv(primary_f)
    d["ID"]=pd.to_numeric(d["ID"],errors="raise").astype(int)

    if len(d)!=EXPECTED_PRIMARY_N:
        raise RuntimeError(f"Expected primary N=45, got {len(d)}.")
    if int((d["sample"].astype(str)=="young").sum())!=EXPECTED_YOUNG_N:
        raise RuntimeError("Young count mismatch.")
    if int((d["sample"].astype(str)=="control").sum())!=EXPECTED_CONTROL_N:
        raise RuntimeError("Control count mismatch.")
    if d["ID"].duplicated().any():
        raise RuntimeError("Duplicate primary IDs.")
    if not d["MC_READY"].astype(bool).all():
        raise RuntimeError("All primary objects must be MC-ready.")

    import astropy.units as u
    from astropy.coordinates import SkyCoord
    import galpy
    from galpy.util import conversion
    from galpy.potential.mwpotentials import McMillan17, Irrgang13III
    from galpy.potential import MWPotential2014

    pots={
        "McMillan17":McMillan17,
        "Irrgang13III":Irrgang13III,
        "MWPotential2014":MWPotential2014,
    }

    scales={}
    scale_rows=[]
    for pname,pot in pots.items():
        ph=conversion.get_physical(pot,include_set=True)
        ro=float(ph["ro"])
        vo=float(ph["vo"])
        tu=float(conversion.time_in_Gyr(vo=vo,ro=ro))
        scales[pname]=(ro,vo,tu)
        scale_rows.append({
            "potential":pname,
            "ro_kpc":ro,
            "vo_kms":vo,
            "time_unit_Gyr":tu,
            "roSet":bool(ph.get("roSet",False)),
            "voSet":bool(ph.get("voSet",False)),
        })
    scale_df=pd.DataFrame(scale_rows)
    scale_df.to_csv(out/"00_POTENTIAL_PHYSICAL_SCALES.csv",index=False)

    print("="*112)
    print(f"YHMC STAGE-6B2R1 FAST-MC ORBIT-PROXY PRODUCTION v{VERSION}")
    print("="*112)
    print("ALIGNMENT_READ=False")
    print("CORRELATION_COMPUTED=False")
    print("NOMINAL_METHOD=FULL_NUMERICAL_1GYR")
    print("MC_METHOD=VALIDATED_STAECKEL_ANALYTIC")
    print("PRIMARY_SAMPLE_N=45")
    print("N_MC=512")
    print("EXPECTED_NOMINAL_ROWS=135")
    print("EXPECTED_MC_ROWS=69120")
    print(f"GALPY_VERSION={getattr(galpy,'__version__','UNKNOWN')}")
    print()

    nominal_rows=[]
    cell_rows=[]
    total_cells=len(d)*len(POTENTIAL_NAMES)
    kcell=0

    for _,r in d.sort_values(["sample","ID"]).iterrows():
        cid=int(r["ID"])
        sample=str(r["sample"])
        name=str(r.get("Name_frozen",r.get("Name_catalog","")))

        sc_nom=SkyCoord(
            ra=float(r["RA_ICRS"])*u.deg,
            dec=float(r["DE_ICRS"])*u.deg,
            distance=float(r["dist50"])*u.pc,
            pm_ra_cosdec=float(r["pmRA"])*u.mas/u.yr,
            pm_dec=float(r["pmDE"])*u.mas/u.yr,
            radial_velocity=float(r["RV"])*u.km/u.s,
            frame="icrs",
        )

        for pidx,pname in enumerate(POTENTIAL_NAMES):
            kcell+=1
            pot=pots[pname]
            ro,vo,tu=scales[pname]
            tt=np.linspace(0.0,HORIZON_GYR,N_TIME)/tu

            # Full numerical nominal orbit.
            rp0,ra0,ec0,zm0,method,fallback=numeric_nominal(
                sc_nom,pot,ro,vo,tt
            )
            if not bool(physical_ok([rp0],[ra0],[ec0],[zm0])[0]):
                raise RuntimeError(f"Nonphysical nominal ID={cid} {pname}")

            nominal_rows.append({
                "sample":sample,
                "ID":cid,
                "Name":name,
                "potential":pname,
                "potential_ro_kpc":ro,
                "potential_vo_kms":vo,
                "integration_method":method,
                "used_python_fallback":fallback,
                "rperi_kpc":rp0,
                "rap_kpc":ra0,
                "eccentricity":ec0,
                "zmax_kpc":zm0,
                "X_peri":float(-np.log(rp0)),
            })

            cp=chk/f"MC_ID{cid:05d}_{pname}.csv"

            if checkpoint_valid(cp,cid,pname):
                mcdf=pd.read_csv(cp)
                reused=True
                print(
                    f"CELL={kcell}/{total_cells} ID={cid} {pname} "
                    f"NOMINAL_DONE MC_CHECKPOINT_REUSED rows=512",
                    flush=True
                )
            else:
                reused=False
                rng=np.random.default_rng(
                    np.random.SeedSequence([BASE_SEED,cid,pidx,232])
                )

                dist=sample_split_normal_distance(
                    rng,
                    float(r["dist16"]),float(r["dist50"]),float(r["dist84"]),
                    N_MC
                )
                pmra=rng.normal(
                    float(r["pmRA"]),float(r["e_pmRA"]),size=N_MC
                )
                pmde=rng.normal(
                    float(r["pmDE"]),float(r["e_pmDE"]),size=N_MC
                )
                rv=rng.normal(
                    float(r["RV"]),float(r["e_RV"]),size=N_MC
                )

                sc=SkyCoord(
                    ra=np.full(N_MC,float(r["RA_ICRS"]))*u.deg,
                    dec=np.full(N_MC,float(r["DE_ICRS"]))*u.deg,
                    distance=dist*u.pc,
                    pm_ra_cosdec=pmra*u.mas/u.yr,
                    pm_dec=pmde*u.mas/u.yr,
                    radial_velocity=rv*u.km/u.s,
                    frame="icrs",
                )

                rp,ra,ec,zm=fast_mc_metrics(sc,pot,ro,vo)
                if not (
                    len(rp)==len(ra)==len(ec)==len(zm)==N_MC
                ):
                    raise RuntimeError(
                        f"Fast MC shape mismatch ID={cid} {pname}: "
                        f"{len(rp)},{len(ra)},{len(ec)},{len(zm)}"
                    )
                ok=physical_ok(rp,ra,ec,zm)
                if not np.all(ok):
                    bad=np.where(~ok)[0].tolist()[:10]
                    raise RuntimeError(
                        f"Nonphysical fast MC ID={cid} {pname}, bad={bad}"
                    )

                mcdf=pd.DataFrame({
                    "sample":sample,
                    "ID":cid,
                    "Name":name,
                    "potential":pname,
                    "draw_index":np.arange(N_MC,dtype=int),
                    "distance_pc":dist,
                    "pmRA_masyr":pmra,
                    "pmDE_masyr":pmde,
                    "RV_kms":rv,
                    "rperi_kpc":rp,
                    "rap_kpc":ra,
                    "eccentricity":ec,
                    "zmax_kpc":zm,
                    "X_peri":-np.log(rp),
                    "orbit_method":"staeckel_analytic",
                })
                atomic_csv(mcdf,cp)
                if not checkpoint_valid(cp,cid,pname):
                    raise RuntimeError(
                        f"Checkpoint self-validation failed: {cp}"
                    )
                print(
                    f"CELL={kcell}/{total_cells} ID={cid} {pname} "
                    f"NOMINAL_DONE MC_FAST_DONE rows=512",
                    flush=True
                )

            cell_rows.append({
                "sample":sample,
                "ID":cid,
                "Name":name,
                "potential":pname,
                "checkpoint_file":cp.name,
                "checkpoint_sha256":sha256(cp),
                "N_MC_rows":N_MC,
                "reused_checkpoint":reused,
                "rperi_mc16":float(np.percentile(mcdf["rperi_kpc"],16)),
                "rperi_mc50":float(np.percentile(mcdf["rperi_kpc"],50)),
                "rperi_mc84":float(np.percentile(mcdf["rperi_kpc"],84)),
                "rap_mc16":float(np.percentile(mcdf["rap_kpc"],16)),
                "rap_mc50":float(np.percentile(mcdf["rap_kpc"],50)),
                "rap_mc84":float(np.percentile(mcdf["rap_kpc"],84)),
                "ecc_mc16":float(np.percentile(mcdf["eccentricity"],16)),
                "ecc_mc50":float(np.percentile(mcdf["eccentricity"],50)),
                "ecc_mc84":float(np.percentile(mcdf["eccentricity"],84)),
                "zmax_mc16":float(np.percentile(mcdf["zmax_kpc"],16)),
                "zmax_mc50":float(np.percentile(mcdf["zmax_kpc"],50)),
                "zmax_mc84":float(np.percentile(mcdf["zmax_kpc"],84)),
                "Xperi_mc16":float(np.percentile(mcdf["X_peri"],16)),
                "Xperi_mc50":float(np.percentile(mcdf["X_peri"],50)),
                "Xperi_mc84":float(np.percentile(mcdf["X_peri"],84)),
            })

    nominal=pd.DataFrame(nominal_rows).sort_values(
        ["sample","ID","potential"]
    ).reset_index(drop=True)
    cells=pd.DataFrame(cell_rows).sort_values(
        ["sample","ID","potential"]
    ).reset_index(drop=True)

    if len(nominal)!=EXPECTED_PRIMARY_N*3:
        raise RuntimeError("Nominal row count mismatch.")
    if not np.all(physical_ok(
        nominal["rperi_kpc"],nominal["rap_kpc"],
        nominal["eccentricity"],nominal["zmax_kpc"]
    )):
        raise RuntimeError("Nominal physical validation failed.")

    nominal.to_csv(out/"01_PRIMARY_NOMINAL_ORBIT_PROXIES_FROZEN.csv",index=False)
    cells.to_csv(out/"02_MC_CELL_SUMMARY_AND_HASHES.csv",index=False)

    frames=[]
    for _,rr in cells.iterrows():
        cp=chk/str(rr["checkpoint_file"])
        if sha256(cp)!=str(rr["checkpoint_sha256"]):
            raise RuntimeError(f"Checkpoint hash drift: {cp}")
        frames.append(pd.read_csv(cp))

    mc=pd.concat(frames,ignore_index=True).sort_values(
        ["sample","ID","potential","draw_index"]
    ).reset_index(drop=True)

    expected=EXPECTED_PRIMARY_N*3*N_MC
    if len(mc)!=expected:
        raise RuntimeError(f"Expected MC rows {expected}, got {len(mc)}.")
    if not np.all(physical_ok(
        mc["rperi_kpc"],mc["rap_kpc"],
        mc["eccentricity"],mc["zmax_kpc"]
    )):
        raise RuntimeError("MC physical validation failed.")

    counts=mc.groupby(["ID","potential"]).size()
    if len(counts)!=EXPECTED_PRIMARY_N*3 or not (counts==N_MC).all():
        raise RuntimeError("MC cell completeness failure.")

    mc.to_csv(out/"03_PRIMARY_MC_ORBIT_PROXY_DRAWS_FROZEN.csv",index=False)

    dropcols=["checkpoint_file","checkpoint_sha256","N_MC_rows","reused_checkpoint"]
    summary=nominal.merge(
        cells.drop(columns=dropcols),
        on=["sample","ID","Name","potential"],
        how="left",validate="one_to_one"
    )
    summary.to_csv(out/"04_PRIMARY_ORBIT_PROXY_SUMMARY_FROZEN.csv",index=False)

    spread=[]
    for (sample,cid,name),g in nominal.groupby(["sample","ID","Name"]):
        spread.append({
            "sample":sample,
            "ID":int(cid),
            "Name":name,
            "rperi_min_kpc":float(g["rperi_kpc"].min()),
            "rperi_max_kpc":float(g["rperi_kpc"].max()),
            "rperi_frac_range_over_mean":
                float((g["rperi_kpc"].max()-g["rperi_kpc"].min())/
                      g["rperi_kpc"].mean()),
            "rap_min_kpc":float(g["rap_kpc"].min()),
            "rap_max_kpc":float(g["rap_kpc"].max()),
            "ecc_min":float(g["eccentricity"].min()),
            "ecc_max":float(g["eccentricity"].max()),
            "zmax_min_kpc":float(g["zmax_kpc"].min()),
            "zmax_max_kpc":float(g["zmax_kpc"].max()),
        })
    spread=pd.DataFrame(spread)
    spread.to_csv(out/"05_CROSS_POTENTIAL_NOMINAL_SPREAD.csv",index=False)

    hn=sha256(out/"01_PRIMARY_NOMINAL_ORBIT_PROXIES_FROZEN.csv")
    hc=sha256(out/"02_MC_CELL_SUMMARY_AND_HASHES.csv")
    hm=sha256(out/"03_PRIMARY_MC_ORBIT_PROXY_DRAWS_FROZEN.csv")
    hs=sha256(out/"04_PRIMARY_ORBIT_PROXY_SUMMARY_FROZEN.csv")

    contract={
        "stage":"STAGE6B2R1_FAST_MC_ORBIT_PROXY_PRODUCTION",
        "version":VERSION,
        "alignment_read":False,
        "correlation_computed":False,
        "science_design_changed":False,
        "performance_amendment":{
            "primary_nominal_method":"full numerical 1-Gyr integration",
            "MC_method":"Staeckel analytic",
            "MC_method_authorized_by":"Stage-6B2R0 v2.3.1",
            "adjudication_sha256":sha256(adjud_f),
        },
        "primary_sample_sha256":EXPECTED_PRIMARY_SHA,
        "N_objects":45,
        "N_potentials":3,
        "N_nominal_rows":int(len(nominal)),
        "N_MC_per_cell":N_MC,
        "N_MC_rows":int(len(mc)),
        "all_nominal_physical":True,
        "all_MC_physical":True,
        "all_cells_complete_512":True,
        "primary_potential":PRIMARY_POTENTIAL,
        "primary_metric":"rperi_kpc",
        "primary_exposure":"X_peri=-log(rperi_kpc)",
        "nominal_sha256":hn,
        "cell_manifest_sha256":hc,
        "MC_draws_sha256":hm,
        "summary_sha256":hs,
        "ORBIT_PROXY_FREEZE_PASS":True,
        "next":
            "Stage-6B3 may join the frozen alignment outcomes and execute only the prospectively frozen primary/secondary association tests."
    }
    (out/"STAGE6B2R1_FREEZE.json").write_text(
        json.dumps(contract,indent=2),encoding="utf-8"
    )

    prim=nominal[nominal["potential"]==PRIMARY_POTENTIAL]
    report=[
        f"YHMC STAGE-6B2R1 FAST-MC ORBIT-PROXY PRODUCTION v{VERSION}",
        "="*112,
        "ALIGNMENT_READ=False",
        "CORRELATION_COMPUTED=False",
        "SCIENCE_DESIGN_CHANGED=False",
        "NOMINAL_METHOD=FULL_NUMERICAL_1GYR",
        "MC_METHOD=VALIDATED_STAECKEL_ANALYTIC",
        f"PRIMARY_SAMPLE_N={EXPECTED_PRIMARY_N}",
        f"NOMINAL_ROWS={len(nominal)}",
        f"MC_ROWS={len(mc)}",
        f"MC_ROWS_EXPECTED={expected}",
        "ALL_NOMINAL_PHYSICAL=True",
        "ALL_MC_PHYSICAL=True",
        "ALL_CELLS_COMPLETE_512=True",
        "",
        "PRIMARY-POTENTIAL NOMINAL PROXY SUMMARY:",
        prim.groupby("sample")[["rperi_kpc","rap_kpc","eccentricity","zmax_kpc"]]
            .agg(["count","median","min","max"]).to_string(),
        "",
        "CROSS-POTENTIAL RPERI FRACTIONAL RANGE:",
        spread["rperi_frac_range_over_mean"].describe().to_string(),
        "",
        f"NOMINAL_SHA256={hn}",
        f"MC_DRAWS_SHA256={hm}",
        f"SUMMARY_SHA256={hs}",
        f"CELL_MANIFEST_SHA256={hc}",
        "ORBIT_PROXY_FREEZE_PASS=True",
        "",
        "NEXT:",
        "  Stage-6B3 association unblind using exact frozen McMillan17",
        "  nominal X_peri and the pre-specified two-sided cohort-stratified",
        "  permutation Spearman test.",
    ]
    (out/"STAGE6B2R1_REPORT.txt").write_text(
        "\n".join(report)+"\n",encoding="utf-8"
    )

    tops=[
        "00_POTENTIAL_PHYSICAL_SCALES.csv",
        "01_PRIMARY_NOMINAL_ORBIT_PROXIES_FROZEN.csv",
        "02_MC_CELL_SUMMARY_AND_HASHES.csv",
        "03_PRIMARY_MC_ORBIT_PROXY_DRAWS_FROZEN.csv",
        "04_PRIMARY_ORBIT_PROXY_SUMMARY_FROZEN.csv",
        "05_CROSS_POTENTIAL_NOMINAL_SPREAD.csv",
        "STAGE6B2R1_FREEZE.json",
        "STAGE6B2R1_REPORT.txt",
    ]
    (out/"SHA256SUMS.txt").write_text(
        "\n".join(f"{sha256(out/n)}  {n}" for n in tops)+"\n",
        encoding="utf-8"
    )

    print()
    print((out/"STAGE6B2R1_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

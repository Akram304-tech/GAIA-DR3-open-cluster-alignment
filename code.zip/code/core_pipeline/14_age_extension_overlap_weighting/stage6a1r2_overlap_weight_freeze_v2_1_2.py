#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-6A1R2 Overlap-Weight Design Freeze v2.1.2

Outcome-blind alternative after pair matching failed its predeclared
common-support balance gate.

NO morphology.
NO PA.
NO Galactic-plane angle.
NO alignment outcome.

Estimand
--------
Average age-cohort contrast in the population with covariate overlap between:
  Y1 = 100--500 Myr, exact frozen Stage-2C PA sample (N=95)
  Y2 = 0.5--2 Gyr, quality-selected catalogue candidate pool (N=142)

Propensity model
----------------
Binary logistic regression for Z=1 (Y2) using pooled standardized:
  logMass, logDist, logNJ, AV50, |b|, sin(l), cos(l)

Fixed ridge penalty:
  lambda = 1e-4, excluding intercept.

Overlap weights:
  Y1 (Z=0): w = e(X)
  Y2 (Z=1): w = 1-e(X)

Weights are normalized to sum to 1 within each cohort.

Prospective acceptance gates
----------------------------
1) max weighted absolute SMD <= 0.10
   across logMass, logDist, logNJ, AV50, |b|, sin(l), cos(l)
2) ESS_Y1 >= 40
3) ESS_Y2 >= 40
4) model optimization succeeds and all propensities are finite in (0,1)

If any gate fails, the age-extension inference stops.
No alternate weighting model is tuned after this result.

Important
---------
These are design weights only. If Y2 later undergoes a morphology gate,
alignment remains blinded. A separate outcome-blind post-morphology balance
audit is required before any Y1-vs-Y2 alignment contrast is unblinded.
"""

from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit

VERSION="2.1.2"
EXPECTED_CONTROL_SHA="124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd"
EXPECTED_FULL_SNAPSHOT_SHA="2164adf7ed3e516f035f60c6e6bfc06affbc4d809157c8eb06306d3e78d2cb47"

AGE_LO=math.log10(5e8)
AGE_HI=math.log10(2e9)
MASS_MIN=1000.0
RIDGE=1e-4
MAX_ABS_SMD_GATE=0.10
MIN_ESS=40.0

def sha256(p):
    h=hashlib.sha256()
    with Path(p).open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()

def num(df,c): return pd.to_numeric(df[c],errors="coerce")

def base_quality(df):
    typ=df["Type"].astype(str).str.strip().str.lower()
    return (
        (typ=="o") &
        (num(df,"CST")>=5) &
        (num(df,"CMDCl50")>=0.5) &
        (num(df,"probJ")>=0.5) &
        (num(df,"NJ")>=40) &
        np.isfinite(num(df,"rJ")) & (num(df,"rJ")>0) &
        np.isfinite(num(df,"r50J")) & (num(df,"r50J")>0) &
        np.isfinite(num(df,"MassJ")) & (num(df,"MassJ")>0) &
        np.isfinite(num(df,"logAge50"))
    )

def feat(df):
    out=pd.DataFrame(index=df.index)
    out["logMass"]=np.log10(num(df,"MassJ"))
    out["logDist"]=np.log10(num(df,"dist50"))
    out["logNJ"]=np.log10(num(df,"NJ"))
    out["AV50"]=num(df,"AV50")
    out["abs_b"]=np.abs(num(df,"GLAT"))
    l=np.deg2rad(num(df,"GLON")%360.0)
    out["sin_l"]=np.sin(l)
    out["cos_l"]=np.cos(l)
    return out

def weighted_mean(x,w):
    x=np.asarray(x,float); w=np.asarray(w,float)
    return float(np.sum(w*x)/np.sum(w))

def weighted_var(x,w):
    x=np.asarray(x,float); w=np.asarray(w,float)
    m=weighted_mean(x,w)
    return float(np.sum(w*(x-m)**2)/np.sum(w))

def weighted_smd(x0,w0,x1,w1):
    m0=weighted_mean(x0,w0); m1=weighted_mean(x1,w1)
    v0=weighted_var(x0,w0); v1=weighted_var(x1,w1)
    den=np.sqrt((v0+v1)/2.0)
    return float((m0-m1)/den) if den>0 else 0.0

def ess(w):
    w=np.asarray(w,float)
    return float(w.sum()**2/np.square(w).sum())

def fit_logistic(X,z):
    X=np.asarray(X,float); z=np.asarray(z,float)
    X1=np.column_stack([np.ones(len(X)),X])

    def obj(beta):
        eta=X1@beta
        # stable logistic NLL
        nll=np.sum(np.logaddexp(0.0,eta)-z*eta)
        pen=0.5*RIDGE*np.sum(beta[1:]**2)
        return float(nll+pen)

    def grad(beta):
        eta=X1@beta
        p=expit(eta)
        g=X1.T@(p-z)
        g[1:]+=RIDGE*beta[1:]
        return g

    res=minimize(obj,np.zeros(X1.shape[1]),jac=grad,method="BFGS",
                 options={"gtol":1e-9,"maxiter":5000})
    return res, X1

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage6",required=True)
    ap.add_argument("--stage2c",required=True)
    ap.add_argument("--out",default="STAGE6A1R2_OUTPUT")
    args=ap.parse_args()

    s6=Path(args.stage6).resolve()
    s2=Path(args.stage2c).resolve()
    out=Path(args.out).resolve(); out.mkdir(parents=True,exist_ok=True)

    snap=s6/"00_HUNT_REFFERT_FULLCOLUMN_SNAPSHOT.csv"
    cf=s2/"02_CONTROL_PA_SAMPLE_FROZEN.csv"
    if sha256(snap)!=EXPECTED_FULL_SNAPSHOT_SHA:
        raise RuntimeError("Stage-6 full-column snapshot hash mismatch.")
    if sha256(cf)!=EXPECTED_CONTROL_SHA:
        raise RuntimeError("Stage-2C control frozen hash mismatch.")

    cat=pd.read_csv(snap,low_memory=False)
    y1f=pd.read_csv(cf)
    cat["ID"]=pd.to_numeric(cat["ID"],errors="coerce")
    y1f["ID"]=pd.to_numeric(y1f["ID"],errors="coerce")
    cat["Name"]=cat["Name"].astype(str).str.strip()
    y1f["Name"]=y1f["Name"].astype(str).str.strip()
    if cat["ID"].duplicated().any(): raise RuntimeError("Catalogue ID not unique.")

    cols=["ID","Name","Type","CST","CMDCl50","probJ","NJ","rJ","r50J",
          "MassJ","logAge16","logAge50","logAge84","dist50","AV50","GLON","GLAT"]
    src=cat[cols].copy()

    y1=y1f[["ID","Name"]].merge(src,on="ID",how="left",
                                suffixes=("_frozen","_catalog"),validate="one_to_one")
    if len(y1)!=95 or y1["MassJ"].isna().any():
        raise RuntimeError("Could not bind exact 95 Y1 anchors.")

    q=base_quality(cat)
    age=(num(cat,"logAge50")>AGE_LO)&(num(cat,"logAge50")<=AGE_HI)
    y2=cat.loc[q&age&(num(cat,"MassJ")>=MASS_MIN),cols].copy().reset_index(drop=True)
    if len(y2)!=142:
        raise RuntimeError(f"Expected 142 Y2 candidates, found {len(y2)}.")

    F1=feat(y1).reset_index(drop=True)
    F2=feat(y2).reset_index(drop=True)
    names=list(F1.columns)

    pooled=pd.concat([F1,F2],ignore_index=True)
    mu=pooled.mean()
    sd=pooled.std(ddof=1).replace(0,1.0)
    Z1=(F1-mu)/sd
    Z2=(F2-mu)/sd
    X=pd.concat([Z1,Z2],ignore_index=True).to_numpy(float)
    z=np.concatenate([np.zeros(len(Z1)),np.ones(len(Z2))])

    if not np.all(np.isfinite(X)):
        raise RuntimeError("Non-finite propensity covariates.")

    res,X1=fit_logistic(X,z)
    p=expit(X1@res.x)
    finite_ps=bool(np.all(np.isfinite(p)) and np.all((p>0)&(p<1)))

    p1=p[:len(y1)]
    p2=p[len(y1):]
    w1=p1.copy()        # Z=0 overlap weight
    w2=1.0-p2           # Z=1 overlap weight
    w1n=w1/w1.sum()
    w2n=w2/w2.sum()

    bal=[]
    for c in names:
        v=weighted_smd(F1[c],w1n,F2[c],w2n)
        bal.append({
            "covariate":c,
            "weighted_Y1_mean":weighted_mean(F1[c],w1n),
            "weighted_Y2_mean":weighted_mean(F2[c],w2n),
            "weighted_SMD":v,
            "abs_weighted_SMD":abs(v),
        })
    baldf=pd.DataFrame(bal)
    maxs=float(baldf["abs_weighted_SMD"].max())
    e1=ess(w1n); e2=ess(w2n)

    accepted=bool(
        res.success and finite_ps and
        maxs<=MAX_ABS_SMD_GATE and
        e1>=MIN_ESS and e2>=MIN_ESS
    )

    # Save design table with no alignment fields.
    d1=y1[["ID","Name_frozen","Name_catalog","MassJ","logAge16","logAge50",
           "logAge84","dist50","NJ","AV50","GLON","GLAT"]].copy()
    d1["cohort"]="Y1_100_500M"
    d1["propensity_Y2"]=p1
    d1["overlap_weight_raw"]=w1
    d1["overlap_weight_norm"]=w1n

    d2=y2[["ID","Name","MassJ","logAge16","logAge50","logAge84","dist50",
           "NJ","AV50","GLON","GLAT"]].copy()
    d2=d2.rename(columns={"Name":"Name_catalog"})
    d2["Name_frozen"]=""
    d2["cohort"]="Y2_0p5_2G"
    d2["propensity_Y2"]=p2
    d2["overlap_weight_raw"]=w2
    d2["overlap_weight_norm"]=w2n
    d2["AGE_INTERVAL_SECURE"]=(
        np.isfinite(num(d2,"logAge16")) &
        np.isfinite(num(d2,"logAge84")) &
        (num(d2,"logAge16")>AGE_LO) &
        (num(d2,"logAge84")<=AGE_HI)
    )

    design=pd.concat([d1,d2],ignore_index=True,sort=False)
    design.to_csv(out/"01_OVERLAP_WEIGHT_DESIGN_FROZEN.csv",index=False)
    baldf.to_csv(out/"02_WEIGHTED_BALANCE.csv",index=False)

    coef=pd.DataFrame({
        "term":["intercept"]+names,
        "coefficient":res.x,
    })
    coef.to_csv(out/"03_PROPENSITY_MODEL_COEFFICIENTS.csv",index=False)

    diag={
        "optimizer_success":bool(res.success),
        "optimizer_message":str(res.message),
        "optimizer_iterations":int(getattr(res,"nit",-1)),
        "ridge_lambda":RIDGE,
        "propensity_min":float(np.min(p)),
        "propensity_p01":float(np.percentile(p,1)),
        "propensity_median":float(np.median(p)),
        "propensity_p99":float(np.percentile(p,99)),
        "propensity_max":float(np.max(p)),
        "ESS_Y1":e1,
        "ESS_Y2":e2,
        "max_abs_weighted_SMD":maxs,
        "max_normalized_weight_Y1":float(np.max(w1n)),
        "max_normalized_weight_Y2":float(np.max(w2n)),
        "DESIGN_ACCEPTED":accepted,
    }
    (out/"04_DESIGN_DIAGNOSTICS.json").write_text(json.dumps(diag,indent=2),encoding="utf-8")

    hd=sha256(out/"01_OVERLAP_WEIGHT_DESIGN_FROZEN.csv")
    hc=sha256(out/"03_PROPENSITY_MODEL_COEFFICIENTS.csv")

    contract={
        "stage":"STAGE6A1R2_OVERLAP_WEIGHT_FREEZE",
        "version":VERSION,
        "outcome_blind":True,
        "alignment_computed":False,
        "Y1_n":95,
        "Y2_n":142,
        "propensity_covariates":names,
        "ridge_lambda":RIDGE,
        "overlap_weights":{"Y1":"e(X)","Y2":"1-e(X)"},
        "acceptance":{
            "max_abs_weighted_SMD_le":MAX_ABS_SMD_GATE,
            "ESS_each_ge":MIN_ESS,
            "optimizer_success":True,
            "finite_propensity_in_open_interval":True
        },
        "observed":diag,
        "DESIGN_ACCEPTED":accepted,
        "design_sha256":hd,
        "coefficient_sha256":hc,
        "post_morphology_rule":
            "After blind Y2 morphology freeze, re-audit balance before alignment. "
            "If restricted design violates max|SMD|<=0.10 or ESS<30 in either cohort, "
            "do not unblind the weighted age contrast.",
        "next_if_pass":
            "Acquire members and independently blind-calibrate all 142 Y2 candidates.",
        "next_if_fail":
            "STOP inferential 0.5-2 Gyr extension in the current manuscript."
    }
    (out/"STAGE6A1R2_FREEZE.json").write_text(json.dumps(contract,indent=2),encoding="utf-8")

    report=[
        f"YHMC STAGE-6A1R2 OVERLAP-WEIGHT DESIGN FREEZE v{VERSION}",
        "="*104,
        "NO_Y2_MORPHOLOGY=True",
        "NO_Y2_PA=True",
        "NO_Y2_ALIGNMENT=True",
        f"Y1_N={len(y1)}",
        f"Y2_N={len(y2)}",
        "",
        "PROPENSITY MODEL:",
        f"  optimizer_success={res.success}",
        f"  message={res.message}",
        f"  ridge_lambda={RIDGE}",
        f"  propensity range=[{np.min(p):.6f}, {np.max(p):.6f}]",
        "",
        "WEIGHTED BALANCE:",
        baldf.to_string(index=False),
        "",
        f"MAX_ABS_WEIGHTED_SMD={maxs:.6f}",
        f"ESS_Y1={e1:.3f}",
        f"ESS_Y2={e2:.3f}",
        f"MAX_NORM_WEIGHT_Y1={np.max(w1n):.6f}",
        f"MAX_NORM_WEIGHT_Y2={np.max(w2n):.6f}",
        "",
        f"BALANCE_GATE={MAX_ABS_SMD_GATE:.2f}",
        f"MIN_ESS={MIN_ESS:.1f}",
        f"DESIGN_ACCEPTED={accepted}",
        f"DESIGN_SHA256={hd}",
        f"COEFFICIENT_SHA256={hc}",
        "",
        "NEXT:",
        "  PASS -> blind member/morphology calibration for all 142 Y2 candidates,",
        "          then a separate post-morphology overlap-balance freeze before alignment.",
        "  FAIL -> stop inferential Y2 age extension; do not tune another weighting model.",
    ]
    (out/"STAGE6A1R2_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    manifest=[]
    for pp in sorted(out.rglob("*")):
        if pp.is_file():
            manifest.append(f"{sha256(pp)}  {pp.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")
    print((out/"STAGE6A1R2_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

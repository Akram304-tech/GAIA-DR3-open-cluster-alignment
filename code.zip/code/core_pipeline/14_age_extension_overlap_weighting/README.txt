YHMC Stage-6A1R2 Overlap-Weight Design Freeze v2.1.2
========================================================

Pair matching was attempted prospectively and failed its frozen balance gate.
This is the final prospective alternative for the 0.5-2 Gyr extension.

Design:
- exact 95 frozen 100-500 Myr Y1 objects;
- all 142 quality-selected 0.5-2 Gyr Y2 candidates;
- propensity model on catalogue covariates only;
- overlap weights.

Acceptance:
  max weighted |SMD| <= 0.10
  ESS_Y1 >= 40
  ESS_Y2 >= 40

No morphology, PA, or alignment is computed.

If this design fails, the inferential 0.5-2 Gyr extension is stopped rather
than tuning additional models after repeated design failures.

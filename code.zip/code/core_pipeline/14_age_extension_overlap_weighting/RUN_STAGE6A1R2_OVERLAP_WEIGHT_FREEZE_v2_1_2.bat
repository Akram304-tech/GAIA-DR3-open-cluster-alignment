@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-6A1R2 OVERLAP-WEIGHT DESIGN FREEZE v2.1.2
echo OUTCOME-BLIND / NO MORPHOLOGY / NO ALIGNMENT
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" exit /b 1

set "STAGE6=%USERPROFILE%\Downloads\YHMC_STAGE6_FULLCOLUMN_RECOVERY_v2_0_2\YHMC_STAGE6_FULLCOLUMN_RECOVERY_v2_0_2\STAGE6_FULLCOLUMN_OUTPUT"
set "STAGE2C=%USERPROFILE%\Downloads\YHMC_STAGE2C_CONTROL_REAL_MORPHOLOGY_FREEZE_v0_7_0\YHMC_STAGE2C_CONTROL_REAL_MORPHOLOGY_FREEZE_v0_7_0\STAGE2C_OUTPUT"

"%PYEXE%" -c "import numpy,pandas,scipy" >nul 2>nul
if errorlevel 1 exit /b 1

"%PYEXE%" stage6a1r2_overlap_weight_freeze_v2_1_2.py ^
 --stage6 "%STAGE6%" ^
 --stage2c "%STAGE2C%" ^
 --out "%CD%\STAGE6A1R2_OUTPUT"

set "RC=%ERRORLEVEL%"
echo.
echo RETURN_CODE=%RC%
if exist "%CD%\STAGE6A1R2_OUTPUT\STAGE6A1R2_REPORT.txt" echo REPORT=%CD%\STAGE6A1R2_OUTPUT\STAGE6A1R2_REPORT.txt
if exist "%CD%\STAGE6A1R2_OUTPUT\STAGE6A1R2_FREEZE.json" echo FREEZE=%CD%\STAGE6A1R2_OUTPUT\STAGE6A1R2_FREEZE.json
exit /b %RC%

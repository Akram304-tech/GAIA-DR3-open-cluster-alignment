YHMC Stage-6A4 Post-Morphology Overlap Audit v2.4.0
======================================================

Purpose:
Audit whether the previously validated overlap-weight design remains balanced
after Stage-6A3 admits 48/142 Y2 clusters.

No model is refit.
No weight is optimized or trimmed.
No PA value is used.
No Galactic alignment is computed.

The existing overlap weights are only:
  1. restricted to the Stage-6A3 admitted Y2 identities;
  2. renormalized within cohort.

Frozen gate:
  max weighted |SMD| <= 0.10
  ESS_Y1 >= 30
  ESS_Y2 >= 30

PASS authorizes Stage-6A5 alignment/age-trend unblinding.
FAIL closes the inferential Y1-vs-Y2 age contrast without post-hoc repair.

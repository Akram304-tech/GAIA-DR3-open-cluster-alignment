@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-6A4 POST-MORPHOLOGY OVERLAP AUDIT v2.4.0
echo RESTRICT+RENORMALIZE ONLY / NO ALIGNMENT
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" exit /b 1

set "STAGE6A1R3=%USERPROFILE%\Downloads\YHMC_STAGE6A1R3_NUMERICAL_SOLVER_ADJUDICATION_v2_1_3\YHMC_STAGE6A1R3_NUMERICAL_SOLVER_ADJUDICATION_v2_1_3\STAGE6A1R3_OUTPUT"
set "STAGE6A3=%USERPROFILE%\Downloads\YHMC_STAGE6A3_Y2_REAL_MORPHOLOGY_FREEZE_v2_3_0\YHMC_STAGE6A3_Y2_REAL_MORPHOLOGY_FREEZE_v2_3_0\STAGE6A3_OUTPUT"

"%PYEXE%" -c "import numpy,pandas" >nul 2>nul
if errorlevel 1 exit /b 1

"%PYEXE%" stage6a4_post_morphology_overlap_audit_v2_4_0.py ^
 --stage6a1r3 "%STAGE6A1R3%" ^
 --stage6a3 "%STAGE6A3%" ^
 --out "%CD%\STAGE6A4_OUTPUT"

set "RC=%ERRORLEVEL%"
echo.
echo RETURN_CODE=%RC%
if "%RC%"=="0" (
 echo REPORT=%CD%\STAGE6A4_OUTPUT\STAGE6A4_REPORT.txt
 echo DESIGN=%CD%\STAGE6A4_OUTPUT\01_POST_MORPHOLOGY_OVERLAP_DESIGN_FROZEN.csv
 echo FREEZE=%CD%\STAGE6A4_OUTPUT\STAGE6A4_FREEZE.json
)
exit /b %RC%

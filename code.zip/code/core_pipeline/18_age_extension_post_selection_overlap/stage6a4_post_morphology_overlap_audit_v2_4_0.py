#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-6A4 Post-Morphology Overlap Audit v2.4.0

Purpose
-------
Audit whether the PRE-EXISTING Stage-6A1R3 overlap-weight design remains
balanced after the blind Stage-6A3 Y2 morphology gate.

STRICT RULES
------------
- Propensity model is NOT refit.
- Covariates are NOT changed.
- Weights are NOT optimized or trimmed.
- Y1 remains the exact frozen Stage-2C morphology-resolved control sample.
- Y2 is restricted only by the already frozen Stage-6A3 morphology admission.
- Existing overlap weights are only restricted and renormalized within cohort.
- PA values are NOT used.
- Galactic-plane PA, Delta theta, alignment A, and age contrast are NOT computed.

Pre-frozen post-morphology acceptance gate from Stage-6A1R3:
  max weighted |SMD| <= 0.10
  ESS_Y1 >= 30
  ESS_Y2 >= 30

If PASS:
  Stage-6A5 alignment/age-trend unblind is authorized.

If FAIL:
  The inferential weighted Y1-vs-Y2 age contrast remains closed.
  No post-hoc propensity refit, trimming, caliper tuning, or gate relaxation.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

VERSION="2.4.0"

EXPECTED_VALIDATED_DESIGN_SHA="177cbd6ef1220157809a7e4585e2b85373ce49a9d50b90ff55dd7fe61102c8d3"
EXPECTED_Y2_PA_SAMPLE_SHA="8b7d394a203e308cca5aed6194eac2eb473742287e81d1f6ecfa407654fd9cb5"
EXPECTED_Y2_ALL_MORPH_SHA="a8002167ca541d32c3b66c18c36e824b932cf63977c37127bc2acceb035dc7dd"

MAX_ABS_SMD_GATE=0.10
MIN_ESS=30.0

def sha256(p):
    h=hashlib.sha256()
    with Path(p).open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def num(s):
    return pd.to_numeric(s,errors="coerce")

def feature_table(df):
    out=pd.DataFrame(index=df.index)
    out["logMass"]=np.log10(num(df["MassJ"]))
    out["logDist"]=np.log10(num(df["dist50"]))
    out["logNJ"]=np.log10(num(df["NJ"]))
    out["AV50"]=num(df["AV50"])
    out["abs_b"]=np.abs(num(df["GLAT"]))
    l=np.deg2rad(num(df["GLON"])%360.0)
    out["sin_l"]=np.sin(l)
    out["cos_l"]=np.cos(l)
    return out

def weighted_mean(x,w):
    x=np.asarray(x,float); w=np.asarray(w,float)
    return float(np.sum(w*x)/np.sum(w))

def weighted_var(x,w):
    x=np.asarray(x,float); w=np.asarray(w,float)
    m=weighted_mean(x,w)
    return float(np.sum(w*(x-m)**2)/np.sum(w))

def weighted_smd(x0,w0,x1,w1):
    m0=weighted_mean(x0,w0)
    m1=weighted_mean(x1,w1)
    v0=weighted_var(x0,w0)
    v1=weighted_var(x1,w1)
    den=np.sqrt((v0+v1)/2.0)
    return float((m0-m1)/den) if den>0 else 0.0

def ess(w):
    w=np.asarray(w,float)
    return float((w.sum()**2)/np.square(w).sum())

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage6a1r3",required=True)
    ap.add_argument("--stage6a3",required=True)
    ap.add_argument("--out",default="STAGE6A4_OUTPUT")
    args=ap.parse_args()

    s1=Path(args.stage6a1r3).resolve()
    s3=Path(args.stage6a3).resolve()
    out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=True)

    design_f=s1/"05_NUMERICALLY_VALIDATED_OVERLAP_DESIGN.csv"
    y2_pa_f=s3/"02_Y2_PA_SAMPLE_FROZEN.csv"
    y2_all_f=s3/"01_Y2_REAL_MORPHOLOGY_ALL.csv"

    for p in [design_f,y2_pa_f,y2_all_f]:
        if not p.exists():
            raise FileNotFoundError(p)

    if sha256(design_f)!=EXPECTED_VALIDATED_DESIGN_SHA:
        raise RuntimeError("Validated overlap design hash mismatch.")
    if sha256(y2_pa_f)!=EXPECTED_Y2_PA_SAMPLE_SHA:
        raise RuntimeError("Stage-6A3 Y2 PA-sample hash mismatch.")
    if sha256(y2_all_f)!=EXPECTED_Y2_ALL_MORPH_SHA:
        raise RuntimeError("Stage-6A3 all-morphology hash mismatch.")

    design=pd.read_csv(design_f)
    y2_pa_ids=pd.read_csv(y2_pa_f,usecols=["ID"])
    y2_all=pd.read_csv(y2_all_f,usecols=["ID","MORPHOLOGY_ADMITTED"])

    design["ID"]=pd.to_numeric(design["ID"],errors="raise").astype(int)
    y2_pa_ids["ID"]=pd.to_numeric(y2_pa_ids["ID"],errors="raise").astype(int)
    y2_all["ID"]=pd.to_numeric(y2_all["ID"],errors="raise").astype(int)

    y1=design[design["cohort"].astype(str)=="Y1_100_500M"].copy()
    y2=design[design["cohort"].astype(str)=="Y2_0p5_2G"].copy()

    if len(y1)!=95 or len(y2)!=142:
        raise RuntimeError(f"Expected Y1/Y2 design N=95/142, got {len(y1)}/{len(y2)}")
    if len(y2_pa_ids)!=48:
        raise RuntimeError(f"Expected Stage-6A3 admitted Y2 N=48, got {len(y2_pa_ids)}")

    # Cross-check PA-sample identity list against morphology-admission flag only.
    adm_ids=set(y2_all.loc[y2_all["MORPHOLOGY_ADMITTED"]==True,"ID"].tolist())
    pa_ids=set(y2_pa_ids["ID"].tolist())
    if adm_ids!=pa_ids:
        raise RuntimeError("Y2 admitted identity mismatch between all-morphology and PA-sample files.")

    y2r=y2[y2["ID"].isin(pa_ids)].copy()
    if len(y2r)!=48:
        raise RuntimeError(f"Validated design binds only {len(y2r)} of 48 admitted Y2 IDs.")

    # Existing weights only: restrict + renormalize.
    w1=num(y1["overlap_weight_norm"]).to_numpy(float)
    w2=num(y2r["overlap_weight_norm"]).to_numpy(float)
    if not np.all(np.isfinite(w1)) or not np.all(np.isfinite(w2)):
        raise RuntimeError("Non-finite pre-existing overlap weights.")
    if np.any(w1<=0) or np.any(w2<=0):
        raise RuntimeError("Non-positive pre-existing overlap weights.")

    w1=w1/w1.sum()
    w2=w2/w2.sum()

    F1=feature_table(y1)
    F2=feature_table(y2r)

    balance=[]
    for c in F1.columns:
        smd=weighted_smd(F1[c],w1,F2[c],w2)
        balance.append({
            "covariate":c,
            "weighted_Y1_mean":weighted_mean(F1[c],w1),
            "weighted_Y2_admitted_mean":weighted_mean(F2[c],w2),
            "weighted_SMD":smd,
            "abs_weighted_SMD":abs(smd),
        })
    bdf=pd.DataFrame(balance)

    maxs=float(bdf["abs_weighted_SMD"].max())
    ess1=ess(w1)
    ess2=ess(w2)
    maxw1=float(np.max(w1))
    maxw2=float(np.max(w2))

    passed=bool(
        maxs<=MAX_ABS_SMD_GATE and
        ess1>=MIN_ESS and
        ess2>=MIN_ESS
    )

    # Save restricted design without any PA values.
    cols=[
        "ID","Name_frozen","Name_catalog","MassJ","logAge16","logAge50",
        "logAge84","dist50","NJ","AV50","GLON","GLAT",
        "cohort","propensity_Y2","overlap_weight_norm"
    ]
    cols=[c for c in cols if c in y1.columns]
    y1out=y1[cols].copy()
    y2out=y2r[cols].copy()
    y1out["post_morphology_weight_norm"]=w1
    y2out["post_morphology_weight_norm"]=w2

    restricted=pd.concat([y1out,y2out],ignore_index=True,sort=False)
    restricted.to_csv(out/"01_POST_MORPHOLOGY_OVERLAP_DESIGN_FROZEN.csv",index=False)
    bdf.to_csv(out/"02_POST_MORPHOLOGY_WEIGHTED_BALANCE.csv",index=False)

    # Descriptive support only; no alignment.
    support=[]
    for label,d,w in [
        ("Y1_100_500M",y1,w1),
        ("Y2_0p5_2G_ADMITTED",y2r,w2),
    ]:
        support.append({
            "cohort":label,
            "N":len(d),
            "ESS":ess(w),
            "max_normalized_weight":float(np.max(w)),
            "N_MassJ_ge3000":int((num(d["MassJ"])>=3000).sum()),
            "N_MassJ_ge5000":int((num(d["MassJ"])>=5000).sum()),
            "weighted_mean_logAge50":weighted_mean(num(d["logAge50"]),w),
            "weighted_mean_MassJ":weighted_mean(num(d["MassJ"]),w),
            "weighted_mean_dist50_pc":weighted_mean(num(d["dist50"]),w),
        })
    sdf=pd.DataFrame(support)
    sdf.to_csv(out/"03_POST_MORPHOLOGY_SUPPORT_SUMMARY.csv",index=False)

    hdesign=sha256(out/"01_POST_MORPHOLOGY_OVERLAP_DESIGN_FROZEN.csv")
    hbal=sha256(out/"02_POST_MORPHOLOGY_WEIGHTED_BALANCE.csv")

    contract={
        "stage":"STAGE6A4_POST_MORPHOLOGY_OVERLAP_AUDIT",
        "version":VERSION,
        "inputs":{
            "validated_overlap_design_sha256":EXPECTED_VALIDATED_DESIGN_SHA,
            "Y2_PA_sample_sha256":EXPECTED_Y2_PA_SAMPLE_SHA,
            "Y2_all_morphology_sha256":EXPECTED_Y2_ALL_MORPH_SHA,
        },
        "propensity_model_refit":False,
        "weight_optimization":False,
        "weight_trimming":False,
        "weights_only_restricted_and_renormalized":True,
        "PA_values_used":False,
        "galactic_plane_PA_computed":False,
        "delta_theta_computed":False,
        "alignment_computed":False,
        "Y1_N":int(len(y1)),
        "Y2_admitted_N":int(len(y2r)),
        "post_morphology_gate":{
            "max_abs_weighted_SMD_le":MAX_ABS_SMD_GATE,
            "ESS_each_ge":MIN_ESS,
        },
        "observed":{
            "max_abs_weighted_SMD":maxs,
            "ESS_Y1":ess1,
            "ESS_Y2":ess2,
            "max_normalized_weight_Y1":maxw1,
            "max_normalized_weight_Y2":maxw2,
        },
        "POST_MORPHOLOGY_DESIGN_PASS":passed,
        "restricted_design_sha256":hdesign,
        "balance_sha256":hbal,
        "next_if_pass":
            "Stage-6A5 alignment/age-trend unblind is authorized using this exact frozen weighted design.",
        "next_if_fail":
            "Close inferential Y1-vs-Y2 age-alignment contrast. No refit/trimming/tuning authorized."
    }
    (out/"STAGE6A4_FREEZE.json").write_text(
        json.dumps(contract,indent=2),encoding="utf-8"
    )

    report=[
        f"YHMC STAGE-6A4 POST-MORPHOLOGY OVERLAP AUDIT v{VERSION}",
        "="*108,
        "PROPENSITY_REFIT=False",
        "WEIGHT_TRIMMING=False",
        "PA_VALUES_USED=False",
        "GALACTIC_PLANE_PA_COMPUTED=False",
        "DELTA_THETA_COMPUTED=False",
        "ALIGNMENT_COMPUTED=False",
        f"Y1_N={len(y1)}",
        f"Y2_ADMITTED_N={len(y2r)}",
        "",
        "POST-MORPHOLOGY WEIGHTED BALANCE:",
        bdf.to_string(index=False),
        "",
        "SUPPORT SUMMARY:",
        sdf.to_string(index=False),
        "",
        f"MAX_ABS_WEIGHTED_SMD={maxs:.6f}",
        f"ESS_Y1={ess1:.3f}",
        f"ESS_Y2={ess2:.3f}",
        f"MAX_NORM_WEIGHT_Y1={maxw1:.6f}",
        f"MAX_NORM_WEIGHT_Y2={maxw2:.6f}",
        "",
        f"BALANCE_GATE={MAX_ABS_SMD_GATE:.2f}",
        f"MIN_ESS={MIN_ESS:.1f}",
        f"POST_MORPHOLOGY_DESIGN_PASS={passed}",
        f"RESTRICTED_DESIGN_SHA256={hdesign}",
        f"BALANCE_SHA256={hbal}",
        "",
        "NEXT:",
        "  PASS -> Stage-6A5 first alignment/age-trend unblind.",
        "  FAIL -> close inferential Y1-vs-Y2 age contrast; no post-hoc refit/tuning.",
    ]
    (out/"STAGE6A4_REPORT.txt").write_text(
        "\n".join(report)+"\n",encoding="utf-8"
    )

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")

    print((out/"STAGE6A4_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

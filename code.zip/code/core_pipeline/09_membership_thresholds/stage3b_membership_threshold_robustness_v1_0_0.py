#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-3B membership-threshold robustness v1.0.0

Purpose
-------
Re-evaluate the already-frozen young and older-control PA samples under the
pre-specified stricter membership-probability thresholds:
    Prob >= 0.7, 0.8, 0.9

For EACH threshold and EACH cluster:
  1) use only members surviving that threshold;
  2) independently re-run synthetic q/PA recovery calibration;
  3) recompute real weighted-second-moment q and PA;
  4) bootstrap q/PA uncertainty;
  5) apply the same morphology-only gate;
  6) only then recompute Galactic-plane alignment.

No threshold is selected based on results.

Young identities are the exact Stage-1B frozen PA sample.
Control identities are the exact Stage-2C frozen PA sample.
"""

from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "1.0.0"
SEED = 20260912
P_CUTS = [0.7, 0.8, 0.9]
Q_GRID = [1.00,0.98,0.96,0.94,0.92,0.90,0.85,0.80,0.70,0.60]
N_SYNTH = 250
N_BOOT = 2000
N_PERM = 200000
N_SIGNFLIP = 200000

PA_P68_MAX = 20.0
PA_MED_MAX = 10.0
Q_BIAS_MED_MAX = 0.05
PRIMARY_MASS = 3000.0

EXPECTED_YOUNG_SHA256 = "cc1d3ae4ce1cf52387f535da92fbd0dc5d984a3bb2dc750bf6672682e85f65dd"
EXPECTED_CONTROL_SHA256 = "124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd"

def sha256(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def safe_name(s):
    return "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in str(s))

def find_member_file(member_dir,cid,name):
    hits=sorted(member_dir.glob(f"{int(cid):04d}_*.csv"))
    if not hits: return None
    if len(hits)==1: return hits[0]
    sn=safe_name(name)
    for p in hits:
        if sn in p.stem: return p
    return hits[0]

def tangent_xy_arcmin(ra,dec,ra0,dec0):
    ra=np.asarray(ra,float); dec=np.asarray(dec,float)
    dra=((ra-float(ra0)+180.0)%360.0)-180.0
    x=dra*math.cos(math.radians(float(dec0)))*60.0
    y=(dec-float(dec0))*60.0
    return x,y

def weighted_shape(x,y,w):
    x=np.asarray(x,float); y=np.asarray(y,float); w=np.asarray(w,float)
    g=np.isfinite(x)&np.isfinite(y)&np.isfinite(w)&(w>0)
    x,y,w=x[g],y[g],w[g]
    if len(x)<3 or w.sum()<=0: return np.nan,np.nan
    sw=w.sum()
    xc=np.sum(w*x)/sw; yc=np.sum(w*y)/sw
    dx=x-xc; dy=y-yc
    C=np.array([
        [np.sum(w*dx*dx)/sw,np.sum(w*dx*dy)/sw],
        [np.sum(w*dx*dy)/sw,np.sum(w*dy*dy)/sw]
    ])
    vals,vecs=np.linalg.eigh(C)
    order=np.argsort(vals)[::-1]
    vals=vals[order]; vecs=vecs[:,order]
    if vals[0]<=0 or vals[1]<0: return np.nan,np.nan
    q=float(np.sqrt(max(vals[1],0)/vals[0]))
    vx,vy=vecs[:,0]
    pa=float(np.degrees(np.arctan2(vy,vx))%180.0)
    return q,pa

def neff(w):
    w=np.asarray(w,float)
    w=w[np.isfinite(w)&(w>0)]
    return float(w.sum()**2/np.square(w).sum()) if len(w) and np.square(w).sum()>0 else 0.0

def axial_diff(a,b):
    return ((np.asarray(a,float)-np.asarray(b,float)+90.0)%180.0)-90.0

def pct(x,p):
    x=np.asarray(x,float); x=x[np.isfinite(x)]
    return float(np.percentile(x,p)) if len(x) else np.nan

def med(x):
    x=np.asarray(x,float); x=x[np.isfinite(x)]
    return float(np.median(x)) if len(x) else np.nan

def local_gal_pa(ra,dec,eps=1e-3):
    from astropy.coordinates import SkyCoord
    import astropy.units as u
    c=SkyCoord(ra=float(ra)*u.deg,dec=float(dec)*u.deg,frame="icrs")
    g=c.galactic
    p=SkyCoord(l=g.l+eps*u.deg,b=g.b,frame="galactic").icrs
    m=SkyCoord(l=g.l-eps*u.deg,b=g.b,frame="galactic").icrs
    def xy(o):
        dra=((o.ra.deg-c.ra.deg+180)%360)-180
        return dra*math.cos(math.radians(c.dec.deg)),o.dec.deg-c.dec.deg
    xp,yp=xy(p); xm,ym=xy(m)
    return float(np.degrees(np.arctan2(yp-ym,xp-xm))%180)

def calibrate(r,w,cid,pcut):
    out=[]
    ptag=int(round(100*pcut))
    for qi,qtrue in enumerate(Q_GRID):
        rng=np.random.default_rng(np.random.SeedSequence([SEED,int(cid),ptag,qi,33]))
        qrec=np.empty(N_SYNTH)
        pae=np.full(N_SYNTH,np.nan)
        for k in range(N_SYNTH):
            th=rng.uniform(0,2*np.pi,len(r))
            phi=rng.uniform(0,np.pi)
            x0=r*np.cos(th); y0=qtrue*r*np.sin(th)
            c=math.cos(phi); s=math.sin(phi)
            x=c*x0-s*y0; y=s*x0+c*y0
            qr,pr=weighted_shape(x,y,w)
            qrec[k]=qr
            if qtrue<0.999 and np.isfinite(pr):
                pae[k]=abs(float(axial_diff(pr,math.degrees(phi)%180)))
        rec={
            "q_true":qtrue,
            "qrec_p05":pct(qrec,5),
            "qrec_p16":pct(qrec,16),
            "qrec_p84":pct(qrec,84),
            "qrec_med":med(qrec),
            "qbias_med":med(qrec-qtrue)
        }
        if qtrue<0.999:
            rec["pa_med"]=med(pae); rec["pa_p68"]=pct(pae,68)
            rec["pass"]=bool(
                rec["pa_p68"]<=PA_P68_MAX and
                rec["pa_med"]<=PA_MED_MAX and
                abs(rec["qbias_med"])<=Q_BIAS_MED_MAX
            )
        else:
            rec["pa_med"]=np.nan; rec["pa_p68"]=np.nan; rec["pass"]=False
        out.append(rec)
    g=pd.DataFrame(out)
    rr=g[np.isclose(g.q_true,1.0)].iloc[0]
    non=g[g.q_true<0.999]
    mp={float(x.q_true):bool(x["pass"]) for _,x in non.iterrows()}
    qs=sorted(mp)
    good=[]
    for q in qs:
        if all(mp[qq] for qq in qs if qq<=q):
            good.append(q)
    return {
        "q_round_null_p05":float(rr.qrec_p05),
        "qmax":max(good) if good else np.nan,
    }

def real_morph(x,y,w,cid,pcut):
    q,pa=weighted_shape(x,y,w)
    if not np.isfinite(q): return None
    rng=np.random.default_rng(np.random.SeedSequence([SEED,int(cid),int(round(100*pcut)),77]))
    qs=np.full(N_BOOT,np.nan); pas=np.full(N_BOOT,np.nan)
    n=len(x)
    for k in range(N_BOOT):
        idx=rng.integers(0,n,n)
        qs[k],pas[k]=weighted_shape(x[idx],y[idx],w[idx])
    pe=np.abs(axial_diff(pas,pa))
    return {
        "q":q,"pa":pa,"q84":pct(qs,84),"pa_p68":pct(pe,68)
    }

def pa_position_perm(pa,gp,nperm,rng,chunk=20000):
    pa=np.asarray(pa,float); gp=np.asarray(gp,float); n=len(pa)
    obs=float(np.mean(np.cos(np.deg2rad(2*np.abs(axial_diff(pa,gp))))))
    vals=[]; rem=nperm
    while rem:
        k=min(chunk,rem)
        idx=np.argsort(rng.random((k,n)),axis=1)
        pp=pa[idx]
        d=np.abs(((pp-gp[None,:]+90)%180)-90)
        vals.append(np.mean(np.cos(np.deg2rad(2*d)),axis=1))
        rem-=k
    vals=np.concatenate(vals)
    p=float((1+np.count_nonzero(vals>=obs))/(len(vals)+1))
    return obs,p

def signflip(d,rng):
    d=np.asarray(d,float); n=len(d); obs=float(np.mean(d))
    vals=[]; rem=N_SIGNFLIP
    while rem:
        k=min(20000,rem)
        s=rng.choice(np.array([-1.0,1.0]),size=(k,n))
        vals.append(np.mean(s*d[None,:],axis=1))
        rem-=k
    vals=np.concatenate(vals)
    p=float((1+np.count_nonzero(vals>=obs))/(len(vals)+1))
    return obs,p

def prepare_sample(df,coord_source=None):
    out=df.copy()
    if "__RAdeg" not in out.columns or "__DEdeg" not in out.columns:
        if coord_source is None: raise RuntimeError("Coordinates unavailable.")
        cs=coord_source[["ID","Name","__RAdeg","__DEdeg"]]
        out=out.merge(cs,on=["ID","Name"],how="left",validate="one_to_one")
    return out

def process_population(base,member_dir,label,pcut):
    rows=[]
    for i,r in base.reset_index(drop=True).iterrows():
        cid=int(r["ID"]); name=str(r["Name"])
        mf=find_member_file(member_dir,cid,name)
        if mf is None:
            rows.append({"ID":cid,"Name":name,"status":"MISSING"})
            continue
        m=pd.read_csv(mf)
        p=pd.to_numeric(m["Prob"],errors="coerce").to_numpy(float)
        ra=pd.to_numeric(m["__RAdeg"],errors="coerce").to_numpy(float)
        de=pd.to_numeric(m["__DEdeg"],errors="coerce").to_numpy(float)
        g=np.isfinite(p)&np.isfinite(ra)&np.isfinite(de)&(p>=pcut)
        p,ra,de=p[g],ra[g],de[g]
        x,y=tangent_xy_arcmin(ra,de,r["__RAdeg"],r["__DEdeg"])
        gg=np.isfinite(x)&np.isfinite(y)&np.isfinite(p)&(p>0)
        x,y,p=x[gg],y[gg],p[gg]
        if len(x)<20 or neff(p)<10:
            rows.append({"ID":cid,"Name":name,"status":"TOO_FEW","N":len(x),"Neff":neff(p)})
            continue
        rad=np.hypot(x,y)
        cal=calibrate(rad,p,cid,pcut)
        rm=real_morph(x,y,p,cid,pcut)
        if rm is None:
            rows.append({"ID":cid,"Name":name,"status":"SHAPE_FAIL"})
            continue
        g2=np.isfinite(cal["qmax"]) and rm["q84"]<=cal["qmax"]
        g3=rm["q"]<cal["q_round_null_p05"]
        g4=rm["pa_p68"]<=PA_P68_MAX
        admit=bool(g2 and g3 and g4)
        gp=local_gal_pa(r["__RAdeg"],r["__DEdeg"])
        delta=abs(float(axial_diff(rm["pa"],gp)))
        rows.append({
            "ID":cid,"Name":name,"status":"OK","sample":label,
            "MassJ":r["MassJ"],"logAge50":r.get("logAge50",np.nan),
            "__RAdeg":r["__RAdeg"],"__DEdeg":r["__DEdeg"],
            "N":len(x),"Neff":neff(p),"pcut":pcut,
            "q":rm["q"],"q84":rm["q84"],"PA_deg":rm["pa"],"PAerr68":rm["pa_p68"],
            "q_round_null_p05":cal["q_round_null_p05"],"qmax":cal["qmax"],
            "admitted":admit,
            "PA_Gal":gp,"Delta":delta,"cos2Delta":math.cos(math.radians(2*delta)),
        })
    return pd.DataFrame(rows)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage0",required=True)
    ap.add_argument("--stage1b",required=True)
    ap.add_argument("--stage2a",required=True)
    ap.add_argument("--stage2c",required=True)
    ap.add_argument("--out",default="STAGE3B_OUTPUT")
    args=ap.parse_args()

    stage0=Path(args.stage0).resolve()
    stage1b=Path(args.stage1b).resolve()
    stage2a=Path(args.stage2a).resolve()
    stage2c=Path(args.stage2c).resolve()
    out=Path(args.out).resolve(); out.mkdir(parents=True,exist_ok=True)

    yf=stage1b/"02_PRIMARY_PA_SAMPLE_FROZEN.csv"
    cf=stage2c/"02_CONTROL_PA_SAMPLE_FROZEN.csv"
    if sha256(yf)!=EXPECTED_YOUNG_SHA256: raise RuntimeError("Young hash mismatch.")
    if sha256(cf)!=EXPECTED_CONTROL_SHA256: raise RuntimeError("Control hash mismatch.")

    y=prepare_sample(pd.read_csv(yf),pd.read_csv(stage0/"07_provisional_morphology_ready.csv"))
    c=prepare_sample(pd.read_csv(cf))
    ymem=stage0/"members_primary"
    cmem=stage2a/"members_control_frozen"

    print("="*96)
    print(f"YHMC STAGE-3B MEMBERSHIP-THRESHOLD ROBUSTNESS v{VERSION}")
    print("="*96)
    print("CHAIN_OF_CUSTODY=PASS")
    print(f"YOUNG_N={len(y)} CONTROL_N={len(c)}")
    print(f"P_CUTS={P_CUTS}")
    print("Each threshold gets an independent synthetic calibration.")

    summaries=[]
    matched_summaries=[]

    for pcut in P_CUTS:
        tag=f"P{int(round(100*pcut))}"
        print(f"\n--- {tag} ---")
        yr=process_population(y,ymem,"young",pcut)
        cr=process_population(c,cmem,"control",pcut)
        yr.to_csv(out/f"01_{tag}_young_reanalysis.csv",index=False)
        cr.to_csv(out/f"02_{tag}_control_reanalysis.csv",index=False)

        for label,df in [("young",yr),("control",cr)]:
            ok=df[(df.status=="OK")&(df.admitted==True)].copy()
            for mass in [1000,3000]:
                s=ok[pd.to_numeric(ok.MassJ,errors="coerce")>=mass]
                if len(s)>=2:
                    rng=np.random.default_rng(np.random.SeedSequence([SEED,int(pcut*100),mass,1 if label=="young" else 2]))
                    A,pp=pa_position_perm(s.PA_deg,s.PA_Gal,N_PERM,rng)
                elif len(s)==1:
                    A=float(s.cos2Delta.iloc[0]); pp=np.nan
                else:
                    A=pp=np.nan
                summaries.append({
                    "pcut":pcut,"sample":label,"MassJ_threshold":mass,
                    "N_parent":len(df),"N_admitted_mass":len(s),
                    "A":A,"PA_position_perm_p":pp,
                    "median_Delta":float(s.Delta.median()) if len(s) else np.nan,
                })

        # Matched contrast using original control->young anchor mapping already frozen in control file.
        ya=yr[(yr.status=="OK")&(yr.admitted==True)].copy()
        ca=cr[(cr.status=="OK")&(cr.admitted==True)].copy()
        mapcols=c[["ID","Name","young_ID","young_Name"]]
        ca=ca.merge(mapcols,on=["ID","Name"],how="left",validate="one_to_one")
        cc=ca.groupby(["young_ID","young_Name"],as_index=False).agg(
            cmean=("cos2Delta","mean"),Ncontrol=("ID","size")
        )
        ys=ya[["ID","Name","MassJ","cos2Delta"]].rename(
            columns={"ID":"young_ID","Name":"young_Name","MassJ":"MassJ_young","cos2Delta":"ycos"}
        )
        a=ys.merge(cc,on=["young_ID","young_Name"],how="inner",validate="one_to_one")
        a["D"]=a.ycos-a.cmean
        a.to_csv(out/f"03_{tag}_matched_anchor_table.csv",index=False)

        for role,mask in [
            ("PRIMARY_M3000",pd.to_numeric(a.MassJ_young,errors="coerce")>=PRIMARY_MASS),
            ("EXTENDED",np.ones(len(a),dtype=bool))
        ]:
            s=a.loc[mask]
            if len(s)>=2:
                rng=np.random.default_rng(np.random.SeedSequence([SEED,int(pcut*100),999 if role=="PRIMARY_M3000" else 998]))
                D,ps=signflip(s.D.to_numpy(float),rng)
            elif len(s)==1:
                D=float(s.D.iloc[0]); ps=np.nan
            else:
                D=ps=np.nan
            matched_summaries.append({
                "pcut":pcut,"ROLE":role,"N_anchors":len(s),
                "A_young":float(s.ycos.mean()) if len(s) else np.nan,
                "A_control_anchor":float(s.cmean.mean()) if len(s) else np.nan,
                "D":D,"signflip_p_D_gt0":ps,
                "fraction_D_gt0":float(np.mean(s.D>0)) if len(s) else np.nan
            })

        print(f"{tag}: young admitted={int(((yr.status=='OK') & (yr.admitted==True)).sum())}, "
              f"control admitted={int(((cr.status=='OK') & (cr.admitted==True)).sum())}, "
              f"matched anchors={len(a)}")

    ssum=pd.DataFrame(summaries)
    msum=pd.DataFrame(matched_summaries)
    ssum.to_csv(out/"04_threshold_alignment_summary.csv",index=False)
    msum.to_csv(out/"05_threshold_matched_contrast_summary.csv",index=False)

    contract={
        "stage":"STAGE3B_MEMBERSHIP_THRESHOLD_ROBUSTNESS",
        "version":VERSION,
        "young_frozen_sha256":sha256(yf),
        "control_frozen_sha256":sha256(cf),
        "pre_specified_probability_thresholds":P_CUTS,
        "q_grid":Q_GRID,
        "n_synthetic_per_q":N_SYNTH,
        "n_bootstrap":N_BOOT,
        "gate":"same four-part morphology gate, recalibrated independently at each probability threshold",
        "threshold_selection_after_results":False,
    }
    (out/"STAGE3B_CONTRACT.json").write_text(json.dumps(contract,indent=2),encoding="utf-8")

    report=[
        f"YHMC STAGE-3B MEMBERSHIP-THRESHOLD ROBUSTNESS v{VERSION}",
        "="*96,
        "CHAIN_OF_CUSTODY=PASS",
        f"Pre-specified thresholds: {P_CUTS}",
        "Each threshold independently recalibrated before real morphology admission.",
        "",
        "ALIGNMENT SUMMARY:",
        ssum.to_string(index=False),
        "",
        "MATCHED AGE-CONTRAST SUMMARY:",
        msum.to_string(index=False),
        "",
        "INTERPRETATION:",
        "  Robust common Galactic-plane alignment requires positive A with consistent magnitude",
        "  and small PA-position permutation p across the stricter membership thresholds.",
        "  The young-vs-old age claim is evaluated separately through D; it must not be inferred",
        "  from standalone A values.",
        "",
        "NEXT:",
        "  Estimator robustness and independently calibrated inner r<r50J morphology.",
    ]
    (out/"STAGE3B_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")
    print()
    print((out/"STAGE3B_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

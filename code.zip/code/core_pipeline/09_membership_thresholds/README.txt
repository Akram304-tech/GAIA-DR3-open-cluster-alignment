YHMC STAGE-3B MEMBERSHIP-THRESHOLD ROBUSTNESS v1.0.0
=======================================================

Tests the pre-specified member probability cuts:
  P >= 0.7
  P >= 0.8
  P >= 0.9

Important:
The baseline P>=0.5 morphology gate is NOT reused.

For every threshold and every frozen young/control identity, the script:
1. rebuilds the member sample;
2. independently runs the synthetic q/PA calibration;
3. recomputes real q/PA and bootstrap errors;
4. reapplies the morphology gate;
5. recomputes Galactic-plane alignment only after admission.

This is a conservative sensitivity analysis on the exact already-frozen
young and control identity sets.

Run:
  call RUN_STAGE3B_MEMBERSHIP_THRESHOLD_ROBUSTNESS_v1_0_0.bat

YHMC Stage-6B3B Mechanism Association Unblind v2.4.1
======================================================

This is the one-time pre-specified mechanism association analysis.

Everything is already frozen before value access:
- exact N=45 primary sample;
- exact McMillan17 numerical orbit predictor;
- exact historical young/control alignment outcome files;
- exact outcome columns;
- exact statistic;
- exact two-sided cohort-stratified permutation inference.

Primary:
  Y = cos(2 Delta_theta_GP)
  X = -log(rperi/kpc)
  Spearman rho
  100,000 permutations, X shuffled within young/control cohorts.

Secondary analyses are those explicitly frozen in Stage-6B1:
- within-cohort Spearman;
- HC3 regression;
- Irrgang13III and MWPotential2014 potential sensitivity;
- 512-draw McMillan17 phase-space MC rho distribution.

Interpretation ceiling:
association may be called consistent with orbital/tidal environmental coupling,
but cannot establish tidal causation.

@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-6B3B MECHANISM ASSOCIATION UNBLIND v2.4.1
echo ONE-TIME PRE-SPECIFIED TEST
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" exit /b 1

set "STAGE6B1=%USERPROFILE%\Downloads\YHMC_STAGE6B1_ORBIT_MECHANISM_DESIGN_FREEZE_v2_2_0\YHMC_STAGE6B1_ORBIT_MECHANISM_DESIGN_FREEZE_v2_2_0\STAGE6B1_OUTPUT"
set "STAGE6B2R1=%USERPROFILE%\Downloads\YHMC_STAGE6B2R1_FAST_MC_ORBIT_PROXY_PRODUCTION_v2_3_2\YHMC_STAGE6B2R1_FAST_MC_ORBIT_PROXY_PRODUCTION_v2_3_2\STAGE6B2R1_OUTPUT"
set "STAGE6B3A=%USERPROFILE%\Downloads\YHMC_STAGE6B3A_ALIGNMENT_BINDING_PREFLIGHT_v2_4_0\YHMC_STAGE6B3A_ALIGNMENT_BINDING_PREFLIGHT_v2_4_0\STAGE6B3A_OUTPUT"

"%PYEXE%" -c "import numpy,pandas,scipy" >nul 2>nul
if errorlevel 1 exit /b 1

"%PYEXE%" stage6b3b_mechanism_association_unblind_v2_4_1.py ^
 --stage6b1 "%STAGE6B1%" ^
 --stage6b2r1 "%STAGE6B2R1%" ^
 --stage6b3a "%STAGE6B3A%" ^
 --out "%CD%\STAGE6B3B_OUTPUT"

set "RC=%ERRORLEVEL%"
echo.
echo RETURN_CODE=%RC%
if exist "%CD%\STAGE6B3B_OUTPUT\STAGE6B3B_REPORT.txt" echo REPORT=%CD%\STAGE6B3B_OUTPUT\STAGE6B3B_REPORT.txt
if exist "%CD%\STAGE6B3B_OUTPUT\STAGE6B3B_FREEZE.json" echo FREEZE=%CD%\STAGE6B3B_OUTPUT\STAGE6B3B_FREEZE.json
exit /b %RC%

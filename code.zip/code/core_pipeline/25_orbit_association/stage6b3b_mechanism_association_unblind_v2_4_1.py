#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-6B3B Mechanism Association Unblind v2.4.1

ONE-TIME PRE-SPECIFIED ASSOCIATION ANALYSIS.

Prerequisites already frozen:
- Stage-6B1 primary science sample and statistical design;
- Stage-6B2R1 orbital predictors and MC proxy draws;
- Stage-6B3A unique historical alignment-outcome binding.

PRIMARY TEST
------------
Response:
    Y = cos(2 Delta_theta_GP)

Predictor:
    X_peri = -log(rperi/kpc)
from the McMillan17 FULL NUMERICAL nominal orbit.

Sample:
    exact primary high-mass sample:
    22 young + 23 control = 45.

Statistic:
    Spearman rho.

Inference:
    100,000 TWO-SIDED cohort-stratified permutations.
    X_peri ranks are shuffled independently within young and control cohorts.
    p = (1 + #(|rho_perm| >= |rho_obs|)) / (N_perm + 1).

SECONDARY PREDECLARED TESTS
---------------------------
- within-young Spearman, 100,000 two-sided permutations;
- within-control Spearman, 100,000 two-sided permutations;
- pooled HC3 regression Y ~ X_peri + cohort;
- pooled cohort-stratified permutation Spearman for Irrgang13III;
- pooled cohort-stratified permutation Spearman for MWPotential2014;
- McMillan17 512-draw phase-space MC distribution of Spearman rho.

INTERPRETATION CEILING
----------------------
Even a positive association may be described only as consistent with
orbital/tidal environmental coupling. It does not establish tidal causation.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import rankdata, spearmanr

VERSION="2.4.1"

EXPECTED_PRIMARY_SHA="46e1c9fa4ab1ff8d557d3aa2f38dd61bd05de0a3abe0664f6e57f4434a634c46"
EXPECTED_NOMINAL_SHA="1513737e70b44214bdffa8addd74d95b0ac52980624b24e0b6486fed9b1b1c92"
EXPECTED_MC_SHA="6e93caa2e53c5bf94ef3b5b09db21b5c245502809b9e6f758c61adf2de7f85af"
EXPECTED_ORBIT_SUMMARY_SHA="29932f41f94a9625125cbd7619a42985feab851cab60143969fc31fc8dfcade9"

N_PERM=100000
PERM_SEED=20260912
PRIMARY_POTENTIAL="McMillan17"
SENSITIVITY_POTENTIALS=["Irrgang13III","MWPotential2014"]

YOUNG_DELTA_COL="Delta_theta_deg"
YOUNG_Y_COL="cos2Delta"
CONTROL_DELTA_COL="Delta_theta_control_deg"
CONTROL_Y_COL="cos2Delta_control"

def sha256(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def pearson_on_vectors(a,b):
    a=np.asarray(a,float); b=np.asarray(b,float)
    ac=a-a.mean(); bc=b-b.mean()
    den=np.sqrt(np.sum(ac*ac)*np.sum(bc*bc))
    return float(np.sum(ac*bc)/den) if den>0 else np.nan

def spearman_fast(y,x):
    return pearson_on_vectors(rankdata(y,method="average"),rankdata(x,method="average"))

def strat_perm_spearman(y,x,group,nperm,seed):
    y=np.asarray(y,float)
    x=np.asarray(x,float)
    group=np.asarray(group,str)

    ry=rankdata(y,method="average")
    rx=rankdata(x,method="average")
    ryc=ry-ry.mean()
    denom_y=np.sqrt(np.sum(ryc*ryc))

    idxs=[np.where(group==g)[0] for g in sorted(set(group.tolist()))]
    rng=np.random.default_rng(seed)

    obs=pearson_on_vectors(ry,rx)
    ge=0
    vals=np.empty(nperm,float)

    for i in range(nperm):
        rp=rx.copy()
        for ix in idxs:
            rp[ix]=rp[rng.permutation(ix)]
        rpc=rp-rp.mean()
        den=denom_y*np.sqrt(np.sum(rpc*rpc))
        rr=float(np.sum(ryc*rpc)/den)
        vals[i]=rr
        if abs(rr)>=abs(obs)-1e-15:
            ge+=1

    p=(ge+1)/(nperm+1)
    return obs,p,vals

def unstrat_perm_spearman(y,x,nperm,seed):
    y=np.asarray(y,float); x=np.asarray(x,float)
    ry=rankdata(y,method="average")
    rx=rankdata(x,method="average")
    ryc=ry-ry.mean()
    denom_y=np.sqrt(np.sum(ryc*ryc))
    obs=pearson_on_vectors(ry,rx)
    rng=np.random.default_rng(seed)
    ge=0
    vals=np.empty(nperm,float)
    for i in range(nperm):
        rp=rx[rng.permutation(len(rx))]
        rpc=rp-rp.mean()
        rr=float(np.sum(ryc*rpc)/(denom_y*np.sqrt(np.sum(rpc*rpc))))
        vals[i]=rr
        if abs(rr)>=abs(obs)-1e-15:
            ge+=1
    return obs,(ge+1)/(nperm+1),vals

def hc3_regression(y,x,cohort):
    """
    OLS Y ~ 1 + X + I(control), HC3 covariance.
    Returns coefficient table.
    """
    y=np.asarray(y,float)
    x=np.asarray(x,float)
    c=(np.asarray(cohort,str)=="control").astype(float)
    X=np.column_stack([np.ones(len(y)),x,c])

    XtX_inv=np.linalg.inv(X.T@X)
    beta=XtX_inv@(X.T@y)
    resid=y-X@beta
    H=np.sum((X@XtX_inv)*X,axis=1)
    adj=resid/(1.0-H)
    meat=X.T@((adj*adj)[:,None]*X)
    cov=XtX_inv@meat@XtX_inv
    se=np.sqrt(np.diag(cov))
    t=beta/se

    # Normal approximation for HC3 coefficient summary.
    from scipy.stats import norm
    p=2.0*norm.sf(np.abs(t))
    lo=beta-1.959963984540054*se
    hi=beta+1.959963984540054*se

    return pd.DataFrame({
        "term":["intercept","X_peri","control_indicator"],
        "coefficient":beta,
        "HC3_SE":se,
        "z_approx":t,
        "p_two_sided_normal":p,
        "CI95_lo":lo,
        "CI95_hi":hi,
    })

def validate_outcome_semantics(df,delta_col,y_col,label):
    delta=pd.to_numeric(df[delta_col],errors="coerce").to_numpy(float)
    y=pd.to_numeric(df[y_col],errors="coerce").to_numpy(float)
    if not np.all(np.isfinite(delta)) or not np.all(np.isfinite(y)):
        raise RuntimeError(f"{label}: non-finite outcome values.")
    if np.any(delta<0) or np.any(delta>90):
        raise RuntimeError(f"{label}: Delta theta outside [0,90].")
    expected=np.cos(2.0*np.deg2rad(delta))
    maxdiff=float(np.max(np.abs(expected-y)))
    if maxdiff>5e-8:
        raise RuntimeError(
            f"{label}: {y_col} inconsistent with cos(2*Delta); maxdiff={maxdiff}"
        )
    if np.any(y < -1.0000001) or np.any(y > 1.0000001):
        raise RuntimeError(f"{label}: cos2Delta outside [-1,1].")
    return maxdiff

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage6b1",required=True)
    ap.add_argument("--stage6b2r1",required=True)
    ap.add_argument("--stage6b3a",required=True)
    ap.add_argument("--out",default="STAGE6B3B_OUTPUT")
    args=ap.parse_args()

    s1=Path(args.stage6b1).resolve()
    s2=Path(args.stage6b2r1).resolve()
    s3=Path(args.stage6b3a).resolve()
    out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=True)

    primary_f=s1/"01_PRIMARY_HIGH_MASS_6D_SAMPLE_FROZEN.csv"
    nominal_f=s2/"01_PRIMARY_NOMINAL_ORBIT_PROXIES_FROZEN.csv"
    mc_f=s2/"03_PRIMARY_MC_ORBIT_PROXY_DRAWS_FROZEN.csv"
    summary_f=s2/"04_PRIMARY_ORBIT_PROXY_SUMMARY_FROZEN.csv"
    orbit_freeze=s2/"STAGE6B2R1_FREEZE.json"
    preflight_f=s3/"STAGE6B3A_BINDING_PREFLIGHT.json"

    for p in [primary_f,nominal_f,mc_f,summary_f,orbit_freeze,preflight_f]:
        if not p.exists(): raise FileNotFoundError(p)

    if sha256(primary_f)!=EXPECTED_PRIMARY_SHA:
        raise RuntimeError("Primary sample hash mismatch.")
    if sha256(nominal_f)!=EXPECTED_NOMINAL_SHA:
        raise RuntimeError("Nominal orbit hash mismatch.")
    if sha256(mc_f)!=EXPECTED_MC_SHA:
        raise RuntimeError("MC orbit hash mismatch.")
    if sha256(summary_f)!=EXPECTED_ORBIT_SUMMARY_SHA:
        raise RuntimeError("Orbit summary hash mismatch.")

    of=json.loads(orbit_freeze.read_text(encoding="utf-8"))
    if not bool(of.get("ORBIT_PROXY_FREEZE_PASS",False)):
        raise RuntimeError("Orbit proxy freeze is not PASS.")
    if bool(of.get("alignment_read",True)):
        raise RuntimeError("Orbit-production alignment firewall violated.")

    pre=json.loads(preflight_f.read_text(encoding="utf-8"))
    if not bool(pre.get("UNIQUE_BINDING_CANDIDATES",False)):
        raise RuntimeError("Stage-6B3A did not produce unique outcome binding.")

    young_path=Path(pre["young_candidate_path"])
    control_path=Path(pre["control_candidate_path"])
    for p in [young_path,control_path]:
        if not p.exists(): raise FileNotFoundError(p)

    # PRE-UNBLIND BINDING FREEZE:
    # only paths, hashes, headers and predetermined columns.
    yh=list(pd.read_csv(young_path,nrows=0).columns)
    ch=list(pd.read_csv(control_path,nrows=0).columns)

    for c in ["ID",YOUNG_DELTA_COL,YOUNG_Y_COL]:
        if c not in yh:
            raise RuntimeError(f"Young outcome missing exact frozen column {c}.")
    for c in ["ID",CONTROL_DELTA_COL,CONTROL_Y_COL]:
        if c not in ch:
            raise RuntimeError(f"Control outcome missing exact frozen column {c}.")

    binding={
        "stage":"STAGE6B3B_PREUNBLIND_BINDING_FREEZE",
        "version":VERSION,
        "alignment_values_read_at_binding_freeze":False,
        "young_path":str(young_path),
        "young_sha256":sha256(young_path),
        "young_ID_column":"ID",
        "young_delta_column":YOUNG_DELTA_COL,
        "young_response_column":YOUNG_Y_COL,
        "control_path":str(control_path),
        "control_sha256":sha256(control_path),
        "control_ID_column":"ID",
        "control_delta_column":CONTROL_DELTA_COL,
        "control_response_column":CONTROL_Y_COL,
        "primary_orbit_sha256":EXPECTED_NOMINAL_SHA,
        "primary_predictor":"McMillan17 nominal X_peri",
        "primary_statistic":"Spearman rho",
        "primary_inference":"100000 two-sided cohort-stratified permutations",
        "permutation_seed":PERM_SEED,
    }
    binding_f=out/"00_PREUNBLIND_BINDING_FREEZE.json"
    binding_f.write_text(json.dumps(binding,indent=2),encoding="utf-8")
    binding_sha=sha256(binding_f)

    print("="*112)
    print(f"YHMC STAGE-6B3B MECHANISM ASSOCIATION UNBLIND v{VERSION}")
    print("="*112)
    print("PREUNBLIND_BINDING_FROZEN=True")
    print(f"PREUNBLIND_BINDING_SHA256={binding_sha}")
    print("PRIMARY_PREDICTOR_FROZEN=McMillan17 nominal X_peri")
    print("PRIMARY_RESPONSE_FROZEN=cos(2 Delta_theta_GP)")
    print(f"N_PERM={N_PERM}")
    print("UNBLINDING_NOW=True")
    print()

    # ---------- FIRST VALUE READ ----------
    young=pd.read_csv(young_path,usecols=["ID",YOUNG_DELTA_COL,YOUNG_Y_COL])
    control=pd.read_csv(control_path,usecols=["ID",CONTROL_DELTA_COL,CONTROL_Y_COL])
    young["ID"]=pd.to_numeric(young["ID"],errors="raise").astype(int)
    control["ID"]=pd.to_numeric(control["ID"],errors="raise").astype(int)

    if young["ID"].duplicated().any() or control["ID"].duplicated().any():
        raise RuntimeError("Duplicate IDs in historical alignment outcome file.")

    qy=validate_outcome_semantics(young,YOUNG_DELTA_COL,YOUNG_Y_COL,"young")
    qc=validate_outcome_semantics(control,CONTROL_DELTA_COL,CONTROL_Y_COL,"control")

    yout=young.rename(columns={
        YOUNG_DELTA_COL:"Delta_theta_GP_deg",
        YOUNG_Y_COL:"Y_cos2Delta"
    })[["ID","Delta_theta_GP_deg","Y_cos2Delta"]]
    yout["sample"]="young"

    cout=control.rename(columns={
        CONTROL_DELTA_COL:"Delta_theta_GP_deg",
        CONTROL_Y_COL:"Y_cos2Delta"
    })[["ID","Delta_theta_GP_deg","Y_cos2Delta"]]
    cout["sample"]="control"

    outcomes=pd.concat([yout,cout],ignore_index=True)

    primary=pd.read_csv(primary_f,usecols=["ID","sample"])
    primary["ID"]=pd.to_numeric(primary["ID"],errors="raise").astype(int)

    target=primary.merge(
        outcomes,on=["ID","sample"],how="left",validate="one_to_one"
    )
    if len(target)!=45 or target["Y_cos2Delta"].isna().any():
        raise RuntimeError(
            f"Outcome binding did not cover exact primary sample: rows={len(target)}, "
            f"missing={target['Y_cos2Delta'].isna().sum()}"
        )
    if int((target["sample"]=="young").sum())!=22 or int((target["sample"]=="control").sum())!=23:
        raise RuntimeError("Bound primary cohort counts are not 22/23.")

    nominal=pd.read_csv(nominal_f)
    nominal["ID"]=pd.to_numeric(nominal["ID"],errors="raise").astype(int)

    # Primary-potential exact join.
    pnom=nominal[nominal["potential"].astype(str)==PRIMARY_POTENTIAL][
        ["ID","sample","potential","rperi_kpc","rap_kpc","eccentricity","zmax_kpc","X_peri"]
    ].copy()

    dat=target.merge(
        pnom,on=["ID","sample"],how="left",validate="one_to_one"
    )
    if len(dat)!=45 or dat["X_peri"].isna().any():
        raise RuntimeError("Primary McMillan17 orbit join incomplete.")

    y=dat["Y_cos2Delta"].to_numpy(float)
    x=dat["X_peri"].to_numpy(float)
    grp=dat["sample"].astype(str).to_numpy()

    rho_primary,p_primary,perm_primary=strat_perm_spearman(
        y,x,grp,N_PERM,PERM_SEED
    )

    # Cohort-specific secondary.
    cohort_rows=[]
    for j,label in enumerate(["young","control"]):
        dd=dat[dat["sample"]==label]
        rho,p,vals=unstrat_perm_spearman(
            dd["Y_cos2Delta"].to_numpy(float),
            dd["X_peri"].to_numpy(float),
            N_PERM,PERM_SEED+101+j
        )
        cohort_rows.append({
            "analysis":f"{label}_within",
            "potential":PRIMARY_POTENTIAL,
            "N":len(dd),
            "rho_spearman":rho,
            "p_two_sided_perm":p,
            "N_perm":N_PERM,
            "perm_q025":float(np.quantile(vals,0.025)),
            "perm_q975":float(np.quantile(vals,0.975)),
        })
    cohort_df=pd.DataFrame(cohort_rows)

    # Potential sensitivities, same exact outcomes and IDs.
    pot_rows=[]
    for j,pname in enumerate([PRIMARY_POTENTIAL]+SENSITIVITY_POTENTIALS):
        pp=nominal[nominal["potential"].astype(str)==pname][
            ["ID","sample","X_peri","rperi_kpc"]
        ].copy()
        dd=target.merge(pp,on=["ID","sample"],how="left",validate="one_to_one")
        if len(dd)!=45 or dd["X_peri"].isna().any():
            raise RuntimeError(f"{pname}: incomplete exact join.")
        rho,p,vals=strat_perm_spearman(
            dd["Y_cos2Delta"].to_numpy(float),
            dd["X_peri"].to_numpy(float),
            dd["sample"].astype(str).to_numpy(),
            N_PERM,PERM_SEED+1000+j
        )
        pot_rows.append({
            "potential":pname,
            "role":"PRIMARY" if pname==PRIMARY_POTENTIAL else "SENSITIVITY",
            "N":45,
            "rho_spearman":rho,
            "p_two_sided_cohort_stratified_perm":p,
            "N_perm":N_PERM,
            "direction_expected_positive":True,
            "observed_sign":"positive" if rho>0 else ("negative" if rho<0 else "zero"),
        })
    pot_df=pd.DataFrame(pot_rows)

    # Pooled HC3 regression for primary potential.
    reg=hc3_regression(y,x,grp)

    # MC propagation of PRIMARY-potential Spearman rho.
    mc=pd.read_csv(mc_f,usecols=["ID","sample","potential","draw_index","X_peri"])
    mc["ID"]=pd.to_numeric(mc["ID"],errors="raise").astype(int)
    mc["draw_index"]=pd.to_numeric(mc["draw_index"],errors="raise").astype(int)
    mc=mc[mc["potential"].astype(str)==PRIMARY_POTENTIAL].copy()
    if len(mc)!=45*512:
        raise RuntimeError(f"Expected McMillan17 MC rows 23040, got {len(mc)}.")

    # Enforce exact cell completeness.
    cnt=mc.groupby(["ID","sample"]).size()
    if len(cnt)!=45 or not (cnt==512).all():
        raise RuntimeError("Primary-potential MC cells not complete 512/512.")

    # Join response once; then one independent orbit draw/object per draw_index.
    mcj=mc.merge(
        target[["ID","sample","Y_cos2Delta"]],
        on=["ID","sample"],how="left",validate="many_to_one"
    )
    if mcj["Y_cos2Delta"].isna().any():
        raise RuntimeError("MC response join incomplete.")

    mc_rhos=[]
    for draw in range(512):
        dd=mcj[mcj["draw_index"]==draw]
        if len(dd)!=45:
            raise RuntimeError(f"MC draw {draw} has N={len(dd)}, expected45.")
        rr=spearman_fast(
            dd["Y_cos2Delta"].to_numpy(float),
            dd["X_peri"].to_numpy(float)
        )
        mc_rhos.append(rr)
    mc_rhos=np.asarray(mc_rhos,float)

    mc_summary=pd.DataFrame([{
        "potential":PRIMARY_POTENTIAL,
        "N_objects":45,
        "N_phase_space_realizations":512,
        "rho_nominal":rho_primary,
        "rho_MC_median":float(np.median(mc_rhos)),
        "rho_MC_q025":float(np.quantile(mc_rhos,0.025)),
        "rho_MC_q16":float(np.quantile(mc_rhos,0.16)),
        "rho_MC_q84":float(np.quantile(mc_rhos,0.84)),
        "rho_MC_q975":float(np.quantile(mc_rhos,0.975)),
        "fraction_rho_positive":float(np.mean(mc_rhos>0)),
        "fraction_rho_negative":float(np.mean(mc_rhos<0)),
    }])

    # Object-level joined table for reproducibility.
    dat_out=dat[[
        "ID","sample","Delta_theta_GP_deg","Y_cos2Delta",
        "rperi_kpc","rap_kpc","eccentricity","zmax_kpc","X_peri"
    ]].copy()
    dat_out.to_csv(out/"01_PRIMARY_JOINED_OBJECT_TABLE.csv",index=False)

    primary_df=pd.DataFrame([{
        "analysis":"PRIMARY_POOLED",
        "potential":PRIMARY_POTENTIAL,
        "N":45,
        "N_young":22,
        "N_control":23,
        "response":"cos(2 Delta_theta_GP)",
        "predictor":"X_peri=-log(rperi/kpc)",
        "rho_spearman":rho_primary,
        "p_two_sided_cohort_stratified_perm":p_primary,
        "N_perm":N_PERM,
        "expected_direction":"positive",
        "observed_sign":"positive" if rho_primary>0 else ("negative" if rho_primary<0 else "zero"),
        "perm_p_floor":1/(N_PERM+1),
    }])
    primary_df.to_csv(out/"02_PRIMARY_ASSOCIATION_RESULT.csv",index=False)
    cohort_df.to_csv(out/"03_WITHIN_COHORT_SECONDARY.csv",index=False)
    pot_df.to_csv(out/"04_POTENTIAL_SENSITIVITY.csv",index=False)
    reg.to_csv(out/"05_HC3_REGRESSION.csv",index=False)
    mc_summary.to_csv(out/"06_MC_RHO_SUMMARY.csv",index=False)
    pd.DataFrame({"draw_index":np.arange(512),"rho_spearman":mc_rhos}).to_csv(
        out/"07_MC_RHO_DRAWS.csv",index=False
    )

    # Interpretation is mechanically limited by the frozen contract.
    if p_primary < 0.05 and rho_primary > 0:
        interpretation=(
            "PRIMARY_ASSOCIATION_SUPPORTED_POSITIVE__CONSISTENT_WITH_ORBITAL_TIDAL_ENVIRONMENTAL_COUPLING__CAUSATION_NOT_ESTABLISHED"
        )
    elif p_primary < 0.05 and rho_primary < 0:
        interpretation=(
            "PRIMARY_ASSOCIATION_SIGNIFICANT_OPPOSITE_TO_PREDECLARED_PHYSICAL_EXPECTATION__DO_NOT_CLAIM_TIDAL_COUPLING"
        )
    else:
        interpretation=(
            "PRIMARY_ASSOCIATION_NOT_SUPPORTED_AT_P_LT_0P05__ORBITAL_TIDAL_COUPLING_NOT_ESTABLISHED"
        )

    hjoin=sha256(out/"01_PRIMARY_JOINED_OBJECT_TABLE.csv")
    hpri=sha256(out/"02_PRIMARY_ASSOCIATION_RESULT.csv")
    hpot=sha256(out/"04_POTENTIAL_SENSITIVITY.csv")
    hmc=sha256(out/"06_MC_RHO_SUMMARY.csv")

    freeze={
        "stage":"STAGE6B3B_MECHANISM_ASSOCIATION_UNBLIND",
        "version":VERSION,
        "preunblind_binding_sha256":binding_sha,
        "young_outcome_sha256":binding["young_sha256"],
        "control_outcome_sha256":binding["control_sha256"],
        "nominal_orbit_sha256":EXPECTED_NOMINAL_SHA,
        "MC_orbit_sha256":EXPECTED_MC_SHA,
        "N":45,
        "primary":{
            "potential":PRIMARY_POTENTIAL,
            "response":"Y=cos(2 Delta_theta_GP)",
            "predictor":"X_peri=-log(rperi/kpc)",
            "rho_spearman":rho_primary,
            "p_two_sided_cohort_stratified_perm":p_primary,
            "N_perm":N_PERM,
        },
        "outcome_semantic_qc":{
            "young_max_abs_cos2_reconstruction_diff":qy,
            "control_max_abs_cos2_reconstruction_diff":qc,
        },
        "interpretation_state":interpretation,
        "causation_established":False,
        "joined_table_sha256":hjoin,
        "primary_result_sha256":hpri,
        "potential_sensitivity_sha256":hpot,
        "MC_rho_summary_sha256":hmc,
        "ASSOCIATION_UNBLIND_COMPLETE":True,
        "next":
            "Interpret against the predeclared claim ceiling; then decide whether the independently predeclared tidal-tensor secondary mechanism layer is worth technical validation. Do not replace the primary rperi endpoint."
    }
    (out/"STAGE6B3B_FREEZE.json").write_text(
        json.dumps(freeze,indent=2),encoding="utf-8"
    )

    report=[
        f"YHMC STAGE-6B3B MECHANISM ASSOCIATION UNBLIND v{VERSION}",
        "="*112,
        f"PREUNBLIND_BINDING_SHA256={binding_sha}",
        "ASSOCIATION_UNBLIND_COMPLETE=True",
        "",
        "PRIMARY:",
        f"N=45 (young=22, control=23)",
        f"POTENTIAL={PRIMARY_POTENTIAL}",
        "RESPONSE=cos(2 Delta_theta_GP)",
        "PREDICTOR=X_peri=-log(rperi/kpc)",
        f"RHO_SPEARMAN={rho_primary:.9f}",
        f"P_TWO_SIDED_COHORT_STRATIFIED_PERM={p_primary:.9f}",
        f"N_PERM={N_PERM}",
        f"OBSERVED_SIGN={'positive' if rho_primary>0 else ('negative' if rho_primary<0 else 'zero')}",
        "",
        "POTENTIAL SENSITIVITY:",
        pot_df.to_string(index=False),
        "",
        "WITHIN-COHORT SECONDARY:",
        cohort_df.to_string(index=False),
        "",
        "HC3 REGRESSION:",
        reg.to_string(index=False),
        "",
        "PHASE-SPACE MC RHO:",
        mc_summary.to_string(index=False),
        "",
        f"INTERPRETATION_STATE={interpretation}",
        "CAUSATION_ESTABLISHED=False",
        "",
        f"JOINED_TABLE_SHA256={hjoin}",
        f"PRIMARY_RESULT_SHA256={hpri}",
        f"POTENTIAL_SENSITIVITY_SHA256={hpot}",
        f"MC_RHO_SUMMARY_SHA256={hmc}",
    ]
    (out/"STAGE6B3B_REPORT.txt").write_text(
        "\n".join(report)+"\n",encoding="utf-8"
    )

    files=[
        "00_PREUNBLIND_BINDING_FREEZE.json",
        "01_PRIMARY_JOINED_OBJECT_TABLE.csv",
        "02_PRIMARY_ASSOCIATION_RESULT.csv",
        "03_WITHIN_COHORT_SECONDARY.csv",
        "04_POTENTIAL_SENSITIVITY.csv",
        "05_HC3_REGRESSION.csv",
        "06_MC_RHO_SUMMARY.csv",
        "07_MC_RHO_DRAWS.csv",
        "STAGE6B3B_FREEZE.json",
        "STAGE6B3B_REPORT.txt",
    ]
    (out/"SHA256SUMS.txt").write_text(
        "\n".join(f"{sha256(out/f)}  {f}" for f in files)+"\n",
        encoding="utf-8"
    )

    print()
    print((out/"STAGE6B3B_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

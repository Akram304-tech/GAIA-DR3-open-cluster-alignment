#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-4C inner-alignment unblind + paired radial contrast v1.4.0

FIRST authorized stage to compute Galactic-plane alignment for the
Stage-4B SHA256-frozen inner-PA samples.

Pre-frozen radial hierarchy
---------------------------
PRIMARY RADIAL TEST (young population):
  Exact Stage-4B young inner-admitted sample.
  For cluster i:
      R_i = cos(2 Delta_outer_i) - cos(2 Delta_inner_i)
  Endpoint:
      R = mean_i R_i
  Test:
      two-sided paired sign-flip test.
  Interpretation:
      R > 0 : outer alignment stronger
      R < 0 : inner alignment stronger

SECONDARY RADIAL REPLICATION (older controls):
  Same endpoint and two-sided paired sign-flip test for the exact
  Stage-4B control inner-admitted sample.

Standalone inner alignment
--------------------------
For young and older-control inner samples:
  A_inner = mean cos(2 Delta_inner)

Inference includes:
  - random-orientation null
  - PA-position permutation null (preserves empirical PA marginal and
    sky-position marginal)
  - bootstrap CI for A_inner

High-mass inner subsets are descriptive only because Stage-4B left
N=1 young and N=2 controls above 3000 Msun.

No sample changes or threshold changes are allowed.
"""

from __future__ import annotations
import argparse, hashlib, itertools, json, math
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "1.4.0"
SEED = 20260912

EXPECTED_YOUNG_INNER_SHA256 = "837caa2aca8d0bba0dab13aece0feee87c78899e74326424be7aaefe830f1bef"
EXPECTED_CONTROL_INNER_SHA256 = "8b9b847c2e55387bb461323fd94a2ea4111b1673493aa5d1792f5cf0b7d99d51"
EXPECTED_ANCHOR_COVERAGE_SHA256 = "8d10c0a2d2a6c87d836120c013f2d79076c687bb32ad56a82d2b4a3bd0c0dbea"
EXPECTED_STAGE4B_FREEZE_SHA256 = "87d24af7ea148bf13ad8e4ad1d3a1a12587d26837e1f6437b7e389fb2d0008b4"

N_NULL = 500000
N_PERM = 500000
N_BOOT = 200000

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()

def axial_diff(a,b):
    return ((np.asarray(a,float)-np.asarray(b,float)+90.0)%180.0)-90.0

def pct(x,p):
    x=np.asarray(x,float)
    x=x[np.isfinite(x)]
    return float(np.percentile(x,p)) if len(x) else np.nan

def local_reference_pas(ra,dec):
    """
    Independently derive local Galactic- and ecliptic-longitude tangent PAs
    from frozen ICRS coordinates.
    """
    from astropy.coordinates import SkyCoord, BarycentricMeanEcliptic
    from astropy.time import Time
    import astropy.units as u

    ra=np.asarray(ra,float)
    dec=np.asarray(dec,float)
    c=SkyCoord(ra=ra*u.deg,dec=dec*u.deg,frame="icrs")
    eps=1e-3*u.deg
    cosdec=np.cos(np.deg2rad(dec))

    g=c.galactic
    gp=SkyCoord(l=g.l+eps,b=g.b,frame="galactic").icrs
    gm=SkyCoord(l=g.l-eps,b=g.b,frame="galactic").icrs

    ef=BarycentricMeanEcliptic(equinox=Time("J2000"))
    e=c.transform_to(ef)
    ep=SkyCoord(lon=e.lon+eps,lat=e.lat,frame=ef).icrs
    em=SkyCoord(lon=e.lon-eps,lat=e.lat,frame=ef).icrs

    def pa_from(pm,mm):
        dra_p=((pm.ra.deg-ra+180.0)%360.0)-180.0
        dra_m=((mm.ra.deg-ra+180.0)%360.0)-180.0
        dx=(dra_p-dra_m)*cosdec
        dy=(pm.dec.deg-dec)-(mm.dec.deg-dec)
        return np.degrees(np.arctan2(dy,dx))%180.0

    return pa_from(gp,gm), pa_from(ep,em)

def random_orientation_null_A(n,nsim,rng,chunk=25000):
    vals=[]
    rem=nsim
    while rem:
        k=min(chunk,rem)
        d=rng.uniform(0.0,90.0,size=(k,n))
        vals.append(np.mean(np.cos(np.deg2rad(2*d)),axis=1))
        rem-=k
    return np.concatenate(vals)

def pa_position_perm_null(pa,refpa,nsim,rng):
    """
    Exact enumeration when feasible (n<=8); otherwise random permutations.
    """
    pa=np.asarray(pa,float)
    refpa=np.asarray(refpa,float)
    n=len(pa)

    if n<=8:
        vals=[]
        for perm in itertools.permutations(range(n)):
            pp=pa[list(perm)]
            d=np.abs(axial_diff(pp,refpa))
            vals.append(float(np.mean(np.cos(np.deg2rad(2*d)))))
        return np.asarray(vals,float), True

    vals=[]
    rem=nsim
    chunk=20000
    while rem:
        k=min(chunk,rem)
        idx=np.argsort(rng.random((k,n)),axis=1)
        pp=pa[idx]
        d=np.abs(((pp-refpa[None,:]+90.0)%180.0)-90.0)
        vals.append(np.mean(np.cos(np.deg2rad(2*d)),axis=1))
        rem-=k
    return np.concatenate(vals), False

def boot_mean(x,nsim,rng,chunk=25000):
    x=np.asarray(x,float)
    n=len(x)
    vals=[]
    rem=nsim
    while rem:
        k=min(chunk,rem)
        idx=rng.integers(0,n,size=(k,n))
        vals.append(np.mean(x[idx],axis=1))
        rem-=k
    return np.concatenate(vals)

def exact_signflip(d):
    """
    Exact paired sign-flip distribution. Safe here because n<=10/6.
    """
    d=np.asarray(d,float)
    n=len(d)
    obs=float(np.mean(d))
    vals=np.empty(2**n,dtype=float)
    for mask in range(2**n):
        signs=np.ones(n,float)
        for j in range(n):
            if mask & (1<<j):
                signs[j]=-1.0
        vals[mask]=np.mean(signs*d)
    p_two=float(np.mean(np.abs(vals)>=abs(obs)-1e-15))
    p_pos=float(np.mean(vals>=obs-1e-15))
    p_neg=float(np.mean(vals<=obs+1e-15))
    return obs,p_two,p_pos,p_neg,vals

def p_upper(obs,null):
    null=np.asarray(null,float)
    return float((1+np.count_nonzero(null>=obs))/(len(null)+1))

def p_two_abs(obs,null):
    null=np.asarray(null,float)
    return float((1+np.count_nonzero(np.abs(null)>=abs(obs)))/(len(null)+1))

def enrich(df,label):
    out=df.copy()
    ra=pd.to_numeric(out["__RAdeg"],errors="coerce").to_numpy(float)
    de=pd.to_numeric(out["__DEdeg"],errors="coerce").to_numpy(float)
    gp,ep=local_reference_pas(ra,de)

    pa_i=pd.to_numeric(out["PA_inner_deg_point"],errors="coerce").to_numpy(float)
    pa_o=pd.to_numeric(out["PA_outer_baseline_deg"],errors="coerce").to_numpy(float)

    out["PA_Galactic_parallel_deg"]=gp
    out["PA_Ecliptic_parallel_deg"]=ep

    out["Delta_inner_Gal_deg"]=np.abs(axial_diff(pa_i,gp))
    out["cos2Delta_inner_Gal"]=np.cos(np.deg2rad(2*out["Delta_inner_Gal_deg"].to_numpy(float)))

    out["Delta_outer_Gal_deg"]=np.abs(axial_diff(pa_o,gp))
    out["cos2Delta_outer_Gal"]=np.cos(np.deg2rad(2*out["Delta_outer_Gal_deg"].to_numpy(float)))

    out["R_outer_minus_inner"]=(
        out["cos2Delta_outer_Gal"]-out["cos2Delta_inner_Gal"]
    )

    out["Delta_inner_Ecliptic_deg"]=np.abs(axial_diff(pa_i,ep))
    out["cos2Delta_inner_Ecliptic"]=np.cos(
        np.deg2rad(2*out["Delta_inner_Ecliptic_deg"].to_numpy(float))
    )

    out["Delta_inner_Equatorial_EW_deg"]=np.abs(axial_diff(pa_i,0.0))
    out["cos2Delta_inner_Equatorial_EW"]=np.cos(
        np.deg2rad(2*out["Delta_inner_Equatorial_EW_deg"].to_numpy(float))
    )

    out["sample"]=label
    return out

def standalone_inner(df,label,tag):
    x=df["cos2Delta_inner_Gal"].to_numpy(float)
    pa=df["PA_inner_deg_point"].to_numpy(float)
    gp=df["PA_Galactic_parallel_deg"].to_numpy(float)
    n=len(df)
    A=float(np.mean(x))

    rng_null=np.random.default_rng(np.random.SeedSequence([SEED,tag,1]))
    rng_perm=np.random.default_rng(np.random.SeedSequence([SEED,tag,2]))
    rng_boot=np.random.default_rng(np.random.SeedSequence([SEED,tag,3]))

    null=random_orientation_null_A(n,N_NULL,rng_null)
    perm,perm_exact=pa_position_perm_null(pa,gp,N_PERM,rng_perm)
    boot=boot_mean(x,N_BOOT,rng_boot)

    return {
        "sample":label,
        "N":n,
        "A_inner_Galactic":A,
        "bootstrap_A_p025":pct(boot,2.5),
        "bootstrap_A_p16":pct(boot,16),
        "bootstrap_A_median":pct(boot,50),
        "bootstrap_A_p84":pct(boot,84),
        "bootstrap_A_p975":pct(boot,97.5),
        "p_random_orientation_parallel":p_upper(A,null),
        "p_random_orientation_two_sided":p_two_abs(A,null),
        "p_PA_position_permutation":p_upper(A,perm),
        "PA_position_permutation_exact":perm_exact,
        "permutation_count":len(perm),
        "median_Delta_inner_Gal_deg":float(np.median(df["Delta_inner_Gal_deg"])),
        "fraction_Delta_inner_le30":float(np.mean(df["Delta_inner_Gal_deg"]<=30.0)),
        "A_inner_Ecliptic":float(np.mean(df["cos2Delta_inner_Ecliptic"])),
        "A_inner_Equatorial_EW":float(np.mean(df["cos2Delta_inner_Equatorial_EW"])),
    }

def radial_test(df,label,tag):
    d=df["R_outer_minus_inner"].to_numpy(float)
    obs,p2,ppos,pneg,dist=exact_signflip(d)
    rng=np.random.default_rng(np.random.SeedSequence([SEED,tag,20]))
    boot=boot_mean(d,N_BOOT,rng)
    return {
        "sample":label,
        "N":len(df),
        "A_outer_same_clusters":float(np.mean(df["cos2Delta_outer_Gal"])),
        "A_inner_same_clusters":float(np.mean(df["cos2Delta_inner_Gal"])),
        "R_outer_minus_inner":obs,
        "bootstrap_R_p025":pct(boot,2.5),
        "bootstrap_R_p16":pct(boot,16),
        "bootstrap_R_median":pct(boot,50),
        "bootstrap_R_p84":pct(boot,84),
        "bootstrap_R_p975":pct(boot,97.5),
        "exact_signflip_p_two_sided":p2,
        "exact_signflip_p_R_gt0":ppos,
        "exact_signflip_p_R_lt0":pneg,
        "fraction_R_i_gt0":float(np.mean(d>0)),
        "median_R_i":float(np.median(d)),
        "median_abs_inner_outer_PA_diff_deg":
            float(np.median(df["abs_inner_outer_PA_difference_deg"])),
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage4b",required=True)
    ap.add_argument("--out",default="STAGE4C_OUTPUT")
    args=ap.parse_args()

    s4b=Path(args.stage4b).expanduser().resolve()
    out=Path(args.out).expanduser().resolve()
    out.mkdir(parents=True,exist_ok=True)

    yf=s4b/"03_YOUNG_INNER_PA_SAMPLE_FROZEN.csv"
    cf=s4b/"04_CONTROL_INNER_PA_SAMPLE_FROZEN.csv"
    af=s4b/"05_inner_anchor_coverage_FROZEN.csv"
    ff=s4b/"STAGE4B_FREEZE.json"

    for p in [yf,cf,af,ff]:
        if not p.exists():
            raise FileNotFoundError(p)

    hy=sha256(yf)
    hc=sha256(cf)
    ha=sha256(af)
    hf=sha256(ff)

    if hy!=EXPECTED_YOUNG_INNER_SHA256:
        raise RuntimeError(f"Young inner frozen hash mismatch: {hy}")
    if hc!=EXPECTED_CONTROL_INNER_SHA256:
        raise RuntimeError(f"Control inner frozen hash mismatch: {hc}")
    if ha!=EXPECTED_ANCHOR_COVERAGE_SHA256:
        raise RuntimeError(f"Inner anchor coverage hash mismatch: {ha}")
    if hf!=EXPECTED_STAGE4B_FREEZE_SHA256:
        raise RuntimeError(f"Stage-4B freeze hash mismatch: {hf}")

    freeze=json.loads(ff.read_text(encoding="utf-8"))
    blind=freeze.get("alignment_blinding",[])
    if not any("No inner A computed" in x for x in blind):
        raise RuntimeError("Stage-4B freeze does not prove inner-alignment blinding.")

    y=pd.read_csv(yf)
    c=pd.read_csv(cf)

    print("="*100)
    print(f"YHMC STAGE-4C INNER ALIGNMENT + RADIAL CONTRAST v{VERSION}")
    print("="*100)
    print("CHAIN_OF_CUSTODY=PASS")
    print(f"YOUNG_INNER_SHA256={hy}")
    print(f"CONTROL_INNER_SHA256={hc}")
    print(f"ANCHOR_COVERAGE_SHA256={ha}")
    print(f"STAGE4B_FREEZE_SHA256={hf}")
    print(f"YOUNG_INNER_N={len(y)} CONTROL_INNER_N={len(c)}")
    print("PRIMARY_RADIAL_TEST=young exact paired two-sided sign-flip")
    print("HIGH_MASS_INNER_SUBSETS=DESCRIPTIVE_ONLY")

    y=enrich(y,"young")
    c=enrich(c,"control")

    y.to_csv(out/"01_young_inner_alignment_UNBLINDED.csv",index=False)
    c.to_csv(out/"02_control_inner_alignment_UNBLINDED.csv",index=False)

    inner=pd.DataFrame([
        standalone_inner(y,"young",101),
        standalone_inner(c,"control",102),
    ])
    inner.to_csv(out/"03_inner_alignment_inference.csv",index=False)

    radial=pd.DataFrame([
        radial_test(y,"young_PRIMARY_RADIAL",201),
        radial_test(c,"control_SECONDARY_RADIAL",202),
    ])
    radial.to_csv(out/"04_inner_outer_radial_contrast.csv",index=False)

    # High-mass subsets are explicitly descriptive only.
    desc=[]
    for label,df in [("young",y),("control",c)]:
        for m in [3000,5000,10000]:
            s=df[pd.to_numeric(df["MassJ"],errors="coerce")>=m]
            desc.append({
                "sample":label,
                "MassJ_threshold_Msun":m,
                "N":len(s),
                "A_inner_Galactic":
                    float(s["cos2Delta_inner_Gal"].mean()) if len(s) else np.nan,
                "A_outer_same_clusters":
                    float(s["cos2Delta_outer_Gal"].mean()) if len(s) else np.nan,
                "R_outer_minus_inner":
                    float(s["R_outer_minus_inner"].mean()) if len(s) else np.nan,
                "median_Delta_inner_Gal_deg":
                    float(s["Delta_inner_Gal_deg"].median()) if len(s) else np.nan,
                "ROLE":"DESCRIPTIVE_SMALL_N",
            })
    pd.DataFrame(desc).to_csv(out/"05_high_mass_inner_descriptive.csv",index=False)

    # Non-Galactic specificity for the tiny inner samples.
    spec=[]
    for label,df in [("young",y),("control",c)]:
        spec.append({
            "sample":label,
            "N":len(df),
            "A_Galactic":float(df["cos2Delta_inner_Gal"].mean()),
            "A_Ecliptic":float(df["cos2Delta_inner_Ecliptic"].mean()),
            "A_Equatorial_EW":float(df["cos2Delta_inner_Equatorial_EW"].mean()),
            "Gal_minus_Ecliptic":
                float(df["cos2Delta_inner_Gal"].mean()-df["cos2Delta_inner_Ecliptic"].mean()),
            "Gal_minus_Equatorial":
                float(df["cos2Delta_inner_Gal"].mean()-df["cos2Delta_inner_Equatorial_EW"].mean()),
        })
    pd.DataFrame(spec).to_csv(out/"06_inner_coordinate_specificity.csv",index=False)

    # Leave-one-out radial contrast as a small-N stability diagnostic.
    loo=[]
    for label,df in [("young",y),("control",c)]:
        r=df["R_outer_minus_inner"].to_numpy(float)
        if len(r)>=3:
            for k in range(len(r)):
                loo.append({
                    "sample":label,
                    "left_out_ID":df.iloc[k]["ID"],
                    "left_out_Name":df.iloc[k]["Name"],
                    "R_leave_one_out":float(np.mean(np.delete(r,k))),
                })
    pd.DataFrame(loo).to_csv(out/"07_radial_contrast_leave_one_out.csv",index=False)

    contract={
        "stage":"STAGE4C_INNER_ALIGNMENT_RADIAL_CONTRAST",
        "version":VERSION,
        "young_inner_sha256":hy,
        "control_inner_sha256":hc,
        "inner_anchor_coverage_sha256":ha,
        "stage4b_freeze_sha256":hf,
        "primary_radial_test":{
            "population":"young exact Stage-4B inner-admitted sample",
            "endpoint":"mean[cos2Delta_outer - cos2Delta_inner]",
            "alternative":"two-sided",
            "test":"exact paired sign-flip",
            "interpretation":{
                "R_gt_0":"outer alignment stronger",
                "R_lt_0":"inner alignment stronger",
            }
        },
        "secondary_radial_replication":{
            "population":"older-control exact Stage-4B inner-admitted sample",
            "same_endpoint":True,
            "same_two_sided_test":True,
        },
        "high_mass_inner_subsets":"descriptive only because N is too small",
        "no_sample_or_threshold_changes":True,
    }
    (out/"STAGE4C_UNBLIND_CONTRACT.json").write_text(
        json.dumps(contract,indent=2),encoding="utf-8"
    )

    yi=inner[inner["sample"]=="young"].iloc[0]
    ci=inner[inner["sample"]=="control"].iloc[0]
    yr=radial[radial["sample"]=="young_PRIMARY_RADIAL"].iloc[0]
    cr=radial[radial["sample"]=="control_SECONDARY_RADIAL"].iloc[0]

    def f(x,n=4):
        try:
            return f"{float(x):.{n}f}" if np.isfinite(float(x)) else "NA"
        except Exception:
            return "NA"

    report=[
        f"YHMC STAGE-4C INNER ALIGNMENT + RADIAL CONTRAST v{VERSION}",
        "="*100,
        "CHAIN_OF_CUSTODY=PASS",
        f"YOUNG_INNER_SHA256={hy}",
        f"CONTROL_INNER_SHA256={hc}",
        f"STAGE4B_FREEZE_SHA256={hf}",
        "",
        "YOUNG INNER ALIGNMENT",
        f"  N = {int(yi['N'])}",
        f"  A_inner = {f(yi['A_inner_Galactic'])}",
        f"  bootstrap 68% CI = [{f(yi['bootstrap_A_p16'])}, {f(yi['bootstrap_A_p84'])}]",
        f"  bootstrap 95% CI = [{f(yi['bootstrap_A_p025'])}, {f(yi['bootstrap_A_p975'])}]",
        f"  random-orientation p_parallel = {f(yi['p_random_orientation_parallel'],6)}",
        f"  PA-position permutation p = {f(yi['p_PA_position_permutation'],6)}",
        f"  median inner Delta = {f(yi['median_Delta_inner_Gal_deg'],2)} deg",
        f"  A_ecliptic = {f(yi['A_inner_Ecliptic'])}",
        f"  A_equatorial = {f(yi['A_inner_Equatorial_EW'])}",
        "",
        "PRIMARY YOUNG RADIAL TEST",
        f"  N paired clusters = {int(yr['N'])}",
        f"  A_outer (same clusters) = {f(yr['A_outer_same_clusters'])}",
        f"  A_inner (same clusters) = {f(yr['A_inner_same_clusters'])}",
        f"  R = A_outer - A_inner = {f(yr['R_outer_minus_inner'])}",
        f"  bootstrap 68% CI(R) = [{f(yr['bootstrap_R_p16'])}, {f(yr['bootstrap_R_p84'])}]",
        f"  bootstrap 95% CI(R) = [{f(yr['bootstrap_R_p025'])}, {f(yr['bootstrap_R_p975'])}]",
        f"  exact paired sign-flip p_two_sided = {f(yr['exact_signflip_p_two_sided'],6)}",
        f"  exact p(R>0) = {f(yr['exact_signflip_p_R_gt0'],6)}",
        f"  fraction R_i>0 = {f(yr['fraction_R_i_gt0'],3)}",
        f"  median |PA_inner-PA_outer| = {f(yr['median_abs_inner_outer_PA_diff_deg'],2)} deg",
        "",
        "OLDER-CONTROL INNER ALIGNMENT",
        f"  N = {int(ci['N'])}",
        f"  A_inner = {f(ci['A_inner_Galactic'])}",
        f"  bootstrap 68% CI = [{f(ci['bootstrap_A_p16'])}, {f(ci['bootstrap_A_p84'])}]",
        f"  random-orientation p_parallel = {f(ci['p_random_orientation_parallel'],6)}",
        f"  PA-position permutation p = {f(ci['p_PA_position_permutation'],6)}",
        f"  median inner Delta = {f(ci['median_Delta_inner_Gal_deg'],2)} deg",
        "",
        "SECONDARY CONTROL RADIAL TEST",
        f"  N paired clusters = {int(cr['N'])}",
        f"  A_outer (same clusters) = {f(cr['A_outer_same_clusters'])}",
        f"  A_inner (same clusters) = {f(cr['A_inner_same_clusters'])}",
        f"  R = {f(cr['R_outer_minus_inner'])}",
        f"  exact paired sign-flip p_two_sided = {f(cr['exact_signflip_p_two_sided'],6)}",
        f"  fraction R_i>0 = {f(cr['fraction_R_i_gt0'],3)}",
        f"  median |PA_inner-PA_outer| = {f(cr['median_abs_inner_outer_PA_diff_deg'],2)} deg",
        "",
        "INTERPRETATION RULE:",
        "  Young radial test is the primary radial inference.",
        "  Older-control radial test is secondary replication.",
        "  High-mass inner subsets are descriptive only.",
        "  With N=10 and N=6, effect sizes and exact tests matter more than asymptotic claims.",
        "",
        "NEXT:",
        "  Integrate all frozen robustness results into a manuscript-level evidence",
        "  synthesis; do not add new radial thresholds based on these results.",
    ]
    (out/"STAGE4C_REPORT.txt").write_text(
        "\n".join(report)+"\n",encoding="utf-8"
    )

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text(
        "\n".join(manifest)+"\n",encoding="utf-8"
    )

    print()
    print((out/"STAGE4C_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

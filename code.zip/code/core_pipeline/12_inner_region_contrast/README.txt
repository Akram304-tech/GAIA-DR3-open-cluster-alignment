YHMC STAGE-4C INNER ALIGNMENT + RADIAL CONTRAST v1.4.0
=========================================================

This is the FIRST stage authorized to compute inner Galactic-plane alignment.

Primary radial test
-------------------
Young Stage-4B inner-admitted sample (N expected = 10):

  R_i = cos(2 Delta_outer_i) - cos(2 Delta_inner_i)

Primary test:
  exact paired TWO-SIDED sign-flip test.

Interpretation:
  R > 0 : outer alignment stronger.
  R < 0 : inner alignment stronger.

The two-sided alternative is frozen before inner alignment is viewed.

Older controls
--------------
Same radial test is a secondary replication (N expected = 6).

Standalone inner alignment
--------------------------
A_inner is tested against:
- random-orientation null;
- PA-position permutation null.

High-mass inner subsets are descriptive only because Stage-4B admitted
too few objects for inferential use.

Run
---
call RUN_STAGE4C_INNER_ALIGNMENT_RADIAL_CONTRAST_v1_4_0.bat

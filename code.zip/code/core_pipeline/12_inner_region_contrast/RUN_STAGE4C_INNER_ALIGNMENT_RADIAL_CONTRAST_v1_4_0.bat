@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-4C INNER ALIGNMENT + RADIAL CONTRAST v1.4.0
echo FIRST INNER ALIGNMENT UNBLIND
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" (
  echo ERROR: Miniconda Python not found.
  exit /b 1
)

set "STAGE4B=%USERPROFILE%\Downloads\YHMC_STAGE4B_INNER_R50J_REAL_MORPHOLOGY_FREEZE_v1_3_0\YHMC_STAGE4B_INNER_R50J_REAL_MORPHOLOGY_FREEZE_v1_3_0\STAGE4B_OUTPUT"

if not exist "%STAGE4B%\03_YOUNG_INNER_PA_SAMPLE_FROZEN.csv" (
  echo ERROR: Stage-4B frozen inner sample not found.
  exit /b 1
)

echo PYEXE=%PYEXE%
"%PYEXE%" --version

"%PYEXE%" -c "import numpy,pandas,astropy" >nul 2>nul
if errorlevel 1 (
  "%PYEXE%" -m pip install numpy pandas astropy
  if errorlevel 1 exit /b 1
)

"%PYEXE%" stage4c_inner_alignment_radial_contrast_v1_4_0.py ^
 --stage4b "%STAGE4B%" ^
 --out "%CD%\STAGE4C_OUTPUT"

set "RC=%ERRORLEVEL%"
echo.
echo RETURN_CODE=%RC%
if "%RC%"=="0" (
  echo REPORT=%CD%\STAGE4C_OUTPUT\STAGE4C_REPORT.txt
  echo INNER=%CD%\STAGE4C_OUTPUT\03_inner_alignment_inference.csv
  echo RADIAL=%CD%\STAGE4C_OUTPUT\04_inner_outer_radial_contrast.csv
  echo CONTRACT=%CD%\STAGE4C_OUTPUT\STAGE4C_UNBLIND_CONTRACT.json
)
exit /b %RC%

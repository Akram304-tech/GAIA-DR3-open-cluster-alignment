YHMC STAGE-1B REAL MORPHOLOGY FREEZE v0.3.0
================================================

This stage measures REAL projected morphology but remains blind to the
Galactic plane.

It computes:
- q=b/a
- epsilon=1-q
- sky PA from the weighted second-moment tensor
- 2000x bootstrap q uncertainty
- 2000x bootstrap axial PA uncertainty
- the pre-frozen morphology-only admission gates

It does NOT compute:
- Galactic-plane PA
- Delta theta
- cos(2 Delta theta)
- alignment statistic A
- alignment p-values

The primary alignment sample is hashed before any alignment calculation.

Default input paths are already configured for the Stage-0 and Stage-1A
folders used in this project.

Run:
  call RUN_STAGE1B_REAL_MORPHOLOGY_FREEZE_v0_3_0.bat

Main outputs:
  STAGE1B_OUTPUT\STAGE1B_REPORT.txt
  STAGE1B_OUTPUT\01_real_morphology_all.csv
  STAGE1B_OUTPUT\02_PRIMARY_PA_SAMPLE_FROZEN.csv
  STAGE1B_OUTPUT\03_gate_attrition_by_mass.csv
  STAGE1B_OUTPUT\04_morphology_descriptive_summary.csv
  STAGE1B_OUTPUT\STAGE1B_FREEZE.json
  STAGE1B_OUTPUT\SHA256SUMS.txt

Important:
Inner r<r50J morphology is not evaluated in this stage. It requires its
own blind synthetic recovery calibration before any radial-alignment
comparison is allowed.

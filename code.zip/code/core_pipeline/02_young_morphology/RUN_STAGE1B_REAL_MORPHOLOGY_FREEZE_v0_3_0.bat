@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-1B REAL MORPHOLOGY FREEZE v0.3.0
echo NO GALACTIC-PLANE ALIGNMENT COMPUTED
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" (
  echo ERROR: Miniconda Python not found.
  exit /b 1
)

set "STAGE0=%USERPROFILE%\Downloads\YHMC_STAGE0_PREFLIGHT_v0_1_2\YHMC_STAGE0_PREFLIGHT_v0_1_2\STAGE0_OUTPUT"
set "STAGE1A=%USERPROFILE%\Downloads\YHMC_STAGE1A_SYNTHETIC_PA_CALIBRATION_v0_2_0\YHMC_STAGE1A_SYNTHETIC_PA_CALIBRATION_v0_2_0\STAGE1A_OUTPUT"

if not exist "%STAGE0%\07_provisional_morphology_ready.csv" (
  echo ERROR: Stage-0 output not found:
  echo   %STAGE0%
  exit /b 1
)
if not exist "%STAGE1A%\03_cluster_specific_PA_gate.csv" (
  echo ERROR: Stage-1A output not found:
  echo   %STAGE1A%
  exit /b 1
)

echo PYEXE=%PYEXE%
"%PYEXE%" --version
echo STAGE0=%STAGE0%
echo STAGE1A=%STAGE1A%

"%PYEXE%" -c "import numpy,pandas,matplotlib" >nul 2>nul
if errorlevel 1 (
  "%PYEXE%" -m pip install numpy pandas matplotlib
  if errorlevel 1 exit /b 1
)

"%PYEXE%" stage1b_real_morphology_freeze_v0_3_0.py --stage0 "%STAGE0%" --stage1a "%STAGE1A%" --out "%CD%\STAGE1B_OUTPUT"
set "RC=%ERRORLEVEL%"

echo.
echo RETURN_CODE=%RC%
if "%RC%"=="0" (
  echo REPORT=%CD%\STAGE1B_OUTPUT\STAGE1B_REPORT.txt
  echo PRIMARY=%CD%\STAGE1B_OUTPUT\02_PRIMARY_PA_SAMPLE_FROZEN.csv
  echo FREEZE=%CD%\STAGE1B_OUTPUT\STAGE1B_FREEZE.json
)
exit /b %RC%

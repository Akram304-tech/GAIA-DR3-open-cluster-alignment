#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-1B real morphology freeze v0.3.0

Purpose
-------
Measure real projected axis ratio q and position angle PA for the
pre-defined r<rJ morphology sample, quantify bootstrap uncertainty,
and freeze the PA-resolved morphology sample WITHOUT computing any
Galactic-plane direction or alignment statistic.

This script intentionally does NOT compute:
  - local Galactic-plane PA
  - Delta theta
  - cos(2 Delta theta)
  - population alignment statistic A
  - any alignment p-value

Inputs
------
Stage-0 v0.1.2:
  STAGE0_OUTPUT/07_provisional_morphology_ready.csv
  STAGE0_OUTPUT/members_primary/*.csv

Stage-1A v0.2.0:
  STAGE1A_OUTPUT/03_cluster_specific_PA_gate.csv
  STAGE1A_OUTPUT/STAGE1A_FREEZE.json

Frozen Stage-1B PA-resolved gate
--------------------------------
A cluster is admitted to the later PRIMARY alignment sample only if ALL:
  1) Stage-1A PA_CALIBRATABLE == True
  2) q84_real <= q_max_PA_reliable
  3) q_point_real < q_round_null_p05
  4) bootstrap P68(|Delta PA|) <= 20 deg

The gate uses morphology only; it has no access to Galactic-plane direction.

Important
---------
This stage measures only r<rJ morphology. Inner r<r50J morphology is
deliberately deferred until it receives an independent blind synthetic
recovery calibration.
"""

from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "0.3.0"
SEED = 20260912
N_BOOT = 2000
BOOT_PA_P68_MAX = 20.0

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()

def safe_name(s):
    return "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in str(s))

def find_member_file(member_dir: Path, cid: int, name: str):
    hits = sorted([p for p in member_dir.glob(f"{cid:04d}_*.csv") if p.is_file()])
    if not hits:
        return None
    if len(hits) == 1:
        return hits[0]
    sn = safe_name(name)
    for p in hits:
        if sn in p.stem:
            return p
    return hits[0]

def tangent_xy_arcmin(ra, dec, ra0, dec0):
    ra = np.asarray(ra, dtype=float)
    dec = np.asarray(dec, dtype=float)
    dra = ((ra - float(ra0) + 180.0) % 360.0) - 180.0
    x = dra * math.cos(math.radians(float(dec0))) * 60.0
    y = (dec - float(dec0)) * 60.0
    return x, y

def weighted_shape(x, y, w):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    w = np.asarray(w, dtype=float)
    good = np.isfinite(x) & np.isfinite(y) & np.isfinite(w) & (w > 0)
    x, y, w = x[good], y[good], w[good]
    if len(x) < 3 or w.sum() <= 0:
        return np.nan, np.nan, np.nan, np.nan

    sw = w.sum()
    xc = float(np.sum(w*x)/sw)
    yc = float(np.sum(w*y)/sw)
    dx, dy = x-xc, y-yc

    sxx = np.sum(w*dx*dx)/sw
    syy = np.sum(w*dy*dy)/sw
    sxy = np.sum(w*dx*dy)/sw
    C = np.array([[sxx, sxy],[sxy, syy]], dtype=float)

    vals, vecs = np.linalg.eigh(C)
    order = np.argsort(vals)[::-1]
    vals = vals[order]
    vecs = vecs[:,order]
    if vals[0] <= 0 or vals[1] < 0:
        return np.nan, np.nan, xc, yc

    q = float(np.sqrt(max(vals[1],0.0)/vals[0]))
    vx, vy = vecs[:,0]
    pa = float(np.degrees(np.arctan2(vy,vx)) % 180.0)
    return q, pa, xc, yc

def axial_signed_diff_deg(a, b):
    return ((np.asarray(a, dtype=float) - float(b) + 90.0) % 180.0) - 90.0

def weighted_neff(w):
    w = np.asarray(w, dtype=float)
    w = w[np.isfinite(w) & (w>0)]
    if len(w)==0:
        return 0.0
    return float(w.sum()**2 / np.square(w).sum())

def pct(a,p):
    a=np.asarray(a,dtype=float)
    a=a[np.isfinite(a)]
    return float(np.percentile(a,p)) if len(a) else np.nan

def med(a):
    a=np.asarray(a,dtype=float)
    a=a[np.isfinite(a)]
    return float(np.median(a)) if len(a) else np.nan

def bootstrap_shape(x,y,w,nboot,rng):
    n=len(x)
    qs=np.full(nboot,np.nan)
    pas=np.full(nboot,np.nan)
    for k in range(nboot):
        idx=rng.integers(0,n,size=n)
        q,pa,_,_=weighted_shape(x[idx],y[idx],w[idx])
        qs[k]=q
        pas[k]=pa
    return qs,pas

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage0",required=True)
    ap.add_argument("--stage1a",required=True)
    ap.add_argument("--out",default="STAGE1B_OUTPUT")
    ap.add_argument("--nboot",type=int,default=N_BOOT)
    args=ap.parse_args()

    stage0=Path(args.stage0).expanduser().resolve()
    stage1a=Path(args.stage1a).expanduser().resolve()
    out=Path(args.out).expanduser().resolve()
    out.mkdir(parents=True,exist_ok=True)

    sample_file=stage0/"07_provisional_morphology_ready.csv"
    member_dir=stage0/"members_primary"
    gate_file=stage1a/"03_cluster_specific_PA_gate.csv"
    freeze_file=stage1a/"STAGE1A_FREEZE.json"

    for p in [sample_file,gate_file,freeze_file]:
        if not p.exists():
            raise FileNotFoundError(p)
    if not member_dir.is_dir():
        raise FileNotFoundError(member_dir)

    sample=pd.read_csv(sample_file)
    gate=pd.read_csv(gate_file)
    freeze=json.loads(freeze_file.read_text(encoding="utf-8"))

    # Verify expected Stage-1A contract.
    if freeze.get("science_blinding","") == "":
        raise RuntimeError("Stage-1A freeze lacks science_blinding contract.")
    if "q_max_PA_reliable" not in gate.columns or "q_round_null_p05" not in gate.columns:
        raise RuntimeError("Stage-1A gate table missing required columns.")

    merged=sample.merge(
        gate[["ID","Name","q_round_null_p05","q_round_null_p16","q_round_null_median",
              "q_max_PA_reliable","PA_CALIBRATABLE"]],
        on=["ID","Name"],how="inner",validate="one_to_one"
    )
    if len(merged)!=len(sample):
        raise RuntimeError(f"Stage0/Stage1A merge mismatch: {len(sample)} -> {len(merged)}")

    print("="*84)
    print(f"YHMC STAGE-1B REAL MORPHOLOGY FREEZE v{VERSION}")
    print("NO GALACTIC-PLANE PA / NO DELTA-THETA / NO ALIGNMENT A")
    print("="*84)
    print(f"INPUT_CLUSTERS={len(merged)}")
    print(f"N_BOOT={args.nboot}")
    print(f"SEED={SEED}")
    print("FROZEN_GATE:")
    print("  PA_CALIBRATABLE")
    print("  q84_real <= q_max_PA_reliable")
    print("  q_point_real < q_round_null_p05")
    print(f"  bootstrap P68(|DeltaPA|) <= {BOOT_PA_P68_MAX:.1f} deg")

    rows=[]
    for ii,row in merged.reset_index(drop=True).iterrows():
        cid=int(row["ID"])
        name=str(row["Name"])
        mf=find_member_file(member_dir,cid,name)
        if mf is None:
            rows.append({"ID":cid,"Name":name,"status":"MISSING_MEMBER_FILE"})
            print(f"{ii+1:3d}/{len(merged):3d} {name}: MISSING_MEMBER_FILE")
            continue

        mem=pd.read_csv(mf)
        req={"Prob","__RAdeg","__DEdeg"}
        miss=sorted(req-set(mem.columns))
        if miss:
            rows.append({"ID":cid,"Name":name,"status":"BAD_MEMBER_SCHEMA","missing":";".join(miss)})
            print(f"{ii+1:3d}/{len(merged):3d} {name}: BAD_MEMBER_SCHEMA")
            continue

        p=pd.to_numeric(mem["Prob"],errors="coerce").to_numpy(float)
        ra=pd.to_numeric(mem["__RAdeg"],errors="coerce").to_numpy(float)
        de=pd.to_numeric(mem["__DEdeg"],errors="coerce").to_numpy(float)
        good=np.isfinite(p)&np.isfinite(ra)&np.isfinite(de)&(p>=0.5)
        p,ra,de=p[good],ra[good],de[good]

        x,y=tangent_xy_arcmin(ra,de,row["__RAdeg"],row["__DEdeg"])
        good2=np.isfinite(x)&np.isfinite(y)&np.isfinite(p)&(p>0)
        x,y,p=x[good2],y[good2],p[good2]

        q,pa,xc,yc=weighted_shape(x,y,p)
        ne=weighted_neff(p)
        if not np.isfinite(q) or not np.isfinite(pa):
            rows.append({"ID":cid,"Name":name,"status":"SHAPE_FAIL"})
            print(f"{ii+1:3d}/{len(merged):3d} {name}: SHAPE_FAIL")
            continue

        rng=np.random.default_rng(np.random.SeedSequence([SEED,cid,args.nboot]))
        qb,pab=bootstrap_shape(x,y,p,args.nboot,rng)
        dpa=np.abs(axial_signed_diff_deg(pab,pa))

        q16,q50,q84=pct(qb,16),pct(qb,50),pct(qb,84)
        q05,q95=pct(qb,5),pct(qb,95)
        pa_p68=pct(dpa,68)
        pa_p95=pct(dpa,95)
        pa_med=med(dpa)

        pa_cal=bool(row["PA_CALIBRATABLE"])
        qmax=float(row["q_max_PA_reliable"]) if pd.notna(row["q_max_PA_reliable"]) else np.nan
        qnull05=float(row["q_round_null_p05"]) if pd.notna(row["q_round_null_p05"]) else np.nan

        g1=pa_cal
        g2=bool(np.isfinite(q84) and np.isfinite(qmax) and q84<=qmax)
        g3=bool(np.isfinite(qnull05) and q<qnull05)
        g4=bool(np.isfinite(pa_p68) and pa_p68<=BOOT_PA_P68_MAX)
        admitted=bool(g1 and g2 and g3 and g4)

        rows.append({
            "ID":cid,"Name":name,"status":"OK",
            "MassJ":row["MassJ"],"logAge50":row["logAge50"],
            "N_members":len(x),"Neff":ne,
            "q_point":q,"epsilon_point":1.0-q,
            "q_boot_p05":q05,"q_boot_p16":q16,"q_boot_median":q50,
            "q_boot_p84":q84,"q_boot_p95":q95,
            "PA_deg_point":pa,
            "PA_boot_abs_median_deg":pa_med,
            "PA_boot_abs_p68_deg":pa_p68,
            "PA_boot_abs_p95_deg":pa_p95,
            "weighted_centroid_x_arcmin":xc,
            "weighted_centroid_y_arcmin":yc,
            "q_round_null_p05":qnull05,
            "q_round_null_p16":row["q_round_null_p16"],
            "q_round_null_median":row["q_round_null_median"],
            "q_max_PA_reliable":qmax,
            "gate1_PA_CALIBRATABLE":g1,
            "gate2_q84_le_qmax":g2,
            "gate3_qpoint_lt_roundnull_p05":g3,
            "gate4_bootPA_p68_le20":g4,
            "PRIMARY_PA_SAMPLE_ADMITTED":admitted,
            "GALACTIC_ALIGNMENT_NOT_COMPUTED":True,
        })
        print(f"{ii+1:3d}/{len(merged):3d} {name}: q={q:.3f}, PAerr68={pa_p68:.1f}, admitted={admitted}")

    res=pd.DataFrame(rows)
    res.to_csv(out/"01_real_morphology_all.csv",index=False)

    good=res[res["status"]=="OK"].copy()
    admitted=good[good["PRIMARY_PA_SAMPLE_ADMITTED"]==True].copy()
    admitted.to_csv(out/"02_PRIMARY_PA_SAMPLE_FROZEN.csv",index=False)

    # Gate attrition audit, independent of any Galactic-plane orientation.
    gate_rows=[]
    for m in [1000,3000,5000,10000]:
        s=good[pd.to_numeric(good["MassJ"],errors="coerce")>=m].copy()
        gate_rows.append({
            "MassJ_threshold_Msun":m,
            "N_real_morphology_OK":len(s),
            "N_gate1_PA_calibratable":int(s["gate1_PA_CALIBRATABLE"].sum()) if len(s) else 0,
            "N_gate2_q84_le_qmax":int(s["gate2_q84_le_qmax"].sum()) if len(s) else 0,
            "N_gate3_significantly_elongated":int(s["gate3_qpoint_lt_roundnull_p05"].sum()) if len(s) else 0,
            "N_gate4_bootPA_p68_le20":int(s["gate4_bootPA_p68_le20"].sum()) if len(s) else 0,
            "N_PRIMARY_PA_SAMPLE_ADMITTED":int(s["PRIMARY_PA_SAMPLE_ADMITTED"].sum()) if len(s) else 0,
        })
    gate_summary=pd.DataFrame(gate_rows)
    gate_summary.to_csv(out/"03_gate_attrition_by_mass.csv",index=False)

    # Morphology-only descriptive summary.
    desc=[]
    for m in [1000,3000,5000,10000]:
        s=good[pd.to_numeric(good["MassJ"],errors="coerce")>=m]
        a=admitted[pd.to_numeric(admitted["MassJ"],errors="coerce")>=m]
        desc.append({
            "MassJ_threshold_Msun":m,
            "N_all":len(s),
            "median_q_all":med(s["q_point"]) if len(s) else np.nan,
            "median_epsilon_all":med(s["epsilon_point"]) if len(s) else np.nan,
            "N_admitted":len(a),
            "median_q_admitted":med(a["q_point"]) if len(a) else np.nan,
            "median_epsilon_admitted":med(a["epsilon_point"]) if len(a) else np.nan,
        })
    pd.DataFrame(desc).to_csv(out/"04_morphology_descriptive_summary.csv",index=False)

    freeze_record={
        "stage":"STAGE1B_REAL_MORPHOLOGY_FREEZE",
        "version":VERSION,
        "seed":SEED,
        "n_boot":args.nboot,
        "region":"r<rJ only (Stage-0 members with inrj=1, Prob>=0.5)",
        "estimator":"membership-probability weighted second central moments",
        "selection_gate":{
            "gate1":"Stage-1A PA_CALIBRATABLE == True",
            "gate2":"q_boot_p84 <= q_max_PA_reliable",
            "gate3":"q_point < q_round_null_p05",
            "gate4":f"bootstrap P68(|DeltaPA|) <= {BOOT_PA_P68_MAX:.1f} deg",
            "all_required":True,
        },
        "alignment_blinding":[
            "No local Galactic-plane PA computed",
            "No Delta-theta computed",
            "No cos(2 Delta-theta) computed",
            "No population alignment statistic A computed",
            "No alignment p-value computed",
        ],
        "radial_scope_note":
            "Inner r<r50J morphology is deferred until a separate blind synthetic calibration.",
        "next_stage":
            "Stage-1C computes Galactic-plane alignment ONLY for 02_PRIMARY_PA_SAMPLE_FROZEN.csv, after this sample is hashed/frozen."
    }
    (out/"STAGE1B_FREEZE.json").write_text(json.dumps(freeze_record,indent=2),encoding="utf-8")

    # Hash the primary sample explicitly before any alignment analysis.
    primary_hash=sha256(out/"02_PRIMARY_PA_SAMPLE_FROZEN.csv")
    freeze_hash=sha256(out/"STAGE1B_FREEZE.json")

    report=[
        f"YHMC STAGE-1B REAL MORPHOLOGY FREEZE v{VERSION}",
        "="*84,
        f"Input clusters: {len(merged)}",
        f"Real morphology successful: {len(good)}",
        f"Primary PA sample admitted: {len(admitted)}",
        f"N_BOOT={args.nboot}",
        f"SEED={SEED}",
        "",
        "FROZEN MORPHOLOGY-ONLY GATE:",
        "  1) PA_CALIBRATABLE == True",
        "  2) q84_real <= q_max_PA_reliable",
        "  3) q_point_real < q_round_null_p05",
        f"  4) bootstrap P68(|DeltaPA|) <= {BOOT_PA_P68_MAX:.1f} deg",
        "",
        "GATE ATTRITION BY MASS:",
        gate_summary.to_string(index=False),
        "",
        f"PRIMARY_SAMPLE_SHA256={primary_hash}",
        f"FREEZE_JSON_SHA256={freeze_hash}",
        "",
        "SCIENCE BLINDING STATUS:",
        "  Galactic-plane PA: NOT COMPUTED",
        "  Delta-theta: NOT COMPUTED",
        "  Alignment A: NOT COMPUTED",
        "  Alignment p-value: NOT COMPUTED",
        "",
        "NEXT_STAGE:",
        "  Stage-1C may now compute the Galactic-plane alignment only for the hashed",
        "  frozen primary sample. Inner r<r50J comparison remains deferred pending",
        "  its own blind synthetic calibration.",
    ]
    (out/"STAGE1B_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    # Morphology-only plots.
    try:
        import matplotlib.pyplot as plt

        fig=plt.figure(figsize=(7.2,5.4))
        ax=fig.add_subplot(111)
        ax.hist(good["q_point"].dropna(),bins=20)
        ax.set_xlabel(r"$q=b/a$")
        ax.set_ylabel("Number of clusters")
        fig.tight_layout()
        fig.savefig(out/"FIG01_q_distribution_all.pdf",bbox_inches="tight")
        fig.savefig(out/"FIG01_q_distribution_all.png",dpi=220,bbox_inches="tight")
        plt.close(fig)

        fig=plt.figure(figsize=(7.2,5.4))
        ax=fig.add_subplot(111)
        ax.scatter(good["Neff"],good["q_point"],s=22)
        ax.set_xlabel(r"$N_{\rm eff}$")
        ax.set_ylabel(r"$q=b/a$")
        ax.set_ylim(0.45,1.02)
        ax.grid(alpha=0.25)
        fig.tight_layout()
        fig.savefig(out/"FIG02_q_vs_Neff.pdf",bbox_inches="tight")
        fig.savefig(out/"FIG02_q_vs_Neff.png",dpi=220,bbox_inches="tight")
        plt.close(fig)
    except Exception as e:
        (out/"FIGURE_WARNING.txt").write_text(str(e),encoding="utf-8")

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")

    print()
    print((out/"STAGE1B_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

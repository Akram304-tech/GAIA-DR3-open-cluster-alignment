YHMC Stage-0 Preflight v0.1.2

Fixes:
- Automatically resolves cluster/member coordinate aliases:
  RAdeg/DEdeg, RA_ICRS/DE_ICRS, _RA_icrs/_DE_icrs, or _RA/_DE.
- Internally canonicalizes the selected coordinates to __RAdeg/__DEdeg.
- Keeps v0.1.1 robust POST TAP querying and direct Miniconda binding.

Run:
  call RUN_STAGE0_PREFLIGHT_v0_1_2.bat

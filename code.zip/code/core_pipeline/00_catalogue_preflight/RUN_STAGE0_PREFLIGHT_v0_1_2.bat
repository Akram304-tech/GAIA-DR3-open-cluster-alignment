@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-0 PREFLIGHT v0.1.2
echo Schema-adaptive VizieR TAP version
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"

if not exist "%PYEXE%" (
  echo ERROR: Miniconda Python not found.
  exit /b 1
)

echo PYEXE=%PYEXE%
"%PYEXE%" --version

"%PYEXE%" -c "import numpy,pandas,requests" >nul 2>nul
if errorlevel 1 (
  "%PYEXE%" -m pip install numpy pandas requests
  if errorlevel 1 exit /b 1
)

"%PYEXE%" stage0_preflight_v0_1_2.py
set "RC=%ERRORLEVEL%"

echo.
echo RETURN_CODE=%RC%
if "%RC%"=="0" (
  echo REPORT=%CD%\STAGE0_OUTPUT\STAGE0_REPORT.txt
  echo SAMPLE=%CD%\STAGE0_OUTPUT\07_provisional_morphology_ready.csv
)
exit /b %RC%

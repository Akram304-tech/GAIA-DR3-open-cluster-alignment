#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-0 sample/data preflight v0.1.2
Schema-adaptive VizieR TAP version.

v0.1.2 fixes the coordinate-column alias mismatch seen in VizieR TAP:
the catalogue ReadMe uses RAdeg/DEdeg, while TAP may expose RA_ICRS/DE_ICRS
(and may also provide _RA_icrs/_DE_icrs). The script now detects the
available coordinate pair automatically for BOTH cluster and member tables.

No science inference is performed here.
"""

from __future__ import annotations
import io, json, math, time, hashlib
from pathlib import Path

import numpy as np
import pandas as pd
import requests

VERSION = "0.1.2"
TAP = "https://tapvizier.cds.unistra.fr/TAPVizieR/tap/sync"
CLUSTER_TABLE = '"J/A+A/686/A42/clusters"'
MEMBER_TABLE = '"J/A+A/686/A42/members"'
OUT = Path("STAGE0_OUTPUT")
OUT.mkdir(exist_ok=True)

CONFIG = {
    "version": VERSION,
    "catalogue": "J/A+A/686/A42 (Hunt & Reffert 2024)",
    "primary_age_logyr_max": 8.0,
    "mass_thresholds_msun": [1000, 3000, 5000, 10000],
    "cluster_type": "o",
    "cst_min": 5.0,
    "cmdcl50_min": 0.5,
    "probJ_min": 0.5,
    "NJ_min": 40,
    "member_prob_fetch_min": 0.5,
    "member_prob_thresholds": [0.5, 0.7, 0.8, 0.9],
    "provisional_neff_min": 50.0,
    "provisional_inner_n_min": 20,
}

COORD_CANDIDATES = [
    ("RAdeg", "DEdeg"),
    ("RA_ICRS", "DE_ICRS"),
    ("_RA_icrs", "_DE_icrs"),
    ("_RA", "_DE"),
]

def tap_query(adql: str, timeout: int = 240, retries: int = 4) -> pd.DataFrame:
    payload = {"REQUEST": "doQuery", "LANG": "ADQL", "FORMAT": "csv", "QUERY": adql}
    last = None
    for k in range(retries):
        try:
            r = requests.post(TAP, data=payload, timeout=timeout)
            if r.status_code != 200:
                raise RuntimeError(
                    f"HTTP {r.status_code} from VizieR TAP\n"
                    f"Response payload:\n{r.text[:12000]}\n"
                    f"ADQL:\n{adql}"
                )
            txt = r.text
            if txt.lstrip().startswith("<?xml") or "QUERY_STATUS" in txt[:3000]:
                raise RuntimeError(
                    "VizieR TAP returned XML/error payload:\n"
                    + txt[:12000] + "\nADQL:\n" + adql
                )
            return pd.read_csv(io.StringIO(txt))
        except Exception as e:
            last = e
            if k + 1 < retries:
                time.sleep(min(2 ** k, 12))
    raise RuntimeError(f"TAP query failed after {retries} attempts:\n{last}")

def resolve_coords(df: pd.DataFrame, label: str):
    cols = set(df.columns)
    for ra, de in COORD_CANDIDATES:
        if ra in cols and de in cols:
            print(f"       {label} coordinate columns: {ra} / {de}")
            return ra, de
    raise RuntimeError(
        f"{label}: no recognized coordinate pair found.\n"
        f"Available columns:\n  " + ", ".join(map(str, df.columns))
    )

def canonicalize_coords(df: pd.DataFrame, ra_col: str, de_col: str):
    out = df.copy()
    out["__RAdeg"] = pd.to_numeric(out[ra_col], errors="coerce")
    out["__DEdeg"] = pd.to_numeric(out[de_col], errors="coerce")
    return out

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()

def spherical_sep_deg(ra, dec, ra0, dec0):
    ra = np.deg2rad(np.asarray(ra, dtype=float))
    dec = np.deg2rad(np.asarray(dec, dtype=float))
    ra0 = math.radians(float(ra0))
    dec0 = math.radians(float(dec0))
    cosd = np.sin(dec) * math.sin(dec0) + np.cos(dec) * math.cos(dec0) * np.cos(ra - ra0)
    cosd = np.clip(cosd, -1, 1)
    return np.rad2deg(np.arccos(cosd))

def neff(p):
    p = np.asarray(p, dtype=float)
    p = p[np.isfinite(p)]
    if len(p) == 0:
        return 0.0
    s1 = p.sum()
    s2 = np.square(p).sum()
    return float(s1 * s1 / s2) if s2 > 0 else 0.0

print("=" * 78)
print(f"YHMC STAGE-0 PREFLIGHT v{VERSION}")
print("Schema-adaptive VizieR TAP / Hunt & Reffert (2024) / NO SCIENCE INFERENCE")
print("=" * 78)

print("[0a/5] TAP connectivity test...")
probe = tap_query(f"SELECT TOP 1 * FROM {CLUSTER_TABLE}")
print("       PASS: cluster table is reachable.")

print("[0b/5] Cluster schema sanity check...")
required_cluster_cols = {
    "Name","ID","Type","CST","N","GLON","GLAT","r50","r50pc","dist50",
    "CMDCl50","CMDClHuman","logAge16","logAge50","logAge84","AV50","diffAV50",
    "r50J","rJ","r50Jpc","rJpc","probJ","NJ","MassJ","e_MassJ","MassTot",
    "e_MassTot","isMerged","isGMMMemb","Note"
}
missing_probe = sorted(required_cluster_cols - set(probe.columns))
if missing_probe:
    raise RuntimeError(
        "Cluster table schema mismatch. Missing non-coordinate columns:\n  "
        + ", ".join(missing_probe)
        + "\nColumns returned by TAP:\n  "
        + ", ".join(map(str, probe.columns))
    )
cluster_ra_col, cluster_de_col = resolve_coords(probe, "Cluster")
print("       PASS: required cluster schema is usable.")

print("[1/5] Querying complete cluster master table...")
cl = tap_query(f"SELECT * FROM {CLUSTER_TABLE}")
cluster_ra_col, cluster_de_col = resolve_coords(cl, "Cluster")
cl = canonicalize_coords(cl, cluster_ra_col, cluster_de_col)
cl.to_csv(OUT / "01_cluster_master_raw.csv", index=False)

numeric = [
    "CST","N","GLON","GLAT","r50","r50pc","dist50","CMDCl50","logAge16",
    "logAge50","logAge84","AV50","diffAV50","r50J","rJ","r50Jpc","rJpc",
    "probJ","NJ","MassJ","e_MassJ","MassTot","e_MassTot","isMerged","isGMMMemb","ID",
    "__RAdeg","__DEdeg"
]
for c in numeric:
    if c in cl.columns:
        cl[c] = pd.to_numeric(cl[c], errors="coerce")

is_open = cl["Type"].astype(str).str.strip().eq(CONFIG["cluster_type"])
young = cl["logAge50"].notna() & (cl["logAge50"] <= CONFIG["primary_age_logyr_max"])
finite_geom = (
    cl["rJ"].notna() & (cl["rJ"] > 0) &
    cl["r50J"].notna() & (cl["r50J"] > 0) &
    cl["__RAdeg"].notna() & cl["__DEdeg"].notna()
)
quality_base = (
    is_open & young &
    cl["CST"].notna() & (cl["CST"] >= CONFIG["cst_min"]) &
    cl["CMDCl50"].notna() & (cl["CMDCl50"] >= CONFIG["cmdcl50_min"]) &
    cl["probJ"].notna() & (cl["probJ"] >= CONFIG["probJ_min"]) &
    cl["NJ"].notna() & (cl["NJ"] >= CONFIG["NJ_min"]) &
    finite_geom
)
m1000 = cl["MassJ"].notna() & (cl["MassJ"] >= 1000)

steps = [
    ("All catalogue rows", np.ones(len(cl), dtype=bool)),
    ("Type=o", is_open),
    ("Type=o + logAge50<=8.0", is_open & young),
    ("+ MassJ>=1000", is_open & young & m1000),
    ("+ CST>=5", is_open & young & m1000 & cl["CST"].notna() & (cl["CST"] >= 5)),
    ("+ CMDCl50>=0.5", is_open & young & m1000 &
     cl["CST"].notna() & (cl["CST"] >= 5) &
     cl["CMDCl50"].notna() & (cl["CMDCl50"] >= 0.5)),
    ("+ probJ>=0.5", is_open & young & m1000 &
     cl["CST"].notna() & (cl["CST"] >= 5) &
     cl["CMDCl50"].notna() & (cl["CMDCl50"] >= 0.5) &
     cl["probJ"].notna() & (cl["probJ"] >= 0.5)),
    ("+ NJ>=40", is_open & young & m1000 &
     cl["CST"].notna() & (cl["CST"] >= 5) &
     cl["CMDCl50"].notna() & (cl["CMDCl50"] >= 0.5) &
     cl["probJ"].notna() & (cl["probJ"] >= 0.5) &
     cl["NJ"].notna() & (cl["NJ"] >= 40)),
    ("+ valid rJ/r50J/coordinates", quality_base & m1000),
]
pd.DataFrame([{"step": s, "N": int(np.count_nonzero(mask))} for s, mask in steps]
             ).to_csv(OUT / "02_cutflow_M1000.csv", index=False)

nested = []
for m in CONFIG["mass_thresholds_msun"]:
    mm = cl["MassJ"].notna() & (cl["MassJ"] >= m)
    mm_tot = cl["MassTot"].notna() & (cl["MassTot"] >= m)
    nested.append({
        "Mass_threshold_Msun": m,
        "N_open_young_MassJ": int(np.count_nonzero(is_open & young & mm)),
        "N_quality_MassJ": int(np.count_nonzero(quality_base & mm)),
        "N_open_young_MassTot": int(np.count_nonzero(is_open & young & mm_tot)),
        "N_quality_MassTot": int(np.count_nonzero(quality_base & mm_tot)),
    })
nested = pd.DataFrame(nested)
nested.to_csv(OUT / "03_nested_mass_counts.csv", index=False)

parent_mask = quality_base & m1000
cand = cl.loc[parent_mask].copy().sort_values(["MassJ", "Name"], ascending=[False, True])
cand.to_csv(OUT / "04_primary_clusterlevel_candidates.csv", index=False)
print(f"[2/5] Cluster-level candidate count: {len(cand)}")

print("[2b/5] Member schema sanity check...")
member_probe = tap_query(f"SELECT TOP 1 * FROM {MEMBER_TABLE}")
required_member_cols = {"ID","Name","GaiaDR3","inrj","Prob","Mass50"}
missing_mem = sorted(required_member_cols - set(member_probe.columns))
if missing_mem:
    raise RuntimeError(
        "Member table schema mismatch. Missing non-coordinate columns:\n  "
        + ", ".join(missing_mem)
        + "\nColumns returned by TAP:\n  "
        + ", ".join(map(str, member_probe.columns))
    )
member_ra_col, member_de_col = resolve_coords(member_probe, "Member")
print("       PASS: required member schema is usable.")

print("[3/5] Querying member rows cluster-by-cluster...")
rows = []
member_dir = OUT / "members_primary"
member_dir.mkdir(exist_ok=True)

for j, (_, r) in enumerate(cand.iterrows(), start=1):
    cid = int(r["ID"])
    name = str(r["Name"])
    q = (
        f'SELECT * FROM {MEMBER_TABLE} '
        f'WHERE "ID"={cid} AND "inrj"=1 AND "Prob">={CONFIG["member_prob_fetch_min"]}'
    )
    try:
        mem = tap_query(q, timeout=240, retries=4)
        mem_ra_col, mem_de_col = resolve_coords(mem if len(mem) else member_probe, f"Member[{name}]")
        mem = canonicalize_coords(mem, mem_ra_col, mem_de_col)

        for c in ["ID","inrj","Prob","Mass50","__RAdeg","__DEdeg"]:
            if c in mem.columns:
                mem[c] = pd.to_numeric(mem[c], errors="coerce")

        safe_name = "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in name)
        mem.to_csv(member_dir / f"{cid:04d}_{safe_name}.csv", index=False)

        rec = {"ID": cid, "Name": name, "N_fetch_P50_inrj": int(len(mem))}
        for pcut in CONFIG["member_prob_thresholds"]:
            sub = mem[mem["Prob"] >= pcut].copy()
            tag = str(int(round(100 * pcut)))
            rec[f"N_P{tag}_inrj"] = int(len(sub))
            rec[f"Neff_P{tag}_inrj"] = neff(sub["Prob"].to_numpy())
            if len(sub) and np.isfinite(r["r50J"]):
                sep = spherical_sep_deg(
                    sub["__RAdeg"], sub["__DEdeg"], r["__RAdeg"], r["__DEdeg"]
                )
                rec[f"N_P{tag}_r50J"] = int(np.count_nonzero(sep <= float(r["r50J"])))
            else:
                rec[f"N_P{tag}_r50J"] = 0
        rec["query_ok"] = True
        rec["error"] = ""
    except Exception as e:
        rec = {"ID": cid, "Name": name, "query_ok": False, "error": str(e)}
    rows.append(rec)
    print(f"  {j:3d}/{len(cand):3d}  {name}")

mqc = pd.DataFrame(rows)
mqc.to_csv(OUT / "05_member_qc.csv", index=False)

merged = cand.merge(mqc, on=["ID", "Name"], how="left")
if "Neff_P50_inrj" in merged.columns:
    provisional = (
        merged["query_ok"].fillna(False).astype(bool) &
        pd.to_numeric(merged["Neff_P50_inrj"], errors="coerce").fillna(0).ge(CONFIG["provisional_neff_min"]) &
        pd.to_numeric(merged["N_P50_r50J"], errors="coerce").fillna(0).ge(CONFIG["provisional_inner_n_min"])
    )
else:
    provisional = pd.Series(False, index=merged.index)

merged["PROVISIONAL_MORPHOLOGY_READY"] = provisional
merged.to_csv(OUT / "06_primary_with_member_qc.csv", index=False)
merged.loc[provisional].to_csv(OUT / "07_provisional_morphology_ready.csv", index=False)

audit = []
for m in CONFIG["mass_thresholds_msun"]:
    sub = merged[merged["MassJ"] >= m].copy()
    qok = sub.get("query_ok", pd.Series(index=sub.index, dtype=bool)).fillna(False)
    prov = sub.get("PROVISIONAL_MORPHOLOGY_READY", pd.Series(index=sub.index, dtype=bool)).fillna(False)
    ne = pd.to_numeric(sub.get("Neff_P50_inrj", pd.Series(index=sub.index, dtype=float)), errors="coerce")
    audit.append({
        "MassJ_threshold_Msun": m,
        "N_clusterlevel_quality": int(len(sub)),
        "N_member_query_ok": int(qok.sum()) if len(sub) else 0,
        "N_NeffP50_ge50": int((ne >= 50).sum()) if len(sub) else 0,
        "N_provisional_morphology_ready": int(prov.sum()) if len(sub) else 0,
    })
pd.DataFrame(audit).to_csv(OUT / "08_nested_member_qc_counts.csv", index=False)

CONFIG["cluster_coordinate_columns_used"] = [cluster_ra_col, cluster_de_col]
CONFIG["member_coordinate_columns_detected"] = [member_ra_col, member_de_col]
(OUT / "STAGE0_CONFIG.json").write_text(json.dumps(CONFIG, indent=2), encoding="utf-8")

report = [
    f"YHMC STAGE-0 PREFLIGHT v{VERSION}",
    "=" * 78,
    f"Catalogue rows fetched: {len(cl)}",
    f"Cluster coordinate columns used: {cluster_ra_col}, {cluster_de_col}",
    f"Member coordinate columns detected: {member_ra_col}, {member_de_col}",
    f"Type=o, logAge50<=8, MassJ>=1000 raw count: {int(np.count_nonzero(is_open & young & m1000))}",
    f"Cluster-level quality + MassJ>=1000 count: {len(cand)}",
    f"Provisional morphology-ready count: {int(provisional.sum())}",
    "",
    "Nested mass counts:",
    nested.to_string(index=False),
    "",
    "IMPORTANT: final PA-resolved sample is NOT frozen here.",
    "Synthetic recovery must calibrate PA reliability versus q and N_eff.",
]
(OUT / "STAGE0_REPORT.txt").write_text("\n".join(report) + "\n", encoding="utf-8")

manifest_lines = []
for p in sorted(OUT.rglob("*")):
    if p.is_file():
        manifest_lines.append(f"{sha256(p)}  {p.relative_to(OUT).as_posix()}")
(OUT / "SHA256SUMS.txt").write_text("\n".join(manifest_lines) + "\n", encoding="utf-8")

print("[4/5] Outputs written.")
print("[5/5] DONE")
print()
print((OUT / "STAGE0_REPORT.txt").read_text(encoding="utf-8"))

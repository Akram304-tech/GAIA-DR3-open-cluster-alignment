YHMC STAGE-2B CONTROL SYNTHETIC PA CALIBRATION v0.6.0
==========================================================

Purpose
-------
Blindly calibrate q/PA recovery for the exact Stage-2A frozen older controls.

No real control morphology or alignment is computed.

Run
---
call RUN_STAGE2B_CONTROL_SYNTHETIC_PA_CALIBRATION_v0_6_0.bat

Main outputs
------------
STAGE2B_OUTPUT\STAGE2B_REPORT.txt
STAGE2B_OUTPUT\01_control_input_audit.csv
STAGE2B_OUTPUT\02_control_qgrid_recovery.csv
STAGE2B_OUTPUT\03_control_specific_PA_gate.csv
STAGE2B_OUTPUT\04_control_global_qgrid_summary.csv
STAGE2B_OUTPUT\05_control_mass_threshold_calibration_coverage.csv
STAGE2B_OUTPUT\STAGE2B_FREEZE.json

Frozen inputs
-------------
CONTROL_LIST_SHA256:
b31d69d0e90359f9d2a5e0d31db2ce20a3b7b9f5888862de9a15e8cb89ee7c6a

MATCH_TABLE_SHA256:
ee17d8f92f1cc7b97537faafab1de077ff003e869dcd161b92be44e50239e5db

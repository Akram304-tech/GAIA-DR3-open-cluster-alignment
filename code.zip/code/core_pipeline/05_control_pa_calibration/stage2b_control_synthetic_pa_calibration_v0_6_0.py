#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-2B blind synthetic PA calibration for frozen older controls v0.6.0

Purpose
-------
Calibrate morphology/PA recovery for the EXACT frozen Stage-2A older-control
sample before any real control morphology or Galactic-plane alignment is
measured.

This stage DOES NOT compute:
  - real control q or PA
  - local Galactic-plane PA
  - Delta theta
  - cos(2 Delta theta)
  - control alignment statistic A

Synthetic design is intentionally identical to Stage-1A:
  * keep each control's actual member count;
  * keep observed member radii from the catalogue centre;
  * keep membership-probability weights;
  * randomize angular positions;
  * impose known q_true and random PA_true;
  * recover q and PA with weighted second central moments.

Frozen reliability rule
-----------------------
At a given q_true, a control is PA-reliable if:
  P68(|Delta PA|) <= 20 deg
  median(|Delta PA|) <= 10 deg
  |median(q_rec - q_true)| <= 0.05

q_max_PA_reliable is the roundest tested q satisfying the criterion and
all more-elongated tested q values.
"""

from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "0.6.0"
SEED = 20260912
Q_GRID = [1.00, 0.98, 0.96, 0.94, 0.92, 0.90, 0.85, 0.80, 0.70, 0.60]
N_REP = 250

PA_P68_MAX = 20.0
PA_MED_MAX = 10.0
Q_BIAS_MED_MAX = 0.05

EXPECTED_CONTROL_LIST_SHA256 = "b31d69d0e90359f9d2a5e0d31db2ce20a3b7b9f5888862de9a15e8cb89ee7c6a"
EXPECTED_MATCH_TABLE_SHA256 = "ee17d8f92f1cc7b97537faafab1de077ff003e869dcd161b92be44e50239e5db"

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()

def weighted_neff(w):
    w = np.asarray(w, dtype=float)
    w = w[np.isfinite(w) & (w > 0)]
    if len(w) == 0:
        return 0.0
    return float(w.sum()**2 / np.square(w).sum())

def tangent_xy_arcmin(ra, dec, ra0, dec0):
    ra = np.asarray(ra, dtype=float)
    dec = np.asarray(dec, dtype=float)
    dra = ((ra - float(ra0) + 180.0) % 360.0) - 180.0
    x = dra * math.cos(math.radians(float(dec0))) * 60.0
    y = (dec - float(dec0)) * 60.0
    return x, y

def weighted_shape(x, y, w):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    w = np.asarray(w, dtype=float)
    good = np.isfinite(x) & np.isfinite(y) & np.isfinite(w) & (w > 0)
    x, y, w = x[good], y[good], w[good]
    if len(x) < 3 or w.sum() <= 0:
        return np.nan, np.nan

    sw = w.sum()
    xc = np.sum(w*x)/sw
    yc = np.sum(w*y)/sw
    dx, dy = x-xc, y-yc
    sxx = np.sum(w*dx*dx)/sw
    syy = np.sum(w*dy*dy)/sw
    sxy = np.sum(w*dx*dy)/sw
    C = np.array([[sxx, sxy],[sxy, syy]], dtype=float)

    vals, vecs = np.linalg.eigh(C)
    order = np.argsort(vals)[::-1]
    vals = vals[order]
    vecs = vecs[:,order]
    if vals[0] <= 0 or vals[1] < 0:
        return np.nan, np.nan

    q = float(np.sqrt(max(vals[1],0.0)/vals[0]))
    vx, vy = vecs[:,0]
    pa = float(np.degrees(np.arctan2(vy,vx)) % 180.0)
    return q, pa

def axial_signed_diff_deg(a, b):
    return ((float(a)-float(b)+90.0)%180.0)-90.0

def pct(a,p):
    a=np.asarray(a,dtype=float)
    a=a[np.isfinite(a)]
    return float(np.percentile(a,p)) if len(a) else np.nan

def med(a):
    a=np.asarray(a,dtype=float)
    a=a[np.isfinite(a)]
    return float(np.median(a)) if len(a) else np.nan

def safe_name(s):
    return "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in str(s))

def find_member_file(member_dir: Path, cid: int, name: str):
    hits = sorted([p for p in member_dir.glob(f"{cid:04d}_*.csv") if p.is_file()])
    if not hits:
        return None
    if len(hits) == 1:
        return hits[0]
    sn = safe_name(name)
    for p in hits:
        if sn in p.stem:
            return p
    return hits[0]

def synth_one(r, w, q_true, rng):
    theta = rng.uniform(0.0, 2.0*np.pi, size=len(r))
    phi = rng.uniform(0.0, np.pi)

    x0 = r*np.cos(theta)
    y0 = q_true*r*np.sin(theta)

    c = math.cos(phi)
    s = math.sin(phi)
    x = c*x0 - s*y0
    y = s*x0 + c*y0

    q_rec, pa_rec = weighted_shape(x,y,w)
    pa_true = math.degrees(phi)%180.0
    return q_rec, pa_rec, pa_true

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage2a", required=True)
    ap.add_argument("--out", default="STAGE2B_OUTPUT")
    ap.add_argument("--nrep", type=int, default=N_REP)
    args=ap.parse_args()

    stage2a=Path(args.stage2a).expanduser().resolve()
    out=Path(args.out).expanduser().resolve()
    out.mkdir(parents=True,exist_ok=True)

    controls_file=stage2a/"02_MATCHED_OLDER_CONTROLS_FROZEN.csv"
    matches_file=stage2a/"01_young_to_control_matches.csv"
    freeze_file=stage2a/"STAGE2A_FREEZE.json"
    member_dir=stage2a/"members_control_frozen"

    for p in [controls_file,matches_file,freeze_file]:
        if not p.exists():
            raise FileNotFoundError(p)
    if not member_dir.is_dir():
        raise FileNotFoundError(member_dir)

    control_hash=sha256(controls_file)
    match_hash=sha256(matches_file)
    if control_hash != EXPECTED_CONTROL_LIST_SHA256:
        raise RuntimeError(
            "CONTROL CHAIN-OF-CUSTODY FAIL\n"
            f"Expected {EXPECTED_CONTROL_LIST_SHA256}\nActual   {control_hash}"
        )
    if match_hash != EXPECTED_MATCH_TABLE_SHA256:
        raise RuntimeError(
            "MATCH TABLE CHAIN-OF-CUSTODY FAIL\n"
            f"Expected {EXPECTED_MATCH_TABLE_SHA256}\nActual   {match_hash}"
        )

    freeze=json.loads(freeze_file.read_text(encoding="utf-8"))
    if freeze.get("alignment_information_used", True):
        raise RuntimeError("Stage-2A freeze indicates alignment information was used.")
    if freeze.get("control_morphology_used", True):
        raise RuntimeError("Stage-2A freeze indicates control morphology was used.")

    controls=pd.read_csv(controls_file)
    required={"ID","Name","MassJ","logAge50","__RAdeg","__DEdeg"}
    miss=sorted(required-set(controls.columns))
    if miss:
        raise RuntimeError("Frozen control list missing columns: "+", ".join(miss))
    if controls.duplicated(["ID","Name"]).any():
        raise RuntimeError("Frozen control list has duplicate ID+Name.")

    print("="*88)
    print(f"YHMC STAGE-2B CONTROL SYNTHETIC PA CALIBRATION v{VERSION}")
    print("BLIND: NO REAL CONTROL MORPHOLOGY OR ALIGNMENT")
    print("="*88)
    print(f"CONTROL_LIST_SHA256={control_hash}")
    print(f"MATCH_TABLE_SHA256={match_hash}")
    print(f"FROZEN_CONTROLS={len(controls)}")
    print(f"Q_GRID={Q_GRID}")
    print(f"N_REP={args.nrep}")
    print(f"SEED={SEED}")

    audit=[]
    summaries=[]

    for ii,row in controls.reset_index(drop=True).iterrows():
        cid=int(row["ID"])
        name=str(row["Name"])
        mf=find_member_file(member_dir,cid,name)
        if mf is None:
            audit.append({"ID":cid,"Name":name,"status":"MISSING_MEMBER_FILE"})
            print(f"{ii+1:3d}/{len(controls):3d} {name}: MISSING_MEMBER_FILE")
            continue

        mem=pd.read_csv(mf)
        needed={"Prob","__RAdeg","__DEdeg"}
        missing=sorted(needed-set(mem.columns))
        if missing:
            audit.append({
                "ID":cid,"Name":name,"status":"BAD_MEMBER_SCHEMA",
                "missing":";".join(missing)
            })
            print(f"{ii+1:3d}/{len(controls):3d} {name}: BAD_MEMBER_SCHEMA")
            continue

        p=pd.to_numeric(mem["Prob"],errors="coerce").to_numpy(float)
        ra=pd.to_numeric(mem["__RAdeg"],errors="coerce").to_numpy(float)
        de=pd.to_numeric(mem["__DEdeg"],errors="coerce").to_numpy(float)
        good=np.isfinite(p)&np.isfinite(ra)&np.isfinite(de)&(p>=0.5)
        p,ra,de=p[good],ra[good],de[good]

        x,y=tangent_xy_arcmin(ra,de,row["__RAdeg"],row["__DEdeg"])
        r=np.hypot(x,y)
        g=np.isfinite(r)&np.isfinite(p)&(p>0)
        r,p=r[g],p[g]

        n=len(r)
        ne=weighted_neff(p)
        if n<20 or ne<10:
            audit.append({
                "ID":cid,"Name":name,"status":"TOO_FEW_VALID_MEMBERS",
                "N":n,"Neff":ne
            })
            print(f"{ii+1:3d}/{len(controls):3d} {name}: TOO_FEW_VALID_MEMBERS")
            continue

        audit.append({
            "ID":cid,"Name":name,"status":"OK","N":n,"Neff":ne,
            "MassJ":row["MassJ"],"logAge50":row["logAge50"],
            "r_arcmin_median":float(np.median(r)),
            "r_arcmin_p90":float(np.percentile(r,90)),
        })

        for q_idx,q_true in enumerate(Q_GRID):
            rng=np.random.default_rng(np.random.SeedSequence([SEED,cid,q_idx,args.nrep,2]))
            q_rec=np.empty(args.nrep,dtype=float)
            pa_abs=np.full(args.nrep,np.nan,dtype=float)

            for k in range(args.nrep):
                qr,par,pat=synth_one(r,p,q_true,rng)
                q_rec[k]=qr
                if q_true<0.999 and np.isfinite(par):
                    pa_abs[k]=abs(axial_signed_diff_deg(par,pat))

            q_bias=q_rec-q_true
            rec={
                "ID":cid,"Name":name,
                "MassJ":row["MassJ"],"logAge50":row["logAge50"],
                "N":n,"Neff":ne,"q_true":q_true,"N_rep":args.nrep,
                "qrec_median":med(q_rec),
                "qrec_p05":pct(q_rec,5),
                "qrec_p16":pct(q_rec,16),
                "qrec_p84":pct(q_rec,84),
                "qrec_p95":pct(q_rec,95),
                "qbias_median":med(q_bias),
                "qbias_abs_median":med(np.abs(q_bias)),
                "qbias_abs_p68":pct(np.abs(q_bias),68),
            }
            if q_true<0.999:
                rec.update({
                    "pa_abs_median_deg":med(pa_abs),
                    "pa_abs_p68_deg":pct(pa_abs,68),
                    "pa_abs_p95_deg":pct(pa_abs,95),
                })
                rec["pa_reliable_at_q"]=bool(
                    np.isfinite(rec["pa_abs_p68_deg"]) and
                    rec["pa_abs_p68_deg"]<=PA_P68_MAX and
                    rec["pa_abs_median_deg"]<=PA_MED_MAX and
                    abs(rec["qbias_median"])<=Q_BIAS_MED_MAX
                )
            else:
                rec.update({
                    "pa_abs_median_deg":np.nan,
                    "pa_abs_p68_deg":np.nan,
                    "pa_abs_p95_deg":np.nan,
                    "pa_reliable_at_q":False,
                })
            summaries.append(rec)

        print(f"{ii+1:3d}/{len(controls):3d} {name}: N={n}, Neff={ne:.1f}")

    audit_df=pd.DataFrame(audit)
    sum_df=pd.DataFrame(summaries)
    audit_df.to_csv(out/"01_control_input_audit.csv",index=False)
    sum_df.to_csv(out/"02_control_qgrid_recovery.csv",index=False)

    gate_rows=[]
    for cid,g in sum_df.groupby("ID",sort=False):
        g=g.sort_values("q_true")
        name=str(g["Name"].iloc[0])
        mass=float(g["MassJ"].iloc[0])
        age=float(g["logAge50"].iloc[0])
        n=int(g["N"].iloc[0])
        ne=float(g["Neff"].iloc[0])

        round_row=g[np.isclose(g["q_true"],1.0)]
        q_round_p05=float(round_row["qrec_p05"].iloc[0]) if len(round_row) else np.nan
        q_round_p16=float(round_row["qrec_p16"].iloc[0]) if len(round_row) else np.nan
        q_round_med=float(round_row["qrec_median"].iloc[0]) if len(round_row) else np.nan

        nonround=g[g["q_true"]<0.999].copy().sort_values("q_true")
        pass_map={float(r.q_true):bool(r.pa_reliable_at_q) for r in nonround.itertuples()}
        qvals=sorted(pass_map)
        reliable=[]
        for q in qvals:
            if all(pass_map[qq] for qq in qvals if qq<=q):
                reliable.append(q)
        qmax=max(reliable) if reliable else np.nan

        gate_rows.append({
            "ID":int(cid),"Name":name,"MassJ":mass,"logAge50":age,
            "N":n,"Neff":ne,
            "q_round_null_p05":q_round_p05,
            "q_round_null_p16":q_round_p16,
            "q_round_null_median":q_round_med,
            "q_max_PA_reliable":qmax,
            "PA_CALIBRATABLE":bool(np.isfinite(qmax)),
            "LATER_REAL_GATE_PROPOSED":
                "q84_real<=q_max_PA_reliable AND q_real<q_round_null_p05"
        })

    gate_df=pd.DataFrame(gate_rows).sort_values(
        ["PA_CALIBRATABLE","Neff"],ascending=[False,False]
    )
    gate_df.to_csv(out/"03_control_specific_PA_gate.csv",index=False)

    global_rows=[]
    for q,g in sum_df.groupby("q_true"):
        global_rows.append({
            "q_true":q,
            "N_controls":int(g["ID"].nunique()),
            "median_qbias_median":med(g["qbias_median"]),
            "median_qbias_abs_p68":med(g["qbias_abs_p68"]),
            "median_PA_abs_median_deg":med(g["pa_abs_median_deg"]),
            "median_PA_abs_p68_deg":med(g["pa_abs_p68_deg"]),
            "fraction_control_q_reliable":
                float(pd.to_numeric(g["pa_reliable_at_q"],errors="coerce").fillna(False).mean())
                if q<0.999 else np.nan,
        })
    pd.DataFrame(global_rows).sort_values("q_true",ascending=False).to_csv(
        out/"04_control_global_qgrid_summary.csv",index=False
    )

    # Calibration coverage by mass bins, for comparability with young analysis.
    coverage=[]
    for m in [1000,3000,5000,10000]:
        s=gate_df[gate_df["MassJ"]>=m]
        coverage.append({
            "MassJ_threshold_Msun":m,
            "N_calibrated":len(s),
            "N_PA_calibratable":int(s["PA_CALIBRATABLE"].sum()) if len(s) else 0,
            "fraction_PA_calibratable":float(s["PA_CALIBRATABLE"].mean()) if len(s) else np.nan,
            "median_Neff":med(s["Neff"]) if len(s) else np.nan,
            "median_qmax_reliable":med(s["q_max_PA_reliable"]) if len(s) else np.nan,
        })
    cov_df=pd.DataFrame(coverage)
    cov_df.to_csv(out/"05_control_mass_threshold_calibration_coverage.csv",index=False)

    config={
        "stage":"STAGE2B_CONTROL_SYNTHETIC_PA_CALIBRATION",
        "version":VERSION,
        "seed":SEED,
        "control_list_sha256":control_hash,
        "match_table_sha256":match_hash,
        "q_grid":Q_GRID,
        "n_rep":args.nrep,
        "estimator":"membership-probability weighted second central moments",
        "synthetic_geometry":
            "actual member radii + actual Prob weights; randomized angles; imposed q_true; random PA_true",
        "pa_reliability_rule":{
            "p68_abs_deltaPA_deg_max":PA_P68_MAX,
            "median_abs_deltaPA_deg_max":PA_MED_MAX,
            "abs_median_q_bias_max":Q_BIAS_MED_MAX,
            "monotonic_requirement":
                "candidate q passes only if all tested more-elongated q values also pass",
        },
        "control_alignment_blinding":True,
        "next_stage":
            "Stage-2C real control morphology freeze using the pre-frozen gate; no alignment until identities/admission are hashed."
    }
    (out/"STAGE2B_FREEZE.json").write_text(json.dumps(config,indent=2),encoding="utf-8")

    n_ok=int((audit_df["status"]=="OK").sum()) if len(audit_df) else 0
    n_cal=int(gate_df["PA_CALIBRATABLE"].sum()) if len(gate_df) else 0
    report=[
        f"YHMC STAGE-2B CONTROL SYNTHETIC PA CALIBRATION v{VERSION}",
        "="*88,
        f"CONTROL_CHAIN_OF_CUSTODY=PASS",
        f"CONTROL_LIST_SHA256={control_hash}",
        f"MATCH_TABLE_SHA256={match_hash}",
        f"Frozen older controls: {len(controls)}",
        f"Successfully calibrated controls: {n_ok}",
        f"Controls with >=1 reliable PA q-grid regime: {n_cal}",
        f"Q_GRID={Q_GRID}",
        f"N_REP={args.nrep}",
        f"SEED={SEED}",
        "",
        "FROZEN PA-RELIABILITY RULE:",
        f"  P68(|DeltaPA|) <= {PA_P68_MAX:.1f} deg",
        f"  median(|DeltaPA|) <= {PA_MED_MAX:.1f} deg",
        f"  |median(q_rec-q_true)| <= {Q_BIAS_MED_MAX:.3f}",
        "  q_max requires all more-elongated tested q values to pass.",
        "",
        "MASS-THRESHOLD CALIBRATION COVERAGE:",
        cov_df.to_string(index=False),
        "",
        "BLINDING:",
        "  Real control q: NOT COMPUTED",
        "  Real control PA: NOT COMPUTED",
        "  Control Galactic-plane alignment: NOT COMPUTED",
        "",
        "NEXT_STAGE:",
        "  Stage-2C real control morphology freeze, then hash admitted controls before unblinding.",
    ]
    (out/"STAGE2B_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")

    print()
    print((out/"STAGE2B_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

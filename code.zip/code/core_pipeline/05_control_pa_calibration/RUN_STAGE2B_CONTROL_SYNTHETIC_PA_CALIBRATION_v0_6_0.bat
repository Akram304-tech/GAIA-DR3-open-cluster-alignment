@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-2B CONTROL SYNTHETIC PA CALIBRATION v0.6.0
echo BLIND CONTROL MORPHOLOGY/ALIGNMENT CALIBRATION
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" (
  echo ERROR: Miniconda Python not found.
  exit /b 1
)

set "STAGE2A=%USERPROFILE%\Downloads\YHMC_STAGE2A_MATCHED_OLDER_CONTROL_FREEZE_v0_5_0\YHMC_STAGE2A_MATCHED_OLDER_CONTROL_FREEZE_v0_5_0\STAGE2A_OUTPUT"

if not exist "%STAGE2A%\02_MATCHED_OLDER_CONTROLS_FROZEN.csv" (
  echo ERROR: Stage-2A frozen control list not found:
  echo   %STAGE2A%
  exit /b 1
)

echo PYEXE=%PYEXE%
"%PYEXE%" --version
echo STAGE2A=%STAGE2A%

"%PYEXE%" -c "import numpy,pandas" >nul 2>nul
if errorlevel 1 (
  "%PYEXE%" -m pip install numpy pandas
  if errorlevel 1 exit /b 1
)

"%PYEXE%" stage2b_control_synthetic_pa_calibration_v0_6_0.py --stage2a "%STAGE2A%" --out "%CD%\STAGE2B_OUTPUT"
set "RC=%ERRORLEVEL%"

echo.
echo RETURN_CODE=%RC%
if "%RC%"=="0" (
  echo REPORT=%CD%\STAGE2B_OUTPUT\STAGE2B_REPORT.txt
  echo GATE=%CD%\STAGE2B_OUTPUT\03_control_specific_PA_gate.csv
  echo FREEZE=%CD%\STAGE2B_OUTPUT\STAGE2B_FREEZE.json
)
exit /b %RC%

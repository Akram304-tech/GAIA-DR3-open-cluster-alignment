#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-6A1R3 Numerical Solver Adjudication v2.1.3

IMPLEMENTATION-ONLY adjudication of Stage-6A1R2.

No science model is changed:
- same Y1 N=95
- same Y2 N=142
- same covariates
- same pooled standardization
- same ridge lambda=1e-4
- same overlap-weight formulas
- same acceptance gates:
      max weighted |SMD| <= 0.10
      ESS_Y1 >= 40
      ESS_Y2 >= 40

Stage-6A1R2 was formally rejected only because scipy BFGS returned:
  success=False
  "Desired error not necessarily achieved due to precision loss."

The resulting design nevertheless had near-zero weighted imbalance and large
ESS. This stage determines whether that failure was numerical only.

Two independent numerical routes solve the EXACT SAME penalized logistic
objective:
  1) L-BFGS-B with analytic gradient
  2) damped Newton / IRLS with exact Hessian and backtracking

Validation requires:
  - both solvers converge under explicit gradient criteria;
  - objective values agree;
  - coefficients agree;
  - propensities and normalized overlap weights agree;
  - both reproduce the frozen balance/ESS gates.

NO morphology, PA, Galactic-plane angle, or alignment is read/computed.
"""

from __future__ import annotations
import argparse, hashlib, json, math
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit

VERSION="2.1.3"

EXPECTED_CONTROL_SHA="124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd"
EXPECTED_FULL_SNAPSHOT_SHA="2164adf7ed3e516f035f60c6e6bfc06affbc4d809157c8eb06306d3e78d2cb47"
EXPECTED_FAILED_DESIGN_SHA="9b08c0bca1e8c5197268d9dfa5d940624eff41565551d19e1a80a12dfbe19117"
EXPECTED_FAILED_COEF_SHA="4599d436280e0cbd60f2efc55bd2af956abad3b475160e073358f7d3b9f27fac"

AGE_LO=math.log10(5e8)
AGE_HI=math.log10(2e9)
MASS_MIN=1000.0
RIDGE=1e-4

MAX_ABS_SMD_GATE=0.10
MIN_ESS=40.0

GRAD_INF_TOL=1e-7
OBJ_DIFF_TOL=1e-7
COEF_MAX_DIFF_TOL=2e-5
PROP_MAX_DIFF_TOL=2e-7
WEIGHT_MAX_DIFF_TOL=2e-7

def sha256(p):
    h=hashlib.sha256()
    with Path(p).open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def num(df,c):
    return pd.to_numeric(df[c],errors="coerce")

def base_quality(df):
    typ=df["Type"].astype(str).str.strip().str.lower()
    return (
        (typ=="o") &
        (num(df,"CST")>=5) &
        (num(df,"CMDCl50")>=0.5) &
        (num(df,"probJ")>=0.5) &
        (num(df,"NJ")>=40) &
        np.isfinite(num(df,"rJ")) & (num(df,"rJ")>0) &
        np.isfinite(num(df,"r50J")) & (num(df,"r50J")>0) &
        np.isfinite(num(df,"MassJ")) & (num(df,"MassJ")>0) &
        np.isfinite(num(df,"logAge50"))
    )

def feat(df):
    out=pd.DataFrame(index=df.index)
    out["logMass"]=np.log10(num(df,"MassJ"))
    out["logDist"]=np.log10(num(df,"dist50"))
    out["logNJ"]=np.log10(num(df,"NJ"))
    out["AV50"]=num(df,"AV50")
    out["abs_b"]=np.abs(num(df,"GLAT"))
    l=np.deg2rad(num(df,"GLON")%360.0)
    out["sin_l"]=np.sin(l)
    out["cos_l"]=np.cos(l)
    return out

def objective(beta,X1,z):
    eta=X1@beta
    nll=np.sum(np.logaddexp(0.0,eta)-z*eta)
    return float(nll+0.5*RIDGE*np.sum(beta[1:]**2))

def gradient(beta,X1,z):
    p=expit(X1@beta)
    g=X1.T@(p-z)
    g[1:]+=RIDGE*beta[1:]
    return g

def hessian(beta,X1):
    p=expit(X1@beta)
    v=p*(1.0-p)
    H=X1.T@(X1*v[:,None])
    H[1:,1:]+=RIDGE*np.eye(X1.shape[1]-1)
    return H

def solve_lbfgsb(X1,z):
    res=minimize(
        lambda b: objective(b,X1,z),
        np.zeros(X1.shape[1]),
        jac=lambda b: gradient(b,X1,z),
        method="L-BFGS-B",
        options={
            "ftol":1e-15,
            "gtol":1e-10,
            "maxiter":20000,
            "maxls":100,
        }
    )
    gi=float(np.max(np.abs(gradient(res.x,X1,z))))
    converged=bool(np.isfinite(res.fun) and gi<=GRAD_INF_TOL)
    return {
        "name":"L-BFGS-B",
        "beta":res.x,
        "objective":float(res.fun),
        "grad_inf":gi,
        "native_success":bool(res.success),
        "message":str(res.message),
        "iterations":int(getattr(res,"nit",-1)),
        "converged_by_frozen_gradient":converged,
    }

def solve_newton(X1,z):
    beta=np.zeros(X1.shape[1],float)
    f=objective(beta,X1,z)
    converged=False
    msg=""
    nit=0

    for it in range(1,501):
        nit=it
        g=gradient(beta,X1,z)
        gi=float(np.max(np.abs(g)))
        if gi<=GRAD_INF_TOL:
            converged=True
            msg="gradient criterion"
            break

        H=hessian(beta,X1)
        try:
            step=np.linalg.solve(H,g)
        except np.linalg.LinAlgError:
            step=np.linalg.lstsq(H,g,rcond=None)[0]

        # Backtracking Armijo line search.
        alpha=1.0
        descent=float(g@step)
        accepted=False
        for _ in range(80):
            cand=beta-alpha*step
            fc=objective(cand,X1,z)
            if np.isfinite(fc) and fc <= f - 1e-4*alpha*descent:
                beta=cand
                f=fc
                accepted=True
                break
            alpha*=0.5
        if not accepted:
            msg="line search failed"
            break
    else:
        msg="maximum iterations"

    gi=float(np.max(np.abs(gradient(beta,X1,z))))
    if gi<=GRAD_INF_TOL:
        converged=True
        if not msg:
            msg="gradient criterion at exit"

    return {
        "name":"DAMPED_NEWTON",
        "beta":beta,
        "objective":float(objective(beta,X1,z)),
        "grad_inf":gi,
        "native_success":converged,
        "message":msg,
        "iterations":nit,
        "converged_by_frozen_gradient":bool(converged),
    }

def weighted_mean(x,w):
    return float(np.sum(np.asarray(w,float)*np.asarray(x,float))/np.sum(w))

def weighted_var(x,w):
    m=weighted_mean(x,w)
    return float(np.sum(np.asarray(w,float)*(np.asarray(x,float)-m)**2)/np.sum(w))

def weighted_smd(x0,w0,x1,w1):
    m0=weighted_mean(x0,w0); m1=weighted_mean(x1,w1)
    v0=weighted_var(x0,w0); v1=weighted_var(x1,w1)
    den=np.sqrt((v0+v1)/2)
    return float((m0-m1)/den) if den>0 else 0.0

def ess(w):
    w=np.asarray(w,float)
    return float(w.sum()**2/np.square(w).sum())

def design_metrics(beta,X1,F1,F2,n1):
    p=expit(X1@beta)
    p1=p[:n1]; p2=p[n1:]
    w1=p1
    w2=1.0-p2
    w1n=w1/w1.sum()
    w2n=w2/w2.sum()

    bal=[]
    for c in F1.columns:
        v=weighted_smd(F1[c],w1n,F2[c],w2n)
        bal.append({
            "covariate":c,
            "weighted_Y1_mean":weighted_mean(F1[c],w1n),
            "weighted_Y2_mean":weighted_mean(F2[c],w2n),
            "weighted_SMD":v,
            "abs_weighted_SMD":abs(v),
        })
    bdf=pd.DataFrame(bal)
    return {
        "p":p,"p1":p1,"p2":p2,
        "w1n":w1n,"w2n":w2n,
        "balance":bdf,
        "max_abs_smd":float(bdf["abs_weighted_SMD"].max()),
        "ess1":ess(w1n),"ess2":ess(w2n),
        "maxw1":float(w1n.max()),"maxw2":float(w2n.max()),
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage6",required=True)
    ap.add_argument("--stage2c",required=True)
    ap.add_argument("--stage6a1r2",required=True)
    ap.add_argument("--out",default="STAGE6A1R3_OUTPUT")
    args=ap.parse_args()

    s6=Path(args.stage6).resolve()
    s2=Path(args.stage2c).resolve()
    old=Path(args.stage6a1r2).resolve()
    out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=True)

    snap=s6/"00_HUNT_REFFERT_FULLCOLUMN_SNAPSHOT.csv"
    cf=s2/"02_CONTROL_PA_SAMPLE_FROZEN.csv"
    old_design=old/"01_OVERLAP_WEIGHT_DESIGN_FROZEN.csv"
    old_coef=old/"03_PROPENSITY_MODEL_COEFFICIENTS.csv"

    for p in [snap,cf,old_design,old_coef]:
        if not p.exists():
            raise FileNotFoundError(p)

    if sha256(snap)!=EXPECTED_FULL_SNAPSHOT_SHA:
        raise RuntimeError("Stage-6 snapshot hash mismatch.")
    if sha256(cf)!=EXPECTED_CONTROL_SHA:
        raise RuntimeError("Stage-2C control hash mismatch.")
    if sha256(old_design)!=EXPECTED_FAILED_DESIGN_SHA:
        raise RuntimeError("Stage-6A1R2 failed-design hash mismatch.")
    if sha256(old_coef)!=EXPECTED_FAILED_COEF_SHA:
        raise RuntimeError("Stage-6A1R2 failed-coefficient hash mismatch.")

    cat=pd.read_csv(snap,low_memory=False)
    y1f=pd.read_csv(cf)
    cat["ID"]=pd.to_numeric(cat["ID"],errors="coerce")
    y1f["ID"]=pd.to_numeric(y1f["ID"],errors="coerce")
    cat["Name"]=cat["Name"].astype(str).str.strip()
    y1f["Name"]=y1f["Name"].astype(str).str.strip()

    if cat["ID"].duplicated().any():
        raise RuntimeError("Catalogue ID not unique.")

    cols=["ID","Name","Type","CST","CMDCl50","probJ","NJ","rJ","r50J",
          "MassJ","logAge16","logAge50","logAge84",
          "dist50","AV50","GLON","GLAT"]
    src=cat[cols].copy()

    y1=y1f[["ID","Name"]].merge(
        src,on="ID",how="left",suffixes=("_frozen","_catalog"),
        validate="one_to_one"
    )
    if len(y1)!=95 or y1["MassJ"].isna().any():
        raise RuntimeError("Y1 binding failure.")

    q=base_quality(cat)
    age=(num(cat,"logAge50")>AGE_LO)&(num(cat,"logAge50")<=AGE_HI)
    y2=cat.loc[q&age&(num(cat,"MassJ")>=MASS_MIN),cols].copy().reset_index(drop=True)
    if len(y2)!=142:
        raise RuntimeError(f"Expected Y2 N=142, found {len(y2)}.")

    F1=feat(y1).reset_index(drop=True)
    F2=feat(y2).reset_index(drop=True)
    names=list(F1.columns)

    pooled=pd.concat([F1,F2],ignore_index=True)
    mu=pooled.mean()
    sd=pooled.std(ddof=1).replace(0,1.0)
    Z1=(F1-mu)/sd
    Z2=(F2-mu)/sd
    X=np.vstack([Z1.to_numpy(float),Z2.to_numpy(float)])
    z=np.concatenate([np.zeros(len(Z1)),np.ones(len(Z2))])
    X1=np.column_stack([np.ones(len(X)),X])

    if not np.all(np.isfinite(X1)):
        raise RuntimeError("Non-finite design matrix.")

    sA=solve_lbfgsb(X1,z)
    sB=solve_newton(X1,z)

    mA=design_metrics(sA["beta"],X1,F1,F2,len(y1))
    mB=design_metrics(sB["beta"],X1,F1,F2,len(y1))

    objdiff=abs(sA["objective"]-sB["objective"])
    coefdiff=float(np.max(np.abs(sA["beta"]-sB["beta"])))
    propdiff=float(np.max(np.abs(mA["p"]-mB["p"])))
    w1diff=float(np.max(np.abs(mA["w1n"]-mB["w1n"])))
    w2diff=float(np.max(np.abs(mA["w2n"]-mB["w2n"])))

    agreement={
        "objective_abs_diff":objdiff,
        "coefficient_max_abs_diff":coefdiff,
        "propensity_max_abs_diff":propdiff,
        "Y1_normalized_weight_max_abs_diff":w1diff,
        "Y2_normalized_weight_max_abs_diff":w2diff,
    }

    solver_gate=bool(
        sA["converged_by_frozen_gradient"] and
        sB["converged_by_frozen_gradient"] and
        objdiff<=OBJ_DIFF_TOL and
        coefdiff<=COEF_MAX_DIFF_TOL and
        propdiff<=PROP_MAX_DIFF_TOL and
        w1diff<=WEIGHT_MAX_DIFF_TOL and
        w2diff<=WEIGHT_MAX_DIFF_TOL
    )

    design_gate_A=bool(
        mA["max_abs_smd"]<=MAX_ABS_SMD_GATE and
        mA["ess1"]>=MIN_ESS and mA["ess2"]>=MIN_ESS
    )
    design_gate_B=bool(
        mB["max_abs_smd"]<=MAX_ABS_SMD_GATE and
        mB["ess1"]>=MIN_ESS and mB["ess2"]>=MIN_ESS
    )
    accepted=bool(solver_gate and design_gate_A and design_gate_B)

    solver_df=pd.DataFrame([
        {
            "solver":s["name"],
            "objective":s["objective"],
            "grad_inf":s["grad_inf"],
            "native_success":s["native_success"],
            "converged_by_frozen_gradient":s["converged_by_frozen_gradient"],
            "iterations":s["iterations"],
            "message":s["message"],
        }
        for s in [sA,sB]
    ])
    solver_df.to_csv(out/"01_SOLVER_DIAGNOSTICS.csv",index=False)

    pd.DataFrame([agreement]).to_csv(out/"02_SOLVER_AGREEMENT.csv",index=False)

    # Use Newton route as canonical only if accepted; both must agree.
    canon=sB
    metrics=mB
    coef=pd.DataFrame({
        "term":["intercept"]+names,
        "coefficient":canon["beta"],
    })
    coef.to_csv(out/"03_CANONICAL_COEFFICIENTS.csv",index=False)
    metrics["balance"].to_csv(out/"04_CANONICAL_WEIGHTED_BALANCE.csv",index=False)

    # Recreate the exact design identities and canonical weights.
    d1=y1[[
        "ID","Name_frozen","Name_catalog","MassJ","logAge16","logAge50",
        "logAge84","dist50","NJ","AV50","GLON","GLAT"
    ]].copy()
    d1["cohort"]="Y1_100_500M"
    d1["propensity_Y2"]=metrics["p1"]
    d1["overlap_weight_norm"]=metrics["w1n"]

    d2=y2[[
        "ID","Name","MassJ","logAge16","logAge50","logAge84",
        "dist50","NJ","AV50","GLON","GLAT"
    ]].copy()
    d2=d2.rename(columns={"Name":"Name_catalog"})
    d2["Name_frozen"]=""
    d2["cohort"]="Y2_0p5_2G"
    d2["propensity_Y2"]=metrics["p2"]
    d2["overlap_weight_norm"]=metrics["w2n"]
    d2["AGE_INTERVAL_SECURE"]=(
        np.isfinite(num(d2,"logAge16")) &
        np.isfinite(num(d2,"logAge84")) &
        (num(d2,"logAge16")>AGE_LO) &
        (num(d2,"logAge84")<=AGE_HI)
    )

    design=pd.concat([d1,d2],ignore_index=True,sort=False)
    design.to_csv(out/"05_NUMERICALLY_VALIDATED_OVERLAP_DESIGN.csv",index=False)

    diag={
        "same_frozen_model":True,
        "same_ridge_lambda":RIDGE,
        "same_covariates":names,
        "solver_gate":solver_gate,
        "design_gate_LBFGSB":design_gate_A,
        "design_gate_NEWTON":design_gate_B,
        "canonical_solver":"DAMPED_NEWTON",
        "canonical_max_abs_weighted_SMD":metrics["max_abs_smd"],
        "canonical_ESS_Y1":metrics["ess1"],
        "canonical_ESS_Y2":metrics["ess2"],
        "canonical_propensity_min":float(metrics["p"].min()),
        "canonical_propensity_max":float(metrics["p"].max()),
        "NUMERICAL_ADJUDICATION_PASS":accepted,
    }
    (out/"06_ADJUDICATION.json").write_text(json.dumps(diag,indent=2),encoding="utf-8")

    hd=sha256(out/"05_NUMERICALLY_VALIDATED_OVERLAP_DESIGN.csv")
    hc=sha256(out/"03_CANONICAL_COEFFICIENTS.csv")

    contract={
        "stage":"STAGE6A1R3_NUMERICAL_SOLVER_ADJUDICATION",
        "version":VERSION,
        "implementation_only":True,
        "alignment_computed":False,
        "science_model_changed":False,
        "ridge_changed":False,
        "covariates_changed":False,
        "acceptance_gates_changed":False,
        "source_failed_design_sha256":EXPECTED_FAILED_DESIGN_SHA,
        "source_failed_coefficient_sha256":EXPECTED_FAILED_COEF_SHA,
        "solver_agreement":agreement,
        "adjudication":diag,
        "DESIGN_AUTHORIZED_FOR_BLIND_Y2_MORPHOLOGY":accepted,
        "validated_design_sha256":hd,
        "canonical_coefficient_sha256":hc,
        "next_if_pass":
            "Proceed to blind Y2 member acquisition/calibration. Alignment remains closed.",
        "next_if_fail":
            "Close inferential 0.5-2 Gyr extension. No further optimizer/model tuning."
    }
    (out/"STAGE6A1R3_FREEZE.json").write_text(json.dumps(contract,indent=2),encoding="utf-8")

    report=[
        f"YHMC STAGE-6A1R3 NUMERICAL SOLVER ADJUDICATION v{VERSION}",
        "="*108,
        "IMPLEMENTATION_ONLY=True",
        "SCIENCE_MODEL_CHANGED=False",
        "NO_MORPHOLOGY=True",
        "NO_PA=True",
        "NO_ALIGNMENT=True",
        "",
        "SOLVER DIAGNOSTICS:",
        solver_df.to_string(index=False),
        "",
        "SOLVER AGREEMENT:",
        pd.DataFrame([agreement]).to_string(index=False),
        "",
        "CANONICAL WEIGHTED BALANCE:",
        metrics["balance"].to_string(index=False),
        "",
        f"CANONICAL_MAX_ABS_WEIGHTED_SMD={metrics['max_abs_smd']:.9f}",
        f"CANONICAL_ESS_Y1={metrics['ess1']:.3f}",
        f"CANONICAL_ESS_Y2={metrics['ess2']:.3f}",
        f"SOLVER_GATE={solver_gate}",
        f"DESIGN_GATE_LBFGSB={design_gate_A}",
        f"DESIGN_GATE_NEWTON={design_gate_B}",
        f"NUMERICAL_ADJUDICATION_PASS={accepted}",
        f"VALIDATED_DESIGN_SHA256={hd}",
        "",
        "NEXT:",
        "  PASS -> blind Y2 member/morphology calibration.",
        "  FAIL -> close inferential 0.5-2 Gyr extension; no further tuning.",
    ]
    (out/"STAGE6A1R3_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")

    print((out/"STAGE6A1R3_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

YHMC Stage-6A1R3 Numerical Solver Adjudication v2.1.3
========================================================

Stage-6A1R2 satisfied its balance and ESS goals but failed only because
BFGS returned a precision-loss status.

This package does NOT change the weighting model.

It resolves the exact same convex penalized-logistic objective using:
- L-BFGS-B
- damped Newton / IRLS

The design is authorized only if both independent numerical routes converge,
agree to strict tolerances, and reproduce the unchanged weighted-balance
and ESS gates.

No morphology, PA, or alignment is accessed.

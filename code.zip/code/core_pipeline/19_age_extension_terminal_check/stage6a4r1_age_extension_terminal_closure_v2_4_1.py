#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-6A4R1 Age-Extension Terminal Closure v2.4.1

NO NEW INFERENCE.

This stage closes the confirmatory/inferential Y1 (100--500 Myr) versus
Y2 (0.5--2 Gyr) age-alignment contrast because the pre-frozen
post-morphology overlap audit failed.

The closure does NOT inspect or compute any Galactic-plane alignment outcome.

Authoritative failure:
  max weighted |SMD| = 0.610175 > 0.10
  ESS_Y2 = 28.148 < 30

Therefore:
  - no propensity refit;
  - no weight trimming;
  - no gate relaxation;
  - no Stage-6A5 weighted age-contrast unblind.

The 0.5--2 Gyr morphology work remains useful as a feasibility/selection
diagnostic but is not authorized as evidence for an age trend.
"""

from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
import pandas as pd

VERSION="2.4.1"
EXPECTED_RESTRICTED_SHA="639820780862ac5868abb19b800faf090d599e0aa99761d473b20669a3985c99"
EXPECTED_BALANCE_SHA="54505833bc1aa504ad3f3e9ae4acd60aed9124fd2c8772dc32f0ef7fe26240a7"
EXPECTED_Y2_PA_SAMPLE_SHA="8b7d394a203e308cca5aed6194eac2eb473742287e81d1f6ecfa407654fd9cb5"

def sha256(p):
    h=hashlib.sha256()
    with Path(p).open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage6a4",required=True)
    ap.add_argument("--stage6a3",required=True)
    ap.add_argument("--out",default="STAGE6A4R1_OUTPUT")
    args=ap.parse_args()

    s4=Path(args.stage6a4).resolve()
    s3=Path(args.stage6a3).resolve()
    out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=True)

    restricted=s4/"01_POST_MORPHOLOGY_OVERLAP_DESIGN_FROZEN.csv"
    balance=s4/"02_POST_MORPHOLOGY_WEIGHTED_BALANCE.csv"
    support=s4/"03_POST_MORPHOLOGY_SUPPORT_SUMMARY.csv"
    freeze=s4/"STAGE6A4_FREEZE.json"
    y2pa=s3/"02_Y2_PA_SAMPLE_FROZEN.csv"

    for p in [restricted,balance,support,freeze,y2pa]:
        if not p.exists(): raise FileNotFoundError(p)

    if sha256(restricted)!=EXPECTED_RESTRICTED_SHA:
        raise RuntimeError("Restricted design hash mismatch.")
    if sha256(balance)!=EXPECTED_BALANCE_SHA:
        raise RuntimeError("Balance hash mismatch.")
    if sha256(y2pa)!=EXPECTED_Y2_PA_SAMPLE_SHA:
        raise RuntimeError("Y2 PA-sample hash mismatch.")

    fr=json.loads(freeze.read_text(encoding="utf-8"))
    if bool(fr.get("POST_MORPHOLOGY_DESIGN_PASS",True)):
        raise RuntimeError("Closure expected Stage-6A4 FAIL but freeze says PASS.")

    obs=fr["observed"]
    maxs=float(obs["max_abs_weighted_SMD"])
    ess1=float(obs["ESS_Y1"])
    ess2=float(obs["ESS_Y2"])

    bdf=pd.read_csv(balance)
    sdf=pd.read_csv(support)

    # No PA columns are read from y2pa; only count/hash provenance.
    y2_n=sum(1 for _ in open(y2pa,encoding="utf-8"))-1

    closure={
        "stage":"STAGE6A4R1_AGE_EXTENSION_TERMINAL_CLOSURE",
        "version":VERSION,
        "new_inference":False,
        "alignment_read_or_computed":False,
        "age_contrast_unblinded":False,
        "authoritative_stage6a4_pass":False,
        "authoritative_failure":{
            "max_abs_weighted_SMD":maxs,
            "required_max_abs_weighted_SMD":0.10,
            "ESS_Y1":ess1,
            "ESS_Y2":ess2,
            "required_ESS_each":30.0,
        },
        "Y2_morphology_admitted_N":y2_n,
        "Y2_PA_sample_sha256":EXPECTED_Y2_PA_SAMPLE_SHA,
        "restricted_design_sha256":EXPECTED_RESTRICTED_SHA,
        "balance_sha256":EXPECTED_BALANCE_SHA,
        "terminal_state":
            "CLOSED_INFERENTIAL_Y1_VS_Y2_AGE_ALIGNMENT_CONTRAST_POST_MORPHOLOGY_OVERLAP_FAILED",
        "forbidden_reopen_actions":[
            "post-hoc propensity refit",
            "post-hoc weight trimming or optimization",
            "balance-gate relaxation",
            "ESS-gate relaxation",
            "alternate matching/caliper tuning based on this failure",
            "claiming age independence or an alignment decay timescale from Y1/Y2"
        ],
        "allowed_manuscript_use":[
            "state that an older 0.5-2 Gyr extension was prospectively explored",
            "report that 142/142 candidates were blindly PA-calibratable and 48 passed the frozen morphology gate",
            "state that morphology admission induced covariate imbalance, preventing a clean weighted age comparison",
            "use this as methodological evidence for claim discipline, not as an age-trend result"
        ],
        "next_primary_strengthening_branch":
            "Stage-6B orbital/tidal mechanism diagnostics"
    }
    (out/"STAGE6A4R1_TERMINAL_CLOSURE.json").write_text(
        json.dumps(closure,indent=2),encoding="utf-8"
    )

    manuscript = """MANUSCRIPT-SAFE AGE-EXTENSION NOTE
==================================

We prospectively examined whether the projected-alignment analysis could be
extended to a 0.5--2 Gyr cohort. All 142 catalogue-quality candidates were
independently calibratable in blind synthetic PA-recovery tests, and 48
passed the pre-specified real-morphology reliability gate. However, restricting
the pre-frozen overlap-weight design to those morphology-resolved objects
substantially degraded covariate balance (maximum weighted |SMD| = 0.610)
and reduced the effective Y2 sample size to 28.1, below the pre-specified
minimum of 30. We therefore did not unblind or interpret a weighted
100--500 Myr versus 0.5--2 Gyr alignment contrast. No propensity-model
refitting, weight trimming, or relaxation of the balance criteria was
performed.

CLAIM CEILING
-------------
Allowed:
  The attempted older-age extension failed the pre-specified post-morphology
  exchangeability/balance audit.

Not allowed:
  alignment is age-independent;
  alignment decays with age;
  older clusters are more/less aligned than Y1;
  a decay timescale has been measured.
"""
    (out/"MANUSCRIPT_SAFE_AGE_EXTENSION_NOTE.txt").write_text(
        manuscript,encoding="utf-8"
    )

    report=[
        f"YHMC STAGE-6A4R1 AGE-EXTENSION TERMINAL CLOSURE v{VERSION}",
        "="*108,
        "NO_NEW_INFERENCE=True",
        "ALIGNMENT_READ_OR_COMPUTED=False",
        "AGE_CONTRAST_UNBLINDED=False",
        f"Y2_MORPHOLOGY_ADMITTED_N={y2_n}",
        f"MAX_ABS_WEIGHTED_SMD={maxs:.6f}",
        f"ESS_Y1={ess1:.3f}",
        f"ESS_Y2={ess2:.3f}",
        "POST_MORPHOLOGY_DESIGN_PASS=False",
        "",
        "TERMINAL_STATE=CLOSED_INFERENTIAL_Y1_VS_Y2_AGE_ALIGNMENT_CONTRAST_POST_MORPHOLOGY_OVERLAP_FAILED",
        "",
        "NEXT_PRIMARY_STRENGTHENING_BRANCH=STAGE6B_ORBITAL_TIDAL_MECHANISM",
    ]
    (out/"STAGE6A4R1_REPORT.txt").write_text("\n".join(report)+"\n",encoding="utf-8")

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")

    print((out/"STAGE6A4R1_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

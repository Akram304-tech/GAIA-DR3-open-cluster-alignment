Terminally closes the inferential Y1-vs-Y2 age-alignment branch after
the pre-frozen post-morphology overlap audit failed.

No alignment result is accessed. No design is repaired post hoc.
The next manuscript-strengthening branch is Stage-6B orbital/tidal mechanism.

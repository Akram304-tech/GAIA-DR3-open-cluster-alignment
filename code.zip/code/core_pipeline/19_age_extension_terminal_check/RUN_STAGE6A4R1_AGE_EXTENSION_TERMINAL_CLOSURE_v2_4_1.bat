@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo YHMC STAGE-6A4R1 AGE-EXTENSION TERMINAL CLOSURE v2.4.1
echo NO NEW INFERENCE / NO ALIGNMENT
echo ============================================================

set "PYEXE=%USERPROFILE%\miniconda3\envs\gc-mp-clock\python.exe"
if not exist "%PYEXE%" set "PYEXE=%USERPROFILE%\miniconda3\python.exe"
if not exist "%PYEXE%" exit /b 1

set "STAGE6A4=%USERPROFILE%\Downloads\YHMC_STAGE6A4_POST_MORPHOLOGY_OVERLAP_AUDIT_v2_4_0\YHMC_STAGE6A4_POST_MORPHOLOGY_OVERLAP_AUDIT_v2_4_0\STAGE6A4_OUTPUT"
set "STAGE6A3=%USERPROFILE%\Downloads\YHMC_STAGE6A3_Y2_REAL_MORPHOLOGY_FREEZE_v2_3_0\YHMC_STAGE6A3_Y2_REAL_MORPHOLOGY_FREEZE_v2_3_0\STAGE6A3_OUTPUT"

"%PYEXE%" stage6a4r1_age_extension_terminal_closure_v2_4_1.py ^
 --stage6a4 "%STAGE6A4%" ^
 --stage6a3 "%STAGE6A3%" ^
 --out "%CD%\STAGE6A4R1_OUTPUT"

set "RC=%ERRORLEVEL%"
echo.
echo RETURN_CODE=%RC%
if "%RC%"=="0" (
 echo REPORT=%CD%\STAGE6A4R1_OUTPUT\STAGE6A4R1_REPORT.txt
 echo CLOSURE=%CD%\STAGE6A4R1_OUTPUT\STAGE6A4R1_TERMINAL_CLOSURE.json
)
exit /b %RC%

YHMC Stage-6B1 Orbit / Mechanism Design Freeze v2.2.0
========================================================

This is a prospective science-design freeze.

It performs NO orbit production and reads NO alignment outcome.

Primary sample:
  exact frozen morphology-resolved young/control objects
  M_J >= 3000 Msun
  finite nominal 6D phase space
  expected 22 young + 23 controls = 45.

Primary potential:
  McMillan17.

Sensitivity:
  Irrgang13III
  MWPotential2014.

Primary orbit metric:
  r_peri.

Primary exposure:
  X_peri = -log(r_peri/kpc).

Future primary association:
  Spearman rho between cos(2 Delta_theta_GP) and X_peri;
  100000 two-sided permutations;
  X_peri shuffled within young/control cohort.

No e_RV threshold is used for nominal inclusion.
Uncertainty is propagated with N_MC=512 where catalogue uncertainty fields
are complete.

The next stage must compute and freeze orbit proxies WITHOUT reading
alignment columns. Only after those files are frozen may Stage-6B3 join
the alignment outcome.

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YHMC Stage-6B1 Orbit / Mechanism Design Freeze v2.2.0

PROSPECTIVE DESIGN ONLY.
NO ORBIT INTEGRATION.
NO ALIGNMENT READ.
NO CORRELATION.

Purpose
-------
Freeze the science design for testing whether the already established
projected Galactic-plane structural alignment is associated with the
clusters' orbital environment.

This stage is executed AFTER Stage-6B0R1 technical orbit micropilot PASS,
but BEFORE any full-sample orbit proxy is computed.

Primary science sample
----------------------
Exact morphology-resolved samples already frozen before this mechanism work:
  young:   Stage-1B PA sample, M_J >= 3000 Msun
  control: Stage-2C PA sample, M_J >= 3000 Msun
Require finite nominal 6D:
  RA_ICRS, DE_ICRS, dist50, pmRA, pmDE, RV

Expected from prior audit:
  young N = 22
  control N = 23
  pooled N = 45

No cut on e_RV is permitted in the primary nominal sample. Large RV
uncertainties are propagated rather than selected away.

Potential hierarchy
-------------------
PRIMARY:
  McMillan17, with its galpy-native physical ro/vo.

SENSITIVITY:
  Irrgang13III
  MWPotential2014

For every potential, Orbit initialization and time conversion use the
potential-specific values returned by galpy.util.conversion.get_physical().
Thus each named potential is treated as a complete Galactic model.

Solar convention
----------------
z_sun = 0.0208 kpc.
Solar peculiar motion relative to the LSR:
  (U,V,W) = (11.1, 12.24, 7.25) km/s.
These are held fixed across the three Galactic-potential models.
Potential parameters themselves are not Monte-Carlo sampled; model
uncertainty is represented by the three-potential sensitivity analysis.

Nominal orbit production
------------------------
Static axisymmetric potentials.
Forward horizon = 1.0 Gyr.
Output grid = 2001 points.
Integrator = dop853_c; pure-Python dop853 fallback is implementation-only.
Primary orbit proxy:
  rperi.
Primary exposure score:
  X_peri = -log(rperi / kpc)
Secondary orbit descriptors:
  rap, eccentricity, zmax.

Uncertainty propagation
-----------------------
N_MC = 512 deterministic realizations per object and potential.
RA/Dec held fixed.
distance:
  split-normal around dist50:
    z ~ N(0,1)
    d = dist50 + z*(dist50-dist16) for z<0
    d = dist50 + z*(dist84-dist50) for z>=0
  non-positive draws are resampled.
pmRA, pmDE:
  independent Gaussians using e_pmRA/e_pmDE.
RV:
  Gaussian using e_RV.
No artificial e_RV threshold.

MC-ready requires finite:
  dist16 < dist50 < dist84, e_pmRA>0, e_pmDE>0, e_RV>0.
Objects not MC-ready remain in nominal primary analysis but are absent from
the uncertainty-propagation sensitivity. MC-readiness is frozen before orbit
outcomes and before alignment/orbit association.

Primary association (future Stage-6B3 only)
-------------------------------------------
Alignment response:
  Y = cos(2 Delta_theta_GP)

Primary predictor:
  X_peri from the McMillan17 nominal orbit.

Statistic:
  Spearman rho(Y, X_peri), pooled high-mass sample.

Inference:
  100,000 TWO-SIDED permutations, shuffling X_peri WITHIN cohort
  (young/control) to preserve cohort structure.

Physical directional expectation:
  stronger exposure (smaller rperi; larger X_peri) -> larger Y.
But p-value remains two-sided.

Secondary:
  - within-young and within-control Spearman rho;
  - pooled cohort-adjusted regression Y ~ X_peri + cohort, HC3 SE;
  - rap, eccentricity, zmax;
  - Irrgang13III and MWPotential2014 sensitivity;
  - MC propagation of rho using one proxy draw/object/replicate.

Interpretation ceiling:
  An association may be called "consistent with orbital/tidal environmental
  coupling". It does NOT establish tidal causation.

Tidal tensor
------------
A tidal-tensor exposure metric is reserved as a SECONDARY mechanism layer.
It must undergo an independent technical validation before full production.
It is not a replacement primary endpoint and must not be selected based on
the sign/significance of the rperi result.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

VERSION="2.2.0"

EXPECTED_FULL_SNAPSHOT_SHA="2164adf7ed3e516f035f60c6e6bfc06affbc4d809157c8eb06306d3e78d2cb47"
EXPECTED_YOUNG_SHA="cc1d3ae4ce1cf52387f535da92fbd0dc5d984a3bb2dc750bf6672682e85f65dd"
EXPECTED_CONTROL_SHA="124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd"

MASS_PRIMARY=3000.0
MASS_EXTENDED=1000.0
N_MC=512
BASE_SEED=20260912
HORIZON_GYR=1.0
N_TIME=2001
PRIMARY_POTENTIAL="McMillan17"
SENSITIVITY_POTENTIALS=["Irrgang13III","MWPotential2014"]
SOLAR_Z_KPC=0.0208
SOLAR_MOTION=[11.1,12.24,7.25]
N_PERM=100000

def sha256(p):
    h=hashlib.sha256()
    with Path(p).open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def num(df,c):
    return pd.to_numeric(df[c],errors="coerce")

def bind_sample(f,cat,label):
    d=pd.read_csv(f)
    d["ID"]=pd.to_numeric(d["ID"],errors="raise").astype(int)

    needed=[
        "ID","Name","MassJ","RA_ICRS","DE_ICRS",
        "dist16","dist50","dist84",
        "pmRA","e_pmRA","pmDE","e_pmDE",
        "RV","e_RV","n_RV",
        "logAge50","GLON","GLAT"
    ]
    miss=[c for c in needed if c not in cat.columns]
    if miss:
        raise RuntimeError(f"Full snapshot missing orbit fields: {miss}")

    x=d[["ID","Name"]].merge(
        cat[needed],
        on="ID",how="left",
        suffixes=("_frozen","_catalog"),
        validate="one_to_one"
    )
    x["sample"]=label
    return x

def finite_nominal_6d(df):
    cols=["RA_ICRS","DE_ICRS","dist50","pmRA","pmDE","RV"]
    a=np.ones(len(df),dtype=bool)
    for c in cols:
        a &= np.isfinite(num(df,c).to_numpy(float))
    a &= num(df,"dist50").to_numpy(float)>0
    return a

def mc_ready(df):
    d16=num(df,"dist16").to_numpy(float)
    d50=num(df,"dist50").to_numpy(float)
    d84=num(df,"dist84").to_numpy(float)
    epmra=num(df,"e_pmRA").to_numpy(float)
    epmde=num(df,"e_pmDE").to_numpy(float)
    erv=num(df,"e_RV").to_numpy(float)

    return (
        np.isfinite(d16)&np.isfinite(d50)&np.isfinite(d84)&
        (d16>0)&(d16<d50)&(d50<d84)&
        np.isfinite(epmra)&(epmra>0)&
        np.isfinite(epmde)&(epmde>0)&
        np.isfinite(erv)&(erv>0)
    )

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--stage6",required=True)
    ap.add_argument("--stage1b",required=True)
    ap.add_argument("--stage2c",required=True)
    ap.add_argument("--stage6b0r1",required=True)
    ap.add_argument("--out",default="STAGE6B1_OUTPUT")
    args=ap.parse_args()

    s6=Path(args.stage6).resolve()
    s1=Path(args.stage1b).resolve()
    s2=Path(args.stage2c).resolve()
    sb0=Path(args.stage6b0r1).resolve()
    out=Path(args.out).resolve()
    out.mkdir(parents=True,exist_ok=True)

    snap=s6/"00_HUNT_REFFERT_FULLCOLUMN_SNAPSHOT.csv"
    yf=s1/"02_PRIMARY_PA_SAMPLE_FROZEN.csv"
    cf=s2/"02_CONTROL_PA_SAMPLE_FROZEN.csv"
    mic=sb0/"STAGE6B0R1_CONTRACT.json"

    for p in [snap,yf,cf,mic]:
        if not p.exists(): raise FileNotFoundError(p)

    if sha256(snap)!=EXPECTED_FULL_SNAPSHOT_SHA:
        raise RuntimeError("Stage-6 full snapshot hash mismatch.")
    if sha256(yf)!=EXPECTED_YOUNG_SHA:
        raise RuntimeError("Stage-1B young sample hash mismatch.")
    if sha256(cf)!=EXPECTED_CONTROL_SHA:
        raise RuntimeError("Stage-2C control sample hash mismatch.")

    micro=json.loads(mic.read_text(encoding="utf-8"))
    if not bool(micro.get("ALL_INTEGRATIONS_PASS",False)):
        raise RuntimeError("Stage-6B0R1 technical micropilot is not PASS.")

    cat=pd.read_csv(snap,low_memory=False)
    cat["ID"]=pd.to_numeric(cat["ID"],errors="raise").astype(int)
    if cat["ID"].duplicated().any():
        raise RuntimeError("Catalogue ID is not unique.")

    young=bind_sample(yf,cat,"young")
    ctrl=bind_sample(cf,cat,"control")
    allm=pd.concat([young,ctrl],ignore_index=True)

    allm["MassJ"]=num(allm,"MassJ")
    allm["FINITE_NOMINAL_6D"]=finite_nominal_6d(allm)
    allm["MC_READY"]=mc_ready(allm)

    primary=allm[
        (allm["MassJ"]>=MASS_PRIMARY) &
        allm["FINITE_NOMINAL_6D"]
    ].copy().sort_values(["sample","ID"]).reset_index(drop=True)

    extended=allm[
        (allm["MassJ"]>=MASS_EXTENDED) &
        allm["FINITE_NOMINAL_6D"]
    ].copy().sort_values(["sample","ID"]).reset_index(drop=True)

    py=primary[primary["sample"]=="young"]
    pc=primary[primary["sample"]=="control"]

    # Historical expectation is an identity/integrity gate.
    if len(py)!=22 or len(pc)!=23 or len(primary)!=45:
        raise RuntimeError(
            f"Primary 6D count mismatch: young={len(py)}, control={len(pc)}, pooled={len(primary)}; "
            "expected 22/23/45."
        )

    primary.to_csv(out/"01_PRIMARY_HIGH_MASS_6D_SAMPLE_FROZEN.csv",index=False)
    extended.to_csv(out/"02_EXTENDED_6D_SENSITIVITY_SAMPLE_FROZEN.csv",index=False)

    readiness=[]
    for label,d in [
        ("young_primary",py),
        ("control_primary",pc),
        ("pooled_primary",primary),
        ("young_extended",extended[extended["sample"]=="young"]),
        ("control_extended",extended[extended["sample"]=="control"]),
        ("pooled_extended",extended),
    ]:
        readiness.append({
            "sample":label,
            "N":len(d),
            "N_MC_READY":int(d["MC_READY"].sum()),
            "fraction_MC_READY":float(d["MC_READY"].mean()) if len(d) else np.nan,
            "N_eRV_le2":int((num(d,"e_RV")<=2).sum()),
            "N_eRV_le5":int((num(d,"e_RV")<=5).sum()),
            "median_eRV":float(num(d,"e_RV").median()) if len(d) else np.nan,
            "max_eRV":float(num(d,"e_RV").max()) if len(d) else np.nan,
            "median_n_RV":float(num(d,"n_RV").median()) if len(d) else np.nan,
        })
    rdf=pd.DataFrame(readiness)
    rdf.to_csv(out/"03_PHASESPACE_UNCERTAINTY_READINESS.csv",index=False)

    hprimary=sha256(out/"01_PRIMARY_HIGH_MASS_6D_SAMPLE_FROZEN.csv")
    hext=sha256(out/"02_EXTENDED_6D_SENSITIVITY_SAMPLE_FROZEN.csv")
    hready=sha256(out/"03_PHASESPACE_UNCERTAINTY_READINESS.csv")
    hmic=sha256(mic)

    design={
        "stage":"STAGE6B1_ORBIT_MECHANISM_DESIGN_FREEZE",
        "version":VERSION,
        "prospective":True,
        "orbit_integration_performed":False,
        "alignment_read":False,
        "correlation_computed":False,
        "inputs":{
            "full_snapshot_sha256":EXPECTED_FULL_SNAPSHOT_SHA,
            "young_PA_sample_sha256":EXPECTED_YOUNG_SHA,
            "control_PA_sample_sha256":EXPECTED_CONTROL_SHA,
            "stage6b0r1_contract_sha256":hmic,
        },
        "primary_sample":{
            "mass_threshold_Msun":MASS_PRIMARY,
            "finite_nominal_6D_required":True,
            "young_N":int(len(py)),
            "control_N":int(len(pc)),
            "pooled_N":int(len(primary)),
            "sha256":hprimary,
            "no_eRV_cut":True,
        },
        "extended_sensitivity":{
            "mass_threshold_Msun":MASS_EXTENDED,
            "finite_nominal_6D_required":True,
            "pooled_N":int(len(extended)),
            "sha256":hext,
            "role":"sensitivity only; cannot replace failed primary result",
        },
        "potential_hierarchy":{
            "primary":PRIMARY_POTENTIAL,
            "sensitivity":SENSITIVITY_POTENTIALS,
            "physical_scale_rule":"use galpy conversion.get_physical(potential) ro/vo for Orbit and time conversion",
        },
        "solar":{
            "z_sun_kpc":SOLAR_Z_KPC,
            "peculiar_motion_UVW_kms":SOLAR_MOTION,
            "fixed_across_potentials":True,
        },
        "nominal_orbit":{
            "horizon_Gyr":HORIZON_GYR,
            "N_time":N_TIME,
            "integrator_primary":"dop853_c",
            "integrator_fallback":"dop853",
            "primary_metric":"rperi_kpc",
            "primary_exposure":"X_peri=-log(rperi_kpc)",
            "secondary_metrics":["rap_kpc","eccentricity","zmax_kpc"],
        },
        "uncertainty":{
            "N_MC":N_MC,
            "base_seed":BASE_SEED,
            "RA_DE":"fixed",
            "distance":"split-normal from dist16/dist50/dist84 using signed standard-normal draw",
            "pmRA":"Gaussian(mean=pmRA, sigma=e_pmRA)",
            "pmDE":"Gaussian(mean=pmDE, sigma=e_pmDE)",
            "RV":"Gaussian(mean=RV, sigma=e_RV)",
            "covariances":"not available at cluster-catalogue level; sampled independently",
            "potential_parameters":"not sampled; represented by discrete potential sensitivity",
            "MC_ready_rule":"ordered positive distance quantiles and positive finite e_pmRA/e_pmDE/e_RV",
            "MC_not_ready_rule":"retain in nominal primary; omit only from MC uncertainty sensitivity",
        },
        "future_primary_association":{
            "response":"Y=cos(2*Delta_theta_GP)",
            "predictor":"X_peri from McMillan17 nominal orbit",
            "statistic":"Spearman rho",
            "permutations":N_PERM,
            "permutation":"two-sided; shuffle X_peri within young/control cohort",
            "directional_expectation":"positive rho (smaller rperi -> stronger alignment), but p-value is two-sided",
        },
        "future_secondary_association":[
            "within-young Spearman",
            "within-control Spearman",
            "pooled HC3 regression Y ~ X_peri + cohort",
            "rap/eccentricity/zmax",
            "Irrgang13III sensitivity",
            "MWPotential2014 sensitivity",
            "MC distribution of Spearman rho"
        ],
        "tidal_tensor":{
            "status":"predeclared secondary mechanism layer",
            "requires_independent_technical_validation":True,
            "cannot_replace_primary_rperi_endpoint":True,
            "execution_must_not_depend_on_primary_significance":True,
        },
        "interpretation_ceiling":
            "Association can support consistency with orbital/tidal environmental coupling; it cannot establish tidal causation.",
        "readiness_sha256":hready,
        "next":
            "Stage-6B2 full orbit-proxy production with alignment columns inaccessible; freeze/hash orbit outputs before Stage-6B3 association unblind."
    }
    (out/"STAGE6B1_DESIGN_FREEZE.json").write_text(
        json.dumps(design,indent=2),encoding="utf-8"
    )

    methods = r"""STAGE-6B1 MANUSCRIPT-METHODS FREEZE
===================================

The mechanism test is restricted primarily to morphology-resolved clusters
with M_J >= 3000 Msun and finite six-dimensional phase-space information.
No cut is imposed on radial-velocity uncertainty; instead, measurement
uncertainties are propagated in a separate Monte Carlo layer.

McMillan17 is the primary Galactic potential. Irrgang13III and
MWPotential2014 are pre-specified model sensitivities. Each potential is
used with its native galpy physical scales, and the same Solar peculiar
motion (U,V,W)=(11.1,12.24,7.25) km/s and z_sun=20.8 pc is applied.

Nominal orbits are integrated for 1 Gyr. The primary environmental proxy is
pericentric radius, expressed for association testing as
X_peri=-log(r_peri/kpc), so that larger X_peri denotes stronger inner-Galaxy
orbital exposure. Apocentric radius, eccentricity, and z_max are secondary.

Phase-space uncertainty is propagated with 512 deterministic Monte Carlo
realizations per cluster and potential. Distance is sampled using the
catalogue 16th/50th/84th percentiles, proper motions from their standard
errors, and radial velocity from e_RV. Potential-model uncertainty is
represented by the pre-specified three-potential comparison rather than by
continuous sampling of potential parameters.

The primary association test, performed only after orbit outputs are frozen,
is a two-sided cohort-stratified permutation Spearman test between
cos(2 Delta_theta_GP) and -log(r_peri), using 100,000 permutations.
A positive correlation is physically expected if stronger inner-Galaxy
orbital exposure is associated with stronger plane alignment, but the
primary p-value remains two-sided.
"""
    (out/"MANUSCRIPT_METHODS_FREEZE.txt").write_text(methods,encoding="utf-8")

    report=[
        f"YHMC STAGE-6B1 ORBIT / MECHANISM DESIGN FREEZE v{VERSION}",
        "="*108,
        "PROSPECTIVE=True",
        "ORBIT_INTEGRATION_PERFORMED=False",
        "ALIGNMENT_READ=False",
        "CORRELATION_COMPUTED=False",
        "",
        f"PRIMARY_YOUNG_N={len(py)}",
        f"PRIMARY_CONTROL_N={len(pc)}",
        f"PRIMARY_POOLED_N={len(primary)}",
        f"PRIMARY_MC_READY_N={int(primary['MC_READY'].sum())}",
        f"EXTENDED_6D_N={len(extended)}",
        "",
        "PHASE-SPACE UNCERTAINTY READINESS:",
        rdf.to_string(index=False),
        "",
        f"PRIMARY_POTENTIAL={PRIMARY_POTENTIAL}",
        f"SENSITIVITY_POTENTIALS={','.join(SENSITIVITY_POTENTIALS)}",
        f"ORBIT_HORIZON_GYR={HORIZON_GYR}",
        f"N_MC={N_MC}",
        f"N_PERM_FUTURE={N_PERM}",
        "PRIMARY_ORBIT_METRIC=rperi_kpc",
        "PRIMARY_EXPOSURE=X_peri=-log(rperi_kpc)",
        "PRIMARY_ASSOCIATION=TWO_SIDED_COHORT_STRATIFIED_PERMUTATION_SPEARMAN",
        "",
        f"PRIMARY_SAMPLE_SHA256={hprimary}",
        f"EXTENDED_SAMPLE_SHA256={hext}",
        f"READINESS_SHA256={hready}",
        "",
        "NEXT:",
        "  Stage-6B2 orbit-proxy production only.",
        "  Alignment/orbit association remains CLOSED until orbit outputs are frozen and hashed.",
    ]
    (out/"STAGE6B1_REPORT.txt").write_text(
        "\n".join(report)+"\n",encoding="utf-8"
    )

    manifest=[]
    for p in sorted(out.rglob("*")):
        if p.is_file():
            manifest.append(f"{sha256(p)}  {p.relative_to(out).as_posix()}")
    (out/"SHA256SUMS.txt").write_text("\n".join(manifest)+"\n",encoding="utf-8")

    print((out/"STAGE6B1_REPORT.txt").read_text(encoding="utf-8"))

if __name__=="__main__":
    main()

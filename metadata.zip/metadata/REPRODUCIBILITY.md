# Reproducibility notes

## Main sequence

1. Catalogue preflight and quality selection.
2. Young-sample PA calibration, morphology, and alignment.
3. Older-control matching, calibration, morphology, and matched contrast.
4. Coordinate and membership-threshold systematics.
5. Inner-region calibration, morphology, and radial comparison.
6. Prospective age-extension design and terminal overlap check.
7. Orbital-environment analysis.
8. Projection/power, selection/environment, local-gradient, block-dependence,
   ceiling/latitude/geometry, and exact-block sensitivity analyses.

## Identity hashes

- Young PA sample:
  `cc1d3ae4ce1cf52387f535da92fbd0dc5d984a3bb2dc750bf6672682e85f65dd`
- Control PA sample:
  `124bd5b4985e661a063806e318c4be2a44a261cfa2d55d79f659362632d008fd`
- Outcome-blind simulation match table:
  `40fff1276a3899a37a5e08090fe627de3e05c314d225b8f6d501bd42503bd919`

These are internal chain-of-custody hashes, not a claim of public preregistration.

## Age extension

The 0.5--2 Gyr extension terminated at the post-morphology overlap check. Its code is
retained because that termination is part of the reproducibility record.

## Member-level simulation limitation

The final inference does not claim a completed member-level synthetic-PA recovery from
the large Hunt et al. ancillary member file. Cluster-level recovery/environment and
local directional-gradient sensitivity analyses are preserved instead.

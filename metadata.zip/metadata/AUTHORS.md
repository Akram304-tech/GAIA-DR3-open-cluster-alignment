# Authors

Creator order is transcribed from the supplied author image.

1. **Akram Ruziev** — marked with the corresponding-author symbol (`*`) in the supplied image  
   National University of Uzbekistan, 100174, Tashkent, University str. 4, Uzbekistan

2. **Jakhongir Ganiev**  
   National University of Uzbekistan, 100174, Tashkent, University str. 4, Uzbekistan

3. **Sobir Turaev**  
   Ulugh Beg Astronomical Institute, Uzbekistan Academy of Sciences, Astronomy str. 33, Tashkent, Uzbekistan

No e-mail address or ORCID is visible in the supplied image; none is invented here.

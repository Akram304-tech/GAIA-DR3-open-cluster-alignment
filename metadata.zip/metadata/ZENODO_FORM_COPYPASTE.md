# Zenodo form values

**Resource type:** Dataset

**Title:** Reproducibility package for Galactic-plane alignment analysis of open-cluster shapes in Gaia DR3

**Publication date:** 2026-10-28

**Creators, in order:**
1. Ruziev, Akram — National University of Uzbekistan, 100174, Tashkent, University str. 4, Uzbekistan
2. Ganiev, Jakhongir — National University of Uzbekistan, 100174, Tashkent, University str. 4, Uzbekistan
3. Turaev, Sobir — Ulugh Beg Astronomical Institute, Uzbekistan Academy of Sciences, Astronomy str. 33, Tashkent, Uzbekistan

Akram Ruziev carries the corresponding-author marker in the supplied image. No e-mail
or ORCID was supplied, so leave those fields blank unless the authors provide them.

**Description:** Reproducibility archive containing analysis code, machine-readable
derived tables, seven vector figures, MATLAB figure-generation code, environment
specifications, and provenance records supporting the Gaia DR3 open-cluster
Galactic-plane alignment analysis. The article manuscript and article PDF are intentionally excluded.

**Version:** 1.0.0

**Language:** English

**Keywords:** open clusters; Gaia DR3; cluster morphology; Galactic plane; position angle;
matched controls; orbital dynamics; reproducibility

**Access:** Open

**License:** mixed — code MIT; derived tables/figures CC BY 4.0. See `metadata/LICENSES.md`.

**DOI:** use Zenodo **Reserve DOI**. Do not invent one.

**Related identifier:** add the article DOI only after it exists.

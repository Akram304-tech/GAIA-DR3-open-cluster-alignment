# Licensing

- Analysis and figure-generation code: MIT.
- Deposited derived tables and vector figures: CC BY 4.0.
- Third-party catalogues/services are not redistributed and retain their own terms.

The archive therefore uses mixed licensing; see `licenses/`.

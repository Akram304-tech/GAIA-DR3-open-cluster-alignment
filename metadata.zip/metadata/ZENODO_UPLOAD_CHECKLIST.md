# Zenodo upload checklist

1. Create a new Zenodo upload.
2. Select **Reserve DOI**.
3. Insert the reserved DOI locally with `python tools/set_zenodo_doi.py <DOI>`.
4. Rebuild the checksum manifest after the DOI edit.
5. Upload the single ZIP `open_cluster_alignment_gaia_dr3_reproducibility_v1_0_0.zip`.
6. Copy the fields from `metadata/ZENODO_FORM_COPYPASTE.md`.
7. Verify creator order: Akram Ruziev; Jakhongir Ganiev; Sobir Turaev.
8. Verify no manuscript/article PDF is present.
9. Keep mixed licensing stated in `metadata/LICENSES.md`.
10. Add the article DOI as a related identifier only after it actually exists.
11. Publish the Zenodo record.
12. Cite the version DOI for exact reproducibility; use the concept DOI only when
    intentionally citing the evolving record across versions.

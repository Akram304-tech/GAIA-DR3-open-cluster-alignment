# Changelog

## 1.0.0 — 2026-10-28

- Initial Zenodo-ready reproducibility archive.
- Creator metadata set from the supplied author image.
- Includes core analysis and final sensitivity-analysis code.
- Includes final machine-readable tables and seven vector-PDF figures.
- Includes MATLAB figure-generation code.
- Excludes manuscript/article files and third-party raw catalogues.

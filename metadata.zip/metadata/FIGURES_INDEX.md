# Figure index

| Article figure | Vector PDF | MATLAB source |
|---|---|---|
| 1 | `figures/vector_pdf/figure_01_workflow.pdf` | `code/figure_generation/matlab/fig01_workflow.m` |
| 2 | `figures/vector_pdf/figure_02_outer_alignment.pdf` | `code/figure_generation/matlab/fig02_outer_alignment.m` |
| 3 | `figures/vector_pdf/figure_03_latitude_sensitivity.pdf` | `code/figure_generation/matlab/fig03_latitude_sensitivity.m` |
| 4 | `figures/vector_pdf/figure_04_matched_age_contrast.pdf` | `code/figure_generation/matlab/fig04_matched_age_contrast.m` |
| 5 | `figures/vector_pdf/figure_05_coordinate_specificity.pdf` | `code/figure_generation/matlab/fig05_coordinate_specificity.m` |
| 6 | `figures/vector_pdf/figure_06_membership_robustness.pdf` | `code/figure_generation/matlab/fig06_membership_robustness.m` |
| 7 | `figures/vector_pdf/figure_07_inner_outer_alignment.pdf` | `code/figure_generation/matlab/fig07_inner_outer_alignment.m` |

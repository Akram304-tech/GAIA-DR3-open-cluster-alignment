# Intentionally excluded content

The deposit does not contain the article manuscript, article PDF, LaTeX source,
bibliography, cover letter, reviewer correspondence, submission screenshots, or
third-party raw catalogues.

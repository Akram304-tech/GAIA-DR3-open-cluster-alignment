# Table index

| File | Content |
|---|---|
| `matched_age_contrast.csv` | Matched young-minus-control contrast. |
| `membership_robustness.csv` | Membership-threshold robustness. |
| `orbit_mc_uncertainty_summary.csv` | Orbital Monte Carlo uncertainty. |
| `orbit_mechanism_summary.csv` | Orbital-environment association. |
| `outer_alignment_summary.csv` | Outer alignment by mass threshold. |
| `radial_summary.csv` | Inner-versus-outer comparison. |
| `sample_flow_summary.csv` | Sample-count flow across analysis branches. |
| `stage6_age_extension_audit.csv` | Age-extension overlap audit. |
| `stage7a_reviewer_critical_summary.csv` | Phase/projection/power sensitivity summary. |
| `stage7bc_selection_local_gradient_summary.csv` | Selection/environment and local-gradient summary. |
| `stage7d_absb_terciles.csv` | Latitude terciles. |
| `stage7d_block_dependence_summary.csv` | Spatial-kinematic block dependence. |
| `stage7d_control_median_audit.csv` | Control median-angle consistency. |
| `stage7d_coordinate_control_CI_null.csv` | Coordinate-control intervals/null tests. |
| `stage7d_epsilon_matched_age_contrast.csv` | Ellipticity-matched contrast. |
| `stage7d_morphology_dose_response.csv` | Morphology/dose-response associations. |
| `stage7d_power_summary.csv` | Power/precision diagnostics. |
| `stage7e_age_absb_interaction.csv` | Age-by-latitude interaction. |
| `stage7e_ceiling_resistant_matched_effects.csv` | Ceiling-resistant matched effects. |
| `stage7e_common_absb_terciles.csv` | Common-boundary latitude terciles. |
| `stage7e_coordinate_geometry_expectation.csv` | Geometry-aware coordinate expectation. |
| `stage7e_coordinate_reference_binding_audit.csv` | Coordinate reference binding audit. |
| `stage7e_joint_block_sensitivity.csv` | Joint spatial-kinematic block sensitivity. |
| `stage7e_matched_D_by_common_absb_tercile.csv` | Matched D by common latitude tercile. |
| `stage7e_primary_A_ceiling.csv` | Feasible positive ceiling for primary A contrast. |
| `stage7f_cluster_robust_latitude.csv` | Cluster-robust latitude sensitivity. |
| `stage7f_logodds_and_proportion_difference.csv` | 30-degree concentration sensitivity. |
| `stage7f_primary_D_exact_BCa_LOBO.csv` | Exact sign-flip, BCa, and leave-one-block-out D. |

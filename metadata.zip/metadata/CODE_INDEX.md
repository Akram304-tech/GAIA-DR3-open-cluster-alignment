# Code index

## Core pipeline

- `00_catalogue_preflight`
- `01_young_pa_calibration`
- `02_young_morphology`
- `03_young_alignment`
- `04_control_matching`
- `05_control_pa_calibration`
- `06_control_morphology`
- `07_matched_age_contrast`
- `08_coordinate_systematics`
- `09_membership_thresholds`
- `10_inner_region_pa_calibration`
- `11_inner_region_morphology`
- `12_inner_region_contrast`
- `13_age_extension_matching`
- `14_age_extension_overlap_weighting`
- `15_age_extension_solver_check`
- `16_age_extension_pa_calibration`
- `17_age_extension_morphology`
- `18_age_extension_post_selection_overlap`
- `19_age_extension_terminal_check`
- `20_orbit_potential_binding`
- `21_orbit_analysis_design`
- `22_orbit_mc_method_check`
- `23_orbit_proxy_production`
- `24_orbit_alignment_binding`
- `25_orbit_association`
- `26_orbit_terminal_check`

## Sensitivity analyses

- `01_estimator_robustness`
- `02_estimator_gate_diagnostic`
- `03_phase_projection_power`
- `04_selection_environment`
- `05_local_density_dust_gradients`
- `06_dependence_morphology_power`
- `07_ceiling_latitude_geometry_blocks`
- `08_exact_block_logodds_latitude`

## Figure generation

- `code/figure_generation/matlab/`

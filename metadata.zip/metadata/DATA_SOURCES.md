# External data and services

## Hunt & Reffert (2024) open-cluster catalogue

- A&A 686, A42
- DOI: `10.1051/0004-6361/202348662`
- VizieR: `J/A+A/686/A42`
- cluster table: `J/A+A/686/A42/clusters`
- member table: `J/A+A/686/A42/members`

## Gaia DR3

Gaia DR3 underlies the catalogue astrometry and photometry. The local source-density
analysis also uses VizieR table `I/355/gaiadr3`.

## Hunt et al. (2026) selection-function simulations

- A&A 706, A341
- DOI: `10.1051/0004-6361/202557781`
- CDS/VizieR: `J/A+A/706/A341`

The final deposit preserves the cluster-level selection/environment audit. The large
third-party ancillary member file is not redistributed.

## Dust

Directional dust sensitivity uses the NASA/IPAC IRSA Dust Extinction Service and the
Schlafly-Finkbeiner recalibrated `E(B-V)` value (`ext SandF ref`) as a two-dimensional
total line-of-sight dust-column proxy.

## Galactic orbits

Orbit calculations use `galpy==1.12.0`; potential definitions and unit conventions are
recorded in the archived scripts.

## Redistribution

Large upstream catalogues are not copied into this archive. Their public identifiers
remain the canonical source.
